"""Find Blackmagic devices on the local networks by knocking on their ports.

A plain TCP connect sweep of each network this computer sits on (its /24s):
no multicast, no admin rights, no extra packages, and it finds decks whose
Bonjour names were never set. HyperDecks answer on 9993 and Videohubs on 9990.
A few hundred half-second connects in parallel take a couple of seconds.
"""

from __future__ import annotations

import ipaddress
import re
import socket
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor

KNOCK_TIMEOUT = 0.6


def local_networks() -> list[ipaddress.IPv4Network]:
    """The /24 around each private IPv4 address this computer has."""
    addresses: set[str] = set()
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("10.255.255.255", 1))  # no packet is sent
            addresses.add(s.getsockname()[0])
    except OSError:
        pass
    command = ["ipconfig"] if sys.platform == "win32" else ["ifconfig"]
    try:
        text = subprocess.run(command, capture_output=True, text=True,
                              timeout=3).stdout
        addresses.update(re.findall(r"(?:inet |IPv4[^:]*:\s*)(\d+\.\d+\.\d+\.\d+)", text))
    except (OSError, subprocess.SubprocessError):
        pass
    nets = set()
    for a in addresses:
        ip = ipaddress.IPv4Address(a)
        if ip.is_private and not ip.is_loopback and not ip.is_link_local:
            nets.add(ipaddress.IPv4Network(f"{a}/24", strict=False))
    return sorted(nets)


def _knock(host: str, port: int) -> bytes | None:
    try:
        with socket.create_connection((host, port), timeout=KNOCK_TIMEOUT) as s:
            s.settimeout(1.5)
            return s.recv(2048)
    except OSError:
        return None


def scan(port: int, networks=None, own: set[str] | None = None) -> list[dict]:
    """Every host on ``networks`` that answers on ``port``, with a guess at
    what it is from its greeting."""
    networks = networks if networks is not None else local_networks()
    hosts = [str(h) for net in networks for h in net.hosts()]
    found = []
    with ThreadPoolExecutor(max_workers=128) as pool:
        for host, banner in zip(hosts, pool.map(lambda h: _knock(h, port), hosts)):
            if banner is None:
                continue
            text = banner.decode("utf-8", "replace")
            model = ""
            m = re.search(r"(?im)^model(?: name)?:\s*(.+)$", text)
            if m:
                model = m.group(1).strip()
            if port == 9990 and "Device present: false" in text:
                continue  # Videohub software on a computer, no router attached
            found.append({"host": host, "model": model})
    return found
