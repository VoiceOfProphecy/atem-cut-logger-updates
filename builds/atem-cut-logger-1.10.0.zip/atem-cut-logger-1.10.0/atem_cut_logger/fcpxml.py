"""Export a LogSession as an FCPXML timeline DaVinci Resolve can import.

Design decisions (see README for the user-facing description):

* Every cut becomes an ``<asset-clip>`` on the primary storyline (video track
  V1 in Resolve). Camera assets are declared **video-only** so cutting the
  Program bus never chops the audio.
* The program-feed audio (if the user picked a file) is a single continuous
  ``<audio>`` element anchored below the first clip (lane -1 -> track A1),
  spanning the whole timeline.
* All times are integer frame counts multiplied by the exact rational frame
  duration (e.g. ``1001/30000s``), so every value is frame-aligned — a hard
  requirement of the FCPXML format.
* A logged AUTO transition (dissolve, wipe, DVE) puts the clip boundary at the
  blend's **midpoint**. The switcher reports the frame the blend *finished*, so
  using it unchanged would put every dissolve late by its full length.
* ``transitions=True`` additionally writes a ``<transition>`` element straddling
  each of those boundaries, so the blend is reproduced rather than approximated.
  It is opt-in because a plain cut timeline is what most editors want to
  receive; the default output is unchanged. Clip offsets and durations are the
  same either way — a transition consumes each neighbour's handles, exactly as
  it does in Final Cut Pro, so the timeline's total length doesn't move.
* Two ISO-sync models:
    - ``tc_synced_isos=False`` (default): each ISO file started recording at
      the moment logging started, so source position == timeline elapsed time.
    - ``tc_synced_isos=True``: ISO files carry production timecode (jam sync),
      so source positions use absolute timecode.
"""

from __future__ import annotations

import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import PurePath, PureWindowsPath
from urllib.parse import quote

from .session import LogSession


@dataclass(frozen=True)
class TimelineMarker:
    """A marker to drop on the timeline at a logging-relative frame.

    ``name`` is what DaVinci Resolve shows as the marker text. Markers are an
    optional overlay; passing none reproduces the plain cut timeline exactly.
    """

    frame: int
    name: str

# Conventional FCPXML frame durations per rate key.
_FRAME_DURATION = {
    "23.976": (1001, 24000),
    "24": (100, 2400),
    "25": (100, 2500),
    "29.97": (1001, 30000),
    "30": (100, 3000),
}

_AUDIO_ONLY_SUFFIXES = {".wav", ".wave", ".aif", ".aiff", ".mp3", ".flac", ".caf"}

# What each switcher transition style is called on the timeline. Resolve has no
# equivalent for a wipe or a DVE move, and substitutes its own cross dissolve;
# the name still tells the editor what the switcher actually did.
_TRANSITION_NAMES = {
    "mix": "Cross Dissolve",
    "dip": "Dip To Color Dissolve",
    "wipe": "Wipe",
    "dve": "DVE",
    "sting": "Cross Dissolve",
}


class ExportError(ValueError):
    pass


def _file_uri(path: str, fallback_name: str) -> str:
    """Best-effort file:// URI. Missing paths become an obvious relink stub."""
    if not path:
        return "file:///ATEM-Cut-Logger-Relink/" + quote(fallback_name + ".mov")
    if "\\" in path or (len(path) > 1 and path[1] == ":"):
        p: PurePath = PureWindowsPath(path)
        drive = p.drive.rstrip(":")
        parts = p.parts[1:] if p.drive else p.parts
        return f"file:///{quote(drive)}:/" + "/".join(quote(s) for s in parts)
    if not path.startswith("/"):
        path = "/" + path
    return "file://" + quote(path)


def _blend_frames(event, incoming_frames: int, outgoing_frames: int) -> int:
    """How long a transition element may be between two clips.

    Half the blend hangs over each neighbour, so neither shot may be shorter
    than the blend itself — a two-frame shot between two one-second dissolves
    would otherwise ask Resolve for overlap that runs off the far end of the
    clip. Clamping keeps the timeline valid; the log and the EDL still carry
    the length the switcher reported.
    """
    return max(0, min(event.transition_frames, incoming_frames, outgoing_frames))


def export_fcpxml(
    session: LogSession,
    *,
    width: int = 1920,
    height: int = 1080,
    tc_synced_isos: bool = False,
    project_name: str = "ATEM Program Cut",
    markers: list[TimelineMarker] | None = None,
    transitions: bool = False,
) -> str:
    if not session.events:
        raise ExportError("The session log contains no events; nothing to export.")
    session.validate()

    num, den = _FRAME_DURATION[session.rate_key]

    def t(frames: int) -> str:
        """Frames -> rational seconds string, always frame-aligned."""
        return f"{frames * num}/{den}s"

    start = session.start_frames
    total = session.duration_frames
    tc_format = "DF" if session.drop_frame else "NDF"

    root = ET.Element("fcpxml", version="1.8")
    resources = ET.SubElement(root, "resources")
    ET.SubElement(
        resources,
        "format",
        id="r1",
        frameDuration=f"{num}/{den}s",
        width=str(width),
        height=str(height),
    )

    # One video-only asset per camera that actually appears in the log.
    used_inputs: list[int] = sorted({e.input_id for e in session.events})
    asset_ids: dict[int, str] = {}
    # In TC-synced mode media timecode starts at the production start TC;
    # otherwise ISO files begin at zero exactly when logging began.
    asset_start = start if tc_synced_isos else 0
    for input_id in used_inputs:
        asset_id = f"cam{input_id}"
        asset_ids[input_id] = asset_id
        mapping = session.mappings.get(input_id)
        label = session.camera_label(input_id)
        ET.SubElement(
            resources,
            "asset",
            id=asset_id,
            name=label,
            src=_file_uri(mapping.file if mapping else "", label),
            start=t(asset_start),
            duration=t(total),
            hasVideo="1",
            hasAudio="0",
            format="r1",
        )

    audio_asset_id = ""
    if session.audio_file:
        audio_asset_id = "progaudio"
        is_audio_only = (
            PurePath(session.audio_file).suffix.lower() in _AUDIO_ONLY_SUFFIXES
        )
        ET.SubElement(
            resources,
            "asset",
            id=audio_asset_id,
            name="Program Audio",
            src=_file_uri(session.audio_file, "Program Audio"),
            start=t(asset_start),
            duration=t(total),
            hasVideo="0" if is_audio_only else "1",
            hasAudio="1",
            audioSources="1",
            audioChannels="2",
            audioRate="48000",
        )

    library = ET.SubElement(root, "library")
    event = ET.SubElement(library, "event", name="ATEM Cut Logger")
    project = ET.SubElement(event, "project", name=project_name)
    sequence = ET.SubElement(
        project,
        "sequence",
        format="r1",
        duration=t(total),
        tcStart=t(start),
        tcFormat=tc_format,
        audioLayout="stereo",
        audioRate="48k",
    )
    spine = ET.SubElement(sequence, "spine")

    marker_list = sorted(markers, key=lambda m: m.frame) if markers else []

    def boundary(index: int) -> int:
        """Timeline frame where this event's clip begins.

        For a hard cut that's the logged frame. For an AUTO transition it's the
        middle of the blend, since the logged frame is where the blend ended.
        """
        if index >= len(session.events):
            return total
        event = session.events[index]
        if not event.is_transition:
            return event.frame
        midpoint = event.frame - event.transition_frames // 2
        floor = session.events[index - 1].frame + 1 if index else 0
        return max(floor, midpoint)

    bounds = [boundary(i) for i in range(len(session.events) + 1)]

    for i, ev in enumerate(session.events):
        ev_frame = bounds[i]
        next_frame = bounds[i + 1]
        clip_frames = next_frame - ev_frame
        if transitions and i and ev.is_transition:
            blend = _blend_frames(ev, ev_frame - bounds[i - 1], clip_frames)
            if blend:
                # Straddles the edit point, which boundary() already put at the
                # middle of the blend — so the element covers the frames the
                # switcher was actually mixing over.
                ET.SubElement(
                    spine,
                    "transition",
                    name=_TRANSITION_NAMES.get(ev.transition, "Cross Dissolve"),
                    offset=t(start + ev_frame - blend // 2),
                    duration=t(blend),
                )
        source_in = start + ev_frame if tc_synced_isos else ev_frame
        clip = ET.SubElement(
            spine,
            "asset-clip",
            ref=asset_ids[ev.input_id],
            name=session.camera_label(ev.input_id),
            offset=t(start + ev_frame),
            start=t(source_in),
            duration=t(clip_frames),
            format="r1",
            tcFormat=tc_format if tc_synced_isos else "NDF",
        )
        if i == 0 and audio_asset_id:
            # One continuous program-audio clip for the whole show, anchored
            # to the first cut (lane -1 -> audio track under the video).
            # Anchored offsets are in the parent's source time, so aligning
            # the audio head with the parent's start aligns it with the
            # timeline start.
            ET.SubElement(
                clip,
                "audio",
                ref=audio_asset_id,
                lane="-1",
                offset=t(source_in),
                start=t(asset_start),
                duration=t(total),
                role="dialogue",
            )

        # Attach any markers that fall inside this clip. A marker's start is in
        # the clip's own source-time coordinate system, so timeline frame F maps
        # to source_in + (F - ev.frame). The last clip also claims a marker that
        # lands exactly on the timeline end.
        is_last = i + 1 == len(session.events)
        for mk in marker_list:
            in_clip = ev_frame <= mk.frame < next_frame or (
                is_last and mk.frame == next_frame
            )
            if in_clip:
                ET.SubElement(
                    clip,
                    "marker",
                    start=t(source_in + (mk.frame - ev_frame)),
                    duration=t(1),
                    value=mk.name,
                )

    ET.indent(root)
    body = ET.tostring(root, encoding="unicode")
    return '<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE fcpxml>\n' + body + "\n"


def flags_to_markers(session: LogSession) -> list[TimelineMarker]:
    """Turn manually-marked problem moments into timeline markers."""
    return [
        TimelineMarker(frame=f.frame, name=f"⚠ {f.note}" if f.note else "⚠ Flagged")
        for f in session.flags
    ]


def export_flags_fcpxml(
    session: LogSession,
    *,
    width: int = 1920,
    height: int = 1080,
    tc_synced_isos: bool = False,
    project_name: str = "ATEM Flagged Issues",
    transitions: bool = False,
) -> str:
    """The normal cut timeline with a marker at each manually-flagged moment.

    Same idea as Smart Cleanup's issue markers, but for spots the operator
    flagged live during the show rather than anything auto-detected.
    """
    return export_fcpxml(
        session,
        width=width,
        height=height,
        tc_synced_isos=tc_synced_isos,
        project_name=project_name,
        markers=flags_to_markers(session),
        transitions=transitions,
    )
