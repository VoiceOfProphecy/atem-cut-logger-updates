"""The camera settings the Switcher section offers, in Blackmagic's Camera
Control Protocol terms.

Each control is (category, parameter) plus which value in the list it edits,
its range, and how to show it. The ATEM relays these to Blackmagic cameras
over the SDI return feed, so they work on any camera ATEM Software Control's
camera page works on. Values are reported only for settings the camera or a
panel has touched since power-up; the UI shows "—" until then.
"""

from __future__ import annotations

# kind: the wire type the bridge expects — f (fixed-point), i8, i16, i32, void.
# ui: slider | button. For multi-value parameters, ``index`` picks the value
# and ``count`` is how many values the parameter carries (the others are sent
# as they were last reported, or ``fill``).
CONTROLS: list[dict] = [
    # Lens
    {"id": "iris", "group": "Lens", "label": "Iris", "cat": 0, "param": 3, "kind": "f",
     "ui": "slider", "min": 0, "max": 1, "step": 0.01, "hint": "0 = closed, 1 = fully open"},
    {"id": "auto_iris", "group": "Lens", "label": "Auto iris", "cat": 0, "param": 5, "kind": "void", "ui": "button"},
    {"id": "focus", "group": "Lens", "label": "Focus", "cat": 0, "param": 0, "kind": "f",
     "ui": "slider", "min": 0, "max": 1, "step": 0.005, "hint": "0 = near, 1 = far"},
    {"id": "auto_focus", "group": "Lens", "label": "Auto focus", "cat": 0, "param": 1, "kind": "void", "ui": "button"},
    {"id": "zoom", "group": "Lens", "label": "Zoom", "cat": 0, "param": 8, "kind": "f",
     "ui": "slider", "min": 0, "max": 1, "step": 0.01, "hint": "Servo lenses only"},
    # Exposure
    {"id": "gain", "group": "Exposure", "label": "Gain (dB)", "cat": 1, "param": 13, "kind": "i8",
     "ui": "slider", "min": -12, "max": 36, "step": 2},
    {"id": "iso", "group": "Exposure", "label": "ISO", "cat": 1, "param": 14, "kind": "i32",
     "ui": "slider", "min": 100, "max": 25600, "step": 100},
    {"id": "shutter_angle", "group": "Exposure", "label": "Shutter angle (°)", "cat": 1, "param": 11,
     "kind": "i32", "ui": "slider", "min": 100, "max": 36000, "step": 100, "scale": 100},
    {"id": "nd", "group": "Exposure", "label": "ND filter (stops)", "cat": 1, "param": 16, "kind": "f",
     "ui": "slider", "min": 0, "max": 6, "step": 2, "count": 2, "index": 0},
    # White balance
    {"id": "wb_temp", "group": "White balance", "label": "Temperature (K)", "cat": 1, "param": 2,
     "kind": "i16", "ui": "slider", "min": 2500, "max": 10000, "step": 50, "count": 2, "index": 0},
    {"id": "wb_tint", "group": "White balance", "label": "Tint", "cat": 1, "param": 2,
     "kind": "i16", "ui": "slider", "min": -50, "max": 50, "step": 1, "count": 2, "index": 1},
    {"id": "auto_wb", "group": "White balance", "label": "Auto white balance", "cat": 1, "param": 3,
     "kind": "void", "ui": "button"},
    # Colour (master/luma channel of lift, gamma, gain)
    {"id": "lift", "group": "Color", "label": "Lift (blacks)", "cat": 8, "param": 0, "kind": "f",
     "ui": "slider", "min": -2, "max": 2, "step": 0.01, "count": 4, "index": 3},
    {"id": "gamma", "group": "Color", "label": "Gamma (mids)", "cat": 8, "param": 1, "kind": "f",
     "ui": "slider", "min": -4, "max": 4, "step": 0.01, "count": 4, "index": 3},
    {"id": "cgain", "group": "Color", "label": "Gain (highlights)", "cat": 8, "param": 2, "kind": "f",
     "ui": "slider", "min": 0, "max": 16, "step": 0.01, "count": 4, "index": 3, "fill": 1},
    {"id": "contrast", "group": "Color", "label": "Contrast", "cat": 8, "param": 4, "kind": "f",
     "ui": "slider", "min": 0, "max": 2, "step": 0.01, "count": 2, "index": 1, "fill": 0.5},
    {"id": "hue", "group": "Color", "label": "Hue", "cat": 8, "param": 6, "kind": "f",
     "ui": "slider", "min": -1, "max": 1, "step": 0.01, "count": 2, "index": 0},
    {"id": "saturation", "group": "Color", "label": "Saturation", "cat": 8, "param": 6, "kind": "f",
     "ui": "slider", "min": 0, "max": 2, "step": 0.01, "count": 2, "index": 1, "fill": 1},
    {"id": "color_reset", "group": "Color", "label": "Reset color to defaults", "cat": 8, "param": 7,
     "kind": "void", "ui": "button"},
]

BY_ID = {c["id"]: c for c in CONTROLS}

# Neutral values used for the other slots of a multi-value parameter when the
# camera hasn't reported it yet (e.g. lift is [R, G, B, Y]).
_DEFAULT_FILL = {(1, 2): [5600, 0], (1, 16): [0, 0], (8, 2): [1, 1, 1, 1],
                 (8, 4): [0.5, 1], (8, 6): [0, 1]}


def values_for(control: dict, value: float, current: list | None) -> list:
    """The full value list to send when one slot of a parameter changes."""
    count = control.get("count", 1)
    if count == 1:
        return [value]
    base = list(current or [])
    if len(base) < count:
        fallback = _DEFAULT_FILL.get((control["cat"], control["param"]),
                                     [control.get("fill", 0)] * count)
        base = (base + fallback[len(base):])[:count]
    base[control["index"]] = value
    return base


def key(cam: int, cat: int, param: int) -> str:
    return f"{int(cam)}.{int(cat)}.{int(param)}"
