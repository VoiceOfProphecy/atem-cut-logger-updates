"""Per-machine preferences — where sessions are saved, Smart Cleanup rules,
the company logo, the last switcher address.

Unlike templates (one per show) these belong to the computer, so they live in
a single JSON file under ``~/.atem_cut_logger``. Every read tolerates a missing
or damaged file and falls back to defaults: a bad preferences file must never
stop the logger from starting before a show.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

from .analysis import CleanupConfig

LOGO_TYPES = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".svg": "image/svg+xml",
}
MAX_LOGO_BYTES = 2 * 1024 * 1024


class PrefsError(Exception):
    """A user-facing preferences problem (bad logo, bad rule value)."""


def default_prefs_dir() -> Path:
    return Path.home() / ".atem_cut_logger"


def fallback_save_dir() -> Path:
    """The computer's own Downloads folder, or the home folder without one.

    Used when no default is set and whenever the chosen default is unavailable
    (an unmounted NAS, an unplugged drive) — always somewhere local.
    """
    downloads = Path.home() / "Downloads"
    return downloads if downloads.is_dir() else Path.home()


def folder_problem(path: str | Path) -> str:
    """Why a folder can't take a save right now, or "" if it can."""
    if not str(path).strip():
        return "No folder was chosen."
    p = Path(path).expanduser()
    if not p.exists():
        return f"“{p}” isn't available — the drive or network share may be disconnected."
    if not p.is_dir():
        return f"“{p}” is a file, not a folder."
    if not os.access(p, os.W_OK):
        return f"This computer doesn't have permission to save in “{p}”."
    return ""


class Prefs:
    def __init__(self, directory: Path | None = None) -> None:
        self.dir = Path(directory) if directory else default_prefs_dir()
        self.path = self.dir / "prefs.json"
        self.data: dict = {}
        self._load()

    # ------------------------------------------------------------ storage

    def _load(self) -> None:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            self.data = data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            self.data = {}

    def _save(self) -> None:
        self.dir.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.data, indent=2), encoding="utf-8")
        os.replace(tmp, self.path)

    # ------------------------------------------------------------ values

    @property
    def default_save_dir(self) -> str:
        """The folder the operator chose, or "" to mean "use Downloads"."""
        return str(self.data.get("default_save_dir") or "")

    def effective_save_dir(self) -> str:
        return self.default_save_dir or str(fallback_save_dir())

    @property
    def run_cleanup(self) -> bool:
        return bool(self.data.get("run_cleanup", True))

    @property
    def atem_ip(self) -> str:
        return str(self.data.get("atem_ip") or "")

    @property
    def router(self) -> dict:
        """The Videohub this computer drives, and its saved route presets."""
        raw = self.data.get("router")
        raw = raw if isinstance(raw, dict) else {}
        presets = [p for p in raw.get("presets") or []
                   if isinstance(p, dict) and p.get("name")]
        return {"host": str(raw.get("host") or ""), "presets": presets}

    def set_router(self, host: str | None = None, presets: list | None = None) -> None:
        router = self.router
        if host is not None:
            router["host"] = str(host).strip()
        if presets is not None:
            router["presets"] = presets
        self.data["router"] = router
        self._save()

    @property
    def macro_settings(self) -> dict:
        """Per macro (by name): protected = hold to run; on_log = also shown
        on the Log screen. Unknown macros are protected and off the Log
        screen until the operator says otherwise."""
        raw = self.data.get("macros")
        return raw if isinstance(raw, dict) else {}

    def set_macro(self, name: str, protected: bool | None = None,
                  on_log: bool | None = None) -> None:
        settings = dict(self.macro_settings)
        entry = dict(settings.get(name) or {"protected": True, "on_log": False})
        if protected is not None:
            entry["protected"] = bool(protected)
        if on_log is not None:
            entry["on_log"] = bool(on_log)
        settings[name] = entry
        self.data["macros"] = settings
        self._save()

    @property
    def displays(self) -> list[dict]:
        raw = self.data.get("displays")
        return [d for d in raw if isinstance(d, dict)] if isinstance(raw, list) else []

    def set_displays(self, displays: list[dict]) -> None:
        self.data["displays"] = displays
        self._save()

    def cleanup_config(self) -> CleanupConfig:
        try:
            return CleanupConfig.from_dict(self.data.get("cleanup") or {})
        except (TypeError, ValueError):
            return CleanupConfig()

    def update(self, values: dict) -> None:
        if "default_save_dir" in values:
            raw = str(values["default_save_dir"] or "").strip()
            self.data["default_save_dir"] = str(Path(raw).expanduser()) if raw else ""
        if "run_cleanup" in values:
            self.data["run_cleanup"] = bool(values["run_cleanup"])
        if "atem_ip" in values:
            self.data["atem_ip"] = str(values["atem_ip"] or "").strip()
        if "cleanup" in values:
            merged = {**(self.data.get("cleanup") or {}), **(values["cleanup"] or {})}
            try:
                CleanupConfig.from_dict(merged)
            except (TypeError, ValueError) as exc:
                raise PrefsError(f"Smart Cleanup setting rejected: {exc}") from exc
            self.data["cleanup"] = merged
        self._save()

    def to_payload(self) -> dict:
        default = self.default_save_dir
        return {
            "default_save_dir": default,
            "save_dir": self.effective_save_dir(),
            "save_dir_problem": folder_problem(default) if default else "",
            "fallback_save_dir": str(fallback_save_dir()),
            "run_cleanup": self.run_cleanup,
            "atem_ip": self.atem_ip,
            "router": self.router,
            "macros": self.macro_settings,
            "cleanup": self.cleanup_config().to_dict(),
            "logo": self.logo_version("dark"),
            "logo_light": self.logo_version("light"),
        }

    # ------------------------------------------------------------ logo
    # Two optional images: "dark" for the default dark theme (usually white
    # lettering) and "light" for the light theme (dark lettering). Either one
    # stands in for the other when only one is uploaded.

    def _stem(self, variant: str) -> str:
        if variant not in ("dark", "light"):
            raise PrefsError("Unknown logo variant.")
        return "logo" if variant == "dark" else "logo-light"

    def logo_path(self, variant: str = "dark") -> Path | None:
        stem = self._stem(variant)
        for suffix in LOGO_TYPES:
            p = self.dir / f"{stem}{suffix}"
            if p.is_file():
                return p
        return None

    def logo_version(self, variant: str = "dark") -> int:
        """Changes whenever the logo does (0 = none), for cache-busting."""
        p = self.logo_path(variant)
        return int(p.stat().st_mtime_ns // 1_000_000) if p else 0

    def set_logo(self, filename: str, data: bytes, variant: str = "dark") -> None:
        suffix = Path(filename or "").suffix.lower()
        if suffix not in LOGO_TYPES:
            raise PrefsError("Use a PNG, JPG, WebP or SVG image for the logo.")
        if not data:
            raise PrefsError("That image file is empty.")
        if len(data) > MAX_LOGO_BYTES:
            raise PrefsError("Keep the logo under 2 MB.")
        self.dir.mkdir(parents=True, exist_ok=True)
        self.remove_logo(variant)
        (self.dir / f"{self._stem(variant)}{suffix}").write_bytes(data)

    def remove_logo(self, variant: str = "dark") -> None:
        stem = self._stem(variant)
        for suffix in LOGO_TYPES:
            (self.dir / f"{stem}{suffix}").unlink(missing_ok=True)


def folder_shortcuts() -> list[dict]:
    """Starting points for the folder browser: the usual places plus any
    mounted drives and network shares."""
    home = Path.home()
    out = [{"label": "Home", "path": str(home)}]
    for name in ("Desktop", "Documents", "Downloads", "Movies", "Videos"):
        p = home / name
        if p.is_dir():
            out.append({"label": name, "path": str(p)})
    roots: list[Path] = []
    if sys.platform == "darwin":
        roots = [p for p in Path("/Volumes").glob("*") if p.is_dir()]
    elif sys.platform == "win32":
        import string
        roots = [Path(f"{d}:\\") for d in string.ascii_uppercase
                 if Path(f"{d}:\\").exists()]
    else:
        for base in (Path("/media") / home.name, Path("/mnt")):
            if base.is_dir():
                roots += [p for p in base.iterdir() if p.is_dir()]
    for p in roots:
        out.append({"label": p.name or str(p), "path": str(p), "drive": True})
    return out


def list_folder(path: str) -> dict:
    p = Path(path or Path.home()).expanduser()
    note = ""
    if not p.is_dir():
        # Start somewhere usable instead of an empty, unchoosable listing.
        note = (f"“{p}” isn't available — the drive or network share may be "
                "disconnected. Pick another folder.")
        p = fallback_save_dir()
    problem = folder_problem(p)
    dirs: list[str] = []
    if p.is_dir():
        try:
            dirs = sorted(
                (c.name for c in p.iterdir()
                 if c.is_dir() and not c.name.startswith(".")),
                key=str.lower,
            )
        except OSError as exc:
            problem = f"Can't open “{p}”: {exc.strerror or exc}"
    parent = str(p.parent) if p.parent != p else ""
    return {"path": str(p), "parent": parent, "dirs": dirs, "note": note,
            "problem": problem, "shortcuts": folder_shortcuts()}
