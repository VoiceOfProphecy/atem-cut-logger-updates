"""The web app's stateful core — everything except HTTP.

A single :class:`Controller` owns the live session, the switcher backend and the
analysis, exactly like the desktop app's window did, but exposes it as plain
data (dicts) plus a broadcast stream of events. The HTTP layer in
:mod:`.server` is a thin translation on top; this class is what the tests
exercise directly.

Thread model: switcher backends call the listener methods from their own
threads. Every state mutation takes ``self._lock`` and then broadcasts a small
event dict to all subscribers (the SSE clients). Timestamps for logged cuts are
captured inside the backend callbacks, never here, so UI latency can't skew cut
times.
"""

from __future__ import annotations

import os
import queue
import threading
import time
import uuid
from pathlib import Path
from typing import Any

from .. import __version__
from ..backends import create_backend
from ..package import PackageOptions, write_package
from .. import camera_params, discovery, displays
from ..prefs import Prefs, PrefsError, fallback_save_dir, folder_problem
from ..recorders import (
    FILESYSTEMS,
    RecorderConfig,
    RecorderError,
    RecorderPool,
    RecorderWatcher,
)
from ..session import CameraMapping, LogSession
from ..templates import TemplateError, TemplateStore
from ..updates import UpdateError, UpdateManager
from ..videohub import Videohub, VideohubError
from ..timecode import (
    FRAME_RATES,
    TimecodeError,
    frames_to_timecode,
    parse_timecode,
    seconds_to_frames,
)

RESOLUTIONS = {
    "1920x1080": (1920, 1080),
    "1280x720": (1280, 720),
    "3840x2160": (3840, 2160),
}


def default_autosave_path() -> Path:
    return Path.home() / ".atem_cut_logger" / "autosave.atemlog.json"


# Template fields, and how each maps onto the controller/session. Keeping the
# list in one place is what stops a template from quietly carrying per-show
# values (start timecode, session name) into the next show.
TEMPLATE_FIELDS = ("rate_key", "drop_frame", "resolution", "iso_sync",
                   "auto_timecode", "audio_file", "auto_start_on_record",
                   "fcpxml_transitions")

# How often the idle clock re-reads the switcher's timecode generator. Between
# reads it counts forward on its own, so the display ticks smoothly.
TC_RESYNC_SECONDS = 2.0
# A reading older than this is treated as lost (switcher gone, generator off).
TC_STALE_SECONDS = 8.0


# How long one trace step waits on every deck's answer.
COMMAND_TIMEOUT_FOR_TRACE = 5.0


class ControllerError(Exception):
    """A user-facing error (bad input / illegal state) -> HTTP 400."""


class ControlDenied(ControllerError):
    """Another device holds the control lock -> HTTP 403."""


class SaveLocationError(ControllerError):
    """The chosen save folder can't be used right now (unplugged drive,
    unmounted share, no permission). Carries the local fallback so the UI can
    offer it instead of failing the save outright."""

    def __init__(self, message: str, folder: str, fallback: str) -> None:
        super().__init__(message)
        self.folder = folder
        self.fallback = fallback


class Controller:
    def __init__(
        self,
        autosave_path: Path | None = None,
        updates: UpdateManager | None = None,
        templates: TemplateStore | None = None,
        prefs: Prefs | None = None,
    ) -> None:
        self._lock = threading.RLock()
        self.session = LogSession()
        self.backend = None
        self.backend_kind = ""
        self.connected = False
        self.program_input: int | None = None
        self.logging = False
        self.start_mono: float | None = None
        self.status_text = "Not connected."
        self.width, self.height = 1920, 1080
        self.tc_synced = False
        # Write real <transition> elements into FCPXML exports instead of
        # flattening each blend to a cut at its midpoint. Off by default:
        # a plain cut timeline is what most editors expect to receive.
        self.fcpxml_transitions = False
        self.loaded_name = ""
        self.recovered = False
        self.last_saved_folder = ""
        # When on (default) and the backend supports it, Start Timecode is
        # read live from the switcher's own timecode generator the instant
        # Start Logging is pressed, instead of relying on a typed value.
        # Silently a no-op on backends that don't support it (e.g. Test Mode).
        self.auto_timecode = True

        # Macros the switcher reports, and available to fire from the UI.
        self.macros: list[dict] = []

        # Switcher section: Preview bus (tally only, never logged) and the
        # last reported value of every camera setting, "cam.cat.param" ->
        # {"kind", "values"}.
        self.preview_input: int | None = None
        self.camera_available = False
        self.camera_values: dict[str, dict] = {}

        # Control lock: which device (token) is currently allowed to drive.
        self.control_token: str | None = None
        self.control_label = ""

        # Recorders (HyperDecks) the operator drives from the UI. The watcher
        # is what starts logging when a deck starts rolling.
        self.recorders = RecorderPool()
        self.auto_start_on_record = False
        self.recorder_watcher = RecorderWatcher(
            self.recorders, self._on_recording_started
        )

        # Format reviews: what the operator was shown before erasing a card,
        # keyed by a one-time id. Formatting is refused unless the card still
        # matches what was shown.
        self._format_reviews: dict[str, dict] = {}

        # Signal trace (Router section): progress and results, and a flag to
        # stop it early. Only one runs at a time.
        self.trace: dict = {"running": False, "results": [], "done": 0, "total": 0}
        self._trace_stop = threading.Event()

        # Saved show setups (frame rate, mapping, ...) for reuse next time.
        self.templates = templates or TemplateStore()

        # This computer's preferences: save folder, cleanup rules, logo.
        self.prefs = prefs or Prefs()

        # Live switcher timecode shown while not logging: the last reading
        # and the monotonic time it was taken, so the clock can run between
        # reads. None when the backend has no timecode to give.
        self._tc_anchor: tuple[int, float, bool] | None = None
        self._tc_read_lock = threading.Lock()
        self._idle_stop = threading.Event()
        self._idle_thread: threading.Thread | None = None

        # True once the log holds work that hasn't been exported to JSON.
        # Drives the warning on "New session".
        self.unsaved = False

        # Crash-safe autosave (disabled unless a path is given).
        self.autosave_path = Path(autosave_path) if autosave_path else None
        self._autosave_lock = threading.Lock()

        # Self-update. Checks run on a timer started by the entry point, never
        # from here, so tests and the desktop app don't touch the network.
        self.updates = updates or UpdateManager(
            on_change=self._broadcast_update,
            is_busy=lambda: self.logging,
        )

        self._subscribers: set[queue.Queue] = set()
        self._sub_lock = threading.Lock()
        self._ticker_stop = threading.Event()
        self._ticker: threading.Thread | None = None

        self._maybe_recover()

    # ------------------------------------------------------------ autosave

    def _maybe_recover(self) -> None:
        """On startup, reload an autosave left behind by a crash."""
        if not self.autosave_path or not self.autosave_path.is_file():
            return
        try:
            session = LogSession.from_json(
                self.autosave_path.read_text(encoding="utf-8")
            )
        except (OSError, ValueError, KeyError):
            return
        if session.events:
            self.session = session
            self.recovered = True
            self.unsaved = True
            self.loaded_name = "recovered session"
            self.status_text = "Recovered an unsaved session."

    def _autosave(self) -> None:
        if not self.autosave_path:
            return
        with self._lock:
            if not self.session.events:
                return
            text = self.session.to_json()
        with self._autosave_lock:
            try:
                self.autosave_path.parent.mkdir(parents=True, exist_ok=True)
                tmp = self.autosave_path.with_suffix(".tmp")
                tmp.write_text(text, encoding="utf-8")
                os.replace(tmp, self.autosave_path)  # atomic on POSIX & Windows
            except OSError:
                pass  # never let autosave failure disrupt a live show

    def mark_saved(self) -> None:
        """Called when the user exports the JSON log: clears the crash marker."""
        self.unsaved = False
        if not self.autosave_path:
            return
        with self._autosave_lock:
            try:
                self.autosave_path.unlink(missing_ok=True)
            except OSError:
                pass

    # ------------------------------------------------------------ subscribe

    def subscribe(self) -> queue.Queue:
        q: queue.Queue = queue.Queue()
        with self._sub_lock:
            self._subscribers.add(q)
        return q

    def unsubscribe(self, q: queue.Queue) -> None:
        with self._sub_lock:
            self._subscribers.discard(q)

    def _broadcast(self, kind: str, **data: Any) -> None:
        message = {"type": kind, **data}
        with self._sub_lock:
            subscribers = list(self._subscribers)
        for q in subscribers:
            q.put(message)

    # ------------------------------------------------------------ snapshot

    def snapshot(self) -> dict:
        with self._lock:
            s = self.session
            return {
                "version": __version__,
                "connected": self.connected,
                "logging": self.logging,
                "backend": self.backend_kind,
                "status": self.status_text,
                "program_input": self.program_input,
                "program_camera": (
                    s.camera_label(self.program_input)
                    if self.program_input is not None else None
                ),
                "switcher_product": s.switcher_product,
                "macros": list(self.macros),
                "preview_input": self.preview_input,
                "camera_available": self.camera_available,
                "camera_values": dict(self.camera_values),
                "camera_controls": camera_params.CONTROLS,
                "loaded_name": self.loaded_name,
                "recovered": self.recovered,
                "control_label": self.control_label,
                "settings": {
                    "session_name": s.name,
                    "rate_key": s.rate_key,
                    "drop_frame": s.drop_frame,
                    "start_timecode": s.start_timecode,
                    "resolution": f"{self.width}x{self.height}",
                    "iso_sync": "tc" if self.tc_synced else "start",
                    "fcpxml_transitions": self.fcpxml_transitions,
                    "audio_file": s.audio_file,
                    "auto_timecode": self.auto_timecode,
                    "auto_start_on_record": self.auto_start_on_record,
                },
                "recorders": self.recorders.to_payload(),
                "recorder_status": [
                    s.to_dict() for s in self.recorder_watcher.last
                ],
                "rates": list(FRAME_RATES.keys()),
                "resolutions": list(RESOLUTIONS.keys()),
                "mappings": [
                    {"input_id": m.input_id, "name": m.name, "file": m.file}
                    for m in sorted(s.mappings.values(), key=lambda m: m.input_id)
                ],
                "events": self._events_payload(),
                "flags": self._flags_payload(),
                "notes": self._notes_payload(),
                "clock": self.current_clock(),
                "unsaved": self.unsaved,
                "templates": self._templates_payload(),
                "update": self.updates.status(),
                "can_export": bool(s.events) and not self.logging,
                "can_resume": bool(s.events) and not self.logging,
                "prefs": self.prefs.to_payload(),
                "last_saved_folder": self.last_saved_folder,
            }

    def _events_payload(self) -> list[dict]:
        return [
            {
                "n": i + 1,
                "elapsed": round(e.elapsed, 3),
                "frame": e.frame,
                "timecode": e.timecode,
                "input": e.input_id,
                "camera": e.camera,
                "transition": e.transition,
                "transition_frames": e.transition_frames,
            }
            for i, e in enumerate(self.session.events)
        ]

    def _flags_payload(self) -> list[dict]:
        return [
            {
                "index": i,
                "elapsed": round(f.elapsed, 3),
                "frame": f.frame,
                "timecode": f.timecode,
                "note": f.note,
            }
            for i, f in enumerate(self.session.flags)
        ]

    def _notes_payload(self) -> list[dict]:
        return [
            {
                "index": i,
                "elapsed": round(n.elapsed, 3),
                "frame": n.frame,
                "timecode": n.timecode,
                "text": n.text,
            }
            for i, n in enumerate(self.session.notes)
        ]

    # ------------------------------------------------------------- updates

    def _broadcast_update(self) -> None:
        self._broadcast("update", update=self.updates.status())

    def check_for_updates(self) -> dict:
        try:
            return self.updates.check()
        except UpdateError as exc:
            raise ControllerError(str(exc)) from exc

    def apply_update(self, restart: bool = True) -> dict:
        """Install a waiting update. Restarts the server so it takes effect."""
        try:
            result = self.updates.apply()
        except UpdateError as exc:
            raise ControllerError(str(exc)) from exc
        result["restarting"] = bool(restart and result.get("updated"))
        if result["restarting"]:
            self.updates.restart()
        return result

    def current_clock(self) -> dict:
        with self._lock:
            events = len(self.session.events)
            stopped_tc = (
                self.session.end_timecode if self.session.events
                else self.session.start_timecode
            )
            if not self.logging or self.start_mono is None:
                # Not logging: show the switcher's own timecode live when it
                # has one, else where the log ended (not the start TC).
                live = self._live_timecode()
                return {"running": False, "live": live is not None,
                        "timecode": live or stopped_tc,
                        "stopped_at": stopped_tc if self.session.events else "",
                        "events": events}
            elapsed = time.monotonic() - self.start_mono
            frame = seconds_to_frames(elapsed, self.session.rate)
            tc = frames_to_timecode(
                self.session.start_frames + frame,
                self.session.rate, self.session.drop_frame,
            )
            return {"running": True, "live": True, "timecode": tc,
                    "stopped_at": "", "events": events}

    # ------------------------------------------------------- live timecode

    def _live_timecode(self) -> str | None:
        anchor = self._tc_anchor
        if anchor is None:
            return None
        frames, taken, drop = anchor
        age = time.monotonic() - taken
        if age > TC_STALE_SECONDS:
            return None
        rate = self.session.rate
        return frames_to_timecode(frames + seconds_to_frames(age, rate),
                                  rate, drop)

    def _read_switcher_timecode(self, backend) -> tuple[str, bool] | None:
        """One read of the switcher's generator; serialised because the
        backends answer one timecode request at a time."""
        if backend is None:
            return None
        with self._tc_read_lock:
            try:
                return backend.get_current_timecode()
            except Exception:
                return None

    def _set_tc_anchor(self, reading) -> None:
        if not reading:
            self._tc_anchor = None
            return
        tc, drop = reading
        try:
            frames = parse_timecode(tc, self.session.rate, drop)
        except TimecodeError:
            self._tc_anchor = None
            return
        self._tc_anchor = (frames, time.monotonic(), bool(drop))

    def _start_idle_clock(self) -> None:
        """While connected, keep the switcher's timecode on screen even when
        nothing is being logged. Backends without timecode (Test Mode) simply
        never produce a reading, and the clock shows the log's end as before."""
        if self._idle_thread and self._idle_thread.is_alive():
            return
        self._idle_stop.clear()

        def run():
            last_read = 0.0
            while not self._idle_stop.wait(0.5):
                with self._lock:
                    backend, logging = self.backend, self.logging
                if backend is None:
                    continue
                if not logging and time.monotonic() - last_read >= TC_RESYNC_SECONDS:
                    last_read = time.monotonic()
                    self._set_tc_anchor(self._read_switcher_timecode(backend))
                if not logging and self._tc_anchor is not None:
                    self._broadcast("clock", **self.current_clock())

        self._idle_thread = threading.Thread(target=run, name="idle-clock",
                                             daemon=True)
        self._idle_thread.start()

    # ------------------------------------------------------- listener hooks
    # These are called by switcher backends from background threads.

    def on_connected(self, product_name, inputs, program) -> None:
        with self._lock:
            self.connected = True
            self.program_input = program
            self.session.switcher_product = product_name
            for input_id, name in sorted(inputs.items()):
                existing = self.session.mappings.get(input_id)
                if existing is None:
                    self.session.mappings[input_id] = CameraMapping(input_id, name)
                elif not existing.name:
                    existing.name = name
            self.status_text = f"Connected: {product_name}"
        self._start_idle_clock()
        self._broadcast("state", **self.snapshot())

    def on_program_changed(self, input_id, monotonic_time,
                           transition: str = "cut",
                           transition_frames: int = 0) -> None:
        new_event = None
        with self._lock:
            self.program_input = input_id
            if self.logging and self.start_mono is not None:
                new_event = self.session.add_program_change(
                    input_id, max(0.0, monotonic_time - self.start_mono),
                    transition, transition_frames,
                )
        if new_event is not None:
            self._broadcast(
                "event",
                event={
                    "n": len(self.session.events),
                    "elapsed": round(new_event.elapsed, 3),
                    "frame": new_event.frame,
                    "timecode": new_event.timecode,
                    "input": new_event.input_id,
                    "camera": new_event.camera,
                    "transition": new_event.transition,
                    "transition_frames": new_event.transition_frames,
                },
            )
        self._broadcast(
            "program",
            program_input=input_id,
            program_camera=self.session.camera_label(input_id),
            logging=self.logging,
        )
        if new_event is not None:
            self.unsaved = True
            self._autosave()

    def on_macros(self, macros) -> None:
        """The switcher's macro list, delivered once after connecting."""
        with self._lock:
            self.macros = list(macros or [])
        self._broadcast("state", **self.snapshot())

    def on_preview_changed(self, input_id) -> None:
        with self._lock:
            self.preview_input = input_id
        self._broadcast("tally", program_input=self.program_input,
                        preview_input=input_id)

    def on_camera_available(self, available) -> None:
        with self._lock:
            self.camera_available = bool(available)
        self._broadcast("state", **self.snapshot())

    def on_camera_value(self, cam, cat, param, kind, values) -> None:
        k = camera_params.key(cam, cat, param)
        with self._lock:
            self.camera_values[k] = {"kind": kind, "values": list(values)}
        self._broadcast("camera", key=k, value_kind=kind, values=list(values))

    def on_disconnected(self, reason) -> None:
        was_logging = self.logging
        with self._lock:
            if self.logging:
                self._stop_logging_locked()
            self.connected = False
            self.program_input = None
            self.preview_input = None
            self.camera_available = False
            self.camera_values = {}
            self.macros = []
            self.status_text = f"Disconnected: {reason}"
        self._tc_anchor = None
        self._broadcast("state", disconnect_reason=reason,
                        was_logging=was_logging, **self.snapshot())

    def on_error(self, message) -> None:
        with self._lock:
            self.status_text = f"Error: {message}"
        self._broadcast("error", message=message)

    # ----------------------------------------------------------- commands

    def connect(self, mode: str, address: str = "") -> None:
        if mode not in ("atem", "simulator"):
            raise ControllerError("mode must be 'atem' or 'simulator'.")
        if mode == "atem" and not address.strip():
            raise ControllerError("An ATEM IP address is required.")
        with self._lock:
            if self.connected:
                raise ControllerError("Already connected; disconnect first.")
            try:
                self.backend = create_backend(mode, self)
            except (RuntimeError, ImportError) as exc:
                raise ControllerError(str(exc)) from exc
            self.backend_kind = mode
            self.status_text = "Connecting…" if mode == "atem" else "Starting simulator…"
        try:
            self.backend.connect(address.strip())
        except Exception as exc:  # backend-specific failures
            with self._lock:
                self.backend = None
                self.backend_kind = ""
                self.status_text = "Not connected."
            raise ControllerError(f"Could not connect: {exc}") from exc
        if mode == "atem" and address.strip() != self.prefs.atem_ip:
            try:
                self.prefs.update({"atem_ip": address.strip()})
            except OSError:
                pass  # remembering the address is a convenience only

    def disconnect(self) -> None:
        with self._lock:
            backend = self.backend
        if backend:
            backend.disconnect()
        with self._lock:
            self.backend = None
            self.backend_kind = ""

    def simulate_cut(self, input_id: int) -> None:
        with self._lock:
            backend = self.backend
            kind = self.backend_kind
        if kind != "simulator" or backend is None:
            raise ControllerError("Manual cuts are only available in Test Mode.")
        backend.cut_to(int(input_id))

    def run_macro(self, index: int, held: bool = False) -> None:
        """Fire a switcher macro and mark the moment in the log.

        The note is the point: a graphics macro fired at 00:14:32 is exactly
        the kind of thing an editor needs to find later. A protected macro
        only runs when the request says it was held down — the server's own
        check behind the UI's hold-to-run button.
        """
        with self._lock:
            backend = self.backend
            names = {m.get("index"): m.get("name", "") for m in self.macros}
        if backend is None:
            raise ControllerError("Not connected to a switcher.")
        name = names.get(int(index), "")
        settings = self.prefs.macro_settings.get(name) or {"protected": True}
        if settings.get("protected", True) and not held:
            raise ControllerError(f"“{name or index}” is protected — press and hold to run it.")
        try:
            backend.run_macro(int(index))
        except (RuntimeError, ValueError) as exc:
            raise ControllerError(str(exc)) from exc
        label = names.get(int(index)) or f"Macro {index}"
        with self._lock:
            if self.logging and self.start_mono is not None:
                elapsed = max(0.0, time.monotonic() - self.start_mono)
                self.session.add_note(elapsed, f"Macro: {label}")
                self.unsaved = True
        self._broadcast("state", **self.snapshot())

    def set_macro_settings(self, name: str, protected=None, on_log=None) -> None:
        name = str(name or "")
        if not any(m.get("name") == name for m in self.macros) and \
                name not in self.prefs.macro_settings:
            raise ControllerError(f"No macro called “{name}”.")
        self.prefs.set_macro(name, protected, on_log)
        self._broadcast("state", **self.snapshot())

    # ------------------------------------------------------------ cameras

    def _camera_backend(self):
        with self._lock:
            backend = self.backend
            available = self.camera_available
        if backend is None:
            raise ControllerError("Not connected to a switcher.")
        if not available:
            raise ControllerError("This switcher connection doesn't offer camera control.")
        return backend

    def camera_set(self, cam: int, control_id: str, value) -> None:
        control = camera_params.BY_ID.get(str(control_id))
        if not control:
            raise ControllerError("Unknown camera setting.")
        backend = self._camera_backend()
        try:
            if control["kind"] == "void":
                backend.camera("void", int(cam), control["cat"], control["param"])
                return
            v = float(value)
            v = min(max(v, control["min"]), control["max"])
            current = self.camera_values.get(
                camera_params.key(cam, control["cat"], control["param"]), {}).get("values")
            values = camera_params.values_for(control, v, current)
            backend.camera("set", int(cam), control["cat"], control["param"], values)
        except (RuntimeError, ValueError, TypeError) as exc:
            raise ControllerError(str(exc)) from exc

    def camera_refresh(self, cam: int) -> None:
        """Ask the switcher for every setting this section shows."""
        backend = self._camera_backend()
        seen = set()
        for c in camera_params.CONTROLS:
            if c["kind"] == "void" or (c["cat"], c["param"]) in seen:
                continue
            seen.add((c["cat"], c["param"]))
            try:
                backend.camera("get", int(cam), c["cat"], c["param"])
            except RuntimeError as exc:
                raise ControllerError(str(exc)) from exc

    def update_settings(self, data: dict) -> None:
        with self._lock:
            s = self.session
            # session_name can be set anytime (even while logging)
            if "session_name" in data:
                s.name = str(data["session_name"]).strip()
            if self.logging:
                raise ControllerError("Stop logging before changing other settings.")
            if "rate_key" in data:
                if data["rate_key"] not in FRAME_RATES:
                    raise ControllerError(f"Unknown frame rate {data['rate_key']!r}.")
                s.rate_key = data["rate_key"]
            if "drop_frame" in data:
                s.drop_frame = bool(data["drop_frame"])
            if "start_timecode" in data:
                s.start_timecode = str(data["start_timecode"]).strip()
            if "audio_file" in data:
                s.audio_file = str(data["audio_file"]).strip()
            if "resolution" in data:
                if data["resolution"] not in RESOLUTIONS:
                    raise ControllerError("Unknown resolution.")
                self.width, self.height = RESOLUTIONS[data["resolution"]]
            if "iso_sync" in data:
                self.tc_synced = data["iso_sync"] == "tc"
            if "fcpxml_transitions" in data:
                self.fcpxml_transitions = bool(data["fcpxml_transitions"])
            if "auto_timecode" in data:
                self.auto_timecode = bool(data["auto_timecode"])
            if "auto_start_on_record" in data:
                self.auto_start_on_record = bool(data["auto_start_on_record"])
                self.recorder_watcher.enabled = self.auto_start_on_record
            try:
                s.validate()
            except TimecodeError as exc:
                raise ControllerError(str(exc)) from exc
            # Keep already-logged events' displayed timecodes consistent with
            # a corrected Start Timecode/rate/drop-frame (exports already
            # compute positions live from start_frames; this just makes the
            # log table / JSON / CSV match what actually gets exported).
            s.resync_event_timecodes()
        self._broadcast("state", **self.snapshot())

    def add_flag(self, note: str = "") -> None:
        """One-click "mark this moment as a problem" — deliberately requires
        no typing, so it's fast to hit live. A note can be added/edited
        afterward via set_flag_note()."""
        with self._lock:
            if not self.logging or self.start_mono is None:
                raise ControllerError("Start Logging before marking an issue.")
            elapsed = max(0.0, time.monotonic() - self.start_mono)
            flag = self.session.add_error_flag(elapsed, note)
            self.unsaved = True
        self._broadcast(
            "flag",
            flag={
                "index": len(self.session.flags) - 1,
                "elapsed": round(flag.elapsed, 3),
                "frame": flag.frame,
                "timecode": flag.timecode,
                "note": flag.note,
            },
        )

    def remove_flag(self, index: int) -> None:
        with self._lock:
            try:
                self.session.remove_flag(int(index))
            except IndexError:
                raise ControllerError("That flag no longer exists.") from None
        self._broadcast("state", **self.snapshot())

    def set_flag_note(self, index: int, note: str) -> None:
        with self._lock:
            try:
                self.session.set_flag_note(int(index), str(note))
            except IndexError:
                raise ControllerError("That flag no longer exists.") from None
        self._broadcast("state", **self.snapshot())

    def add_note(self, text: str) -> None:
        """Log an editorial note at the current timecode — graphics cue, broll
        timing, or production notes for later editorial review."""
        with self._lock:
            if not self.logging or self.start_mono is None:
                raise ControllerError("Start Logging before adding a note.")
            elapsed = max(0.0, time.monotonic() - self.start_mono)
            note = self.session.add_note(elapsed, text)
            self.unsaved = True
        self._broadcast(
            "note",
            note={
                "index": len(self.session.notes) - 1,
                "elapsed": round(note.elapsed, 3),
                "frame": note.frame,
                "timecode": note.timecode,
                "text": note.text,
            },
        )

    def upsert_mapping(self, input_id: int, name: str = "", file: str = "") -> None:
        with self._lock:
            input_id = int(input_id)
            mapping = self.session.mappings.get(input_id)
            if mapping is None:
                self.session.mappings[input_id] = CameraMapping(input_id, name, file)
            else:
                mapping.name = name
                mapping.file = file
            # Keep already-logged events' labels in sync with the mapping.
            label = self.session.mappings[input_id].label()
            for e in self.session.events:
                if e.input_id == input_id:
                    e.camera = label
        self._broadcast("state", **self.snapshot())

    def add_input(self) -> int:
        with self._lock:
            next_id = max(self.session.mappings, default=0) + 1
            self.session.mappings[next_id] = CameraMapping(next_id, f"Camera {next_id}")
        self._broadcast("state", **self.snapshot())
        return next_id

    def start_logging(self, resume: bool = False) -> None:
        """Start a fresh log, or with ``resume`` carry on the current one.

        Resuming is for picking up after a crash or an early Stop: new cuts are
        appended to the same log. With switcher timecode the log continues at
        the true position (the gap stays a gap); without it, logging carries
        on from where the log ended.
        """
        with self._lock:
            if self.logging:
                raise ControllerError("Already logging.")
            if self.program_input is None:
                raise ControllerError("Not connected to a switcher.")
            if resume and not self.session.events:
                resume = False
            backend, auto = self.backend, self.auto_timecode

        # Ask the switcher for its own timecode right now, outside the lock —
        # this can block up to a second and must never stall other requests
        # (e.g. the SSE state stream) while it waits. A backend that doesn't
        # support it (Test Mode) simply returns None and nothing changes.
        tc = self._read_switcher_timecode(backend) if auto else None

        with self._lock:
            if self.logging:  # re-check: another call may have won the race
                raise ControllerError("Already logging.")
            s = self.session
            if resume:
                offset = s.duration
                if tc:
                    try:
                        now = parse_timecode(tc[0], s.rate, tc[1])
                        gap = float((now - s.start_frames) / s.rate.fps)
                        if gap >= s.duration:
                            offset = gap
                    except TimecodeError:
                        pass
                self.start_mono = time.monotonic() - offset
                self.status_text = "Logging — resumed."
            else:
                if tc:
                    s.start_timecode, s.drop_frame = tc
                try:
                    s.validate()
                except TimecodeError as exc:
                    raise ControllerError(str(exc)) from exc
                s.begin()
                offset = 0.0
                self.start_mono = time.monotonic()
                self.status_text = "Logging…"
            self.recovered = False
            self.logging = True
            self.session.add_program_change(self.program_input, offset)
            self.unsaved = True
            self._start_ticker()
        self._broadcast("state", **self.snapshot())

    def stop_logging(self) -> None:
        with self._lock:
            if not self.logging:
                raise ControllerError("Not currently logging.")
            self._stop_logging_locked()
        self._autosave()
        self._broadcast("state", **self.snapshot())

    def _stop_logging_locked(self) -> None:
        if self.start_mono is not None:
            self.session.end(time.monotonic() - self.start_mono)
        self.logging = False
        self.start_mono = None
        self.status_text = "Stopped."
        self._ticker_stop.set()

    def _start_ticker(self) -> None:
        self._ticker_stop.clear()

        def run():
            ticks = 0
            while not self._ticker_stop.wait(0.5):
                self._broadcast("clock", **self.current_clock())
                ticks += 1
                if ticks % 10 == 0:   # ~every 5 s, a backup autosave
                    self._autosave()

        self._ticker = threading.Thread(target=run, name="web-clock", daemon=True)
        self._ticker.start()

    # --------------------------------------------------------- recorders

    def _on_recording_started(self) -> None:
        """A deck started rolling: begin logging, if we can and should."""
        with self._lock:
            if self.logging or not self.connected or not self.auto_start_on_record:
                return
        try:
            self.start_logging()
            with self._lock:
                self.status_text = "Logging — started with the recorders."
        except ControllerError:
            return  # not connected, bad timecode: the UI already shows why
        self._broadcast("state", **self.snapshot())

    def set_recorders(self, items: list) -> list[dict]:
        try:
            self.recorders.set_configs(list(items or []))
        except RecorderError as exc:
            raise ControllerError(str(exc)) from exc
        if self.recorders.configs:
            self.recorder_watcher.start()
        self._broadcast("state", **self.snapshot())
        return self.recorders.to_payload()

    def recorder_status(self) -> list[dict]:
        statuses = self.recorder_watcher.poll_once()
        self._broadcast("state", **self.snapshot())
        return [s.to_dict() for s in statuses]

    def record_all(self) -> list[dict]:
        """Roll every configured deck, naming the clip after the session."""
        if not self.recorders.configs:
            raise ControllerError("No recorders are configured.")
        clip = self.session.export_basename() if self.session.name else ""
        statuses = self.recorders.record_all(clip)
        self.recorder_watcher.last = statuses
        if self.auto_start_on_record and any(s.recording for s in statuses):
            self._on_recording_started()
        self._broadcast("state", **self.snapshot())
        return [s.to_dict() for s in statuses]

    def stop_recorders(self) -> list[dict]:
        if not self.recorders.configs:
            raise ControllerError("No recorders are configured.")
        statuses = self.recorders.stop_all()
        self.recorder_watcher.last = statuses
        self._broadcast("state", **self.snapshot())
        return [s.to_dict() for s in statuses]

    # ------------------------------------------------- recorders tab

    def decks_info(self) -> list[dict]:
        return self.recorders.info_all()

    def _deck(self, host: str):
        try:
            return self.recorders.deck(str(host or ""))
        except RecorderError as exc:
            raise ControllerError(str(exc)) from exc

    def deck_transport(self, host: str, action: str, slot: int = 0, clip: int = 0) -> None:
        try:
            self._deck(host).transport_command(str(action), int(slot or 0), int(clip or 0))
        except RecorderError as exc:
            raise ControllerError(str(exc)) from exc

    def deck_config(self, host: str, values: dict) -> None:
        try:
            self._deck(host).set_config(values or {})
        except RecorderError as exc:
            raise ControllerError(str(exc)) from exc

    @staticmethod
    def _slot_fingerprint(info: dict, slot: int) -> dict | None:
        for s in info.get("slots", []):
            if s.get("id") == slot:
                return {"volume": s.get("volume", ""),
                        "clips": [c.get("name") for c in s.get("clips", [])],
                        "mounted": s.get("mounted", False)}
        return None

    def format_review(self, host: str, slot: int) -> dict:
        """Step one of erasing a card: gather what's on it, so the operator
        decides with the file list in front of them."""
        deck = self._deck(host)
        slot = int(slot or 0)
        try:
            info = deck.info()
        except RecorderError as exc:
            raise ControllerError(str(exc)) from exc
        card = next((s for s in info["slots"] if s["id"] == slot), None)
        if not card or not card["mounted"]:
            raise ControllerError(f"There's no media in slot {slot}.")
        if info["recording"]:
            raise ControllerError(f"{deck.config.name} is recording — stop it before formatting.")
        review_id = uuid.uuid4().hex
        now = time.monotonic()
        with self._lock:
            self._format_reviews = {k: v for k, v in self._format_reviews.items()
                                    if now - v["at"] < 600}
            self._format_reviews[review_id] = {
                "host": deck.config.host, "slot": slot, "at": now,
                "fingerprint": self._slot_fingerprint(info, slot),
                "can_format_slot": info["can_format_slot"],
                "can_name": info["can_name_disk"],
            }
        return {"review_id": review_id, "deck": deck.config.name,
                "model": info["model"], "slot": card,
                "can_name_disk": info["can_name_disk"],
                "filesystems": list(FILESYSTEMS)}

    def format_confirm(self, review_id: str, filesystem: str, name: str,
                       confirm: str) -> None:
        if str(confirm or "").strip().upper() != "ERASE":
            raise ControllerError("Type ERASE to confirm.")
        with self._lock:
            review = self._format_reviews.pop(str(review_id or ""), None)
        if not review or time.monotonic() - review["at"] > 600:
            raise ControllerError("That review has expired — open Format again.")
        deck = self._deck(review["host"])
        try:
            info = deck.info()
        except RecorderError as exc:
            raise ControllerError(str(exc)) from exc
        if info["recording"]:
            raise ControllerError(f"{deck.config.name} started recording — nothing was erased.")
        if self._slot_fingerprint(info, review["slot"]) != review["fingerprint"]:
            raise ControllerError("The media in that slot changed since you reviewed it "
                                  "— nothing was erased. Open Format again.")
        try:
            deck.format_slot(review["slot"], str(filesystem), str(name or ""),
                             review["can_format_slot"], review["can_name"])
        except RecorderError as exc:
            raise ControllerError(str(exc)) from exc

    def discover(self, kind: str) -> list[dict]:
        port = {"recorders": 9993, "router": 9990}.get(kind)
        if not port:
            raise ControllerError("Unknown device type.")
        return discovery.scan(port)

    # ---------------------------------------------------------- trace

    def _deck_signals(self) -> dict[str, str | None]:
        out: dict[str, str | None] = {}

        def run(cfg):
            try:
                out[cfg.host] = self.recorders.deck(cfg.host).input_signal()
            except RecorderError:
                out[cfg.host] = None

        threads = [threading.Thread(target=run, args=(c,), daemon=True)
                   for c in self.recorders.configs]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=COMMAND_TIMEOUT_FOR_TRACE)
        return out

    def trace_start(self, blank_input: int, outputs: list | None = None,
                    live_input: int | None = None) -> dict:
        """Find which router output feeds which recorder: one output at a
        time, route a source with no picture and see which deck loses its
        input; if a live test source is given, also route that and see which
        dark deck lights up. The original route goes straight back after
        each step."""
        with self._lock:
            if self.trace.get("running"):
                raise ControllerError("A trace is already running.")
            if self.logging:
                raise ControllerError("Stop logging first — tracing briefly blanks router outputs.")
        if not self.recorders.configs:
            raise ControllerError("Add the recorders first (Recorders → Find recorders).")
        if self.recorders.any_recording():
            raise ControllerError("A recorder is recording — tracing would put black into it.")
        state = self.router_state()
        if not state.get("reachable"):
            raise ControllerError(state.get("error") or "The router isn't reachable.")
        blank = int(blank_input)
        if not (0 <= blank < len(state["inputs"])):
            raise ControllerError("Pick the router input that has nothing plugged in.")
        live = int(live_input) if live_input is not None and int(live_input) >= 0 else None
        if live is not None and not (0 <= live < len(state["inputs"])):
            raise ControllerError("Pick a test source that has a picture.")
        before = self._deck_signals()
        watchable = [h for h, v in before.items() if v not in (None, "none")]
        dark = [h for h, v in before.items() if v == "none"] if live is not None else []
        if not watchable and not dark:
            raise ControllerError("None of the recorders report an input picture right now "
                                  "(or their firmware doesn't say). Pick a test source with a "
                                  "picture so dark recorders can be found too.")
        todo = [int(o) for o in (outputs if outputs else range(len(state["outputs"])))]
        todo = [o for o in todo if 0 <= o < len(state["outputs"])
                and state["locks"][o] == "U" and state["routing"][o] != blank]
        names = {c.host: c.name for c in self.recorders.configs}
        self._trace_stop.clear()
        with self._lock:
            self.trace = {"running": True, "results": [], "done": 0, "total": len(todo),
                          "blank": blank, "live": live,
                          "watching": [names[h] for h in watchable + dark],
                          "unreported": [names[h] for h, v in before.items() if v is None]}
        threading.Thread(target=self._run_trace,
                         args=(state, blank, live, todo, watchable, dark, names),
                         name="signal-trace", daemon=True).start()
        return self.trace

    def _run_trace(self, state, blank, live, todo, watchable, dark, names) -> None:
        hub = self._router()

        def probe(o, source, original):
            try:
                hub.route({o: source})
                time.sleep(1.6)                          # let the decks notice
                return self._deck_signals()
            finally:
                try:
                    hub.route({o: original})
                except VideohubError:
                    time.sleep(0.5)
                    hub.route({o: original})             # one retry, then give up loudly

        try:
            for o in todo:
                if self._trace_stop.is_set():
                    break
                original = state["routing"][o]
                lost = []
                if watchable:
                    after = probe(o, blank, original)
                    lost = [names[h] for h in watchable if after.get(h) == "none"]
                if dark and live is not None and original != live and not lost:
                    after = probe(o, live, original)
                    lost += [names[h] for h in dark if after.get(h) not in (None, "none")]
                result = {"output": o, "output_label": state["outputs"][o],
                          "source_label": state["inputs"][original], "feeds": lost}
                with self._lock:
                    self.trace["results"].append(result)
                    self.trace["done"] += 1
                self._broadcast("trace", trace=self.trace)
                if lost:
                    time.sleep(1.0)                      # give decks time to recover
        except VideohubError as exc:
            with self._lock:
                self.trace["error"] = f"Router problem during trace: {exc}. Check routing."
        finally:
            with self._lock:
                self.trace["running"] = False
            self._broadcast("trace", trace=self.trace)

    def trace_stop(self) -> None:
        self._trace_stop.set()

    # ---------------------------------------------------------- router

    def _router(self) -> Videohub:
        host = self.prefs.router["host"]
        if not host:
            raise ControllerError("No router is set up yet.")
        return Videohub(host)

    def router_state(self) -> dict:
        router = self.prefs.router
        if not router["host"]:
            return {"host": "", "presets": router["presets"]}
        try:
            state = self._router().state().to_dict()
            return {**router, "reachable": True, **state}
        except VideohubError as exc:
            return {**router, "reachable": False, "error": str(exc)}

    def router_set_host(self, host: str) -> dict:
        self.prefs.set_router(host=host)
        return self.router_state()

    def _router_call(self, fn, *args):
        try:
            fn(*args)
        except VideohubError as exc:
            raise ControllerError(str(exc)) from exc

    def router_route(self, routes: dict) -> None:
        pairs = {int(o): int(i) for o, i in (routes or {}).items()}
        if not pairs:
            raise ControllerError("Nothing to route.")
        self._router_call(self._router().route, pairs)

    def router_labels(self, kind: str, labels: dict) -> None:
        self._router_call(self._router().set_labels, kind,
                          {int(k): str(v) for k, v in (labels or {}).items()})

    def router_lock(self, output: int, locked: bool) -> None:
        self._router_call(self._router().set_lock, int(output), bool(locked))

    def router_save_preset(self, name: str, routes: dict | None = None) -> list:
        name = " ".join(str(name or "").split())
        if not name:
            raise ControllerError("Give the preset a name.")
        if routes is None:
            state = self.router_state()
            if not state.get("reachable"):
                raise ControllerError(state.get("error") or "Router unreachable.")
            routes = {str(o): i for o, i in enumerate(state["routing"])}
        presets = [p for p in self.prefs.router["presets"] if p["name"] != name]
        presets.append({"name": name, "routes": {str(int(o)): int(i) for o, i in routes.items()}})
        self.prefs.set_router(presets=presets)
        return presets

    def router_apply_preset(self, name: str) -> None:
        preset = next((p for p in self.prefs.router["presets"] if p["name"] == name), None)
        if not preset:
            raise ControllerError(f"No preset called “{name}”.")
        self.router_route(preset["routes"])

    def router_delete_preset(self, name: str) -> list:
        presets = [p for p in self.prefs.router["presets"] if p["name"] != name]
        self.prefs.set_router(presets=presets)
        return presets

    # ------------------------------------------------------------ TVs

    def _display_configs(self) -> list:
        out = []
        for d in self.prefs.displays:
            try:
                out.append(displays.DisplayConfig.from_dict(d))
            except displays.DisplayError:
                continue
        return out

    def displays_state(self) -> dict:
        configs = self._display_configs()
        results: list[dict] = [{} for _ in configs]

        def run(i, cfg):
            drv = displays.driver_for(cfg)
            try:
                on = drv.is_on()
            except Exception:
                on = False
            results[i] = {**cfg.to_dict(), "on": on, **drv.describe()}

        threads = [threading.Thread(target=run, args=(i, c), daemon=True)
                   for i, c in enumerate(configs)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=5)
        return {"displays": [r or {**c.to_dict(), "on": False}
                             for r, c in zip(results, configs)],
                "catalog": displays.catalog()}

    def set_displays(self, items: list) -> dict:
        try:
            configs = [displays.DisplayConfig.from_dict(d) for d in (items or [])]
        except displays.DisplayError as exc:
            raise ControllerError(str(exc)) from exc
        hosts = [c.host for c in configs]
        if len(hosts) != len(set(hosts)):
            raise ControllerError("The same TV is listed twice.")
        self.prefs.set_displays([c.to_dict() for c in configs])
        return self.displays_state()

    def probe_display(self, host: str) -> dict:
        host = str(host or "").strip()
        if not host:
            raise ControllerError("Type the TV's IP address.")
        return displays.probe(host)

    def scan_displays(self, networks: list | None = None) -> list[dict]:
        try:
            return displays.scan(networks or [])
        except displays.DisplayError as exc:
            raise ControllerError(str(exc)) from exc

    def _display(self, host: str):
        for c in self._display_configs():
            if c.host == host:
                return displays.driver_for(c)
        raise ControllerError("That TV isn't set up any more.")

    def display_details(self, host: str) -> dict:
        try:
            return self._display(host).details()
        except displays.DisplayError as exc:
            raise ControllerError(str(exc)) from exc

    def display_command(self, hosts: list, action: str, value=None) -> list[dict]:
        """Run one command on one or many TVs; each reports its own result."""
        results = []
        for host in hosts or []:
            try:
                drv = self._display(str(host))
                if action == "power_on":
                    drv.power_on()
                elif action == "power_off":
                    drv.power_off()
                elif action == "key":
                    drv.send_key(str(value))
                elif action == "volume" and "volume" in drv.features:
                    drv.set_volume(int(value))
                elif action == "source" and "sources" in drv.features:
                    v = value if isinstance(value, dict) else {"id": value}
                    drv.set_source(str(v.get("id", "")), str(v.get("name", "")))
                elif action == "app" and "apps" in drv.features:
                    drv.launch_app(value if isinstance(value, dict) else {"appId": value})
                elif action == "pair" and "pair" in drv.features:
                    drv.pair(str(value))
                else:
                    raise displays.DisplayError(f"{drv.config.name} can't do “{action}”.")
                results.append({"host": host, "ok": True})
            except (displays.DisplayError, ControllerError, ValueError) as exc:
                results.append({"host": host, "ok": False, "error": str(exc)})
        if len(results) == 1 and not results[0]["ok"]:
            raise ControllerError(results[0]["error"])
        return results

    # --------------------------------------------------------- templates

    def _templates_payload(self) -> list[dict]:
        try:
            return self.templates.list()
        except OSError:
            return []

    def template_payload(self) -> dict:
        """The current setup, in template form (no per-show values)."""
        with self._lock:
            s = self.session
            return {
                "rate_key": s.rate_key,
                "drop_frame": s.drop_frame,
                "resolution": f"{self.width}x{self.height}",
                "iso_sync": "tc" if self.tc_synced else "start",
                "fcpxml_transitions": self.fcpxml_transitions,
                "auto_timecode": self.auto_timecode,
                "audio_file": s.audio_file,
                "auto_start_on_record": self.auto_start_on_record,
                "recorders": self.recorders.to_payload(),
                "mappings": [
                    {"input_id": m.input_id, "name": m.name, "file": m.file}
                    for m in sorted(s.mappings.values(), key=lambda m: m.input_id)
                ],
            }

    def save_template(self, name: str) -> dict:
        try:
            saved = self.templates.save(name, self.template_payload())
        except TemplateError as exc:
            raise ControllerError(str(exc)) from exc
        self._broadcast("state", **self.snapshot())
        return saved

    def apply_template(self, name: str) -> None:
        """Load a saved setup over the current one. Never touches the log."""
        try:
            data = self.templates.load(name)
        except TemplateError as exc:
            raise ControllerError(str(exc)) from exc
        with self._lock:
            if self.logging:
                raise ControllerError("Stop logging before loading a template.")
        settings = {k: data[k] for k in TEMPLATE_FIELDS if k in data}
        self.update_settings(settings)   # validates, then broadcasts
        if isinstance(data.get("recorders"), list):
            self.set_recorders(data["recorders"])
        mappings = data.get("mappings") or []
        with self._lock:
            if mappings:
                self.session.mappings = {
                    int(m["input_id"]): CameraMapping(
                        int(m["input_id"]), m.get("name", ""), m.get("file", "")
                    )
                    for m in mappings if "input_id" in m
                }
                for e in self.session.events:
                    e.camera = self.session.camera_label(e.input_id)
            self.status_text = f"Loaded template '{data.get('name', name)}'."
        self._broadcast("state", **self.snapshot())

    def delete_template(self, name: str) -> None:
        try:
            self.templates.delete(name)
        except TemplateError as exc:
            raise ControllerError(str(exc)) from exc
        self._broadcast("state", **self.snapshot())

    # ------------------------------------------------------- new session

    def new_session(self, force: bool = False, keep_settings: bool = True) -> None:
        """Clear the log for the next show, keeping the production setup.

        Refuses when the current log holds unexported work unless ``force`` is
        passed — the UI turns that refusal into a confirmation dialog, so a
        show's cuts can't be thrown away by a mis-click.
        """
        with self._lock:
            if self.logging:
                raise ControllerError("Stop logging before starting a new session.")
            if self.unsaved and self.session.events and not force:
                raise ControllerError(
                    f"This session has {len(self.session.events)} unsaved events. "
                    "Export the log first, or confirm to discard it."
                )
            old = self.session
            fresh = LogSession()
            if keep_settings:
                fresh.rate_key = old.rate_key
                fresh.drop_frame = old.drop_frame
                fresh.start_timecode = old.start_timecode
                fresh.audio_file = old.audio_file
                fresh.switcher_product = old.switcher_product
                fresh.mappings = {
                    i: CameraMapping(m.input_id, m.name, m.file)
                    for i, m in old.mappings.items()
                }
            self.session = fresh
            self.loaded_name = ""
            self.recovered = False
            self.unsaved = False
            self.status_text = ("Connected: " + fresh.switcher_product
                                if self.connected and fresh.switcher_product
                                else "New session ready.")
        self.mark_saved()  # drop the autosave: the old log is deliberately gone
        self._broadcast("state", **self.snapshot())

    # ------------------------------------------------------- save package

    def save_package(self, folder: str = "", run_cleanup: bool | None = None,
                     use_fallback: bool = False) -> dict:
        """Write the whole session as one folder inside ``folder``.

        ``folder`` defaults to this computer's save location. When it can't be
        used (a disconnected NAS) the save is refused with the reason and the
        local fallback, so the operator decides; ``use_fallback`` saves to that
        local folder instead.
        """
        with self._lock:
            if self.logging:
                raise ControllerError("Stop logging before saving the session.")
            if not self.session.events:
                raise ControllerError("There are no logged cuts to save yet.")
        target = str(fallback_save_dir()) if use_fallback else (
            folder.strip() or self.prefs.effective_save_dir())
        problem = folder_problem(target)
        if problem:
            raise SaveLocationError(problem, target, str(fallback_save_dir()))
        options = PackageOptions(
            width=self.width, height=self.height,
            tc_synced_isos=self.tc_synced, transitions=self.fcpxml_transitions,
            run_cleanup=self.prefs.run_cleanup if run_cleanup is None
            else bool(run_cleanup),
            cleanup=self.prefs.cleanup_config(),
        )
        with self._lock:
            session = LogSession.from_json(self.session.to_json())
        try:
            result = write_package(session, Path(target), options)
        except OSError as exc:
            raise SaveLocationError(
                f"Couldn't save in “{target}”: {exc.strerror or exc}",
                target, str(fallback_save_dir())) from exc
        self.mark_saved()
        with self._lock:
            self.status_text = f"Saved “{result.folder.name}”."
            self.last_saved_folder = str(result.folder)
        self._broadcast("state", **self.snapshot())
        return {"folder": str(result.folder), "files": result.files,
                "issues": result.issues, "counts": result.counts,
                "cleanup": options.run_cleanup}

    # ------------------------------------------------------- preferences

    def update_prefs(self, values: dict) -> None:
        try:
            self.prefs.update(values or {})
        except PrefsError as exc:
            raise ControllerError(str(exc)) from exc
        except OSError as exc:
            raise ControllerError(f"Couldn't save preferences: {exc}") from exc
        self._broadcast("state", **self.snapshot())

    def set_logo(self, filename: str, data: bytes, variant: str = "dark") -> None:
        try:
            self.prefs.set_logo(filename, data, variant)
        except PrefsError as exc:
            raise ControllerError(str(exc)) from exc
        self._broadcast("state", **self.snapshot())

    def remove_logo(self, variant: str = "dark") -> None:
        try:
            self.prefs.remove_logo(variant)
        except PrefsError as exc:
            raise ControllerError(str(exc)) from exc
        self._broadcast("state", **self.snapshot())

    # ------------------------------------------------------- session load

    def load_session_json(self, text: str, name: str = "") -> None:
        with self._lock:
            if self.logging:
                raise ControllerError("Stop logging before loading a log.")
            try:
                self.session = LogSession.from_json(text)
            except (ValueError, KeyError) as exc:
                raise ControllerError(f"Could not load log: {exc}") from exc
            self.loaded_name = name or "loaded log"
            self.unsaved = False   # it came from a file, so a copy exists
            self.status_text = f"Loaded {self.loaded_name} ({len(self.session.events)} events)."
        self._broadcast("state", **self.snapshot())

    # ---------------------------------------------------------- control lock

    def claim_control(self, token: str, label: str, force: bool = False) -> None:
        """Take the driver's seat. Fails if someone else holds it (unless force)."""
        if not token:
            raise ControllerError("A control token is required.")
        with self._lock:
            if self.control_token is None or force or token == self.control_token:
                self.control_token = token
                self.control_label = label or "A device"
            else:
                raise ControlDenied(
                    f"{self.control_label} is currently driving. "
                    "Use 'Take control' to take over."
                )
        self._broadcast("control", control_label=self.control_label)

    def release_control(self, token: str) -> None:
        with self._lock:
            if token and token == self.control_token:
                self.control_token = None
                self.control_label = ""
        self._broadcast("control", control_label=self.control_label)

    def enforce_control(self, token: str | None) -> None:
        """Guard mutating actions. While unclaimed, anyone may act (and the
        first claim locks it). Once claimed, only the holder's token passes."""
        with self._lock:
            if self.control_token is None:
                return
            if token != self.control_token:
                raise ControlDenied(
                    f"{self.control_label} is currently driving. "
                    "Use 'Take control' to make changes."
                )

    # --------------------------------------------------------- shutdown

    def shutdown(self) -> None:
        self._ticker_stop.set()
        self._idle_stop.set()
        self.updates.stop()
        self.recorder_watcher.stop()
        try:
            self.disconnect()
        except Exception:
            pass
