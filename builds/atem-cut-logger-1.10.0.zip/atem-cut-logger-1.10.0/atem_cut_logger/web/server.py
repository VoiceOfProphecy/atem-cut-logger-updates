"""HTTP + SSE layer over :class:`Controller` — stdlib only, no dependencies.

Routes are deliberately small and JSON-in/JSON-out. Live updates use
Server-Sent Events (``/api/stream``), which needs no client library — the
browser's built-in ``EventSource`` is enough. Export endpoints stream the
generated file with a download filename.
"""

from __future__ import annotations

import base64
import binascii
import ipaddress
import json
import queue
import socket
import subprocess
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from ..analysis import CleanupConfig, analyze
from ..analysis.cleaned import export_cleaned_fcpxml
from ..analysis.markers import export_markers_fcpxml
from ..analysis.report import render_csv, render_text
from ..edl import export_edl
from ..fcpxml import export_fcpxml, export_flags_fcpxml
from ..prefs import LOGO_TYPES, list_folder
from .controller import (
    ControlDenied,
    Controller,
    ControllerError,
    SaveLocationError,
)

# Mutating endpoints require the control lock; reads and control ops do not.
_MUTATING = {
    "/api/connect", "/api/disconnect", "/api/settings", "/api/mapping",
    "/api/mapping/add", "/api/logging/start", "/api/logging/stop",
    "/api/simulate/cut", "/api/session/load",
    "/api/flag", "/api/flag/remove", "/api/flag/note", "/api/note",
    "/api/update/apply",
    "/api/session/new", "/api/template/save", "/api/template/apply",
    "/api/template/delete",
    "/api/recorders", "/api/recorders/record", "/api/recorders/stop",
    "/api/macro/run",
    "/api/session/save", "/api/prefs", "/api/logo", "/api/logo/remove",
    "/api/fs/list", "/api/fs/mkdir", "/api/reveal",
    "/api/decks/transport", "/api/decks/config", "/api/decks/format/review",
    "/api/decks/format", "/api/router/host", "/api/router/route",
    "/api/router/labels", "/api/router/lock", "/api/router/preset/save",
    "/api/router/preset/apply", "/api/router/preset/delete",
    "/api/displays/save", "/api/displays/command",
    "/api/macro/settings", "/api/camera/set", "/api/camera/refresh",
    "/api/trace/start", "/api/trace/stop",
}

STATIC_DIR = Path(__file__).parent / "static"
MAX_BODY_BYTES = 16 * 1024 * 1024  # generous for a long show's log; blocks abuse
_CONTENT_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".svg": "image/svg+xml",
    ".ico": "image/x-icon",
}


class Handler(BaseHTTPRequestHandler):
    server_version = "ATEMCutLogger/1.0"
    controller: Controller  # injected on the server instance

    # ------------------------------------------------------------- helpers

    def log_message(self, *args):  # silence default request logging
        pass

    def _send_json(self, obj, status=200):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _send_download(self, text, filename, content_type="application/xml"):
        body = text.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self) -> dict:
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            raise ControllerError("Invalid Content-Length.")
        if length < 0 or length > MAX_BODY_BYTES:
            raise ControllerError("Request body too large.")
        if not length:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw or b"{}")
        except json.JSONDecodeError:
            raise ControllerError("Request body was not valid JSON.")

    @property
    def ctrl(self) -> Controller:
        return self.server.controller  # type: ignore[attr-defined]

    def _host_allowed(self) -> bool:
        """Block DNS-rebinding: only localhost, IP literals, or this machine's
        own hostname may set the Host header. A rebinding attack always arrives
        under an attacker-controlled *domain name*, which none of these match."""
        raw = self.headers.get("Host", "")
        hostname = (raw[1:].split("]")[0] if raw.startswith("[")
                    else raw.split(":")[0]).lower()
        if hostname in ("", "localhost"):
            return True
        try:
            ipaddress.ip_address(hostname)
            return True
        except ValueError:
            pass
        return hostname in getattr(self.server, "allowed_hostnames", set())

    # --------------------------------------------------------------- GET

    def do_GET(self):
        if not self._host_allowed():
            return self._send_json({"error": "Host not allowed"}, status=403)
        parsed = urlparse(self.path)
        path = parsed.path
        try:
            if path == "/api/state":
                return self._send_json(self.ctrl.snapshot())
            if path == "/api/update/status":
                return self._send_json(self.ctrl.updates.status())
            if path == "/api/stream":
                return self._stream()
            if path == "/api/logo":
                return self._logo(parse_qs(parsed.query).get("variant", ["dark"])[0])
            if path.startswith("/api/export/"):
                return self._export(path, parse_qs(parsed.query))
            if path.startswith("/api/analyze/"):
                return self._analyze_download(path, parse_qs(parsed.query))
            return self._static(path)
        except (ControllerError, ValueError) as exc:
            self._send_json({"error": str(exc)}, status=400)
        except BrokenPipeError:
            pass
        except Exception:
            self._safe_500()

    # -------------------------------------------------------------- POST

    def do_POST(self):
        if not self._host_allowed():
            return self._send_json({"error": "Host not allowed"}, status=403)
        path = urlparse(self.path).path
        try:
            body = self._read_json()
            if path in _MUTATING:
                self.ctrl.enforce_control(self.headers.get("X-Control-Token"))
            result = self._dispatch_post(path, body)
            self._send_json(result if result is not None else {"ok": True})
        except ControlDenied as exc:
            self._send_json({"error": str(exc)}, status=403)
        except SaveLocationError as exc:
            self._send_json({"error": str(exc), "location_problem": True,
                             "folder": exc.folder, "fallback": exc.fallback},
                            status=409)
        except (ControllerError, ValueError, TypeError) as exc:
            self._send_json({"error": str(exc)}, status=400)
        except BrokenPipeError:
            pass
        except Exception:
            self._safe_500()

    def _safe_500(self):
        """Report an unexpected error without leaking internals."""
        try:
            self._send_json({"error": "Internal server error"}, status=500)
        except Exception:
            pass

    def _dispatch_post(self, path, body):
        c = self.ctrl
        if path == "/api/connect":
            c.connect(body.get("mode", ""), body.get("ip", ""))
        elif path == "/api/disconnect":
            c.disconnect()
        elif path == "/api/settings":
            c.update_settings(body)
        elif path == "/api/mapping":
            c.upsert_mapping(body.get("input_id"), body.get("name", ""),
                             body.get("file", ""))
        elif path == "/api/mapping/add":
            return {"input_id": c.add_input()}
        elif path == "/api/logging/start":
            c.start_logging(bool(body.get("resume")))
        elif path == "/api/logging/stop":
            c.stop_logging()
        elif path == "/api/simulate/cut":
            c.simulate_cut(body.get("input_id"))
        elif path == "/api/session/load":
            c.load_session_json(body.get("json", ""), body.get("name", ""))
        elif path == "/api/flag":
            c.add_flag(body.get("note", ""))
        elif path == "/api/flag/remove":
            c.remove_flag(body.get("index"))
        elif path == "/api/flag/note":
            c.set_flag_note(body.get("index"), body.get("note", ""))
        elif path == "/api/note":
            c.add_note(body.get("text", ""))
        elif path == "/api/control/claim":
            c.claim_control(self.headers.get("X-Control-Token", ""),
                            body.get("label", ""), bool(body.get("force")))
        elif path == "/api/control/release":
            c.release_control(self.headers.get("X-Control-Token", ""))
        elif path == "/api/macro/run":
            c.run_macro(body.get("index"), bool(body.get("held")))
        elif path == "/api/macro/settings":
            c.set_macro_settings(body.get("name"), body.get("protected"), body.get("on_log"))
        elif path == "/api/camera/set":
            c.camera_set(body.get("cam") or 0, body.get("control"), body.get("value"))
        elif path == "/api/camera/refresh":
            c.camera_refresh(body.get("cam") or 0)
        elif path == "/api/recorders":
            return {"recorders": c.set_recorders(body.get("recorders") or [])}
        elif path == "/api/recorders/status":
            return {"status": c.recorder_status()}
        elif path == "/api/recorders/record":
            return {"status": c.record_all()}
        elif path == "/api/recorders/stop":
            return {"status": c.stop_recorders()}
        elif path == "/api/session/new":
            c.new_session(bool(body.get("force")))
        elif path == "/api/template/save":
            return {"template": c.save_template(body.get("name", ""))}
        elif path == "/api/template/apply":
            c.apply_template(body.get("name", ""))
        elif path == "/api/template/delete":
            c.delete_template(body.get("name", ""))
        elif path == "/api/update/check":
            return self.ctrl.check_for_updates()
        elif path == "/api/update/apply":
            return self.ctrl.apply_update(bool(body.get("restart", True)))
        elif path == "/api/analyze":
            return self._run_analysis(body).summary_payload
        elif path == "/api/session/save":
            return c.save_package(str(body.get("folder") or ""),
                                  body.get("run_cleanup"),
                                  bool(body.get("use_fallback")))
        elif path == "/api/prefs":
            c.update_prefs(body)
        elif path == "/api/logo":
            try:
                data = base64.b64decode(str(body.get("data") or ""), validate=True)
            except (binascii.Error, ValueError):
                raise ControllerError("That image couldn't be read.")
            c.set_logo(str(body.get("filename") or ""), data,
                       str(body.get("variant") or "dark"))
        elif path == "/api/logo/remove":
            c.remove_logo(str(body.get("variant") or "dark"))
        elif path == "/api/fs/list":
            return list_folder(str(body.get("path") or ""))
        elif path == "/api/fs/mkdir":
            return self._mkdir(str(body.get("path") or ""),
                               str(body.get("name") or ""))
        elif path == "/api/reveal":
            self._reveal()
        elif path == "/api/decks":
            return {"decks": c.decks_info()}
        elif path == "/api/decks/transport":
            c.deck_transport(body.get("host"), body.get("action"),
                             body.get("slot") or 0, body.get("clip") or 0)
        elif path == "/api/decks/config":
            c.deck_config(body.get("host"), body.get("values") or {})
        elif path == "/api/decks/format/review":
            return c.format_review(body.get("host"), body.get("slot") or 0)
        elif path == "/api/decks/format":
            c.format_confirm(body.get("review_id"), body.get("filesystem"),
                             body.get("name", ""), body.get("confirm", ""))
        elif path == "/api/discover":
            return {"found": c.discover(str(body.get("kind") or ""))}
        elif path == "/api/router":
            return c.router_state()
        elif path == "/api/router/host":
            return c.router_set_host(str(body.get("host") or ""))
        elif path == "/api/router/route":
            c.router_route(body.get("routes") or {})
        elif path == "/api/router/labels":
            c.router_labels(str(body.get("kind") or ""), body.get("labels") or {})
        elif path == "/api/router/lock":
            c.router_lock(body.get("output"), bool(body.get("locked")))
        elif path == "/api/router/preset/save":
            return {"presets": c.router_save_preset(body.get("name"), body.get("routes"))}
        elif path == "/api/router/preset/apply":
            c.router_apply_preset(str(body.get("name") or ""))
        elif path == "/api/displays":
            return c.displays_state()
        elif path == "/api/displays/save":
            return c.set_displays(body.get("displays") or [])
        elif path == "/api/displays/scan":
            return {"found": c.scan_displays(body.get("networks") or [])}
        elif path == "/api/displays/probe":
            return c.probe_display(body.get("host"))
        elif path == "/api/displays/details":
            return c.display_details(str(body.get("host") or ""))
        elif path == "/api/displays/command":
            return {"results": c.display_command(body.get("hosts") or [],
                                                 str(body.get("action") or ""),
                                                 body.get("value"))}
        elif path == "/api/trace/start":
            return c.trace_start(body.get("blank") if body.get("blank") is not None else -1,
                                 body.get("outputs"), body.get("live"))
        elif path == "/api/trace/stop":
            c.trace_stop()
        elif path == "/api/trace":
            return c.trace
        elif path == "/api/router/preset/delete":
            return {"presets": c.router_delete_preset(str(body.get("name") or ""))}
        else:
            raise ControllerError(f"Unknown endpoint {path}.")
        return {"ok": True}

    # ------------------------------------------------------------- SSE

    def _stream(self):
        q = self.ctrl.subscribe()
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "keep-alive")
        self.end_headers()
        try:
            # Prime the client with the current full state.
            self._sse_write({"type": "state", **self.ctrl.snapshot()})
            while True:
                try:
                    message = q.get(timeout=15)
                except queue.Empty:
                    self.wfile.write(b": keep-alive\n\n")
                    self.wfile.flush()
                    continue
                self._sse_write(message)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        finally:
            self.ctrl.unsubscribe(q)

    def _sse_write(self, obj):
        self.wfile.write(f"data: {json.dumps(obj)}\n\n".encode("utf-8"))
        self.wfile.flush()

    # ---------------------------------------------------------- exports

    def _export(self, path, query):
        c = self.ctrl
        s = c.session
        # Use session's export basename (session name if set, else start timecode)
        name = s.export_basename() or "atem-cuts"
        if path == "/api/export/json":
            payload = s.to_json()
            c.mark_saved()  # a real copy now exists; clear the crash marker
            return self._send_download(payload, f"{name}.atemlog.json",
                                       "application/json")
        if path == "/api/export/csv":
            return self._send_download(s.to_csv(), f"{name}.csv", "text/csv")
        if path == "/api/export/edl":
            if not s.events:
                raise ControllerError("No events to export.")
            return self._send_download(export_edl(s, title=name), f"{name}.edl",
                                       "text/plain")
        if path == "/api/export/fcpxml":
            if not s.events:
                raise ControllerError("No events to export.")
            xml = export_fcpxml(
                s, width=c.width, height=c.height,
                tc_synced_isos=c.tc_synced, project_name=name,
                transitions=c.fcpxml_transitions,
            )
            return self._send_download(xml, f"{name}.fcpxml")
        if path == "/api/export/flags-fcpxml":
            if not s.events:
                raise ControllerError("No events to export.")
            if not s.flags:
                raise ControllerError("No flagged moments to export.")
            xml = export_flags_fcpxml(
                s, width=c.width, height=c.height,
                tc_synced_isos=c.tc_synced, project_name=f"{name} — Flags",
                transitions=c.fcpxml_transitions,
            )
            return self._send_download(xml, f"{name}-flags.fcpxml")
        raise ControllerError("Unknown export.")

    # --------------------------------------------------------- analysis

    def _run_analysis(self, body):
        c = self.ctrl
        cfg_data = body.get("config") if isinstance(body, dict) else None
        config = CleanupConfig.from_dict(cfg_data) if cfg_data else CleanupConfig()
        result = analyze(c.session, config)

        class _R:
            summary_payload = {
                "issues": [
                    {
                        "timecode": i.timecode, "type": i.issue_type,
                        "title": i.title, "severity": i.severity,
                        "camera": i.camera, "detail": i.detail,
                        "suggestion": i.suggestion,
                    }
                    for i in result.issues
                ],
                "counts": result.issues_by_type(),
                "screen_time": [
                    {"input": iid, "camera": c.session.camera_label(iid),
                     "fraction": frac, "shots": cnt}
                    for iid, (frames, frac, cnt) in sorted(result.screen_time().items())
                ],
            }

        return _R()

    def _analyze_download(self, path, query):
        c = self.ctrl
        name = (c.loaded_name or "atem-cuts").replace(".atemlog.json", "")
        cfg = _config_from_query(query)
        result = analyze(c.session, cfg)
        if path == "/api/analyze/report":
            fmt = query.get("format", ["txt"])[0]
            if fmt == "csv":
                return self._send_download(render_csv(result),
                                           f"{name}-cleanup.csv", "text/csv")
            return self._send_download(render_text(result),
                                       f"{name}-cleanup.txt", "text/plain")
        if path == "/api/analyze/markers":
            xml = export_markers_fcpxml(result, width=c.width, height=c.height,
                                        tc_synced_isos=c.tc_synced,
                                        transitions=c.fcpxml_transitions,
                                        project_name=f"{name} — Markers")
            return self._send_download(xml, f"{name}-markers.fcpxml")
        if path == "/api/analyze/cleaned":
            xml, clean = export_cleaned_fcpxml(result, width=c.width, height=c.height,
                                               tc_synced_isos=c.tc_synced,
                                               transitions=c.fcpxml_transitions,
                                               project_name=f"{name} — Cleaned")
            fn = f"{name}-cleaned.fcpxml"
            self._send_download(xml, fn)
            return
        raise ControllerError("Unknown analysis download.")

    # ---------------------------------------------------- logo & folders

    def _logo(self, variant: str):
        prefs = self.ctrl.prefs
        if variant not in ("dark", "light"):
            variant = "dark"
        other = "light" if variant == "dark" else "dark"
        p = prefs.logo_path(variant) or prefs.logo_path(other)
        if p is None:
            return self._send_json({"error": "No logo"}, status=404)
        body = p.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", LOGO_TYPES[p.suffix.lower()])
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        # An uploaded SVG is only ever shown as an <img>; this keeps it inert
        # even if someone opens it directly.
        self.send_header("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'")
        self.end_headers()
        self.wfile.write(body)

    def _mkdir(self, parent: str, name: str) -> dict:
        name = name.strip()
        if not name or name in (".", "..") or any(c in name for c in '/\\:'):
            raise ControllerError("Give the new folder a plain name.")
        target = Path(parent).expanduser() / name
        try:
            target.mkdir()
        except FileExistsError:
            pass
        except OSError as exc:
            raise ControllerError(f"Couldn't create the folder: {exc.strerror or exc}")
        return list_folder(str(target))

    def _reveal(self):
        """Open the folder just saved in Finder / Explorer on this computer.
        Only ever the last saved folder, never a path from the request."""
        folder = self.ctrl.last_saved_folder
        if not folder or not Path(folder).is_dir():
            raise ControllerError("Nothing has been saved yet.")
        opener = ({"darwin": ["open"], "win32": ["explorer"]}
                  .get(sys.platform, ["xdg-open"]))
        try:
            subprocess.Popen([*opener, folder])
        except OSError as exc:
            raise ControllerError(f"Couldn't open the folder: {exc}")

    # ---------------------------------------------------------- static

    def _static(self, path):
        rel = "index.html" if path in ("/", "") else path.lstrip("/")
        target = (STATIC_DIR / rel).resolve()
        # Reject anything that escapes the static dir (path traversal). Using
        # relative_to avoids the prefix-match pitfall of startswith().
        try:
            target.relative_to(STATIC_DIR.resolve())
        except ValueError:
            return self._send_json({"error": "Not found"}, status=404)
        if not target.is_file():
            return self._send_json({"error": "Not found"}, status=404)
        body = target.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type",
                         _CONTENT_TYPES.get(target.suffix, "application/octet-stream"))
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def _config_from_query(query) -> CleanupConfig:
    def num(key, cast=float):
        if key in query:
            return cast(query[key][0])
        return None

    kwargs = {}
    for key, cast in (
        ("min_shot_seconds", float), ("max_shot_seconds", float),
        ("accidental_cut_seconds", float), ("back_forth_seconds", float),
        ("repeat_window_seconds", float), ("repeat_count", int),
        ("solo_window_seconds", float), ("solo_fraction", float),
        ("wide_camera_input", int),
    ):
        value = num(key, cast)
        if value is not None:
            kwargs[key] = value
    return CleanupConfig(**kwargs)


def _allowed_hostnames() -> set[str]:
    names = {"localhost"}
    for getter in (socket.gethostname, socket.getfqdn):
        try:
            names.add(getter().lower())
        except OSError:
            pass
    return names


def make_server(host: str, port: int, controller: Controller | None = None):
    controller = controller or Controller()
    httpd = ThreadingHTTPServer((host, port), Handler)
    httpd.controller = controller  # type: ignore[attr-defined]
    httpd.allowed_hostnames = _allowed_hostnames()  # type: ignore[attr-defined]
    httpd.daemon_threads = True
    return httpd
