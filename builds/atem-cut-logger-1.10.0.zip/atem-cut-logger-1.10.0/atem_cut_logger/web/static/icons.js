"use strict";
/* Line icons, drawn inline so they take the text colour and need no files.
   ic("play") returns SVG markup; any <i data-icon="play"></i> in the page is
   filled in on load. Paths are simple 24-unit strokes in one consistent style. */

const ICON_PATHS = {
  play: '<path d="M7 5v14l11-7z" fill="currentColor" stroke="none"/>',
  stop: '<rect x="6.5" y="6.5" width="11" height="11" rx="1.5" fill="currentColor" stroke="none"/>',
  record: '<circle cx="12" cy="12" r="6" fill="currentColor" stroke="none"/>',
  prev: '<path d="M18 6v12l-8.5-6zM6 6v12"/>',
  next: '<path d="M6 6v12l8.5-6zM18 6v12"/>',
  live: '<circle cx="12" cy="12" r="2.5"/><path d="M7.8 7.8a6 6 0 0 0 0 8.4M16.2 7.8a6 6 0 0 1 0 8.4M5 5a10 10 0 0 0 0 14M19 5a10 10 0 0 1 0 14"/>',
  settings: '<path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/>',
  theme: '<circle cx="12" cy="12" r="8"/><path d="M12 4a8 8 0 0 0 0 16z" fill="currentColor"/>',
  close: '<path d="M6 6l12 12M18 6L6 18"/>',
  up: '<path d="M12 19V5M6 11l6-6 6 6"/>',
  lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
  note: '<path d="M5 4h10l4 4v12H5z"/><path d="M9 12h6M9 16h4"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  drive: '<rect x="3" y="13" width="18" height="7" rx="2"/><path d="M5.5 13L8 5h8l2.5 8M16.5 16.5h.01"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/>',
  power: '<path d="M12 3v8M7.1 6.6a7 7 0 1 0 9.8 0"/>',
  volup: '<path d="M4 10v4h4l5 4V6L8 10zM16.5 9.5a3.5 3.5 0 0 1 0 5M19 7a7 7 0 0 1 0 10"/>',
  voldown: '<path d="M4 10v4h4l5 4V6L8 10zM16.5 9.5a3.5 3.5 0 0 1 0 5"/>',
  mute: '<path d="M4 10v4h4l5 4V6L8 10zM17 9l5 6M22 9l-5 6"/>',
  input: '<rect x="3" y="5" width="18" height="12" rx="2"/><path d="M8 21h8M12 17v4"/>',
  home: '<path d="M4 11l8-7 8 7M6 9.5V20h12V9.5"/>',
  back: '<path d="M10 7l-5 5 5 5M5 12h9a5 5 0 0 1 0 10"/>',
  arrowup: '<path d="M6 15l6-6 6 6"/>',
  arrowdown: '<path d="M6 9l6 6 6-6"/>',
  arrowleft: '<path d="M15 6l-6 6 6 6"/>',
  arrowright: '<path d="M9 6l6 6-6 6"/>',
  ok: '<circle cx="12" cy="12" r="3.5" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="8"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  tv: '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8"/>',
  wifi: '<path d="M2.5 9a14 14 0 0 1 19 0M5.5 12.5a9.5 9.5 0 0 1 13 0M8.8 16a5 5 0 0 1 6.4 0M12 19.5h.01"/>',
};

function ic(name, cls = "") {
  const body = ICON_PATHS[name] || "";
  return `<svg class="i${cls ? " " + cls : ""}" viewBox="0 0 24 24" fill="none" stroke="currentColor"
    stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${body}</svg>`;
}

function hydrateIcons(root = document) {
  root.querySelectorAll("i[data-icon]").forEach((el) => {
    el.outerHTML = ic(el.dataset.icon, el.className);
  });
}
document.addEventListener("DOMContentLoaded", () => hydrateIcons());
