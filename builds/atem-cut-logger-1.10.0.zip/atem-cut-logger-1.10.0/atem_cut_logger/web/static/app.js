"use strict";
/* ATEM Cut Logger — web UI. Vanilla JS, no build step.
   State flows one way: the server pushes snapshots/events over SSE, we render.
   User actions POST to the API; the resulting broadcast re-renders. */

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

let state = null;
let renderedInputIds = "";
let renderedFlagCount = -1;
let renderedNoteCount = -1;
let claimedOnce = false;
let recoveryDismissed = false;
let updateDismissed = false;
let restarting = false;

/* This browser's identity for the control lock. Persisted so a refresh keeps
   the same seat. The label is shown to other devices. */
function guessDevice() {
  const p = (navigator.platform || "").toLowerCase();
  if (p.includes("win")) return "Windows PC";
  if (p.includes("mac")) return "Mac";
  if (p.includes("linux")) return "Linux PC";
  if (/iphone|ipad|android/.test((navigator.userAgent || "").toLowerCase())) return "Tablet";
  return "Device";
}
const TOKEN = (() => {
  let t = localStorage.getItem("acl-token");
  if (!t) {
    t = (crypto.randomUUID ? crypto.randomUUID() : String(Math.random()).slice(2));
    localStorage.setItem("acl-token", t);
  }
  return t;
})();
const LABEL = (() => {
  let l = localStorage.getItem("acl-label");
  if (!l) {
    l = guessDevice() + " " + Math.random().toString(16).slice(2, 6).toUpperCase();
    localStorage.setItem("acl-label", l);
  }
  return l;
})();
const iDrive = () => !state || !state.control_label || state.control_label === LABEL;

/* ---- tiny helpers ------------------------------------------------------ */
async function post(path, body) {
  const r = await fetch(path, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Control-Token": TOKEN,
      "X-Control-Label": LABEL,
    },
    body: JSON.stringify(body || {}),
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) { toast(data.error || "Request failed", true); throw new Error(data.error); }
  return data;
}
function download(url) {
  const a = document.createElement("a");
  a.href = url; a.rel = "noopener";
  document.body.appendChild(a); a.click(); a.remove();
}
function setVal(el, v) { if (el && document.activeElement !== el) el.value = v; }
function setChecked(el, v) { if (el && document.activeElement !== el) el.checked = v; }
let toastTimer;
function toast(msg, err) {
  const t = $("#toast");
  t.textContent = msg; t.className = "toast show" + (err ? " err" : "");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.className = "toast"), 3200);
}
const debounce = (fn, ms = 250) => {
  let h; return (...a) => { clearTimeout(h); h = setTimeout(() => fn(...a), ms); };
};

/* ---- SSE --------------------------------------------------------------- */
function connectStream() {
  const es = new EventSource("/api/stream");
  es.onmessage = (e) => handle(JSON.parse(e.data));
  es.onerror = () => {/* EventSource auto-reconnects */};
}
function handle(msg) {
  switch (msg.type) {
    case "state": state = msg; maybeAutoClaim(); render(); break;
    case "event": onEvent(msg.event); break;
    case "flag": onFlag(msg.flag); break;
    case "note": onNote(msg.note); break;
    case "program": onProgram(msg); break;
    case "trace": if (typeof onTrace === "function") onTrace(msg.trace); break;
    case "tally": if (state) { state.program_input = msg.program_input; state.preview_input = msg.preview_input; }
      if (typeof onTally === "function") onTally(); break;
    case "camera": if (state) { (state.camera_values ||= {})[msg.key] = { kind: msg.value_kind, values: msg.values }; }
      if (typeof onCameraValue === "function") onCameraValue(msg.key); break;
    case "clock": onClock(msg.timecode, msg.events, msg.running, msg.live, msg.stopped_at); break;
    case "control": state && (state.control_label = msg.control_label); renderControl(); render(); break;
    case "update": if (state) { state.update = msg.update; renderUpdate(); } break;
    case "error": toast(msg.message, true); break;
  }
  if (msg.disconnect_reason && msg.was_logging)
    toast("Connection lost — logging stopped, all events kept.", true);
}

/* Claim the driver's seat automatically if no one holds it yet. */
function maybeAutoClaim() {
  if (claimedOnce || !state || state.control_label) return;
  claimedOnce = true;
  post("/api/control/claim", { label: LABEL }).catch(() => {});
}

/* ---- render ------------------------------------------------------------ */
function render() {
  if (!state) return;
  const { connected, logging, backend } = state;

  if (state.version) $("#version").textContent = "v" + state.version;
  renderUpdate();
  renderLogo();
  const ip = $("#ip");
  if (!ip.value && state.prefs && state.prefs.atem_ip && document.activeElement !== ip)
    ip.value = state.prefs.atem_ip;

  // status pill
  const pill = $("#statuspill");
  pill.className = "statuspill" + (logging ? " live" : connected ? " on" : "");
  $("#statusText").textContent = state.status;

  // selects (populate once)
  const rate = $("#rate");
  if (!rate.options.length) {
    state.rates.forEach((r) => rate.add(new Option(r + " fps", r)));
    state.resolutions.forEach((r) => $("#res").add(new Option(r.replace("x", " × "), r)));
  }
  const s = state.settings;
  setVal($("#sessionName"), s.session_name);
  setVal(rate, s.rate_key);
  setChecked($("#drop"), s.drop_frame);
  setVal($("#startTc"), s.start_timecode);
  setVal($("#res"), s.resolution);
  setVal($("#audio"), s.audio_file);
  setChecked($("#autoTc"), s.auto_timecode);
  setChecked($("#fcpTransitions"), s.fcpxml_transitions);
  $$("#isoSync button").forEach((b) => b.classList.toggle("active", b.dataset.v === s.iso_sync));

  // Another device is driving -> this one is view-only.
  const viewOnly = !!state.control_label && state.control_label !== LABEL;

  // connection controls
  $("#connectBtn").disabled = connected || viewOnly;
  $("#simBtn").disabled = connected || viewOnly;
  $("#ip").disabled = connected || viewOnly;
  $("#disconnectBtn").disabled = !connected || viewOnly;
  $("#loadBtn").disabled = viewOnly;

  // settings lock while logging OR when another device is driving
  const lock = logging || viewOnly;
  ["rate", "drop", "startTc", "nowBtn", "res", "audio", "addInput", "autoTc",
   "fcpTransitions"].forEach(
    (id) => ($("#" + id).disabled = lock));
  $$("#isoSync button").forEach((b) => (b.disabled = lock));

  renderTemplates();
  renderMacros();
  renderRecorders();
  renderPrefs();
  setChecked($("#autoStartRec"), s.auto_start_on_record);
  $("#newSessionBtn").disabled = logging || viewOnly || !state.events.length;
  $("#unsavedHint").classList.toggle("hidden", !state.unsaved || !state.events.length);

  renderTally();
  renderSimcuts();
  renderMappings();
  renderEvents(state.events);
  renderFlags();
  renderNotes();
  renderControl();
  renderRecovery();
  const k = state.clock;
  onClock(k.timecode, k.events, k.running, k.live, k.stopped_at);

  $("#markErrorBtn").disabled = !logging || viewOnly;
  $("#noteBtn").disabled = !logging || viewOnly;

  // log + export buttons
  const logBtn = $("#logBtn");
  logBtn.disabled = !connected || viewOnly;
  logBtn.innerHTML = logging ? ic("stop") + " Stop Logging" : ic("record") + " Start Logging";
  logBtn.classList.toggle("danger", logging);
  const resume = $("#resumeBtn");
  resume.classList.toggle("hidden", !(state.can_resume && state.unsaved));
  resume.disabled = !connected || viewOnly;
  $("#saveBtn").disabled = !state.can_export || viewOnly;
  $("#saveBtn").classList.toggle("secondary", !state.unsaved);
  $$("[data-dl]").forEach((b) => (b.disabled = !state.can_export));
}

/* ---- logo -------------------------------------------------------------
   Up to two images: one for the dark theme, one for the light. The header
   shows the one matching the current theme, or whichever exists. */
let renderedLogo = "";
const currentTheme = () => document.documentElement.dataset.theme || "dark";
function renderLogo() {
  const p = state.prefs || {};
  const v = { dark: p.logo || 0, light: p.logo_light || 0 };
  const key = `${v.dark}|${v.light}|${currentTheme()}`;
  if (key === renderedLogo) return;
  renderedLogo = key;
  const theme = currentTheme();
  const any = v.dark || v.light;
  const img = $("#brandLogo");
  img.classList.toggle("hidden", !any);
  $("#defaultMark").classList.toggle("hidden", !!any);
  if (any) img.src = `/api/logo?variant=${theme}&v=${v[theme] || v.dark || v.light}`;
  $$(".logoslot").forEach((slot) => {
    const variant = slot.dataset.variant;
    $("[data-preview]", slot).innerHTML = v[variant]
      ? `<img src="/api/logo?variant=${variant}&v=${v[variant]}" alt="">`
      : '<span class="hint">No logo yet</span>';
    $("[data-logo-remove]", slot).disabled = !v[variant] || !iDrive();
    $("[data-logo-upload]", slot).disabled = !iDrive();
  });
}

/* ---- templates ----------------------------------------------------------
   The <select> is rebuilt only when the set of templates changes, so it can't
   snatch back a choice the operator just made. */
let renderedTemplateKey = "";
function renderTemplates() {
  const list = state.templates || [];
  const sel = $("#templateSel");
  const key = list.map((t) => t.slug).join("|");
  if (key !== renderedTemplateKey) {
    renderedTemplateKey = key;
    const previous = sel.value;
    sel.innerHTML = "";
    if (!list.length) sel.add(new Option("— none saved —", ""));
    list.forEach((t) => {
      const label = t.cameras
        ? `${t.name} (${t.rate_key} fps · ${t.cameras} cams)` : t.name;
      sel.add(new Option(label, t.name));
    });
    if (previous && list.some((t) => t.name === previous)) sel.value = previous;
  }
  const viewOnly = !iDrive();
  const none = !list.length;
  if (list.length && !sel.querySelector('option[value=""]'))
    sel.insertBefore(new Option("Choose a show…", ""), sel.firstChild);
  if (!sel.value) sel.value = "";
  $("#templateDelete").classList.toggle("hidden", !sel.value);
  $("#templateDelete").disabled = viewOnly;
  $("#templateSave").disabled = state.logging || viewOnly;
  sel.disabled = none || state.logging || viewOnly;
}

/* ---- recorders ----------------------------------------------------------
   The rows are editable inputs; edits are debounced into one POST so typing an
   IP doesn't fire a request per keystroke. Status comes from the server's last
   poll, so the table shows what the decks actually report. */
let renderedRecorderCount = -1;
function renderRecorders() {
  const list = state.recorders || [];
  const statuses = state.recorder_status || [];
  const body = $("#recorderBody");
  const viewOnly = !iDrive();

  if (list.length !== renderedRecorderCount) {
    renderedRecorderCount = list.length;
    body.innerHTML = "";
    if (!list.length) {
      body.innerHTML = '<tr><td colspan="5" class="empty">No recorders configured.</td></tr>';
    }
    list.forEach((r, i) => {
      const tr = document.createElement("tr");
      tr.innerHTML =
        `<td><input type="text" data-rec="name" data-i="${i}" placeholder="Deck ${i + 1}"></td>` +
        `<td><input type="text" data-rec="host" data-i="${i}" placeholder="192.168.1.50"></td>` +
        `<td><input type="text" data-rec="port" data-i="${i}" placeholder="9993"></td>` +
        `<td class="tnum" data-recstatus="${i}">—</td>` +
        `<td><button class="btn ghost" data-recdel="${i}">${ic("close")}</button></td>`;
      body.appendChild(tr);
    });
    $$("[data-rec]").forEach((el) => (el.oninput = debounce(saveRecorders, 500)));
    $$("[data-recdel]").forEach((b) => (b.onclick = () => {
      const rows = readRecorderRows();
      rows.splice(Number(b.dataset.recdel), 1);
      renderedRecorderCount = -1;
      post("/api/recorders", { recorders: rows });
    }));
  }

  list.forEach((r, i) => {
    setVal(body.querySelector(`[data-rec="name"][data-i="${i}"]`), r.name || "");
    setVal(body.querySelector(`[data-rec="host"][data-i="${i}"]`), r.host || "");
    setVal(body.querySelector(`[data-rec="port"][data-i="${i}"]`), r.port || 9993);
    const cell = body.querySelector(`[data-recstatus="${i}"]`);
    const st = statuses[i];
    if (cell) {
      if (!st) cell.textContent = "—";
      else if (st.error) { cell.textContent = st.error; cell.style.color = "var(--err)"; }
      else {
        cell.style.color = st.recording ? "var(--err)" : "var(--muted)";
        cell.textContent = (st.recording ? "RECORDING " : st.status + " ") +
          (st.timecode || "");
      }
    }
    $$("[data-rec][data-i='" + i + "']").forEach((el) => (el.disabled = viewOnly));
  });

  const none = !list.length;
  $("#recorderBar").classList.toggle("hidden", none);
  const rolling = statuses.filter((st) => st && st.recording).length;
  const failed = statuses.filter((st) => st && st.error).length;
  $("#recorderSummary").textContent = none ? "" :
    `${list.length} deck${list.length === 1 ? "" : "s"}` +
    (rolling ? ` · ${rolling} recording` : "") + (failed ? ` · ${failed} not responding` : "");
  $("#recordAllBtn").disabled = none || viewOnly;
  $("#recordStopBtn").disabled = none || viewOnly;
  $("#recorderRefresh").disabled = none;
  $("#recorderAdd").disabled = viewOnly;
  $("#autoStartRec").disabled = viewOnly;
}

function readRecorderRows() {
  const rows = [];
  (state.recorders || []).forEach((_r, i) => {
    const get = (k) => {
      const el = $(`[data-rec="${k}"][data-i="${i}"]`);
      return el ? el.value.trim() : "";
    };
    rows.push({ name: get("name"), host: get("host"), port: get("port") || 9993 });
  });
  return rows;
}

function saveRecorders() {
  const rows = readRecorderRows().filter((r) => r.host);
  post("/api/recorders", { recorders: rows }).catch(() => {});
}

/* ---- macros -------------------------------------------------------------
   Only rendered when the switcher reports macros, so nothing appears in Test
   Mode or on a switcher without any. */
/* Macros are drawn by switcher.js: the full panel lives in the Switcher
   section and only the ones marked "on the Log screen" appear here. */
function renderMacros() {
  if (typeof renderMacroPanels === "function") renderMacroPanels();
}

function renderTally() {
  const t = $("#tally"), { connected, logging } = state;
  t.classList.toggle("live", logging);
  $("#recLabel").textContent = logging ? "ON AIR — REC" : "PROGRAM";
  if (!connected || state.program_input == null) {
    $("#progText").textContent = "Not connected";
  } else {
    $("#progText").innerHTML =
      `${state.program_input} <small>·</small> ${escapeHtml(state.program_camera)}`;
  }
}

function renderSimcuts() {
  const box = $("#simcuts");
  const show = state.connected && state.backend === "simulator";
  box.classList.toggle("hidden", !show);
  if (!show) { box.innerHTML = ""; return; }
  box.innerHTML = "<span>Simulate cut to</span>";
  state.mappings.forEach((m) => {
    const b = document.createElement("button");
    b.textContent = m.input_id;
    b.title = m.name || "Input " + m.input_id;
    b.disabled = !iDrive();
    b.onclick = () => post("/api/simulate/cut", { input_id: m.input_id });
    box.appendChild(b);
  });
}

function renderMappings() {
  const ids = state.mappings.map((m) => m.input_id).join(",");
  const body = $("#mapBody");
  if (ids !== renderedInputIds) {
    renderedInputIds = ids;
    body.innerHTML = "";
    if (!state.mappings.length) {
      body.innerHTML = '<tr><td colspan="3" class="empty">No inputs yet — connect or add one.</td></tr>';
    }
    state.mappings.forEach((m) => {
      const tr = document.createElement("tr");
      tr.className = "maprow"; tr.dataset.input = m.input_id;
      tr.innerHTML =
        `<td class="tnum">${m.input_id}</td>` +
        `<td><input type="text" class="mname" placeholder="Camera ${m.input_id}"></td>` +
        `<td><input type="text" class="mfile" placeholder="ISO media file path"></td>`;
      body.appendChild(tr);
      const send = debounce(() => post("/api/mapping", {
        input_id: m.input_id,
        name: $(".mname", tr).value, file: $(".mfile", tr).value,
      }));
      $(".mname", tr).addEventListener("input", send);
      $(".mfile", tr).addEventListener("input", send);
    });
  }
  // update values without stomping the field being edited
  const editable = iDrive();
  state.mappings.forEach((m) => {
    const tr = $(`.maprow[data-input="${m.input_id}"]`);
    if (tr) {
      setVal($(".mname", tr), m.name); setVal($(".mfile", tr), m.file);
      $(".mname", tr).disabled = !editable; $(".mfile", tr).disabled = !editable;
    }
  });
}

function renderControl() {
  const chip = $("#controlChip"), take = $("#takeControl");
  const label = state && state.control_label;
  if (!label) { chip.classList.add("hidden"); take.classList.add("hidden"); return; }
  chip.classList.remove("hidden");
  if (label === LABEL) {
    chip.className = "statuspill on";
    chip.innerHTML = '<span class="dot"></span>You’re driving';
    take.classList.add("hidden");
  } else {
    chip.className = "statuspill";
    chip.innerHTML = '<span class="dot"></span>' + ic("lock") + ' ' + escapeHtml(label) + " is in control";
    take.classList.remove("hidden");
  }
}

/* ---- updates ------------------------------------------------------------
   The version badge is the manual check; the banner appears when the timer (or
   a manual check) finds commits waiting. Applying is blocked while logging —
   the server refuses too, this just keeps the button honest. */
function renderUpdate() {
  const u = (state && state.update) || null;
  const badge = $("#version");
  const banner = $("#updateBanner");
  if (!u) { banner.classList.add("hidden"); return; }

  badge.classList.toggle("has-update", !!u.update_available);
  badge.textContent = "v" + (u.version || state.version) +
    (u.update_available ? " · update ready" : "");
  badge.title = u.supported
    ? (u.checking ? "Checking for updates…" : "Click to check for updates")
    : u.reason;

  const show = u.update_available && !updateDismissed;
  banner.classList.toggle("hidden", !show);
  if (!show) return;

  $("#updateTitle").textContent = u.available_version
    ? `Version ${u.available_version} is available.`
    : `An update is available (${u.commits_behind} change` +
      `${u.commits_behind === 1 ? "" : "s"}).`;
  $("#updateText").textContent = (u.summary || []).slice(0, 3).join(" · ");
  const apply = $("#updateApply");
  apply.disabled = state.logging || u.applying || restarting || !iDrive();
  apply.textContent = u.applying ? "Installing…"
    : restarting ? "Restarting…"
    : state.logging ? "Stop logging first" : "Update & restart";
}

async function checkForUpdates(manual) {
  const u = (state && state.update) || {};
  if (!u.supported) { if (manual) toast(u.reason || "Updates aren't available here.", true); return; }
  if (u.checking) return;
  try {
    const res = await post("/api/update/check");
    updateDismissed = false;
    if (state) { state.update = res; renderUpdate(); }
    if (manual) {
      toast(res.update_available
        ? (res.available_version
            ? `Version ${res.available_version} is available.`
            : `Update available (${res.commits_behind} change` +
              `${res.commits_behind === 1 ? "" : "s"}).`)
        : "You're on the latest version.");
    }
  } catch (e) { /* post() already surfaced the error */ }
}

/* Apply, then wait for the restarted server to answer before reloading. */
async function applyUpdate() {
  try {
    const res = await post("/api/update/apply", { restart: true });
    if (!res.restarting) { toast("Already up to date."); return; }
    restarting = true;
    renderUpdate();
    toast("Installing update — the app will reload itself.");
    if (res.bridge === "failed")
      toast("Update installed, but the ATEM bridge failed to rebuild.", true);
    waitForRestart();
  } catch (e) { /* post() already surfaced the error */ }
}

function waitForRestart(tries = 0) {
  setTimeout(async () => {
    try {
      const r = await fetch("/api/state", { cache: "no-store" });
      if (r.ok) { location.reload(); return; }
    } catch (e) { /* server still down — keep waiting */ }
    if (tries < 40) waitForRestart(tries + 1);
    else { restarting = false; toast("The app didn't come back — relaunch it.", true); }
  }, 1000);
}

function renderRecovery() {
  const banner = $("#recoverBanner");
  if (state && state.recovered && !recoveryDismissed) {
    banner.classList.remove("hidden");
    const n = state.events.length;
    $("#recoverText").textContent =
      `${state.settings.session_name || "The last session"} — ${n} cut${n === 1 ? "" : "s"}, ` +
      "kept from when the logger last closed. Resume logging to carry on, or save it.";
    $("#recoverResume").disabled = !state.connected || !iDrive();
    $("#recoverResume").title = state.connected ? "Keep logging into this same session"
      : "Connect to the switcher first";
  } else {
    banner.classList.add("hidden");
  }
}

function renderEvents(events) {
  const body = $("#eventBody");
  if (!events.length) {
    body.innerHTML = '<tr><td colspan="5" class="empty">No events yet.</td></tr>';
    return;
  }
  body.innerHTML = events.map(rowForEvent).join("");
}
/* A hard cut is the norm, so it reads as an empty cell; anything else names
   the style and how long the blend ran. */
function transitionLabel(e) {
  if (!e.transition || e.transition === "cut" || !e.transition_frames) return "";
  const rate = state && state.settings ? parseFloat(state.settings.rate_key) : 0;
  const secs = rate ? (e.transition_frames / rate).toFixed(1) + "s" : e.transition_frames + "f";
  return `${e.transition} ${secs}`;
}
const rowForEvent = (e) =>
  `<tr><td class="tnum">${e.n}</td><td class="tnum">${e.timecode}</td>` +
  `<td class="tnum">${e.input}</td><td>${escapeHtml(e.camera)}</td>` +
  `<td class="hint">${escapeHtml(transitionLabel(e))}</td></tr>`;

function onEvent(e) {
  const body = $("#eventBody");
  if (body.querySelector(".empty")) body.innerHTML = "";
  body.insertAdjacentHTML("beforeend", rowForEvent(e));
  const rowEl = body.lastElementChild;
  if (rowEl) rowEl.classList.add("flash");   // brief highlight on arrival
  const wrap = body.closest(".tablewrap"); wrap.scrollTop = wrap.scrollHeight;
}
function renderFlags() {
  const flags = state.flags || [];
  $("#flagsLabel").classList.toggle("hidden", !flags.length);
  $("#flagsWrap").classList.toggle("hidden", !flags.length);
  if (flags.length === renderedFlagCount) return;  // avoid stomping a note mid-edit
  renderedFlagCount = flags.length;
  const body = $("#flagBody");
  body.innerHTML = flags.map(rowForFlag).join("");
  flags.forEach((f) => wireFlagRow(f.index));
}
const rowForFlag = (f) =>
  `<tr data-index="${f.index}"><td class="tnum">${f.timecode}</td>` +
  `<td><input type="text" class="fnote" placeholder="What happened? (optional)" value="${escapeAttr(f.note)}"></td>` +
  `<td><button class="btn ghost" title="Remove this flag">${ic("close")}</button></td></tr>`;
function wireFlagRow(index) {
  const tr = $(`#flagBody tr[data-index="${index}"]`);
  if (!tr) return;
  const send = debounce(() => post("/api/flag/note", { index, note: $(".fnote", tr).value }));
  $(".fnote", tr).addEventListener("input", send);
  $("button", tr).onclick = () => {
    if (window.confirm("Remove this flag?")) post("/api/flag/remove", { index }).catch(() => {});
  };
}
function onFlag(f) {
  $("#markErrorBtn").classList.add("flash-btn");
  setTimeout(() => $("#markErrorBtn").classList.remove("flash-btn"), 250);
  toast(`Flagged at ${f.timecode} — add a note anytime in the Log below.`);
  if (state) { state.flags = state.flags || []; state.flags.push(f); }
  renderFlags();
}

function renderNotes() {
  const notes = state.notes || [];
  $("#notesLabel").classList.toggle("hidden", !notes.length);
  $("#notesWrap").classList.toggle("hidden", !notes.length);
  if (notes.length === renderedNoteCount) return;
  renderedNoteCount = notes.length;
  const body = $("#noteBody");
  body.innerHTML = notes.map(rowForNote).join("");
}
const rowForNote = (n) =>
  `<tr data-index="${n.index}"><td class="tnum">${n.timecode}</td>` +
  `<td>${escapeHtml(n.text)}</td>` +
  `<td style="text-align:center">${ic("note")}</td></tr>`;

function onNote(n) {
  $("#noteBtn").classList.add("flash-btn");
  setTimeout(() => $("#noteBtn").classList.remove("flash-btn"), 250);
  toast(`Note saved at ${n.timecode}.`);
  if (state) { state.notes = state.notes || []; state.notes.push(n); }
  renderNotes();
}
function escapeAttr(s) {
  return escapeHtml(s).replace(/'/g, "&#39;");
}
function onProgram(msg) {
  state && (state.program_input = msg.program_input,
    state.program_camera = msg.program_camera);
  renderTally();
}
function onClock(tc, events, running, live, stoppedAt) {
  $("#clockTc").textContent = tc || "—";
  $("#clockTc").classList.toggle("dim", !running && !live);
  const count = events ? `${events} cut${events === 1 ? "" : "s"}` : "";
  $("#clockMeta").textContent = running ? count
    : [live ? "Switcher timecode" : "", count].filter(Boolean).join(" · ");
  $("#logClock").textContent = running ? `REC · ${events} cuts`
    : (stoppedAt ? `Stopped at ${stoppedAt}` : "");
}

function escapeHtml(s) {
  return String(s == null ? "" : s).replace(/[&<>"]/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
}

/* ---- wire up static controls ------------------------------------------ */
function init() {
  $("#connectBtn").onclick = () => post("/api/connect", { mode: "atem", ip: $("#ip").value });
  $("#simBtn").onclick = () => post("/api/connect", { mode: "simulator" });
  $("#disconnectBtn").onclick = () => post("/api/disconnect");
  $("#ip").addEventListener("keydown", (e) => { if (e.key === "Enter") $("#connectBtn").click(); });

  // While logging only the name may change, so send just that — otherwise
  // every keystroke in the name box would be refused with an error.
  const settings = debounce(() => post("/api/settings", state && state.logging
    ? { session_name: $("#sessionName").value } : {
    session_name: $("#sessionName").value,
    rate_key: $("#rate").value, drop_frame: $("#drop").checked,
    start_timecode: $("#startTc").value, resolution: $("#res").value,
    audio_file: $("#audio").value, auto_timecode: $("#autoTc").checked,
    fcpxml_transitions: $("#fcpTransitions").checked,
  }));
  ["rate", "drop", "res", "autoTc", "fcpTransitions"].forEach((id) => $("#" + id).addEventListener("change", settings));
  ["sessionName", "startTc", "audio"].forEach((id) => $("#" + id).addEventListener("input", settings));
  $$("#isoSync button").forEach((b) => b.onclick = () => {
    if (b.disabled) return;
    post("/api/settings", { iso_sync: b.dataset.v });
  });
  $("#nowBtn").onclick = () => {
    const d = new Date();
    const tc = [d.getHours(), d.getMinutes(), d.getSeconds()]
      .map((n) => String(n).padStart(2, "0")).join(":") + ":00";
    post("/api/settings", { start_timecode: tc });
  };
  $("#addInput").onclick = () => post("/api/mapping/add");

  $("#logBtn").onclick = async () => {
    if (state.logging) {
      await post("/api/logging/stop");
      openSave();                       // end of show: straight to saving
      return;
    }
    const n = state.events.length;
    if (state.unsaved && n && !window.confirm(
        `Start a brand-new log?\n\nThe ${n} cut${n === 1 ? "" : "s"} in the current ` +
        "log haven't been saved and will be replaced.\n\nCancel to keep them — " +
        "use Resume to carry on logging, or Save session first.")) return;
    await post("/api/logging/start");
  };
  $("#resumeBtn").onclick = () => post("/api/logging/start", { resume: true });
  $("#recoverResume").onclick = async () => {
    await post("/api/logging/start", { resume: true });
    recoveryDismissed = true;
    renderRecovery();
  };
  $("#saveBtn").onclick = openSave;
  $("#recoverSave").onclick = openSave;

  // One click, no typing — fast to hit live. Add detail afterward in the log.
  $("#markErrorBtn").onclick = () => post("/api/flag", {}).catch(() => {});

  // Note: prompt for text (editorial cue, broll timing, etc.)
  $("#noteBtn").onclick = () => {
    const text = prompt("Editorial note (graphics cue, broll timing, etc.):");
    if (text !== null && text.trim()) {
      post("/api/note", { text: text.trim() }).catch(() => {});
    }
  };

  $$("[data-dl]").forEach((b) => b.onclick = () => download(b.dataset.dl));

  // control lock — Take control needs a deliberate confirm so it can't be
  // triggered by an accidental tap/click, especially mid-recording.
  $("#takeControl").onclick = () => {
    const who = (state && state.control_label) || "another device";
    let msg = `Take control from “${who}”?\n\nThey will immediately drop to `
      + `view-only and can no longer log cuts or change settings.`;
    if (state && state.logging)
      msg = "A RECORDING IS IN PROGRESS on the other device.\n\n" + msg;
    if (window.confirm(msg))
      post("/api/control/claim", { label: LABEL, force: true }).catch(() => {});
  };
  $("#recoverDismiss").onclick = () => {
    recoveryDismissed = true;
    $("#recoverBanner").classList.add("hidden");
  };

  // recorders
  $("#recorderAdd").onclick = () => {
    const rows = readRecorderRows();
    rows.push({ name: "", host: "", port: 9993 });
    renderedRecorderCount = -1;
    state.recorders = rows;              // render immediately; saved once an IP is typed
    renderRecorders();
  };
  $("#recordAllBtn").onclick = async () => {
    const res = await post("/api/recorders/record");
    const bad = (res.status || []).filter((s) => s.error);
    toast(bad.length ? `${bad.length} recorder(s) failed: ${bad[0].error}`
                     : "Recording started on all decks.", !!bad.length);
  };
  $("#recordStopBtn").onclick = async () => {
    await post("/api/recorders/stop");
    toast("Recording stopped.");
  };
  $("#recorderRefresh").onclick = () => post("/api/recorders/status");
  $("#autoStartRec").onchange = (e) =>
    post("/api/settings", { auto_start_on_record: e.target.checked });

  // templates
  $("#templateSave").onclick = async () => {
    const suggested = ($("#templateSel").value || state?.settings.session_name || "");
    const name = window.prompt(
      "Save the cameras and settings as a show (e.g. “The Visiting Table”):", suggested);
    if (name === null || !name.trim()) return;
    await post("/api/template/save", { name });
    renderedTemplateKey = "";       // force the list to rebuild with the new one
    renderTemplates();
    $("#templateSel").value = name.trim();
    toast(`Saved the show “${name.trim()}”.`);
  };
  $("#templateSel").onchange = async () => {
    const name = $("#templateSel").value;
    $("#templateDelete").classList.toggle("hidden", !name);
    if (!name) return;
    await post("/api/template/apply", { name });
    toast(`Loaded the “${name}” setup.`);
  };
  $("#templateDelete").onclick = async () => {
    const name = $("#templateSel").value;
    if (!name || !window.confirm(`Delete the saved show “${name}”?`)) return;
    await post("/api/template/delete", { name });
    renderedTemplateKey = "";
    $("#templateDelete").classList.add("hidden");
    toast(`Deleted the show “${name}”.`);
  };

  // new session — the server refuses if the log is unsaved; confirm and retry
  $("#newSessionBtn").onclick = async () => {
    const events = (state?.events || []).length;
    if (state?.unsaved && events) {
      const ok = window.confirm(
        `This session has ${events} cut${events === 1 ? "" : "s"} that ` +
        "haven't been saved.\n\nStart a new session and discard them?");
      if (!ok) return;
      await post("/api/session/new", { force: true });
    } else {
      await post("/api/session/new", {});
    }
    toast("New session started — cameras and settings kept.");
  };

  // updates: the version badge checks on demand, the banner installs
  $("#version").onclick = () => checkForUpdates(true);
  $("#updateApply").onclick = applyUpdate;
  $("#updateDismiss").onclick = () => {
    updateDismissed = true;
    $("#updateBanner").classList.add("hidden");
  };

  // open a saved log
  $("#loadBtn").onclick = () => $("#loadFile").click();
  $("#loadFile").addEventListener("change", async (e) => {
    const f = e.target.files[0]; if (!f) return;
    const text = await f.text();
    await post("/api/session/load", { json: text, name: f.name });
    e.target.value = "";
  });

  // theme toggle (persisted)
  const saved = localStorage.getItem("acl-theme");
  if (saved) document.documentElement.dataset.theme = saved;
  $("#themeBtn").onclick = () => {
    const cur = document.documentElement.dataset.theme || "dark";  // dark is default
    const next = cur === "dark" ? "light" : "dark";
    document.documentElement.dataset.theme = next;
    localStorage.setItem("acl-theme", next);
    if (state) renderLogo();
  };

  initDialogs();
  initSetup();
  initSave();
  initFolderPicker();

  // Closing the tab never loses the log (the logger keeps it and autosaves),
  // but a warning still beats a surprise mid-show.
  window.addEventListener("beforeunload", (e) => {
    if (state && (state.logging || (state.unsaved && state.events.length))) {
      e.preventDefault(); e.returnValue = "";
    }
  });
  connectStream();
}

/* ---- dialogs ------------------------------------------------------------ */
const openDialog = (id) => $("#" + id).classList.add("open");
const closeDialog = (id) => $("#" + id).classList.remove("open");
function initDialogs() {
  $$("[data-close]").forEach((b) => (b.onclick = () => closeDialog(b.dataset.close)));
  $$(".scrim").forEach((scrim) => scrim.addEventListener("mousedown", (e) => {
    if (e.target === scrim) scrim.classList.remove("open");
  }));
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape") return;
    const open = $$(".scrim.open");
    if (open.length) open[open.length - 1].classList.remove("open");
  });
}

/* ---- Setup -------------------------------------------------------------- */
function showTab(name) {
  $$("#setupTabs button").forEach((b) => b.classList.toggle("active", b.dataset.tab === name));
  $$("[data-pane]").forEach((p) => p.classList.toggle("hidden", p.dataset.pane !== name));
}
function initSetup() {
  $("#setupBtn").onclick = () => openDialog("setupScrim");
  $$("#setupTabs button").forEach((b) => (b.onclick = () => showTab(b.dataset.tab)));

  $("#prefSaveChange").onclick = () =>
    pickFolder(state.prefs.save_dir, (path) => post("/api/prefs", { default_save_dir: path }));
  $("#prefSaveReset").onclick = () => post("/api/prefs", { default_save_dir: "" });
  $("#prefCleanup").onchange = (e) => post("/api/prefs", { run_cleanup: e.target.checked });

  const saveRules = debounce(() => {
    const cleanup = {};
    $$("[data-rule]").forEach((el) => {
      if (el.dataset.rule === "wide_camera_input") cleanup.wide_camera_input = el.value ? +el.value : null;
      else if (el.value !== "") cleanup[el.dataset.rule] = +el.value;
    });
    post("/api/prefs", { cleanup }).catch(() => {});
  }, 500);
  $$("[data-rule]").forEach((el) => el.addEventListener(el.tagName === "SELECT" ? "change" : "input", saveRules));

  let logoVariant = "dark";
  $$(".logoslot").forEach((slot) => {
    $("[data-logo-upload]", slot).onclick = () => {
      logoVariant = slot.dataset.variant;
      $("#logoFile").click();
    };
    $("[data-logo-remove]", slot).onclick = () =>
      post("/api/logo/remove", { variant: slot.dataset.variant });
  });
  $("#logoFile").onchange = async (e) => {
    const f = e.target.files[0]; e.target.value = "";
    if (!f) return;
    const data = await new Promise((ok, fail) => {
      const r = new FileReader();
      r.onload = () => ok(String(r.result).split(",")[1] || "");
      r.onerror = fail;
      r.readAsDataURL(f);
    });
    await post("/api/logo", { filename: f.name, data, variant: logoVariant });
    toast("Logo updated.");
  };
}

let renderedWideKey = "";
function renderPrefs() {
  const p = state.prefs;
  if (!p) return;
  $("#prefSavePath").textContent = p.default_save_dir || `${p.fallback_save_dir} (Downloads)`;
  const prob = $("#prefSaveProblem");
  prob.classList.toggle("hidden", !p.save_dir_problem);
  prob.textContent = p.save_dir_problem
    ? p.save_dir_problem + " Sessions will offer Downloads until it's back." : "";
  $("#prefSaveReset").classList.toggle("hidden", !p.default_save_dir);
  setChecked($("#prefCleanup"), p.run_cleanup);

  const wideKey = state.mappings.map((m) => m.input_id + m.name).join("|");
  const wide = $('[data-rule="wide_camera_input"]');
  if (wideKey !== renderedWideKey) {
    renderedWideKey = wideKey;
    wide.innerHTML = "";
    wide.add(new Option("(none — skip the wide-shot checks)", ""));
    state.mappings.forEach((m) =>
      wide.add(new Option(`${m.input_id}: ${m.name || "Input " + m.input_id}`, m.input_id)));
  }
  $$("[data-rule]").forEach((el) => {
    const v = p.cleanup[el.dataset.rule];
    setVal(el, v == null ? "" : String(v));
  });
  const viewOnly = !iDrive();
  ["prefSaveChange", "prefSaveReset", "prefCleanup"]
    .forEach((id) => ($("#" + id).disabled = viewOnly));
  $$("[data-rule]").forEach((el) => (el.disabled = viewOnly));
}

/* ---- Save session --------------------------------------------------------
   One button writes every export (plus the Smart Cleanup pass) into a folder
   named after the session. If the folder isn't reachable, the server says why
   and the dialog offers Downloads or another folder instead. */
let saveFolder = "";
function openSave() {
  if (!state || !state.can_export) return;
  saveFolder = state.prefs.save_dir;
  setVal($("#saveName"), state.settings.session_name || "");
  $("#saveCleanup").checked = state.prefs.run_cleanup;
  $("#saveForm").classList.remove("hidden");
  $("#saveDone").classList.add("hidden");
  $("#saveTitle").textContent = "Save session";
  showSaveProblem(state.prefs.default_save_dir === saveFolder ? state.prefs.save_dir_problem : "");
  renderSaveForm();
  openDialog("saveScrim");
  if (!$("#saveName").value) $("#saveName").focus();
}
function renderSaveForm() {
  $("#savePath").textContent = saveFolder;
  const cleanup = $("#saveCleanup").checked;
  const flags = (state.flags || []).length;
  $("#saveWhat").textContent =
    "Saves one folder with the Resolve timeline, EDL, CSV and the log" +
    (flags ? `, the ${flags} flagged moment${flags === 1 ? "" : "s"}` : "") +
    (cleanup ? ", plus the Smart Cleanup report and a markers timeline." : ".");
}
function showSaveProblem(text) {
  $("#saveProblem").classList.toggle("hidden", !text);
  $("#saveProblemText").textContent = text || "";
  $("#saveGo").disabled = !!text;
}
async function doSave(useFallback) {
  const name = $("#saveName").value.trim();
  if (name !== (state.settings.session_name || ""))
    await post("/api/settings", { session_name: name });
  const r = await fetch("/api/session/save", {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Control-Token": TOKEN },
    body: JSON.stringify({ folder: saveFolder, use_fallback: !!useFallback,
                           run_cleanup: $("#saveCleanup").checked }),
  });
  const res = await r.json().catch(() => ({}));
  if (r.status === 409 && res.location_problem) { showSaveProblem(res.error); return; }
  if (!r.ok) { toast(res.error || "Save failed", true); return; }
  showSaveDone(res);
}
function showSaveDone(res) {
  $("#saveForm").classList.add("hidden");
  $("#saveDone").classList.remove("hidden");
  $("#saveTitle").textContent = "Session saved";
  $("#doneFolder").textContent = res.folder;
  $("#doneFiles").innerHTML = res.files.map((f) => `<div>${escapeHtml(f)}</div>`).join("");
  const n = res.issues.length;
  $("#doneIssues").innerHTML = !res.cleanup ? ""
    : n ? `<div class="alert">Smart Cleanup flagged <b>${n} moment${n === 1 ? "" : "s"}</b> to look at. ` +
          "Import the <b>-markers</b> timeline in Resolve to jump between them.</div>"
        : '<div class="hint">Smart Cleanup found nothing to flag.</div>';
  $("#doneReview").classList.toggle("hidden", !n);
  $("#doneReview").onclick = () => showReview(res.issues, res.counts);
}
function initSave() {
  $("#saveCleanup").onchange = renderSaveForm;
  $("#saveChange").onclick = $("#saveChoose").onclick = () =>
    pickFolder(saveFolder, (path) => { saveFolder = path; showSaveProblem(""); renderSaveForm(); });
  $("#saveUseFallback").onclick = () => doSave(true);
  $("#saveGo").onclick = () => doSave(false);
  $("#saveName").addEventListener("keydown", (e) => { if (e.key === "Enter") doSave(false); });
  $("#doneReveal").onclick = () => post("/api/reveal").catch(() => {});
  $("#doneNew").onclick = async () => {
    await post("/api/session/new", {});
    closeDialog("saveScrim");
    toast("New session ready — cameras and settings kept.");
    $("#sessionName").focus();
  };
}

/* ---- Smart Cleanup review ------------------------------------------------ */
function showReview(issues, counts) {
  const body = $("#issueBody");
  body.innerHTML = issues.length ? issues.map((i) =>
    `<tr><td class="tnum">${i.timecode}</td>` +
    `<td><span class="badge ${i.severity}">${escapeHtml(i.title)}</span></td>` +
    `<td>${escapeHtml(i.camera)}</td>` +
    `<td>${escapeHtml(i.suggestion)}<div class="hint">${escapeHtml(i.detail)}</div></td></tr>`
  ).join("") : '<tr><td colspan="4" class="empty">Nothing flagged.</td></tr>';
  $("#cleanSummary").textContent = Object.entries(counts || {})
    .map(([k, v]) => `${k}: ${v}`).join(" · ");
  openDialog("reviewScrim");
}

/* ---- Folder picker -------------------------------------------------------
   Browses folders on the computer running the logger (which may not be the
   device showing this page), so it asks the logger rather than the browser. */
let fsCurrent = "", fsOnPick = null;
function pickFolder(start, onPick) {
  fsOnPick = onPick;
  openDialog("folderScrim");
  browse(start || "");
}
async function browse(path) {
  let res;
  try { res = await post("/api/fs/list", { path }); } catch { return; }
  fsCurrent = res.path;
  $("#fsPath").textContent = res.path;
  $("#fsUp").disabled = !res.parent;
  $("#fsUp").onclick = () => browse(res.parent);
  const msg = res.problem || res.note;
  $("#fsProblem").classList.toggle("hidden", !msg);
  $("#fsProblem").textContent = msg || "";
  $("#fsChoose").disabled = !!res.problem;
  $("#fsNew").disabled = !!res.problem;
  $("#fsShortcuts").innerHTML = res.shortcuts.map((sc, i) =>
    `<button data-sc="${i}" class="${res.path === sc.path ? "active" : ""}">` +
    `${ic(sc.drive ? "drive" : "folder")} ${escapeHtml(sc.label)}</button>`).join("");
  $$("#fsShortcuts [data-sc]").forEach((b) =>
    (b.onclick = () => browse(res.shortcuts[+b.dataset.sc].path)));
  const sep = res.path.includes("\\") && !res.path.includes("/") ? "\\" : "/";
  const join = (d) => res.path.endsWith(sep) ? res.path + d : res.path + sep + d;
  $("#fsDirs").innerHTML = res.dirs.length
    ? res.dirs.map((d, i) => `<button data-dir="${i}">${ic("folder")} ${escapeHtml(d)}</button>`).join("")
    : '<div class="empty">No folders here.</div>';
  $$("#fsDirs [data-dir]").forEach((b) =>
    (b.ondblclick = b.onclick = () => browse(join(res.dirs[+b.dataset.dir]))));
}
function initFolderPicker() {
  $("#fsChoose").onclick = () => {
    closeDialog("folderScrim");
    if (fsOnPick) fsOnPick(fsCurrent);
  };
  $("#fsNew").onclick = async () => {
    const name = window.prompt("Name for the new folder:");
    if (!name || !name.trim()) return;
    try {
      const res = await post("/api/fs/mkdir", { path: fsCurrent, name: name.trim() });
      browse(res.path);
    } catch { /* toast already shown */ }
  };
}

document.addEventListener("DOMContentLoaded", init);
