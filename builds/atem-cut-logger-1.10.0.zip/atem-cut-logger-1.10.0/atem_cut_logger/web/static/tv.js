"use strict";
/* ATEM Cut Logger — the TVs section. Each card is built from what that TV's
   driver says it can do, so every button a brand accepts shows up without a
   special screen per brand. Uses helpers from app.js, icons.js and control.js. */

let tvs = [];
let tvCatalog = [];
let tvBusy = false;
let tvEditing = null;                 // host being edited, or "" for a new TV
const tvDetails = new Map();          // host -> {sources, apps, volume}
const tvOpenRemotes = new Set();

async function refreshTVs() {
  if (tvBusy || currentView !== "tvs") return;
  tvBusy = true;
  try {
    const res = await fetch("/api/displays", { method: "POST", body: "{}",
      headers: { "Content-Type": "application/json" } });
    if (res.ok) {
      const data = await res.json();
      tvs = data.displays || [];
      tvCatalog = data.catalog || [];
      renderTVs();
    }
  } catch { /* keep last */ }
  finally { tvBusy = false; }
}

const tvCmd = (hosts, action, value) =>
  post("/api/displays/command", { hosts, action, value });

function tvCard(t) {
  const h = escapeAttr(t.host);
  const feats = new Set(t.features || []);
  const keys = t.keys || [];
  const has = (k) => keys.some((x) => x.key === k);
  const key = (k, icon, label, cls = "iconbtn") => has(k)
    ? `<button class="${cls}" title="${escapeAttr(label)}" data-tvkey="${k}" data-tv="${h}">${icon ? ic(icon) : escapeHtml(label)}</button>` : "";
  const d = tvDetails.get(t.host) || {};
  const sources = (d.sources || []).map((s) =>
    `<option value="${escapeAttr(s.id)}" data-name="${escapeAttr(s.name)}">${escapeHtml(s.name || s.id)}</option>`).join("");
  const apps = (d.apps || []).map((a, i) =>
    `<button class="btn ghost sm" data-tvapp="${i}" data-tv="${h}">${escapeHtml(a.name)}</button>`).join("");
  const open = tvOpenRemotes.has(t.host);
  return `<section class="card tv${t.on ? " on" : ""}" data-tvhost="${h}">
    <div class="head">
      <h3>${escapeHtml(t.name)}</h3>
      <span class="hint">${escapeHtml(t.label || t.kind)} · ${escapeHtml(t.host)}</span>
      <div style="flex:1"></div>
      <span class="badge ${t.on ? "ok" : "off"}" title="${t.on ? "" : "Off, asleep, or this computer can't reach it"}">${t.on ? "On" : "Off"}</span>
      <button class="iconbtn" title="Edit this TV" data-tvedit="${h}">${ic("settings")}</button>
    </div>
    <div class="body tvbody">
      <div class="row" style="align-items:center">
        <button class="btn secondary" data-tvpower="on" data-tv="${h}">${ic("power")} On</button>
        <button class="btn secondary" data-tvpower="off" data-tv="${h}">${ic("power")} Off</button>
        <div class="spacer" style="flex:1"></div>
        ${key("KEY_VOLUMEDOWN", "voldown", "Volume down") || key("VolumeDown", "voldown", "Volume down")}
        ${key("KEY_MUTE", "mute", "Mute") || key("VolumeMute", "mute", "Mute")}
        ${key("KEY_VOLUMEUP", "volup", "Volume up") || key("VolumeUp", "volup", "Volume up")}
      </div>
      ${feats.has("sources") || feats.has("apps") ? `<div class="row" style="align-items:flex-end">
        ${sources ? `<label class="field" style="flex:1 1 180px">Input
          <select data-tvsource="${h}"><option value="">Choose…</option>${sources}</select></label>`
          : `<button class="btn ghost sm" data-tvload="${h}"${t.on ? "" : " disabled"}>${ic("input")} Load inputs &amp; apps</button>`}
        ${feats.has("volume") && d.volume != null ? `<label class="field" style="flex:1 1 180px">Volume ${d.volume}
          <input type="range" min="0" max="100" value="${d.volume}" data-tvvol="${h}"></label>` : ""}
      </div>` : ""}
      ${apps ? `<div class="apps">${apps}</div>` : ""}
      <details class="more" data-tvremote="${h}"${open ? " open" : ""}>
        <summary>Remote</summary>
        <div class="remote">
          <div class="dpad">
            <span></span>${key(has("KEY_UP") ? "KEY_UP" : "Up", "arrowup", "Up")}<span></span>
            ${key(has("KEY_LEFT") ? "KEY_LEFT" : "Left", "arrowleft", "Left")}
            ${key(has("KEY_OK") ? "KEY_OK" : "Select", "", "OK", "iconbtn okbtn")}
            ${key(has("KEY_RIGHT") ? "KEY_RIGHT" : "Right", "arrowright", "Right")}
            <span></span>${key(has("KEY_DOWN") ? "KEY_DOWN" : "Down", "arrowdown", "Down")}<span></span>
          </div>
          <div class="keys">${keys.map((k) =>
            `<button class="btn ghost sm" data-tvkey="${k.key}" data-tv="${h}">${escapeHtml(k.label)}</button>`).join("")}</div>
          ${feats.has("pair") ? `<p class="hint">If the TV shows a number and asks to pair, press
            <button class="btn ghost sm" data-tvpair="${h}">Pair…</button> and type it.</p>` : ""}
        </div>
      </details>
    </div></section>`;
}

function renderTVs() {
  const grid = $("#tvGrid");
  const viewOnly = !iDrive();
  const on = tvs.filter((t) => t.on).length;
  $("#tvSummary").textContent = tvs.length ? `${tvs.length} TV${tvs.length === 1 ? "" : "s"} · ${on} on` : "";
  $("#tvAllOn").disabled = !tvs.length || viewOnly;
  $("#tvAllOff").disabled = !tvs.length || viewOnly;
  $("#tvAdd").disabled = viewOnly;
  $("#tvFind").disabled = viewOnly;
  if (!tvs.length) {
    grid.innerHTML = `<section class="card"><div class="body empty">No TVs yet. Use <b>Add TV…</b> and type its IP address.</div></section>`;
    grid.dataset.html = "";
    return;
  }
  const html = tvs.map(tvCard).join("");
  if (grid.dataset.html === html) return;
  if (grid.contains(document.activeElement) && ["SELECT", "INPUT"].includes(document.activeElement.tagName)) return;
  grid.dataset.html = html;
  grid.innerHTML = html;
  wireTVs(viewOnly);
}

function wireTVs(viewOnly) {
  const grid = $("#tvGrid");
  const onErr = () => {};
  $$("button", grid).forEach((b) => { if (!b.dataset.tvedit && b.tagName === "BUTTON" && !b.closest("summary")) b.disabled = b.disabled || viewOnly; });
  $$("[data-tvkey]", grid).forEach((b) => (b.onclick = () => tvCmd([b.dataset.tv], "key", b.dataset.tvkey).catch(onErr)));
  $$("[data-tvpower]", grid).forEach((b) => (b.onclick = async () => {
    await tvCmd([b.dataset.tv], b.dataset.tvpower === "on" ? "power_on" : "power_off").catch(onErr);
    setTimeout(refreshTVs, 4000);
  }));
  $$("[data-tvload]", grid).forEach((b) => (b.onclick = () => loadTVDetails(b.dataset.tvload)));
  $$("[data-tvsource]", grid).forEach((sel) => (sel.onchange = () => {
    const opt = sel.selectedOptions[0];
    if (sel.value) tvCmd([sel.dataset.tvsource], "source", { id: sel.value, name: opt.dataset.name }).catch(onErr);
    sel.blur();
  }));
  $$("[data-tvvol]", grid).forEach((r) => (r.onchange = () => {
    tvCmd([r.dataset.tvvol], "volume", Number(r.value)).catch(onErr);
    const d = tvDetails.get(r.dataset.tvvol); if (d) d.volume = Number(r.value);
    r.blur();
  }));
  $$("[data-tvapp]", grid).forEach((b) => (b.onclick = () => {
    const app = (tvDetails.get(b.dataset.tv).apps || [])[Number(b.dataset.tvapp)];
    tvCmd([b.dataset.tv], "app", app).catch(onErr);
  }));
  $$("[data-tvpair]", grid).forEach((b) => (b.onclick = async () => {
    const code = window.prompt("Type the number shown on the TV:");
    if (code) { await tvCmd([b.dataset.tvpair], "pair", code).catch(onErr); toast("Pairing code sent."); }
  }));
  $$("[data-tvedit]", grid).forEach((b) => (b.onclick = () => openTV(b.dataset.tvedit)));
  $$("details[data-tvremote]", grid).forEach((el) => (el.ontoggle = () => {
    el.open ? tvOpenRemotes.add(el.dataset.tvremote) : tvOpenRemotes.delete(el.dataset.tvremote);
  }));
}

async function loadTVDetails(host) {
  try {
    tvDetails.set(host, await post("/api/displays/details", { host }));
  } catch { return; }
  $("#tvGrid").dataset.html = "";
  renderTVs();
}

/* Add / edit */
function openTV(host) {
  tvEditing = host || "";
  const t = tvs.find((x) => x.host === host) || { name: "", host: "", kind: "hisense", mac: "", cert: "", key: "" };
  $("#tvDlgTitle").textContent = host ? `Edit ${t.name}` : "Add TV";
  $("#tvKind").innerHTML = tvCatalog.map((c) => `<option value="${c.kind}">${escapeHtml(c.label)}</option>`).join("");
  $("#tvName").value = t.name; $("#tvHost").value = t.host; $("#tvKind").value = t.kind;
  $("#tvMac").value = t.mac || ""; $("#tvCert").value = t.cert || ""; $("#tvKey").value = t.key || "";
  $("#tvDetectResult").textContent = "";
  $("#tvRemove").classList.toggle("hidden", !host);
  openDialog("tvScrim");
}

function tvConfigs() {
  return tvs.map(({ name, host, kind, mac, cert, key }) => ({ name, host, kind, mac, cert, key }));
}

let tvFound = [];
async function findTVs() {
  const net = $("#tvFindNet").value.trim();
  try { localStorage.setItem("acl-tvnet", net); } catch { /* private window */ }
  $("#tvFindStatus").textContent = "Searching…";
  $("#tvFindBody").innerHTML = "";
  $("#tvFindAdd").disabled = true;
  let res;
  try { res = await post("/api/displays/scan", { networks: net ? [net] : [] }); }
  catch { $("#tvFindStatus").textContent = ""; return; }
  const known = new Set(tvs.map((x) => x.host));
  tvFound = res.found.filter((f) => !known.has(f.host));
  const already = res.found.length - tvFound.length;
  $("#tvFindStatus").textContent = res.found.length
    ? `Found ${res.found.length} TV${res.found.length === 1 ? "" : "s"}` + (already ? ` (${already} already added)` : "") + "."
    : "No TVs answered. Check they're in network standby and that this computer can reach their network.";
  $("#tvFindBody").innerHTML = tvFound.map((f, i) => `<tr>
    <td><input type="checkbox" data-tvf="${i}" checked></td>
    <td><input type="text" data-tvfname="${i}" value="${escapeAttr(f.name || "")}" placeholder="e.g. Stage Left TV"></td>
    <td class="tnum">${escapeHtml(f.host)}</td><td class="hint">${escapeHtml(f.label)}</td></tr>`).join("");
  $("#tvFindAdd").disabled = !tvFound.length || !iDrive();
}

function initTVs() {
  $("#tvAdd").onclick = () => openTV("");
  $("#tvFind").onclick = () => {
    try { $("#tvFindNet").value = localStorage.getItem("acl-tvnet") || ""; } catch { /* ignore */ }
    openDialog("tvFindScrim");
    findTVs();
  };
  $("#tvFindGo").onclick = findTVs;
  $("#tvFindAdd").onclick = async () => {
    const add = tvFound.filter((_f, i) => $(`[data-tvf="${i}"]`).checked).map((f, _i) => {
      const i = tvFound.indexOf(f);
      return { name: $(`[data-tvfname="${i}"]`).value.trim() || f.host, host: f.host, kind: f.kind,
        mac: "", cert: "", key: "" };
    });
    try {
      const data = await post("/api/displays/save", { displays: tvConfigs().concat(add) });
      tvs = data.displays; tvCatalog = data.catalog;
    } catch { return; }
    closeDialog("tvFindScrim");
    $("#tvGrid").dataset.html = ""; renderTVs();
  };
  $("#tvDetect").onclick = async () => {
    const host = $("#tvHost").value.trim();
    $("#tvDetectResult").textContent = "Checking…";
    let r; try { r = await post("/api/displays/probe", { host }); } catch { $("#tvDetectResult").textContent = ""; return; }
    if (r.kind) $("#tvKind").value = r.kind;
    $("#tvDetectResult").textContent = r.matches.length
      ? "Found: " + r.matches.map((m) => m.label).join(", ")
      : "Nothing answered. The TV may be off, on another network this computer can't reach, or have network control turned off.";
  };
  $("#tvSave").onclick = async () => {
    const item = { name: $("#tvName").value.trim(), host: $("#tvHost").value.trim(), kind: $("#tvKind").value,
      mac: $("#tvMac").value.trim(), cert: $("#tvCert").value.trim(), key: $("#tvKey").value.trim() };
    const list = tvConfigs().filter((t) => t.host !== tvEditing);
    list.push(item);
    try {
      const data = await post("/api/displays/save", { displays: list });
      tvs = data.displays; tvCatalog = data.catalog;
    } catch { return; }
    closeDialog("tvScrim");
    $("#tvGrid").dataset.html = ""; renderTVs();
  };
  $("#tvRemove").onclick = async () => {
    if (!window.confirm("Remove this TV from the app? (The TV itself isn't changed.)")) return;
    const list = tvConfigs().filter((t) => t.host !== tvEditing);
    const data = await post("/api/displays/save", { displays: list }).catch(() => null);
    if (data) { tvs = data.displays; }
    closeDialog("tvScrim");
    $("#tvGrid").dataset.html = ""; renderTVs();
  };
  const all = async (action) => {
    const res = await tvCmd(tvs.map((t) => t.host), action).catch(() => null);
    const bad = res ? res.results.filter((r) => !r.ok) : [];
    toast(bad.length ? `${bad.length} TV(s) didn't respond: ${bad[0].error}` : "Sent to all TVs.", !!bad.length);
    setTimeout(refreshTVs, 4000);
  };
  $("#tvAllOn").onclick = () => all("power_on");
  $("#tvAllOff").onclick = () => all("power_off");
}

document.addEventListener("DOMContentLoaded", initTVs);
