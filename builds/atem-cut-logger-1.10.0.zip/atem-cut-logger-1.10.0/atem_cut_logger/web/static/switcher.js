"use strict";
/* ATEM Cut Logger — the Switcher section: Program/Preview tally, macros with
   press-and-hold protection, and camera control. Loaded last; uses helpers
   from app.js, icons.js and control.js. State arrives on the SSE stream
   (snapshot, "tally" and "camera" messages), so nothing here polls. */

const HOLD_MS = 900;
let macroEditing = false;
let camSelected = null;
let camUnlocked = false;

/* ---- macros ---------------------------------------------------------------- */

function macroSetting(name) {
  const s = ((state && state.prefs && state.prefs.macros) || {})[name];
  return { protected: !s || s.protected !== false, on_log: !!(s && s.on_log) };
}

async function runMacro(m, held) {
  try {
    await post("/api/macro/run", { index: m.index, held });
    toast(`Ran “${m.name || "Macro " + m.index}”.`);
  } catch { /* toast shown */ }
}

/* A protected button fills while held and fires only when full. Letting go
   early — or sliding off it — cancels, so a stray click does nothing. */
function wireHold(btn, m) {
  let timer = null;
  const cancel = () => { clearTimeout(timer); timer = null; btn.classList.remove("holding"); };
  const start = (e) => {
    if (btn.disabled || timer) return;
    if (e && e.type === "pointerdown") btn.setPointerCapture?.(e.pointerId);
    btn.classList.add("holding");
    timer = setTimeout(() => { cancel(); runMacro(m, true); }, HOLD_MS);
  };
  btn.onpointerdown = start;
  btn.onpointerup = cancel;
  btn.onpointercancel = cancel;
  btn.onpointerleave = cancel;
  btn.onkeydown = (e) => { if ((e.key === " " || e.key === "Enter") && !e.repeat) { e.preventDefault(); start(); } };
  btn.onkeyup = (e) => { if (e.key === " " || e.key === "Enter") cancel(); };
  btn.onclick = (e) => e.preventDefault();
}

function macroButton(m, editable) {
  const set = macroSetting(m.name);
  const wrap = document.createElement("div");
  wrap.className = "macro";
  const b = document.createElement("button");
  b.className = "btn secondary macrobtn" + (set.protected ? " protected" : "");
  b.innerHTML = `<span class="fill"></span><span class="mlabel">${set.protected ? ic("lock") + " " : ""}${escapeHtml(m.name || "Macro " + m.index)}</span>`;
  b.title = set.protected ? "Protected — press and hold to run" : "Click to run";
  b.disabled = !iDrive();
  if (set.protected) wireHold(b, m); else b.onclick = () => runMacro(m, false);
  wrap.appendChild(b);
  if (editable) {
    const opts = document.createElement("div");
    opts.className = "macroopts";
    opts.innerHTML = `<label class="check"><input type="checkbox" data-mp${set.protected ? " checked" : ""}> Protected</label>
      <label class="check"><input type="checkbox" data-ml${set.on_log ? " checked" : ""}> On Log screen</label>`;
    const save = (field, value) => post("/api/macro/settings", { name: m.name, [field]: value }).catch(() => {});
    opts.querySelector("[data-mp]").onchange = (e) => save("protected", e.target.checked);
    opts.querySelector("[data-ml]").onchange = (e) => save("on_log", e.target.checked);
    opts.querySelectorAll("input").forEach((i) => (i.disabled = !iDrive()));
    wrap.appendChild(opts);
  }
  return wrap;
}

let renderedMacroKey = "";
function renderMacroPanels() {
  if (!state) return;
  const macros = state.macros || [];
  const key = JSON.stringify([macros, (state.prefs || {}).macros, macroEditing, iDrive()]);
  if (key === renderedMacroKey) return;
  renderedMacroKey = key;

  const pinned = macros.filter((m) => macroSetting(m.name).on_log);
  $("#macroCard").classList.toggle("hidden", !pinned.length);
  const strip = $("#macroButtons");
  strip.innerHTML = "";
  pinned.forEach((m) => strip.appendChild(macroButton(m, false)));

  const panel = $("#swMacros");
  panel.innerHTML = "";
  if (!macros.length) panel.innerHTML = '<div class="hint">The switcher has no macros.</div>';
  macros.forEach((m) => panel.appendChild(macroButton(m, macroEditing)));
  $("#swMacroEdit").textContent = macroEditing ? "Done" : "Edit…";
  $("#swMacroEdit").disabled = !iDrive() || !macros.length;
}

/* ---- tally ----------------------------------------------------------------- */

function onTally() {
  $$("#swTally [data-in]").forEach((el) => {
    const id = Number(el.dataset.in);
    el.classList.toggle("pgm", id === state.program_input);
    el.classList.toggle("pvw", id === state.preview_input && id !== state.program_input);
  });
}

let renderedTallyKey = "";
function renderTallyGrid() {
  const inputs = (state.mappings || []).filter((m) => m.input_id < 1000);
  const key = JSON.stringify(inputs.map((m) => [m.input_id, m.name]));
  if (key !== renderedTallyKey) {
    renderedTallyKey = key;
    $("#swTally").innerHTML = inputs.map((m) =>
      `<div class="tile" data-in="${m.input_id}"><span class="num">${m.input_id}</span>
        <span class="lbl">${escapeHtml(m.name || "Input " + m.input_id)}</span></div>`).join("");
  }
  onTally();
}

/* ---- cameras --------------------------------------------------------------- */

function camValue(cam, c) {
  const v = (state.camera_values || {})[`${cam}.${c.cat}.${c.param}`];
  if (!v || !v.values || v.values[c.index || 0] == null) return null;
  return Number(v.values[c.index || 0]);
}
function camReadout(c, v) {
  if (v == null) return "—";
  if (c.scale) return String(Math.round(v / c.scale));
  if (c.kind === "f") return (Math.round(v * 100) / 100).toFixed(2);
  return String(Math.round(v));
}

let renderedCamKey = "";
function renderCameras() {
  const cams = (state.mappings || []).filter((m) => m.input_id <= 40).map((m) => m.input_id);
  if (camSelected == null || !cams.includes(camSelected)) camSelected = cams[0] ?? null;
  const pickKey = JSON.stringify([cams, camSelected]);
  if (pickKey !== $("#swCamPick").dataset.key) {
    $("#swCamPick").dataset.key = pickKey;
    $("#swCamPick").innerHTML = cams.slice(0, 20).map((id) =>
      `<button data-cam="${id}" class="${id === camSelected ? "active" : ""}">Cam ${id}</button>`).join("");
    $$("#swCamPick [data-cam]").forEach((b) => (b.onclick = () => {
      camSelected = Number(b.dataset.cam);
      renderCameras();
      post("/api/camera/refresh", { cam: camSelected }).catch(() => {});
    }));
  }
  const available = !!state.camera_available;
  $("#swCamNone").classList.toggle("hidden", available);
  $("#swCamGroups").classList.toggle("hidden", !available);
  $("#swCamLock").disabled = !available || !iDrive();
  $("#swCamRead").disabled = !available || camSelected == null;
  $("#swCamLock").innerHTML = camUnlocked ? `${ic("lock")} Lock controls` : `${ic("lock")} Unlock controls`;
  $("#swCamLock").classList.toggle("warnon", camUnlocked);
  if (!available || camSelected == null) return;

  const key = JSON.stringify([camSelected, camUnlocked, iDrive()]);
  if (key !== renderedCamKey) {
    renderedCamKey = key;
    const groups = {};
    (state.camera_controls || []).forEach((c) => (groups[c.group] ||= []).push(c));
    const locked = !camUnlocked || !iDrive();
    $("#swCamGroups").innerHTML = Object.entries(groups).map(([g, list]) =>
      `<div class="camgroup"><div class="sublabel">${escapeHtml(g)}</div>${list.map((c) => c.ui === "button"
        ? `<button class="btn secondary sm" data-camvoid="${c.id}"${locked ? " disabled" : ""}>${escapeHtml(c.label)}</button>`
        : `<label class="camrow" title="${escapeAttr(c.hint || "")}"><span class="cl">${escapeHtml(c.label)}</span>
            <span class="cv tnum" data-camout="${c.id}">—</span>
            <input type="range" min="${c.min}" max="${c.max}" step="${c.step}" data-camctl="${c.id}"${locked ? " disabled" : ""}></label>`).join("")}</div>`).join("");
    const byId = Object.fromEntries((state.camera_controls || []).map((c) => [c.id, c]));
    const sendSoon = new Map();
    $$("#swCamGroups [data-camctl]").forEach((r) => {
      const c = byId[r.dataset.camctl];
      r.oninput = () => {
        $(`[data-camout="${c.id}"]`).textContent = camReadout(c, Number(r.value));
        clearTimeout(sendSoon.get(c.id));
        sendSoon.set(c.id, setTimeout(() =>
          post("/api/camera/set", { cam: camSelected, control: c.id, value: Number(r.value) }).catch(() => {}), 80));
      };
      r.onchange = () => r.blur();
    });
    $$("#swCamGroups [data-camvoid]").forEach((b) => (b.onclick = () =>
      post("/api/camera/set", { cam: camSelected, control: b.dataset.camvoid }).then(() =>
        toast(`${byId[b.dataset.camvoid].label} sent to camera ${camSelected}.`)).catch(() => {})));
  }
  (state.camera_controls || []).forEach((c) => updateCamControl(c));
}

function updateCamControl(c) {
  if (c.ui !== "slider") return;
  const v = camValue(camSelected, c);
  const out = $(`[data-camout="${c.id}"]`), r = $(`[data-camctl="${c.id}"]`);
  if (!out || !r) return;
  if (document.activeElement !== r) {
    out.textContent = camReadout(c, v);
    if (v != null) r.value = v;
    r.classList.toggle("unknown", v == null);
  }
}

function onCameraValue(key) {
  if (currentView !== "switcher" || camSelected == null) return;
  const [cam, cat, param] = key.split(".").map(Number);
  if (cam !== camSelected) return;
  (state.camera_controls || []).filter((c) => c.cat === cat && c.param === param).forEach(updateCamControl);
}

/* ---- section --------------------------------------------------------------- */

function renderSwitcher() {
  if (!state) return;
  const on = !!state.connected;
  $("#swOffline").classList.toggle("hidden", on);
  ["#swTallyCard", "#swMacroCard", "#swCamCard"].forEach((s) => $(s).classList.toggle("hidden", !on));
  if (!on) { camUnlocked = false; return; }
  $("#swProduct").textContent = state.switcher_product || "";
  renderTallyGrid();
  renderMacroPanels();
  renderCameras();
}

document.addEventListener("DOMContentLoaded", () => {
  $("#swMacroEdit").onclick = () => { macroEditing = !macroEditing; renderedMacroKey = ""; renderMacroPanels(); };
  $("#swCamLock").onclick = () => { camUnlocked = !camUnlocked; renderedCamKey = ""; renderCameras(); };
  $("#swCamRead").onclick = () => camSelected != null &&
    post("/api/camera/refresh", { cam: camSelected }).catch(() => {});
  // Re-render whenever a full snapshot lands (the SSE "state" message).
  const base = window.render;
  window.render = function () { base(); if (currentView === "switcher") renderSwitcher(); };
});
