"use strict";
/* ATEM Cut Logger — the Recorders and Router sections.
   Loaded after app.js and uses its helpers ($, $$, post, toast, state, iDrive,
   openDialog, closeDialog, escapeHtml). These sections poll their devices only
   while they're on screen: the log's own SSE stream stays exactly as it was. */

/* ---- sections ------------------------------------------------------------ */
const VIEWS = ["log", "switcher", "recorders", "router", "tvs"];
let currentView = "log";
let pollTimer = null;

function showView(name) {
  if (!VIEWS.includes(name)) name = "log";
  currentView = name;
  $$("#viewTabs button").forEach((b) => b.classList.toggle("active", b.dataset.view === name));
  $$("main[data-view]").forEach((m) => m.classList.toggle("hidden", m.dataset.view !== name));
  try { localStorage.setItem("acl-view", name); } catch { /* private window */ }
  if (location.hash !== "#" + name) history.replaceState(null, "", "#" + name);
  clearInterval(pollTimer);
  pollTimer = null;
  if (name === "recorders") { refreshDecks(); pollTimer = setInterval(refreshDecks, 3000); }
  if (name === "router") { refreshRouter(); pollTimer = setInterval(refreshRouter, 2500); }
  if (name === "tvs") { refreshTVs(); pollTimer = setInterval(refreshTVs, 8000); }
  if (name === "switcher" && typeof renderSwitcher === "function") renderSwitcher();
}

/* ---- recorders ----------------------------------------------------------- */
let decks = [];
let deckBusy = false;
const openDecks = new Set();   // hosts whose settings panel is open

function fmtMinutes(sec) {
  if (!sec) return "full";
  const h = Math.floor(sec / 3600), m = Math.round((sec % 3600) / 60);
  return h ? `${h} h ${m} min left` : `${m} min left`;
}
function tcFrames(tc) {
  const p = String(tc || "").split(/[:;]/).map(Number);
  return p.length === 4 && p.every((n) => !isNaN(n)) ? p : null;
}
function totalDuration(clips) {
  // Adds up hh:mm:ss, ignoring frames — close enough to judge what's on a card.
  let s = 0;
  clips.forEach((c) => { const p = tcFrames(c.duration); if (p) s += p[0] * 3600 + p[1] * 60 + p[2]; });
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60;
  return h ? `${h} h ${m} min` : m ? `${m} min ${r} s` : `${r} s`;
}

async function refreshDecks() {
  if (deckBusy || currentView !== "recorders") return;
  deckBusy = true;
  try {
    const res = await fetch("/api/decks", { method: "POST", body: "{}",
      headers: { "Content-Type": "application/json" } });
    if (res.ok) renderDecks((await res.json()).decks || []);
  } catch { /* offline — keep the last picture */ }
  finally { deckBusy = false; }
}

function renderDecks(list) {
  decks = list;
  const grid = $("#deckGrid");
  const viewOnly = !iDrive();
  $("#decksRecord").disabled = !list.length || viewOnly;
  $("#decksStop").disabled = !list.length || viewOnly;
  const rolling = list.filter((d) => d.recording).length;
  const down = list.filter((d) => !d.reachable).length;
  $("#decksSummary").textContent = list.length
    ? `${list.length} recorder${list.length === 1 ? "" : "s"}` +
      (rolling ? ` · ${rolling} recording` : "") + (down ? ` · ${down} not responding` : "")
    : "";
  $("#recTabDot").classList.toggle("on", rolling > 0);

  if (!list.length) {
    grid.innerHTML = `<section class="card"><div class="body empty">No recorders set up yet. Use
      <b>Find recorders…</b> to add the HyperDecks on this network.</div></section>`;
    return;
  }
  // Patch card by card: a card is rebuilt only when something on it other
  // than the running timecode changed, and never while it's being edited.
  // The timecode ticks in place. Nothing flashes between polls.
  if (!grid.querySelector("[data-host]")) grid.innerHTML = "";
  const seen = new Set();
  list.forEach((d, i) => {
    seen.add(d.host);
    const html = deckCard(d);
    let card = grid.querySelector(`[data-host="${CSS.escape(d.host)}"]`);
    const editing = card && card.contains(document.activeElement) &&
      ["INPUT", "SELECT"].includes(document.activeElement.tagName);
    if (!card || (card.dataset.html !== html && !editing)) {
      const tmp = document.createElement("div");
      tmp.innerHTML = html;
      const fresh = tmp.firstElementChild;
      fresh.dataset.html = html;
      card ? card.replaceWith(fresh) : grid.appendChild(fresh);
      card = fresh;
      wireDeck(card);
    }
    if (grid.children[i] !== card) grid.insertBefore(card, grid.children[i]);
    const tc = card.querySelector("[data-tc]");
    const t = d.transport || {};
    if (tc) tc.textContent = t["display timecode"] || t.timecode || "—";
  });
  $$("#deckGrid > [data-host]").forEach((c) => { if (!seen.has(c.dataset.host)) c.remove(); });
}

function deckCard(d) {
  const h = escapeAttr(d.host);
  if (!d.reachable) {
    return `<section class="card deck down" data-host="${h}"><div class="head">
      <h3>${escapeHtml(d.name)}</h3><span class="hint">${escapeHtml(d.host)}</span>
      <div style="flex:1"></div><span class="badge error">Not responding</span></div>
      <div class="body hint">${escapeHtml(d.error || "")}</div></section>`;
  }
  const t = d.transport || {};
  const status = (t.status || "").toLowerCase();
  const badge = d.recording ? `<span class="badge rec">${ic("record")} REC</span>`
    : status === "play" ? `<span class="badge ok">${ic("play")} Playing</span>`
    : `<span class="badge idle">${escapeHtml(t.status || "idle")}</span>`;
  const slots = d.slots.map((s) => {
    const active = s.id === d.active_slot;
    if (!s.mounted) {
      return `<div class="slot empty"><div class="slotname">Slot ${s.id}</div>
        <div class="hint">No media</div></div>`;
    }
    const n = s.clips.length;
    return `<div class="slot${active ? " active" : ""}">
      <div class="slotname">Slot ${s.id}${active ? ' <span class="hint">· active</span>' : ""}</div>
      <div class="slotvol">${escapeHtml(s.volume || "Untitled")}</div>
      <div class="hint">${fmtMinutes(s.remaining_seconds)} · ${n} clip${n === 1 ? "" : "s"}${n ? " · " + totalDuration(s.clips) : ""}</div>
      <div class="slotbtns">
        ${active ? "" : `<button class="btn ghost sm" data-deck="${h}" data-act="select" data-slot="${s.id}">Make active</button>`}
        ${n ? `<button class="btn ghost sm" data-deck="${h}" data-clips="${s.id}">Clips</button>` : ""}
        <button class="btn ghost sm warnbtn" data-deck="${h}" data-format="${s.id}"${d.recording ? " disabled" : ""}>Format…</button>
      </div></div>`;
  }).join("");
  const cfg = d.config || {};
  const can = new Set(d.settable || []);
  const settings = [];
  if (can.has("timecode input")) settings.push(`<label class="field">Timecode source
      <select data-deck="${h}" data-cfg="timecode input">
        ${["internal", "external", "embedded", "preset", "clip"].map((v) =>
          `<option value="${v}"${cfg["timecode input"] === v ? " selected" : ""}>${v}</option>`).join("")}
      </select></label>`);
  if (can.has("timecode preset")) settings.push(`<label class="field">Timecode preset
      <div class="pathrow" style="margin:0"><input type="text" class="tnum" data-deck="${h}" data-cfg="timecode preset"
        value="${escapeAttr(cfg["timecode preset"] || "")}" placeholder="00:00:00:00">
      <button class="btn ghost sm" data-deck="${h}" data-tcnow>Now</button></div></label>`);
  if (can.has("record prefix")) settings.push(`<label class="field">Clip name prefix
      <input type="text" data-deck="${h}" data-cfg="record prefix" value="${escapeAttr(cfg["record prefix"] || "")}"></label>`);
  if (can.has("append timestamp")) settings.push(`<label class="check"><input type="checkbox" data-deck="${h}"
      data-cfg="append timestamp"${cfg["append timestamp"] === "true" ? " checked" : ""}> Add date and time to clip names</label>`);
  const old = !d.can_name_disk;
  const open = openDecks.has(d.host);
  return `<section class="card deck${d.recording ? " live" : ""}" data-host="${h}">
    <div class="head">
      <h3>${escapeHtml(d.name)}</h3>
      <span class="hint">${escapeHtml(d.model)} · ${escapeHtml(d.host)}</span>
      <div style="flex:1"></div>${badge}
    </div>
    <div class="body deckbody">
      <div class="deckrow">
        <div class="tc tnum" data-tc></div>
        <div class="transport">
          <button class="iconbtn" title="Previous clip" data-deck="${h}" data-act="prev">${ic("prev")}</button>
          <button class="iconbtn" title="Play" data-deck="${h}" data-act="play">${ic("play")}</button>
          <button class="iconbtn" title="Stop" data-deck="${h}" data-act="stop">${ic("stop")}</button>
          <button class="iconbtn" title="Next clip" data-deck="${h}" data-act="next">${ic("next")}</button>
          <button class="btn ghost sm" title="Show the live input on the deck's output" data-deck="${h}" data-act="preview">${ic("live")} Live input</button>
          <button class="btn ghost sm" title="Flash this deck's front panel so you can find it in the rack" data-deck="${h}" data-act="identify">Identify</button>
        </div>
      </div>
      <div class="slots">${slots}</div>
      <details class="more" data-settings="${h}"${open ? " open" : ""}>
        <summary>Deck settings</summary>
        <div class="decksettings">${settings.join("") ||
          '<p class="hint">This deck only reports its input and codec over the network.</p>'}
          <p class="hint">${old
            ? `Firmware reports control protocol ${escapeHtml(d.protocol)} — too old for disk names,
               timecode and clip-name settings. Update it with Blackmagic HyperDeck Setup to unlock them.`
            : ""} The deck's clock (the date and time written to files) can't be set over the network — set it
            on the deck's menu or in HyperDeck Setup.</p>
        </div>
      </details>
    </div></section>`;
}
function deckByHost(host) { return decks.find((d) => d.host === host); }

function wireDeck(root) {
  const viewOnly = !iDrive();
  $$("[data-act]", root).forEach((b) => {
    b.disabled = b.disabled || viewOnly;
    b.onclick = async () => {
      await post("/api/decks/transport", { host: b.dataset.deck, action: b.dataset.act,
        slot: Number(b.dataset.slot || 0) }).catch(() => {});
      refreshDecks();
    };
  });
  $$("[data-format]", root).forEach((b) => {
    b.disabled = b.disabled || viewOnly;
    b.onclick = () => openFormat(b.dataset.deck, Number(b.dataset.format));
  });
  $$("[data-clips]", root).forEach((b) => (b.onclick = () =>
    openClips(b.dataset.deck, Number(b.dataset.clips))));
  $$("[data-cfg]", root).forEach((el) => {
    el.disabled = viewOnly;
    el.onchange = async () => {
      const value = el.type === "checkbox" ? String(el.checked) : el.value.trim();
      await post("/api/decks/config", { host: el.dataset.deck,
        values: { [el.dataset.cfg]: value } }).catch(() => {});
      el.blur();
      refreshDecks();
    };
  });
  $$("[data-tcnow]", root).forEach((b) => (b.onclick = () => {
    const input = b.parentElement.querySelector("input");
    const d = new Date(), p = (n) => String(n).padStart(2, "0");
    input.value = `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}:00`;
    input.dispatchEvent(new Event("change"));
  }));
  $$("details[data-settings]", root).forEach((el) => (el.ontoggle = () => {
    el.open ? openDecks.add(el.dataset.settings) : openDecks.delete(el.dataset.settings);
  }));
}

/* Clips: pick one and it's cued on the deck, ready to play to its output. */
function openClips(host, slot) {
  const d = deckByHost(host);
  const s = d && d.slots.find((x) => x.id === slot);
  if (!s) return;
  if (!$("#clipScrim")) buildClipDialog();
  $("#clipTitle").textContent = `${d.name} · Slot ${slot} · ${s.volume || "Untitled"}`;
  $("#clipBody").innerHTML = s.clips.map((c) => `<tr>
    <td class="tnum">${c.id}</td><td>${escapeHtml(c.name)}</td>
    <td class="hint">${escapeHtml(c.video_format)}</td><td class="tnum">${escapeHtml(c.duration)}</td>
    <td><button class="btn ghost sm" data-cue="${c.id}"${iDrive() ? "" : " disabled"}>Cue</button>
        <button class="btn ghost sm" data-cueplay="${c.id}"${iDrive() ? "" : " disabled"}>${ic("play")} Play</button></td></tr>`).join("");
  $$("#clipBody [data-cue], #clipBody [data-cueplay]").forEach((b) => (b.onclick = async () => {
    const clip = Number(b.dataset.cue || b.dataset.cueplay);
    await post("/api/decks/transport", { host, action: "cue", slot, clip }).catch(() => {});
    if (b.dataset.cueplay) await post("/api/decks/transport", { host, action: "play" }).catch(() => {});
    toast(`Clip ${clip} ${b.dataset.cueplay ? "playing" : "cued"} on ${d.name}.`);
  }));
  openDialog("clipScrim");
}
function buildClipDialog() {
  const el = document.createElement("div");
  el.className = "scrim top"; el.id = "clipScrim";
  el.innerHTML = `<div class="modal" role="dialog" aria-label="Clips">
    <div class="head"><h2 id="clipTitle">Clips</h2><div style="flex:1"></div>
      <button class="iconbtn" data-close="clipScrim">${ic("close")}</button></div>
    <div class="body"><p class="hint lead">Cue a clip to see it on the deck's output (and on the
      multiview, if the deck feeds the switcher).</p>
      <div class="tablewrap" style="max-height:420px"><table>
      <thead><tr><th style="width:44px">#</th><th>File</th><th style="width:100px">Format</th>
        <th style="width:110px">Length</th><th style="width:150px"></th></tr></thead>
      <tbody id="clipBody"></tbody></table></div></div></div>`;
  document.body.appendChild(el);
  el.querySelector("[data-close]").onclick = () => closeDialog("clipScrim");
  el.addEventListener("mousedown", (e) => { if (e.target === el) closeDialog("clipScrim"); });
  return el;
}

/* Format: review what's there, choose filesystem and name, type ERASE. */
let formatReview = null;
async function openFormat(host, slot) {
  let r;
  try { r = await post("/api/decks/format/review", { host, slot }); } catch { return; }
  formatReview = r;
  const s = r.slot;
  $("#formatTitle").textContent = `Format ${r.deck} · Slot ${s.id}`;
  $("#formatFacts").innerHTML = [
    ["Recorder", `${escapeHtml(r.deck)} <span class="hint">${escapeHtml(r.model)}</span>`],
    ["Disk name", escapeHtml(s.volume || "Untitled")],
    ["On it", s.clips.length ? `${s.clips.length} clip${s.clips.length === 1 ? "" : "s"} · ${totalDuration(s.clips)}` : "No clips"],
    ["Space left", fmtMinutes(s.remaining_seconds) + (s.video_format ? ` at ${escapeHtml(s.video_format)}` : "")],
  ].map(([k, v]) => `<div><span>${k}</span><b>${v}</b></div>`).join("");
  $("#formatClips").innerHTML = s.clips.length
    ? s.clips.map((c) => `<tr><td class="tnum">${c.id}</td><td>${escapeHtml(c.name)}</td>
        <td class="hint">${escapeHtml(c.codec)}</td><td class="tnum">${escapeHtml(c.duration)}</td></tr>`).join("")
    : `<tr><td colspan="4" class="empty">The deck reports no clips on this media. Files it
        can't play (copied from a computer, other formats) aren't listed.</td></tr>`;
  $("#formatNameWrap").classList.toggle("hidden", !r.can_name_disk);
  $("#formatNoName").classList.toggle("hidden", r.can_name_disk);
  $("#formatName").value = s.volume || "";
  $("#formatConfirm").value = "";
  $("#formatGo").disabled = true;
  $$("#formatFs button").forEach((b) => b.classList.toggle("active", b.dataset.v === "exFAT"));
  $("#formatWhere").textContent = `${r.deck} · ${host}`;
  openDialog("formatScrim");
  setTimeout(() => $("#formatConfirm").focus(), 50);
}
function initFormat() {
  $$("#formatFs button").forEach((b) => (b.onclick = () =>
    $$("#formatFs button").forEach((x) => x.classList.toggle("active", x === b))));
  $("#formatConfirm").oninput = (e) =>
    ($("#formatGo").disabled = e.target.value.trim().toUpperCase() !== "ERASE");
  $("#formatGo").onclick = async () => {
    if (!formatReview) return;
    const fs = $("#formatFs button.active").dataset.v;
    $("#formatGo").disabled = true;
    $("#formatGo").textContent = "Formatting…";
    try {
      await post("/api/decks/format", { review_id: formatReview.review_id, filesystem: fs,
        name: $("#formatName").value.trim(), confirm: $("#formatConfirm").value });
      toast(`Slot ${formatReview.slot.id} on ${formatReview.deck} formatted.`);
      closeDialog("formatScrim");
    } catch { /* toast shown; the review is spent, so reopen to retry */
      closeDialog("formatScrim");
    } finally {
      $("#formatGo").textContent = "Erase & format";
      formatReview = null;
      setTimeout(refreshDecks, 1500);
    }
  };
}

/* Find recorders on the network and save the chosen ones. */
let foundDecks = [];
async function findDecks() {
  openDialog("findScrim");
  $("#findStatus").textContent = "Looking for HyperDecks on this computer's networks…";
  $("#findBody").innerHTML = "";
  let res;
  try { res = await post("/api/discover", { kind: "recorders" }); } catch { return; }
  const known = new Map((state.recorders || []).map((r) => [r.host, r]));
  foundDecks = res.found;
  (state.recorders || []).forEach((r) => {
    if (!foundDecks.some((f) => f.host === r.host)) foundDecks.push({ host: r.host, model: "(not found now)" });
  });
  $("#findStatus").textContent = res.found.length
    ? `Found ${res.found.length}. Tick the ones this computer should drive and give each a name.`
    : "No HyperDecks answered. Check they're powered, on the network, and that Ethernet control is on.";
  $("#findBody").innerHTML = foundDecks.map((f, i) => {
    const k = known.get(f.host);
    return `<tr><td><input type="checkbox" data-find="${i}"${k || !known.size ? " checked" : ""}></td>
      <td><input type="text" data-findname="${i}" value="${escapeAttr(k ? k.name : "")}" placeholder="e.g. ISO ${i + 1}"></td>
      <td class="tnum">${escapeHtml(f.host)}</td><td class="hint">${escapeHtml(f.model)}</td></tr>`;
  }).join("");
}
function initFind() {
  $("#decksFind").onclick = findDecks;
  $("#findAgain").onclick = findDecks;
  $("#findAdd").onclick = async () => {
    const rows = [];
    foundDecks.forEach((f, i) => {
      if (!$(`[data-find="${i}"]`).checked) return;
      const old = (state.recorders || []).find((r) => r.host === f.host);
      rows.push({ name: $(`[data-findname="${i}"]`).value.trim() || f.model || f.host,
        host: f.host, port: old ? old.port : 9993 });
    });
    await post("/api/recorders", { recorders: rows }).catch(() => {});
    closeDialog("findScrim");
    setTimeout(refreshDecks, 300);
  };
  $("#decksRecord").onclick = () => $("#recordAllBtn").click();
  $("#decksStop").onclick = () => $("#recordStopBtn").click();
}

/* ---- router -------------------------------------------------------------- */
let router = null;
let routerBusy = false;
let selectedOut = null;
const GENERIC = /^(input|output)\s+\d+$/i;

/* Replace an element's contents only when they actually differ, so a poll
   that finds nothing new leaves the screen (and the mouse's hover) alone. */
function setHtml(sel, html) {
  const el = $(sel);
  if (el.dataset.html !== html) { el.innerHTML = html; el.dataset.html = html; }
}

async function refreshRouter() {
  if (routerBusy || currentView !== "router") return;
  routerBusy = true;
  try {
    const res = await fetch("/api/router", { method: "POST", body: "{}",
      headers: { "Content-Type": "application/json" } });
    if (res.ok) { router = await res.json(); renderRouter(); }
  } catch { /* keep last */ }
  finally { routerBusy = false; }
}

function renderRouter() {
  const r = router || {};
  $("#routerSetup").classList.toggle("hidden", !!r.host);
  $("#routerMain").classList.toggle("hidden", !r.host);
  if (!r.host) return;
  $("#routerTitle").textContent = r.friendly_name || r.model || "Router";
  $("#routerStatus").textContent = r.reachable ? r.host : `${r.host} — ${r.error || "not responding"}`;
  $("#routerStatus").classList.toggle("errtext", !r.reachable);
  renderPresets();
  if (!r.reachable) { $("#routerOutputs").innerHTML = ""; $("#routerInputs").innerHTML = ""; return; }

  const q = $("#routerSearch").value.trim().toLowerCase();
  const hide = $("#routerHideGeneric").checked;
  const show = (label, i) => (!hide || !GENERIC.test(label.trim()) || i === selectedOut) &&
    (!q || label.toLowerCase().includes(q) || String(i + 1) === q);
  const viewOnly = !iDrive();

  const outHtml = r.outputs.map((label, o) => {
    if (!show(label, o)) return "";
    const src = r.inputs[r.routing[o]] ?? "";
    const lock = r.locks[o] && r.locks[o] !== "U";
    const unnamed = GENERIC.test(label.trim()) ? " unnamed" : "";
    return `<button class="xp out${unnamed}${o === selectedOut ? " sel" : ""}${lock ? " locked" : ""}" data-out="${o}">
      <span class="num">${o + 1}</span><span class="lbl">${escapeHtml(label)}</span>
      <span class="src">${lock ? ic("lock") + " " : ""}${escapeHtml(src)}</span></button>`;
  }).join("") || `<div class="hint">Nothing matches.</div>`;
  setHtml("#routerOutputs", outHtml);

  const cur = selectedOut != null ? r.routing[selectedOut] : null;
  $("#routerSourceHint").textContent = selectedOut != null
    ? `(for ${r.outputs[selectedOut]})` : "(pick a destination first)";
  const inHtml = r.inputs.map((label, i) => {
    if (!(i === cur || show(label, i))) return "";
    const unnamed = GENERIC.test(label.trim()) ? " unnamed" : "";
    return `<button class="xp in${unnamed}${i === cur ? " on" : ""}" data-in="${i}"
      ${selectedOut == null || viewOnly ? "disabled" : ""}>
      <span class="num">${i + 1}</span><span class="lbl">${escapeHtml(label)}</span></button>`;
  }).join("") || `<div class="hint">Nothing matches.</div>`;
  setHtml("#routerInputs", inHtml);

  $$("#routerOutputs [data-out]").forEach((b) => (b.onclick = () => {
    const o = Number(b.dataset.out);
    selectedOut = selectedOut === o ? null : o;
    renderRouter();
  }));
  $$("#routerInputs [data-in]").forEach((b) => (b.onclick = async () => {
    const i = Number(b.dataset.in), o = selectedOut;
    if (o == null) return;
    if (r.locks[o] && r.locks[o] !== "U") {
      toast(`${r.outputs[o]} is locked on the router.`, true); return;
    }
    r.routing[o] = i; renderRouter();           // show it at once; the poll confirms
    await post("/api/router/route", { routes: { [o]: i } }).catch(() => {});
    refreshRouter();
  }));
}

function renderPresets() {
  const r = router || {};
  const viewOnly = !iDrive();
  $("#routerPresets").innerHTML = (r.presets || []).map((p, k) =>
    `<span class="chip"><button class="chipgo" data-preset="${k}"${viewOnly ? " disabled" : ""}
      title="Route everything as saved">${escapeHtml(p.name)}</button><button class="chipx"
      data-predel="${k}" title="Delete preset"${viewOnly ? " disabled" : ""}>${ic("close")}</button></span>`).join("") +
    `<button class="btn ghost sm" id="presetSave"${viewOnly || !r.reachable ? " disabled" : ""}>+ Save current routing as preset…</button>`;
  $$("[data-preset]").forEach((b) => (b.onclick = async () => {
    const p = r.presets[Number(b.dataset.preset)];
    if (!window.confirm(`Route every output as saved in “${p.name}”?`)) return;
    await post("/api/router/preset/apply", { name: p.name }).catch(() => {});
    toast(`“${p.name}” applied.`); refreshRouter();
  }));
  $$("[data-predel]").forEach((b) => (b.onclick = async () => {
    const p = r.presets[Number(b.dataset.predel)];
    if (!window.confirm(`Delete the preset “${p.name}”?`)) return;
    await post("/api/router/preset/delete", { name: p.name }).catch(() => {});
    refreshRouter();
  }));
  const save = $("#presetSave");
  if (save) save.onclick = async () => {
    const name = window.prompt("Name this routing preset (e.g. Show, Rehearsal):");
    if (!name || !name.trim()) return;
    await post("/api/router/preset/save", { name: name.trim() }).catch(() => {});
    refreshRouter();
  };
}

function openLabels() {
  const r = router;
  if (!r || !r.reachable) return;
  const rows = (list, kind) => list.map((l, i) =>
    `<label class="labelrow"><span class="num">${i + 1}</span>
      <input type="text" maxlength="40" data-lkind="${kind}" data-li="${i}" value="${escapeAttr(l)}"></label>`).join("");
  $("#labelInputs").innerHTML = rows(r.inputs, "input");
  $("#labelOutputs").innerHTML = rows(r.outputs, "output");
  openDialog("labelScrim");
}

function initRouter() {
  $("#routerUse").onclick = async () => {
    await post("/api/router/host", { host: $("#routerHost").value.trim() }).catch(() => {});
    refreshRouter();
  };
  $("#routerFind").onclick = async () => {
    $("#routerFound").innerHTML = '<span class="hint">Looking…</span>';
    let res; try { res = await post("/api/discover", { kind: "router" }); } catch { return; }
    $("#routerFound").innerHTML = res.found.length
      ? res.found.map((f) => `<button class="btn secondary" data-rhost="${escapeAttr(f.host)}">${escapeHtml(f.host)}</button>`).join("")
      : '<span class="hint">No Videohub answered on this network.</span>';
    $$("[data-rhost]").forEach((b) => (b.onclick = () => { $("#routerHost").value = b.dataset.rhost; $("#routerUse").click(); }));
  };
  $("#routerChange").onclick = () => {
    $("#routerHost").value = (router && router.host) || "";
    $("#routerSetup").classList.remove("hidden");
  };
  $("#routerSearch").oninput = renderRouter;
  $("#routerHideGeneric").onchange = renderRouter;
  $("#routerEdit").onclick = openLabels;
  $("#labelSave").onclick = async () => {
    const changes = { input: {}, output: {} };
    $$("[data-lkind]").forEach((el) => {
      const kind = el.dataset.lkind, i = Number(el.dataset.li);
      const before = kind === "input" ? router.inputs[i] : router.outputs[i];
      if (el.value.trim() !== before) changes[kind][i] = el.value.trim();
    });
    for (const kind of ["input", "output"]) {
      if (Object.keys(changes[kind]).length)
        await post("/api/router/labels", { kind, labels: changes[kind] }).catch(() => {});
    }
    closeDialog("labelScrim");
    refreshRouter();
  };
}

/* ---- trace ----------------------------------------------------------------- */
function openTrace() {
  const r = router;
  if (!r || !r.reachable) return;
  const opts = (sel, withNone) => (withNone ? '<option value="-1">None — only watch recorders that have a picture</option>' : "") +
    r.inputs.map((l, i) => `<option value="${i}">${i + 1} · ${escapeHtml(l)}</option>`).join("");
  $("#traceBlank").innerHTML = opts(false);
  $("#traceLive").innerHTML = opts(true);
  // Best guess for "nothing plugged in": the highest-numbered unnamed input.
  const unnamed = r.inputs.map((l, i) => [l, i]).filter(([l]) => GENERIC.test(l.trim()));
  if (unnamed.length) $("#traceBlank").value = unnamed[unnamed.length - 1][1];
  $("#traceScope").querySelector('[value="selected"]').disabled = selectedOut == null;
  openDialog("traceScrim");
  post("/api/trace").then(onTrace).catch(() => {});
}
function onTrace(t) {
  if (!t) return;
  const running = !!t.running;
  $("#traceGo").classList.toggle("hidden", running);
  $("#traceStopBtn").classList.toggle("hidden", !running);
  $("#traceProgress").classList.toggle("hidden", !t.total);
  $("#traceBar").style.width = t.total ? `${Math.round(100 * t.done / t.total)}%` : "0";
  $("#traceWatch").textContent = t.watching ? `Watching: ${t.watching.join(", ") || "—"}` +
    (t.unreported && t.unreported.length ? ` · Can't tell (firmware doesn't report its input): ${t.unreported.join(", ")}` : "") : "";
  $("#traceStatus").textContent = t.error || (running ? `Tracing ${t.done} of ${t.total}…`
    : t.total ? `Done — ${t.results.filter((x) => x.feeds.length).length} output(s) matched a recorder.` : "");
  if (t.results && t.results.length) {
    $("#traceBody").innerHTML = t.results.map((x) => `<tr class="${x.feeds.length ? "hit" : ""}">
      <td class="tnum">${x.output + 1}</td><td>${escapeHtml(x.output_label)}</td>
      <td class="hint">${escapeHtml(x.source_label)}</td>
      <td>${x.feeds.length ? "<b>" + x.feeds.map(escapeHtml).join(", ") + "</b>" : '<span class="hint">no recorder</span>'}</td></tr>`).join("");
  }
}
function initTrace() {
  $("#routerTrace").onclick = openTrace;
  $("#traceGo").onclick = async () => {
    const r = router, scope = $("#traceScope").value;
    let outputs = null;
    if (scope === "unnamed") outputs = r.outputs.map((l, i) => [l, i]).filter(([l]) => GENERIC.test(l.trim())).map(([, i]) => i);
    if (scope === "selected") outputs = [selectedOut];
    if (!window.confirm("Router outputs will blink one at a time while this runs. Nothing is recording or live?")) return;
    $("#traceBody").innerHTML = '<tr><td colspan="4" class="empty">Starting…</td></tr>';
    try {
      onTrace(await post("/api/trace/start", { blank: Number($("#traceBlank").value),
        live: Number($("#traceLive").value), outputs }));
    } catch { $("#traceBody").innerHTML = '<tr><td colspan="4" class="empty">Not run.</td></tr>'; }
  };
  $("#traceStopBtn").onclick = () => post("/api/trace/stop").catch(() => {});
}

/* ---- boot ---------------------------------------------------------------- */
document.addEventListener("DOMContentLoaded", () => {
  $$("#viewTabs button").forEach((b) => (b.onclick = () => showView(b.dataset.view)));
  initFormat();
  initFind();
  initRouter();
  initTrace();
  let start = location.hash.slice(1);
  if (!VIEWS.includes(start)) { try { start = localStorage.getItem("acl-view") || "log"; } catch { start = "log"; } }
  showView(start);
  window.addEventListener("hashchange", () => showView(location.hash.slice(1)));
});
