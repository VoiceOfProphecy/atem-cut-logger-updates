"""Resolve-compatible timeline markers for flagged locations.

We reuse the exact cut timeline the app already exports (so an editor opens a
real, familiar sequence) and attach one FCPXML ``<marker>`` per issue at its
timecode. DaVinci Resolve reads these markers on import.

This is a thin adapter: it maps issues to :class:`TimelineMarker`s and delegates
to :func:`atem_cut_logger.fcpxml.export_fcpxml`, so the timeline structure stays
identical to the normal export.
"""

from __future__ import annotations

from ..fcpxml import TimelineMarker, export_fcpxml
from .model import AnalysisResult


def issues_to_markers(result: AnalysisResult) -> list[TimelineMarker]:
    markers: list[TimelineMarker] = []
    for issue in result.issues:
        name = f"{issue.title}: {issue.suggestion}"
        markers.append(TimelineMarker(frame=issue.frame, name=name))
    return markers


def export_markers_fcpxml(
    result: AnalysisResult,
    *,
    width: int = 1920,
    height: int = 1080,
    tc_synced_isos: bool = False,
    project_name: str = "ATEM Smart Cleanup — Markers",
    transitions: bool = False,
) -> str:
    """Return an FCPXML timeline with a marker at each flagged location."""
    return export_fcpxml(
        result.session,
        width=width,
        height=height,
        tc_synced_isos=tc_synced_isos,
        project_name=project_name,
        transitions=transitions,
        markers=issues_to_markers(result),
    )
