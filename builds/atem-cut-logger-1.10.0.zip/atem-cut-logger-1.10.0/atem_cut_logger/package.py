"""Save a whole session as one folder: every export plus the Smart Cleanup pass.

The folder is named after the session ("TVTL 01-08") and holds:

* ``<name>.atemlog.json`` — the master log; reopen it to export again later
* ``<name>.fcpxml``       — the Resolve timeline
* ``<name>.edl``          — the same cuts as a CMX3600 edit list
* ``<name>.csv``          — the cut list as a spreadsheet
* ``<name>-flags.fcpxml`` — only when moments were flagged with Mark Error
* ``<name>-cleanup.txt``, ``<name>-markers.fcpxml`` and, when accidental cuts
  were found, ``<name>-cleaned.fcpxml`` — only when Smart Cleanup runs

Files are written to a hidden temporary folder first and renamed into place at
the end, so a save that fails halfway (a NAS dropping off) never leaves a
half-written package that looks complete.
"""

from __future__ import annotations

import re
import shutil
from dataclasses import dataclass, field
from pathlib import Path

from .analysis import CleanupConfig, analyze
from .analysis.cleaned import export_cleaned_fcpxml
from .analysis.markers import export_markers_fcpxml
from .analysis.report import render_text
from .edl import export_edl
from .fcpxml import export_fcpxml, export_flags_fcpxml
from .session import LogSession


@dataclass
class PackageOptions:
    width: int = 1920
    height: int = 1080
    tc_synced_isos: bool = False
    transitions: bool = False
    run_cleanup: bool = True
    cleanup: CleanupConfig = field(default_factory=CleanupConfig)


@dataclass
class PackageResult:
    folder: Path
    files: list[str]
    issues: list[dict]
    counts: dict


def folder_name(session: LogSession) -> str:
    """A readable folder name: the session name as typed, minus characters no
    filesystem accepts; the start timecode when the session is unnamed."""
    name = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', "-", session.name).strip(" .-")
    return name[:80] or f"Session {session.start_timecode.replace(':', '-')}"


def _unique(path: Path) -> Path:
    if not path.exists():
        return path
    n = 2
    while True:
        candidate = path.with_name(f"{path.name} ({n})")
        if not candidate.exists():
            return candidate
        n += 1


def write_package(session: LogSession, parent: Path,
                  options: PackageOptions | None = None) -> PackageResult:
    if not session.events:
        raise ValueError("There are no logged cuts to save.")
    o = options or PackageOptions()
    base = session.export_basename() or "atem-cuts"
    title = session.name or base
    common = dict(width=o.width, height=o.height,
                  tc_synced_isos=o.tc_synced_isos, transitions=o.transitions)

    files: dict[str, str] = {
        f"{base}.atemlog.json": session.to_json(),
        f"{base}.fcpxml": export_fcpxml(session, project_name=title, **common),
        f"{base}.edl": export_edl(session, title=title),
        f"{base}.csv": session.to_csv(),
    }
    if session.flags:
        files[f"{base}-flags.fcpxml"] = export_flags_fcpxml(
            session, project_name=f"{title} — Flags", **common)

    issues: list[dict] = []
    counts: dict = {}
    if o.run_cleanup:
        result = analyze(session, o.cleanup)
        files[f"{base}-cleanup.txt"] = render_text(result)
        files[f"{base}-markers.fcpxml"] = export_markers_fcpxml(
            result, project_name=f"{title} — Smart Cleanup markers", **common)
        cleaned_xml, clean = export_cleaned_fcpxml(
            result, project_name=f"{title} — Cleaned", **common)
        if clean.removed_count:
            files[f"{base}-cleaned.fcpxml"] = cleaned_xml
        issues = [
            {"timecode": i.timecode, "type": i.issue_type, "title": i.title,
             "severity": i.severity, "camera": i.camera, "detail": i.detail,
             "suggestion": i.suggestion}
            for i in result.issues
        ]
        counts = result.issues_by_type()

    parent = Path(parent).expanduser()
    target = _unique(parent / folder_name(session))
    staging = parent / f".{target.name}.saving"
    shutil.rmtree(staging, ignore_errors=True)
    try:
        staging.mkdir(parents=True)
        for filename, text in files.items():
            (staging / filename).write_text(text, encoding="utf-8")
        staging.rename(target)
    except OSError:
        shutil.rmtree(staging, ignore_errors=True)
        raise
    return PackageResult(folder=target, files=list(files), issues=issues,
                         counts=counts)
