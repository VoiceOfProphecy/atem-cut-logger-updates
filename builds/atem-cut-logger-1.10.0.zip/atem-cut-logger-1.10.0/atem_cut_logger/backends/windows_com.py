"""Windows backend — drives the official Blackmagic ATEM Switcher SDK.

The SDK is installed with *ATEM Software Control* (or the ATEM Switchers SDK)
as a registered COM server, ``BMDSwitcherAPI(64).dll``. This backend uses the
same COM interfaces as Blackmagic's own ``SwitcherPanelCSharp`` sample:

* ``CBMDSwitcherDiscovery`` / ``IBMDSwitcherDiscovery::ConnectTo``
* ``IBMDSwitcher::CreateIterator`` -> ``IBMDSwitcherMixEffectBlockIterator``
  (first block returned == M/E 1)
* ``IBMDSwitcherMixEffectBlockCallback::Notify`` filtered for
  ``bmdSwitcherMixEffectBlockEventTypeProgramInputChanged`` — which fires on
  CUT and at AUTO-transition *completion* (see docs/ATEM_SDK_NOTES.md §5) —
  and for ``…InTransitionChanged``, which is what says the completion about to
  arrive was a dissolve rather than a cut
* ``IBMDSwitcherTransitionParameters`` plus the per-style ``…Transition*
  Parameters`` interfaces for that transition's style and length
* ``IBMDSwitcherCallback::Notify`` for ``bmdSwitcherEventTypeDisconnected``

Requires: ``pip install comtypes`` and ATEM Software Control installed.
No protocol reverse-engineering — everything goes through Blackmagic's DLL.
"""

from __future__ import annotations

import threading
import time

from . import SwitcherBackend

# Candidate type libraries. ATEM Software Control registers the DLL; loading
# it through comtypes generates a Python module from its embedded typelib.
_TYPELIB_CANDIDATES = (
    r"C:\Program Files (x86)\Blackmagic Design\ATEM Switchers\BMDSwitcherAPI64.dll",
    r"C:\Program Files (x86)\Blackmagic Design\ATEM Switchers\BMDSwitcherAPI.dll",
    r"C:\Program Files\Blackmagic Design\ATEM Switchers\BMDSwitcherAPI64.dll",
    r"C:\Program Files\Blackmagic Design\ATEM Switchers\BMDSwitcherAPI.dll",
)

# Style enum -> the vocabulary the rest of the app speaks (see backends/
# __init__.py). Resolved by name at runtime because an older type library may
# not carry every one of them.
_STYLE_NAMES = (
    ("bmdSwitcherTransitionStyleMix", "mix"),
    ("bmdSwitcherTransitionStyleDip", "dip"),
    ("bmdSwitcherTransitionStyleWipe", "wipe"),
    ("bmdSwitcherTransitionStyleDVE", "dve"),
    ("bmdSwitcherTransitionStyleStinger", "sting"),
)

# Each style keeps its rate on its own parameters interface, so each has to be
# asked separately. A stinger's length lives in its media, not in a rate, so it
# has no entry: it reports zero frames and therefore logs as a cut, which is
# what the macOS bridge does too.
_RATE_INTERFACES = {
    "mix": "IBMDSwitcherTransitionMixParameters",
    "dip": "IBMDSwitcherTransitionDipParameters",
    "wipe": "IBMDSwitcherTransitionWipeParameters",
    "dve": "IBMDSwitcherTransitionDVEParameters",
}

_CONNECT_FAILURES = {
    1: "No response from the switcher at that address.",
    2: "The switcher is running incompatible firmware.",
    3: "Corrupt data received while connecting.",
    4: "State synchronisation failed while connecting.",
    5: "State synchronisation timed out while connecting.",
}


def _create_iterator(switcher, interface):
    """IBMDSwitcher::CreateIterator returns a raw void** — cast it properly.

    Depending on how comtypes generated the typelib wrapper, the out param
    arrives as an IUnknown pointer (QueryInterface works) or as a raw
    address (needs a ctypes cast).
    """
    import ctypes

    raw = switcher.CreateIterator(interface._iid_)
    if raw is None:
        return None
    if hasattr(raw, "QueryInterface"):
        return raw.QueryInterface(interface)
    return ctypes.cast(raw, ctypes.POINTER(interface))


def _query(obj, bmd, interface_name: str):
    """QueryInterface by type-library name, or None if either side lacks it.

    Every transition interface is optional: an old type library may not declare
    it and a small switcher may not implement it. Missing means "no transition
    detail", never an error the operator has to see.
    """
    interface = getattr(bmd, interface_name, None)
    if interface is None:
        return None
    try:
        return obj.QueryInterface(interface)
    except Exception:
        return None


def read_transition(bmd, me) -> tuple[str, int]:
    """The style and length in frames of the transition this M/E will perform.

    Read while the transition is running, which is the only window in which it
    describes the blend that is about to land on Program.
    """
    style = "mix"
    params = _query(me, bmd, "IBMDSwitcherTransitionParameters")
    if params is not None:
        lookup = {getattr(bmd, name): value
                  for name, value in _STYLE_NAMES if hasattr(bmd, name)}
        try:
            style = lookup.get(int(params.GetNextTransitionStyle()), "mix")
        except Exception:
            pass

    frames = 0
    interface_name = _RATE_INTERFACES.get(style)
    if interface_name:
        rate_params = _query(me, bmd, interface_name)
        if rate_params is not None:
            try:
                frames = int(rate_params.GetRate())
            except Exception:
                frames = 0
    return style, max(0, frames)


def in_transition(bmd, me) -> bool:
    """Whether an AUTO transition is running right now.

    The modern type library exposes ``GetInTransition``; a 6.x one only has the
    generic property getter (docs/ATEM_SDK_NOTES.md §4).
    """
    try:
        return bool(me.GetInTransition())
    except AttributeError:
        pass
    except Exception:
        return False
    prop = getattr(bmd, "bmdSwitcherMixEffectBlockPropertyIdInTransition", None)
    if prop is None:
        return False
    try:
        return bool(me.GetFlag(prop))
    except Exception:
        return False


class TransitionTracker:
    """Holds what a starting transition described until its end lands.

    ``ProgramInputChanged`` fires when the blend *completes* and says nothing
    about how the switch was made, so the style and length captured at the
    start are parked here and claimed by the next Program change. Anything else
    is a hard cut.
    """

    def __init__(self) -> None:
        self._pending: tuple[str, int] | None = None

    def started(self, style: str, frames: int) -> None:
        self._pending = (str(style or "mix"), max(0, int(frames)))

    def take(self) -> tuple[str, int]:
        pending, self._pending = self._pending, None
        return pending or ("cut", 0)


def _load_sdk():
    import comtypes.client

    last_error: Exception | None = None
    for path in _TYPELIB_CANDIDATES:
        try:
            return comtypes.client.GetModule(path)
        except OSError as exc:
            last_error = exc
    raise RuntimeError(
        "Could not load the Blackmagic ATEM Switcher SDK type library. "
        "Install ATEM Software Control (which registers BMDSwitcherAPI64.dll) "
        f"and try again. Last error: {last_error}"
    )


class WindowsComBackend(SwitcherBackend):
    def __init__(self, listener):
        super().__init__(listener)
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._tc_request = threading.Event()
        self._tc_done = threading.Event()
        self._tc_result: tuple[str, bool] | None = None

    def connect(self, address: str) -> None:
        if not address:
            raise RuntimeError("An ATEM IP address is required.")
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._run, args=(address,), name="atem-com", daemon=True
        )
        self._thread.start()

    def disconnect(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
            self._thread = None

    def get_current_timecode(self, timeout: float = 1.0):
        """Requests a read on the COM apartment thread (see the pump loop in
        ``_run``) — ``IBMDSwitcher::GetTimeCode`` must be called from the
        thread that owns the switcher's COM object under STA rules."""
        if not self._thread or not self._thread.is_alive():
            return None
        self._tc_result = None
        self._tc_done.clear()
        self._tc_request.set()
        if self._tc_done.wait(timeout):
            return self._tc_result
        return None

    # ----------------------------------------------------------- COM thread

    def _run(self, address: str) -> None:
        """Owns the COM apartment: connect, subscribe, pump until stopped."""
        try:
            import comtypes
            import comtypes.client
        except ImportError:
            self.listener.on_error(
                "The 'comtypes' package is required on Windows: pip install comtypes"
            )
            return

        try:
            comtypes.CoInitialize()
            bmd = _load_sdk()
            discovery = comtypes.client.CreateObject(
                bmd.CBMDSwitcherDiscovery, interface=bmd.IBMDSwitcherDiscovery
            )

            try:
                switcher, fail_reason = discovery.ConnectTo(address)
            except comtypes.COMError as exc:
                self.listener.on_error(
                    f"Could not connect to {address}: "
                    + _CONNECT_FAILURES.get(0, str(exc))
                )
                return
            if not switcher:
                self.listener.on_error(
                    f"Could not connect to {address}: "
                    + _CONNECT_FAILURES.get(int(fail_reason), f"code {fail_reason}")
                )
                return

            product = switcher.GetProductName()

            # M/E 1 = first mix effect block from the iterator.
            me_iter = _create_iterator(
                switcher, bmd.IBMDSwitcherMixEffectBlockIterator
            )
            me1 = me_iter.Next() if me_iter else None
            if not me1:
                self.listener.on_error("The switcher reported no mix effect blocks.")
                return

            inputs = self._enumerate_inputs(bmd, switcher)
            program = int(me1.GetProgramInput())

            events: list[tuple] = []  # (kind, payload, timestamp) from callbacks
            lock = threading.Lock()

            listener = self.listener
            stop = self._stop

            program_event = bmd.bmdSwitcherMixEffectBlockEventTypeProgramInputChanged
            transition_event = getattr(
                bmd, "bmdSwitcherMixEffectBlockEventTypeInTransitionChanged", None
            )

            class MeCallback(comtypes.COMObject):
                _com_interfaces_ = [bmd.IBMDSwitcherMixEffectBlockCallback]

                def Notify(self, event_type):
                    # Timestamp first: transition-completion accuracy.
                    t = time.monotonic()
                    if event_type == program_event:
                        with lock:
                            events.append(("program", int(me1.GetProgramInput()), t))
                    elif (transition_event is not None
                            and event_type == transition_event
                            and in_transition(bmd, me1)):
                        # Fires at start and end; only the start describes the
                        # blend, and only then are the parameters still the
                        # ones being applied.
                        with lock:
                            events.append(("transition", read_transition(bmd, me1), t))
                    # Preview and transition-position events stay ignored.
                    return 0

            class SwitcherCallback(comtypes.COMObject):
                _com_interfaces_ = [bmd.IBMDSwitcherCallback]

                def Notify(self, event_type, video_mode=None):
                    if event_type == bmd.bmdSwitcherEventTypeDisconnected:
                        with lock:
                            events.append(("disconnected", "Switcher disconnected", 0.0))
                    return 0

            me_cb = MeCallback()
            sw_cb = SwitcherCallback()
            me1.AddCallback(me_cb)
            switcher.AddCallback(sw_cb)

            listener.on_connected(product, inputs, program)

            # Pump COM messages; forward captured events in order.
            transitions = TransitionTracker()
            disconnected = False
            while not stop.is_set() and not disconnected:
                comtypes.client.PumpEvents(0.05)
                if self._tc_request.is_set():
                    self._tc_request.clear()
                    try:
                        h, m, s, f, drop = switcher.GetTimeCode()
                        sep = ";" if drop else ":"
                        self._tc_result = (
                            f"{h:02d}:{m:02d}:{s:02d}{sep}{f:02d}", bool(drop)
                        )
                    except Exception:
                        self._tc_result = None
                    self._tc_done.set()
                with lock:
                    pending, events[:] = events[:], []
                for kind, payload, t in pending:
                    if kind == "program":
                        style, frames = transitions.take()
                        listener.on_program_changed(payload, t, style, frames)
                    elif kind == "transition":
                        transitions.started(*payload)
                    else:
                        listener.on_disconnected(payload)
                        disconnected = True

            me1.RemoveCallback(me_cb)
            switcher.RemoveCallback(sw_cb)
            if not disconnected:
                listener.on_disconnected("Disconnected by user")
        except Exception as exc:  # surface anything COM throws at us
            self.listener.on_error(f"ATEM SDK error: {exc}")
        finally:
            try:
                comtypes.CoUninitialize()
            except Exception:
                pass

    @staticmethod
    def _enumerate_inputs(bmd, switcher) -> dict[int, str]:
        inputs: dict[int, str] = {}
        try:
            it = _create_iterator(switcher, bmd.IBMDSwitcherInputIterator)
            if not it:
                return inputs
            while True:
                inp = it.Next()
                if not inp:
                    break
                try:
                    # Physical camera inputs only; everything else is still
                    # logged by ID if it ever hits Program.
                    if inp.GetPortType() == bmd.bmdSwitcherPortTypeExternal:
                        inputs[int(inp.GetInputId())] = str(inp.GetLongName())
                except Exception:
                    continue
        except Exception:
            pass
        return inputs
