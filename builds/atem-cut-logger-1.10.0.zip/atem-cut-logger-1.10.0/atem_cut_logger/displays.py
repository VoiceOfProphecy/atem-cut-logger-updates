"""TV and display control over the network.

Every TV brand speaks its own language, so each one gets a small *driver*
behind the same interface: ``keys`` (every remote button it accepts),
``send_key``, and optional extras — inputs, volume, apps, pairing. The UI
builds itself from what a driver reports, so a new brand appears in full as
soon as its driver exists.

Drivers here:

* **Hisense VIDAA** (Hisense's own smart TVs, e.g. the A6 series) — the TV runs
  an MQTT broker on port 36669 over TLS, the same one Hisense's RemoteNOW app
  uses. Some firmware also wants the app's client certificate and a one-time
  PIN shown on screen; both are supported (the certificate is supplied by the
  operator, never bundled).
* **Roku TV** (TCL, Hisense Roku models, ...) — plain HTTP on port 8060.

Power-on for any brand is Wake-on-LAN: a "magic packet" to the TV's MAC
address. It only works when the TV's network standby / wake-on-LAN setting is
on, and it doesn't cross between networks unless the network lets directed
broadcasts through.

Stdlib only, like the rest of the app: MQTT 3.1.1 is spoken directly (it's a
handful of small binary packets), TLS comes from :mod:`ssl`.
"""

from __future__ import annotations

import ipaddress
import json
import re
import socket
import ssl
import struct
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from dataclasses import dataclass, field

CONNECT_TIMEOUT = 3.0


class DisplayError(Exception):
    """A user-facing TV problem."""


# ----------------------------------------------------------------- config

@dataclass
class DisplayConfig:
    name: str
    host: str
    kind: str = "hisense"          # a key of DRIVERS
    mac: str = ""                  # for Wake-on-LAN
    cert: str = ""                 # VIDAA client certificate (PEM path), optional
    key: str = ""                  # its private key (PEM path), optional

    def to_dict(self) -> dict:
        return {"name": self.name, "host": self.host, "kind": self.kind,
                "mac": self.mac, "cert": self.cert, "key": self.key}

    @classmethod
    def from_dict(cls, data: dict) -> "DisplayConfig":
        host = str(data.get("host", "")).strip()
        if not host:
            raise DisplayError("A TV needs an IP address.")
        kind = str(data.get("kind") or "hisense")
        if kind not in DRIVERS:
            raise DisplayError(f"Unknown TV type “{kind}”.")
        mac = str(data.get("mac") or "").strip()
        if mac and not normalise_mac(mac):
            raise DisplayError(f"“{mac}” isn't a MAC address (looks like 00:11:22:33:44:55).")
        return cls(name=str(data.get("name") or "").strip() or host, host=host,
                   kind=kind, mac=normalise_mac(mac) if mac else "",
                   cert=str(data.get("cert") or "").strip(),
                   key=str(data.get("key") or "").strip())


def normalise_mac(mac: str) -> str:
    digits = re.sub(r"[^0-9a-fA-F]", "", mac or "")
    if len(digits) != 12:
        return ""
    return ":".join(digits[i:i + 2] for i in range(0, 12, 2)).upper()


# ----------------------------------------------------------- wake-on-LAN

def wake(mac: str, host: str = "") -> None:
    mac = normalise_mac(mac)
    if not mac:
        raise DisplayError("Add the TV's MAC address to turn it on over the network.")
    packet = b"\xff" * 6 + bytes.fromhex(mac.replace(":", "")) * 16
    targets = {"255.255.255.255"}
    try:
        # The TV's own network's broadcast address, for when it's on another subnet.
        targets.add(str(ipaddress.IPv4Network(f"{host}/24", strict=False).broadcast_address))
    except ValueError:
        pass
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        for target in targets:
            for port in (9, 7):
                try:
                    s.sendto(packet, (target, port))
                except OSError:
                    pass


def reachable(host: str, port: int, timeout: float = 1.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def probe(host: str) -> dict:
    """Guess what kind of TV lives at ``host`` from which doors are open."""
    signatures = [
        ("hisense", 36669, "Hisense VIDAA"),
        ("roku", 8060, "Roku TV"),
        (None, 8001, "Samsung (Tizen) — not supported yet"),
        (None, 3000, "LG webOS — not supported yet"),
        (None, 6466, "Android / Google TV — not supported yet"),
    ]
    found = []
    for kind, port, label in signatures:
        if reachable(host, port, 0.8):
            found.append({"kind": kind, "port": port, "label": label})
    return {"host": host, "matches": found,
            "kind": next((f["kind"] for f in found if f["kind"]), "")}


def scan(extra_networks: list[str] | None = None) -> list[dict]:
    """TVs on this computer's networks (plus any typed in, like
    "192.168.51.0/24"), found by the control doors a supported TV opens."""
    from concurrent.futures import ThreadPoolExecutor
    from .discovery import local_networks

    nets = list(local_networks())
    for raw in extra_networks or []:
        raw = str(raw).strip()
        if not raw:
            continue
        if raw.count(".") == 3 and "/" not in raw:
            raw = raw.rsplit(".", 1)[0] + ".0/24"   # "192.168.51.37" or ".x" -> its /24
        try:
            net = ipaddress.IPv4Network(raw.replace("x", "0"), strict=False)
        except ValueError as exc:
            raise DisplayError(f"“{raw}” isn't a network (try 192.168.51.0/24).") from exc
        if net.num_addresses > 1024:
            raise DisplayError("Pick a smaller network (a /22 or smaller).")
        nets.append(net)
    hosts = sorted({str(h) for n in nets for h in n.hosts()},
                   key=lambda h: tuple(int(x) for x in h.split(".")))
    ports = [("hisense", HisenseVidaa.PORT), ("roku", RokuTV.PORT)]
    jobs = [(h, k, p) for h in hosts for k, p in ports]
    found: dict[str, str] = {}
    with ThreadPoolExecutor(max_workers=192) as pool:
        for (host, kind, _p), ok in zip(jobs, pool.map(lambda j: reachable(j[0], j[2], 0.6), jobs)):
            if ok:
                found.setdefault(host, kind)
    out = []
    for h, k in found.items():
        item = {"host": h, "kind": k, "label": DRIVERS[k].label, "name": ""}
        if k == "roku":
            # Roku TVs say what they are; use it as the suggested name.
            try:
                with urllib.request.urlopen(f"http://{h}:{RokuTV.PORT}/query/device-info",
                                            timeout=1.5) as r:
                    text = r.read().decode("utf-8", "replace")
                m = re.search(r"<user-device-name>([^<]+)<", text) or \
                    re.search(r"<friendly-device-name>([^<]+)<", text)
                model = re.search(r"<model-name>([^<]+)<", text)
                item["name"] = m.group(1).strip() if m else ""
                if model:
                    item["label"] += f" · {model.group(1).strip()}"
            except (OSError, ValueError):
                pass
        out.append(item)
    return out


# ------------------------------------------------------------ MQTT (tiny)

def _varint(n: int) -> bytes:
    out = bytearray()
    while True:
        byte, n = n % 128, n // 128
        out.append(byte | (0x80 if n else 0))
        if not n:
            return bytes(out)


def _str(s: str) -> bytes:
    b = s.encode("utf-8")
    return struct.pack("!H", len(b)) + b


class MQTT:
    """Just enough MQTT 3.1.1 for a TV remote: connect, subscribe, publish,
    and collect whatever the TV says back for a moment."""

    def __init__(self, sock) -> None:
        self.sock = sock
        self._pid = 0

    def _send(self, kind: int, body: bytes) -> None:
        self.sock.sendall(bytes([kind]) + _varint(len(body)) + body)

    def _recv_exact(self, n: int) -> bytes:
        data = b""
        while len(data) < n:
            chunk = self.sock.recv(n - len(data))
            if not chunk:
                raise DisplayError("The TV closed the connection.")
            data += chunk
        return data

    def read(self) -> tuple[int, bytes]:
        head = self._recv_exact(1)[0]
        length, mult = 0, 1
        while True:
            b = self._recv_exact(1)[0]
            length += (b & 0x7F) * mult
            if not b & 0x80:
                break
            mult *= 128
        return head, self._recv_exact(length) if length else b""

    def connect(self, client_id: str, username: str, password: str) -> None:
        body = (_str("MQTT") + bytes([4, 0xC2]) + struct.pack("!H", 30)
                + _str(client_id) + _str(username) + _str(password))
        self._send(0x10, body)
        head, data = self.read()
        if head >> 4 != 2 or len(data) < 2:
            raise DisplayError("The TV didn't accept the connection.")
        if data[1] != 0:
            raise DisplayError("The TV refused the login — it may need its "
                               "certificate or pairing (see TV settings).")

    def subscribe(self, topic: str) -> None:
        self._pid = self._pid % 65535 + 1
        self._send(0x82, struct.pack("!H", self._pid) + _str(topic) + b"\x00")

    def publish(self, topic: str, payload: str = "") -> None:
        self._send(0x30, _str(topic) + payload.encode("utf-8"))

    def collect(self, seconds: float) -> list[tuple[str, str]]:
        """Messages published to us during the next ``seconds``."""
        deadline = time.monotonic() + seconds
        out = []
        while True:
            left = deadline - time.monotonic()
            if left <= 0:
                return out
            self.sock.settimeout(left)
            try:
                head, data = self.read()
            except (socket.timeout, TimeoutError):
                return out
            if head >> 4 == 3 and len(data) >= 2:
                n = struct.unpack("!H", data[:2])[0]
                topic = data[2:2 + n].decode("utf-8", "replace")
                rest = data[2 + n:]
                if head & 0x06:          # QoS 1/2 carry a packet id
                    rest = rest[2:]
                out.append((topic, rest.decode("utf-8", "replace")))

    def disconnect(self) -> None:
        try:
            self._send(0xE0, b"")
        except OSError:
            pass


# ------------------------------------------------------------ drivers

class Driver:
    label = "TV"
    keys: list[tuple[str, str]] = []   # (command, what the button is called)
    features: set[str] = set()         # "sources", "volume", "apps", "pair"

    def __init__(self, config: DisplayConfig) -> None:
        self.config = config

    def is_on(self) -> bool:
        raise NotImplementedError

    def send_key(self, key: str) -> None:
        raise NotImplementedError

    def power_on(self) -> None:
        wake(self.config.mac, self.config.host)

    def power_off(self) -> None:
        raise NotImplementedError

    def details(self) -> dict:
        return {}

    def describe(self) -> dict:
        return {"label": self.label, "features": sorted(self.features),
                "keys": [{"key": k, "label": l} for k, l in self.keys]}


# Every button on a VIDAA remote, in the order they sit on one.
VIDAA_KEYS = [
    ("KEY_POWER", "Power"), ("KEY_HOME", "Home"), ("KEY_MENU", "Menu"),
    ("KEY_BACK", "Back"), ("KEY_EXIT", "Exit"), ("KEY_INFO", "Info"),
    ("KEY_UP", "Up"), ("KEY_DOWN", "Down"), ("KEY_LEFT", "Left"),
    ("KEY_RIGHT", "Right"), ("KEY_OK", "OK"),
    ("KEY_VOLUMEUP", "Volume up"), ("KEY_VOLUMEDOWN", "Volume down"),
    ("KEY_MUTE", "Mute"), ("KEY_CHANNELUP", "Channel up"),
    ("KEY_CHANNELDOWN", "Channel down"), ("KEY_PLAY", "Play"),
    ("KEY_PAUSE", "Pause"), ("KEY_STOP", "Stop"), ("KEY_FORWARDS", "Fast forward"),
    ("KEY_BACKS", "Rewind"), ("KEY_SUBTITLE", "Subtitles"),
    ("KEY_RED", "Red"), ("KEY_GREEN", "Green"), ("KEY_YELLOW", "Yellow"),
    ("KEY_BLUE", "Blue"),
] + [(f"KEY_{n}", str(n)) for n in range(10)]


class HisenseVidaa(Driver):
    label = "Hisense VIDAA"
    keys = VIDAA_KEYS
    features = {"sources", "volume", "apps", "pair"}
    PORT = 36669
    USER, PASSWORD = "hisenseservice", "multimqttservice"

    def __init__(self, config: DisplayConfig) -> None:
        super().__init__(config)
        # The TV files replies under the id we connect with; a stable one per
        # computer keeps a completed pairing valid across restarts.
        self.client = "acl-" + format(uuid.getnode(), "012x")
        self.topic_id = f"{self.client}$normal"

    def _topic(self, service: str, action: str) -> str:
        return f"/remoteapp/tv/{service}/{self.topic_id}/actions/{action}"

    def _session(self, publishes: list[tuple[str, str]], listen: float = 0.0):
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE        # the TV's certificate is self-signed
        if self.config.cert:
            try:
                ctx.load_cert_chain(self.config.cert, self.config.key or None)
            except (OSError, ssl.SSLError) as exc:
                raise DisplayError(f"Couldn't load the TV certificate: {exc}") from exc
        try:
            raw = socket.create_connection((self.config.host, self.PORT), timeout=CONNECT_TIMEOUT)
            with ctx.wrap_socket(raw) as sock:
                sock.settimeout(CONNECT_TIMEOUT)
                m = MQTT(sock)
                m.connect(self.client, self.USER, self.PASSWORD)
                if listen:
                    m.subscribe(f"/remoteapp/mobile/{self.topic_id}/#")
                    m.subscribe("/remoteapp/mobile/broadcast/#")
                for topic, payload in publishes:
                    m.publish(topic, payload)
                replies = m.collect(listen) if listen else []
                m.disconnect()
                return replies
        except DisplayError:
            raise
        except (OSError, ssl.SSLError) as exc:
            raise DisplayError(f"{self.config.name}: {exc}") from exc

    def is_on(self) -> bool:
        return reachable(self.config.host, self.PORT)

    def send_key(self, key: str) -> None:
        if key not in dict(self.keys):
            raise DisplayError(f"Unknown button “{key}”.")
        self._session([(self._topic("remote_service", "sendkey"), key)])

    def power_off(self) -> None:
        if self.is_on():
            self.send_key("KEY_POWER")

    def set_volume(self, level: int) -> None:
        level = max(0, min(100, int(level)))
        self._session([(self._topic("platform_service", "changevolume"), str(level))])

    def set_source(self, source_id: str, name: str = "") -> None:
        self._session([(self._topic("ui_service", "changesource"),
                        json.dumps({"sourceid": str(source_id), "sourcename": name}))])

    def launch_app(self, app: dict) -> None:
        self._session([(self._topic("ui_service", "launchapp"),
                        json.dumps({k: app.get(k, "") for k in ("appId", "name", "url")}))])

    def pair(self, code: str) -> None:
        code = re.sub(r"\D", "", str(code or ""))
        if not code:
            raise DisplayError("Type the number shown on the TV.")
        self._session([(self._topic("ui_service", "authenticationcode"),
                        json.dumps({"authNum": int(code)}))], listen=1.5)

    def details(self) -> dict:
        replies = self._session([
            (self._topic("ui_service", "gettvstate"), ""),
            (self._topic("ui_service", "sourcelist"), ""),
            (self._topic("platform_service", "getvolume"), ""),
            (self._topic("ui_service", "applist"), ""),
        ], listen=2.5)
        out: dict = {"sources": [], "apps": [], "volume": None, "state": {}}
        for topic, payload in replies:
            try:
                data = json.loads(payload) if payload else None
            except ValueError:
                continue
            if topic.endswith("/sourcelist") and isinstance(data, list):
                out["sources"] = [{"id": str(s.get("sourceid", "")),
                                   "name": s.get("displayname") or s.get("sourcename", "")}
                                  for s in data]
            elif topic.endswith("/applist") and isinstance(data, list):
                out["apps"] = [{"appId": a.get("appId", ""), "name": a.get("name", ""),
                                "url": a.get("url", "")} for a in data]
            elif "volume" in topic and isinstance(data, dict):
                out["volume"] = data.get("volume_value")
            elif topic.endswith("/state") and isinstance(data, dict):
                out["state"] = data
                if data.get("statetype") == "authentication":
                    out["needs_pairing"] = True
        return out


ROKU_KEYS = [
    ("PowerOff", "Power off"), ("PowerOn", "Power on"), ("Home", "Home"),
    ("Back", "Back"), ("Up", "Up"), ("Down", "Down"), ("Left", "Left"),
    ("Right", "Right"), ("Select", "OK"), ("Info", "Options"),
    ("InstantReplay", "Replay"), ("Rev", "Rewind"), ("Play", "Play / pause"),
    ("Fwd", "Fast forward"), ("VolumeUp", "Volume up"),
    ("VolumeDown", "Volume down"), ("VolumeMute", "Mute"),
    ("ChannelUp", "Channel up"), ("ChannelDown", "Channel down"),
    ("InputTuner", "Antenna"), ("InputHDMI1", "HDMI 1"), ("InputHDMI2", "HDMI 2"),
    ("InputHDMI3", "HDMI 3"), ("InputHDMI4", "HDMI 4"), ("InputAV1", "AV"),
    ("Search", "Search"), ("Backspace", "Backspace"), ("Enter", "Enter"),
    ("FindRemote", "Find remote"),
]


class RokuTV(Driver):
    label = "Roku TV"
    keys = ROKU_KEYS
    features = {"sources", "apps"}
    PORT = 8060

    def _url(self, path: str) -> str:
        return f"http://{self.config.host}:{self.PORT}{path}"

    def _call(self, path: str, method: str = "POST") -> bytes:
        req = urllib.request.Request(self._url(path), method=method, data=b"" if method == "POST" else None)
        try:
            with urllib.request.urlopen(req, timeout=CONNECT_TIMEOUT) as r:
                return r.read()
        except (urllib.error.URLError, OSError) as exc:
            raise DisplayError(f"{self.config.name}: {exc}") from exc

    def is_on(self) -> bool:
        try:
            text = self._call("/query/device-info", "GET").decode("utf-8", "replace")
        except DisplayError:
            return False
        m = re.search(r"<power-mode>([^<]+)</power-mode>", text)
        return not m or m.group(1) == "PowerOn"

    def send_key(self, key: str) -> None:
        if key not in dict(self.keys):
            raise DisplayError(f"Unknown button “{key}”.")
        self._call("/keypress/" + urllib.parse.quote(key))

    def power_on(self) -> None:
        try:
            self.send_key("PowerOn")            # works from network standby
        except DisplayError:
            wake(self.config.mac, self.config.host)

    def power_off(self) -> None:
        self.send_key("PowerOff")

    def set_source(self, source_id: str, name: str = "") -> None:
        self.send_key(source_id)

    def launch_app(self, app: dict) -> None:
        self._call("/launch/" + urllib.parse.quote(str(app.get("appId", ""))))

    def details(self) -> dict:
        text = self._call("/query/apps", "GET").decode("utf-8", "replace")
        apps = [{"appId": i, "name": n} for i, n in
                re.findall(r'<app id="([^"]+)"[^>]*>([^<]+)</app>', text)]
        sources = [{"id": k, "name": l} for k, l in ROKU_KEYS if k.startswith("Input")]
        return {"sources": sources, "apps": apps, "volume": None, "state": {}}


DRIVERS = {"hisense": HisenseVidaa, "roku": RokuTV}


def driver_for(config: DisplayConfig) -> Driver:
    return DRIVERS[config.kind](config)


def catalog() -> list[dict]:
    """What each supported TV type can do — the UI's menu of TV types."""
    return [{"kind": k, **cls(DisplayConfig(name="", host="0.0.0.0")).describe()}
            for k, cls in DRIVERS.items()]
