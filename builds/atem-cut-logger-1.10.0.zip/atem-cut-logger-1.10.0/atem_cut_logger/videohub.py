"""Blackmagic Videohub router control over its TCP protocol (port 9990).

The router speaks plain text blocks, each a header line ending in ":" and a
body ended by a blank line. On connect it dumps its whole state:

    <- VIDEOHUB DEVICE:
    <- Model name: Blackmagic Smart Videohub 40 x 40
    <- (blank)
    <- INPUT LABELS:
    <- 0 Camera 1
    <- ...
    <- END PRELUDE:

and a change is sent the same way, answered with ACK or NAK:

    -> VIDEO OUTPUT ROUTING:
    -> 12 4
    -> (blank)
    <- ACK

Numbers on the wire start at 0; the UI shows them from 1, like the router's
own panel. Like the recorders, each call opens its own short connection, so a
router that goes away mid-show never leaves the app holding a dead socket.
"""

from __future__ import annotations

import socket
from dataclasses import dataclass, field

VIDEOHUB_PORT = 9990
CONNECT_TIMEOUT = 4.0
COMMAND_TIMEOUT = 6.0


class VideohubError(Exception):
    """A user-facing router problem (unreachable, refused change)."""


@dataclass
class VideohubState:
    model: str = ""
    friendly_name: str = ""
    unique_id: str = ""
    present: bool = False
    inputs: list[str] = field(default_factory=list)
    outputs: list[str] = field(default_factory=list)
    routing: list[int] = field(default_factory=list)   # output -> input
    locks: list[str] = field(default_factory=list)     # "U" / "O" / "L"

    def to_dict(self) -> dict:
        return {
            "model": self.model, "friendly_name": self.friendly_name,
            "unique_id": self.unique_id, "present": self.present,
            "inputs": self.inputs, "outputs": self.outputs,
            "routing": self.routing, "locks": self.locks,
        }


def parse_blocks(text: str) -> list[tuple[str, list[str]]]:
    blocks: list[tuple[str, list[str]]] = []
    header, body = None, []
    for raw in text.replace("\r", "").split("\n"):
        line = raw.rstrip()
        if header is None:
            if line.endswith(":"):
                header, body = line[:-1].strip(), []
            elif line in ("ACK", "NAK"):
                blocks.append((line, []))
            continue
        if not line:
            blocks.append((header, body))
            header = None
        else:
            body.append(line)
    if header is not None:
        blocks.append((header, body))
    return blocks


def apply_blocks(state: VideohubState, blocks) -> VideohubState:
    def indexed(body, size):
        out = {}
        for line in body:
            idx, _, value = line.partition(" ")
            if idx.isdigit():
                out[int(idx)] = value
        return out

    for header, body in blocks:
        if header == "VIDEOHUB DEVICE":
            fields = {k.strip().lower(): v.strip()
                      for k, _, v in (l.partition(":") for l in body)}
            state.present = fields.get("device present", "") == "true"
            state.model = fields.get("model name", state.model)
            state.friendly_name = fields.get("friendly name", state.friendly_name)
            state.unique_id = fields.get("unique id", state.unique_id)
            n_in = int(fields.get("video inputs") or 0)
            n_out = int(fields.get("video outputs") or 0)
            if n_in:
                state.inputs = (state.inputs + [""] * n_in)[:n_in]
            if n_out:
                state.outputs = (state.outputs + [""] * n_out)[:n_out]
                state.routing = (state.routing + [0] * n_out)[:n_out]
                state.locks = (state.locks + ["U"] * n_out)[:n_out]
        elif header == "INPUT LABELS":
            for i, v in indexed(body, len(state.inputs)).items():
                if i < len(state.inputs):
                    state.inputs[i] = v
        elif header == "OUTPUT LABELS":
            for i, v in indexed(body, len(state.outputs)).items():
                if i < len(state.outputs):
                    state.outputs[i] = v
        elif header == "VIDEO OUTPUT ROUTING":
            for i, v in indexed(body, len(state.routing)).items():
                if i < len(state.routing) and v.strip().isdigit():
                    state.routing[i] = int(v)
        elif header == "VIDEO OUTPUT LOCKS":
            for i, v in indexed(body, len(state.locks)).items():
                if i < len(state.locks):
                    state.locks[i] = v.strip()[:1] or "U"
    return state


class Videohub:
    def __init__(self, host: str, port: int = VIDEOHUB_PORT,
                 timeout: float = COMMAND_TIMEOUT) -> None:
        self.host = host
        self.port = port
        self.timeout = timeout

    def _session(self, message: str = "") -> tuple[str, str]:
        """Connect, read the prelude, optionally send one block and read the
        reply. Returns (prelude text, reply text)."""
        try:
            with socket.create_connection((self.host, self.port),
                                          timeout=CONNECT_TIMEOUT) as sock:
                sock.settimeout(self.timeout)
                prelude = self._read_until(sock, b"END PRELUDE:")
                reply = ""
                if message:
                    sock.sendall(message.encode("utf-8"))
                    reply = self._read_until(sock, b"ACK", b"NAK")
                return prelude, reply
        except VideohubError:
            raise
        except OSError as exc:
            raise VideohubError(f"Router ({self.host}): {exc}") from exc

    @staticmethod
    def _read_until(sock, *markers: bytes) -> str:
        buffer = bytearray()
        while not any(m in buffer for m in markers):
            chunk = sock.recv(8192)
            if not chunk:
                raise VideohubError("The router closed the connection.")
            buffer += chunk
        # Let the rest of that block arrive (the prelude's final blank line).
        return buffer.decode("utf-8", "replace")

    def state(self) -> VideohubState:
        prelude, _ = self._session()
        state = apply_blocks(VideohubState(), parse_blocks(prelude))
        if not state.present:
            raise VideohubError(
                f"{self.host} answers like a Videohub but no router is attached — "
                "it's probably a computer running Videohub software.")
        return state

    def _send(self, header: str, lines: list[str]) -> None:
        if not lines:
            return
        message = header + ":\n" + "\n".join(lines) + "\n\n"
        _, reply = self._session(message)
        if "NAK" in reply and "ACK" not in reply:
            raise VideohubError("The router refused that change.")

    def route(self, pairs: dict[int, int]) -> None:
        """{output: input}, both counted from 0."""
        self._send("VIDEO OUTPUT ROUTING",
                   [f"{int(o)} {int(i)}" for o, i in sorted(pairs.items())])

    def set_labels(self, kind: str, labels: dict[int, str]) -> None:
        header = {"input": "INPUT LABELS", "output": "OUTPUT LABELS"}.get(kind)
        if not header:
            raise VideohubError("Labels are for inputs or outputs.")
        lines = []
        for idx, label in sorted(labels.items()):
            text = " ".join(str(label).split())
            if len(text) > 40:
                raise VideohubError("Keep labels to 40 characters or fewer.")
            lines.append(f"{int(idx)} {text}")
        self._send(header, lines)

    def set_lock(self, output: int, locked: bool) -> None:
        # "O" takes the lock for this client; "F" force-clears anyone's lock.
        self._send("VIDEO OUTPUT LOCKS", [f"{int(output)} {'O' if locked else 'F'}"])
