"""HyperDeck (and compatible) recorder control over the Blackmagic TCP protocol.

Blackmagic's recorders speak a plain line protocol on port 9993 — the same one
ATEM Software Control uses — so this needs no SDK and no extra dependency:

    <- 500 connection info:
    <- protocol version: 1.11
    <- (blank line ends the block)
    -> record\\r\\n
    <- 200 ok

Used for two things:

* start/stop every recorder from the web UI, so the operator doesn't walk the
  rack before a show;
* notice when a deck *starts recording on its own* and begin logging in step
  with it, which is the case that actually keeps the log's timecode honest.

Every deck is independent: one unreachable recorder reports its own error and
never blocks the others, because a show doesn't stop for a dead deck.
"""

from __future__ import annotations

import socket
import threading
import time
from dataclasses import dataclass

HYPERDECK_PORT = 9993
CONNECT_TIMEOUT = 4.0
COMMAND_TIMEOUT = 6.0
# Blackmagic response codes this module cares about. Anything else in the
# 2xx range is a successful reply that carries data (slot info, disk list, ...);
# 1xx codes are the deck refusing ("105 no disk", "120 connection rejected").
OK_CODES = {200, 201, 208, 500}
FORMAT_READY = 216
NO_DISK = 105
# The two filesystems a HyperDeck can write, as the protocol spells them.
FILESYSTEMS = ("exFAT", "HFS+")
# Settings the Recorders tab may change. Anything else the deck reports is
# shown but left alone — a typo in a config key must not reach the deck.
SETTABLE_CONFIG = {
    "timecode input", "timecode preset", "record prefix", "append timestamp",
    "video input", "audio input", "file format", "record trigger",
}


def is_ok(code: int) -> bool:
    return code in OK_CODES or 200 <= code < 300


class RecorderError(Exception):
    """A user-facing recorder problem (unreachable deck, refused command)."""


@dataclass
class RecorderConfig:
    """One configured deck. ``name`` is the operator's label, not the device's."""

    name: str
    host: str
    port: int = HYPERDECK_PORT

    def to_dict(self) -> dict:
        return {"name": self.name, "host": self.host, "port": self.port}

    @classmethod
    def from_dict(cls, data: dict) -> "RecorderConfig":
        host = str(data.get("host", "")).strip()
        if not host:
            raise RecorderError("A recorder needs an IP address.")
        try:
            port = int(data.get("port") or HYPERDECK_PORT)
        except (TypeError, ValueError):
            raise RecorderError("Recorder port must be a number.") from None
        if not (1 <= port <= 65535):
            raise RecorderError("Recorder port must be between 1 and 65535.")
        return cls(name=str(data.get("name", "")).strip() or host,
                   host=host, port=port)


@dataclass
class RecorderStatus:
    """What the UI shows for one deck."""

    name: str
    host: str
    reachable: bool = False
    recording: bool = False
    status: str = ""          # the deck's own transport status word
    timecode: str = ""
    clip: str = ""
    error: str = ""

    def to_dict(self) -> dict:
        return {
            "name": self.name, "host": self.host, "reachable": self.reachable,
            "recording": self.recording, "status": self.status,
            "timecode": self.timecode, "clip": self.clip, "error": self.error,
        }


class HyperDeck:
    """A short-lived connection to one deck. Not kept open between commands:
    a recorder that goes away mid-show must not leave the app holding a dead
    socket, and the protocol is cheap to reconnect."""

    def __init__(self, config: RecorderConfig, timeout: float = COMMAND_TIMEOUT):
        self.config = config
        self.timeout = timeout

    # ------------------------------------------------------------- protocol

    def _read_block(self, sock: socket.socket, buffer: bytearray) -> tuple[int, list[str]]:
        """Read one response block: a status line, optionally followed by
        indented lines ended by a blank line."""
        while b"\r\n" not in buffer:
            chunk = sock.recv(4096)
            if not chunk:
                raise RecorderError("The recorder closed the connection.")
            buffer += chunk
        line, _, rest = bytes(buffer).partition(b"\r\n")
        buffer[:] = rest
        header = line.decode("utf-8", "replace").strip()
        code = int(header.split()[0]) if header[:1].isdigit() else 0
        lines: list[str] = []
        if code == FORMAT_READY:
            # "216 format ready" then the token on its own line — or, on some
            # firmware, the token after the colon on the same line.
            _, _, tail = header.partition("ready")
            tail = tail.strip(" :")
            if tail:
                return code, [tail]
        if header.endswith(":") or code == FORMAT_READY:
            while True:
                while b"\r\n" not in buffer:
                    chunk = sock.recv(4096)
                    if not chunk:
                        return code, lines
                    buffer += chunk
                line, _, rest = bytes(buffer).partition(b"\r\n")
                buffer[:] = rest
                text = line.decode("utf-8", "replace").strip()
                if not text:
                    break
                lines.append(text)
        return code, lines

    def command(self, *commands: str, strict: bool = True) -> list[tuple[int, list[str]]]:
        """Connect, send commands in order, return each response block.
        With ``strict`` off, a refusal is returned rather than raised — for
        questions whose "no" is an answer ("105 no disk")."""
        results: list[tuple[int, list[str]]] = []
        try:
            with socket.create_connection(
                (self.config.host, self.config.port), timeout=CONNECT_TIMEOUT
            ) as sock:
                sock.settimeout(self.timeout)
                buffer = bytearray()
                self._read_block(sock, buffer)  # the connection banner
                for command in commands:
                    sock.sendall((command + "\r\n").encode("utf-8"))
                    code, lines = self._read_block(sock, buffer)
                    if strict and not is_ok(code):
                        detail = lines[0] if lines else f"code {code}"
                        raise RecorderError(
                            f"{self.config.name} refused '{command}': {detail}"
                        )
                    results.append((code, lines))
        except RecorderError:
            raise
        except (OSError, ValueError) as exc:
            raise RecorderError(f"{self.config.name} ({self.config.host}): {exc}") from exc
        return results

    # -------------------------------------------------------------- actions

    @staticmethod
    def _fields(lines: list[str]) -> dict[str, str]:
        out = {}
        for line in lines:
            key, _, value = line.partition(":")
            out[key.strip().lower()] = value.strip()
        return out

    def transport(self) -> dict[str, str]:
        (_code, lines), = self.command("transport info")
        return self._fields(lines)

    def start_recording(self, clip_name: str = "") -> None:
        self.command(f"record: name: {clip_name}" if clip_name else "record")

    def stop_recording(self) -> None:
        self.command("stop")

    # ------------------------------------------------------ media & setup

    def info(self) -> dict:
        """Everything the Recorders tab shows for one deck, in one connection:
        model, firmware, what it can do, each slot and what's on it."""
        (_c, dev), (_c2, trans), (_c3, conf), (_c4, cmds) = self.command(
            "device info", "transport info", "configuration", "commands")
        device = self._fields(dev)
        params = parse_commands(cmds)
        # Older firmware doesn't report a slot count; every such deck has two.
        slot_count = _int(device.get("slot count"), 2)
        slot_commands = []
        for slot in range(1, slot_count + 1):
            slot_commands += [f"slot info: slot id: {slot}", f"disk list: slot id: {slot}"]
        replies = self.command(*slot_commands, strict=False) if slot_commands else []
        slots = []
        for i in range(0, len(replies), 2):
            number = i // 2 + 1
            (code, lines), (list_code, list_lines) = replies[i], replies[i + 1]
            if code == NO_DISK:
                slots.append(slot_payload({"slot id": str(number), "status": "empty"}, []))
            elif is_ok(code):
                clips = parse_disk_list(list_lines) if is_ok(list_code) else []
                slots.append(slot_payload(self._fields(lines), clips))
        transport = self._fields(trans)
        return {
            "model": device.get("model", ""),
            "protocol": device.get("protocol version", ""),
            "software": device.get("software version", ""),
            "unique_id": device.get("unique id", ""),
            "transport": transport,
            "recording": transport.get("status", "").lower() == "record",
            "active_slot": _int(transport.get("slot id"), 0),
            "config": self._fields(conf),
            "settable": sorted(k for k in SETTABLE_CONFIG
                               if k in params.get("configuration", set())),
            "can_name_disk": "name" in params.get("format", set()),
            "can_format_slot": "slot id" in params.get("format", set()),
            "slots": slots,
        }

    def transport_command(self, action: str, slot: int = 0, clip: int = 0) -> None:
        """Playback controls. Recording stays on the Record/Stop buttons."""
        commands = {
            "play": ["play"],
            "stop": ["stop"],
            "next": ["goto: clip id: +1"],
            "prev": ["goto: clip id: -1"],
            "start": ["goto: clip: start"],
            "end": ["goto: clip: end"],
            "preview": ["preview: enable: true"],
            # Flashes the deck's front panel so it can be found in the rack.
            "identify": ["identify: enable: true"],
        }
        if action == "select":
            if slot < 1:
                raise RecorderError("Pick a slot.")
            self.command(f"slot select: slot id: {slot}")
            return
        if action == "cue":
            if clip < 1:
                raise RecorderError("Pick a clip.")
            if slot:
                self.command(f"slot select: slot id: {slot}")
            self.command(f"goto: clip id: {clip}")
            return
        if action not in commands:
            raise RecorderError(f"Unknown transport action “{action}”.")
        self.command(*commands[action])

    def input_signal(self) -> str | None:
        """The video format arriving at the deck's input ("none" when there's
        no picture), or None when the firmware doesn't say."""
        (_code, lines), = self.command("transport info")
        return self._fields(lines).get("input video format")

    def set_config(self, values: dict) -> None:
        clean = {}
        for key, value in (values or {}).items():
            key = str(key).strip().lower()
            if key not in SETTABLE_CONFIG:
                raise RecorderError(f"“{key}” can't be changed from here.")
            text = str(value).strip()
            if "\n" in text or "\r" in text:
                raise RecorderError("Settings must be a single line.")
            clean[key] = text
        for key, value in clean.items():
            self.command(f"configuration: {key}: {value}")

    def format_slot(self, slot: int, filesystem: str, name: str = "",
                    can_format_slot: bool = True, can_name: bool = True) -> None:
        """Erase one slot. The two-step prepare/confirm is the deck's own
        safety catch; the caller is responsible for having shown the operator
        what's on the disk and got a deliberate confirmation first."""
        if filesystem not in FILESYSTEMS:
            raise RecorderError("Choose exFAT or HFS+.")
        name = clean_volume_name(name)
        prepare = f"format: prepare: {filesystem}"
        if can_format_slot:
            prepare = f"format: slot id: {slot} prepare: {filesystem}"
        if name and can_name:
            prepare += f" name: {name}"
        steps = [] if can_format_slot else [f"slot select: slot id: {slot}"]
        replies = self.command(*steps, prepare)
        code, lines = replies[-1]
        token = lines[0].strip() if lines else ""
        if code != FORMAT_READY or not token:
            raise RecorderError(f"{self.config.name} didn't get ready to format.")
        self.command(f"format: confirm: {token}")

    def status(self) -> RecorderStatus:
        state = RecorderStatus(name=self.config.name, host=self.config.host)
        try:
            fields = self.transport()
        except RecorderError as exc:
            state.error = str(exc)
            return state
        state.reachable = True
        state.status = fields.get("status", "")
        state.recording = state.status.lower() == "record"
        state.timecode = fields.get("timecode", "")
        state.clip = fields.get("clip id", "") or fields.get("clip", "")
        return state


def _int(value, default: int = 0) -> int:
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return default


def parse_commands(lines: list[str]) -> dict[str, set[str]]:
    """The deck's ``commands`` XML, as {command: {parameter, ...}}. Parsed by
    pattern rather than as XML: some firmware ships it malformed (the
    Studio 12G's ``shuttle`` entry isn't closed)."""
    import re
    out: dict[str, set[str]] = {}
    for line in lines:
        m = re.search(r'<command name="([^"]+)"', line)
        if not m:
            continue
        out[m.group(1)] = set(re.findall(r'<parameter name="([^"]+)"', line))
    return out


def parse_disk_list(lines: list[str]) -> list[dict]:
    """``1: Clip_01.mov QuickTimeProRes 1080p30 00:01:02:03`` lines → clips.
    The name may contain spaces, so it's everything before the last three
    fields."""
    clips = []
    for line in lines:
        head, sep, rest = line.partition(":")
        if not sep or not head.strip().isdigit():
            continue  # the "slot id: 1" line
        parts = rest.strip().split()
        if len(parts) >= 4:
            name, codec, video, duration = " ".join(parts[:-3]), *parts[-3:]
        else:
            name, codec, video, duration = rest.strip(), "", "", ""
        clips.append({"id": int(head), "name": name, "codec": codec,
                      "video_format": video, "duration": duration})
    return clips


def slot_payload(slot: dict, clips: list[dict]) -> dict:
    status = slot.get("status", "")
    return {
        "id": _int(slot.get("slot id"), 0),
        "status": status,
        "mounted": status == "mounted",
        "volume": slot.get("volume name", ""),
        "remaining_seconds": _int(slot.get("recording time"), 0),
        "video_format": slot.get("video format", ""),
        "blocked": slot.get("blocked", "") == "true",
        "clips": clips,
    }


def clean_volume_name(name: str) -> str:
    """What a card may be called: short, printable, nothing that would break
    the protocol line or a filesystem."""
    name = " ".join(str(name or "").split())
    bad = set(':/\\"*?<>|')
    if any(ch in bad for ch in name):
        raise RecorderError('Disk names can’t contain : / \\ " * ? < > |')
    if len(name) > 32:
        raise RecorderError("Keep the disk name to 32 characters or fewer.")
    return name


class RecorderPool:
    """The configured decks, driven together.

    Each deck is contacted on its own thread so one slow or dead recorder
    can't hold up the rest — the UI gets a full picture in roughly the time
    the slowest *reachable* deck takes.
    """

    def __init__(self, configs: list[RecorderConfig] | None = None,
                 factory=HyperDeck) -> None:
        self._lock = threading.RLock()
        self._configs: list[RecorderConfig] = list(configs or [])
        self._factory = factory

    # ------------------------------------------------------------- config

    @property
    def configs(self) -> list[RecorderConfig]:
        with self._lock:
            return list(self._configs)

    def set_configs(self, data: list[dict]) -> list[RecorderConfig]:
        configs = [RecorderConfig.from_dict(item) for item in data]
        seen: set[tuple[str, int]] = set()
        for config in configs:
            key = (config.host, config.port)
            if key in seen:
                raise RecorderError(f"{config.host} is listed twice.")
            seen.add(key)
        with self._lock:
            self._configs = configs
        return configs

    def to_payload(self) -> list[dict]:
        return [c.to_dict() for c in self.configs]

    # ------------------------------------------------------------ commands

    def _fan_out(self, action) -> list[RecorderStatus]:
        configs = self.configs
        results: list[RecorderStatus | None] = [None] * len(configs)

        def run(index: int, config: RecorderConfig) -> None:
            deck = self._factory(config)
            try:
                results[index] = action(deck, config)
            except RecorderError as exc:
                results[index] = RecorderStatus(name=config.name, host=config.host,
                                                error=str(exc))

        threads = [
            threading.Thread(target=run, args=(i, c), daemon=True)
            for i, c in enumerate(configs)
        ]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(timeout=COMMAND_TIMEOUT + CONNECT_TIMEOUT + 1)
        return [
            r if r is not None
            else RecorderStatus(name=c.name, host=c.host, error="Timed out.")
            for r, c in zip(results, configs)
        ]

    def status_all(self) -> list[RecorderStatus]:
        return self._fan_out(lambda deck, _c: deck.status())

    def record_all(self, clip_name: str = "") -> list[RecorderStatus]:
        def action(deck, _config):
            deck.start_recording(clip_name)
            return deck.status()
        return self._fan_out(action)

    def stop_all(self) -> list[RecorderStatus]:
        def action(deck, _config):
            deck.stop_recording()
            return deck.status()
        return self._fan_out(action)

    def deck(self, host: str) -> HyperDeck:
        for config in self.configs:
            if config.host == host:
                return self._factory(config)
        raise RecorderError("That recorder isn't set up any more.")

    def info_all(self) -> list[dict]:
        """Full detail for every deck, fetched side by side."""
        configs = self.configs
        results: list[dict | None] = [None] * len(configs)

        def run(index: int, config: RecorderConfig) -> None:
            base = {"name": config.name, "host": config.host}
            try:
                results[index] = {**base, "reachable": True,
                                  **self._factory(config).info()}
            except RecorderError as exc:
                results[index] = {**base, "reachable": False, "error": str(exc)}

        threads = [threading.Thread(target=run, args=(i, c), daemon=True)
                   for i, c in enumerate(configs)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(timeout=2 * (COMMAND_TIMEOUT + CONNECT_TIMEOUT) + 1)
        return [r or {"name": c.name, "host": c.host, "reachable": False,
                      "error": "Timed out."}
                for r, c in zip(results, configs)]

    def any_recording(self) -> bool:
        return any(s.recording for s in self.status_all())


class RecorderWatcher:
    """Polls the decks so logging can start when recording does.

    Deliberately a poll rather than the protocol's ``notify`` push: a persistent
    connection per deck would have to be babysat across network blips for the
    whole show, and a few seconds of latency costs nothing here — the log's
    start timecode comes from the switcher's generator, not from when this
    noticed.
    """

    def __init__(self, pool: RecorderPool, on_recording_started,
                 interval: float = 5.0) -> None:
        self.pool = pool
        self.interval = interval
        self._on_started = on_recording_started
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._was_recording = False
        self.enabled = False
        self.last: list[RecorderStatus] = []

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()

        def run() -> None:
            while not self._stop.wait(self.interval):
                if not self.enabled or not self.pool.configs:
                    continue
                statuses = self.pool.status_all()
                self.last = statuses
                recording = any(s.recording for s in statuses)
                if recording and not self._was_recording:
                    try:
                        self._on_started()
                    except Exception:
                        pass  # a refusal (already logging) is not the watcher's problem
                self._was_recording = recording

        self._thread = threading.Thread(target=run, name="recorder-watch", daemon=True)
        self._thread.start()

    def poll_once(self) -> list[RecorderStatus]:
        """Used by tests and by the UI's manual refresh."""
        statuses = self.pool.status_all()
        self.last = statuses
        recording = any(s.recording for s in statuses)
        if recording and not self._was_recording and self.enabled:
            self._on_started()
        self._was_recording = recording
        return statuses

    def stop(self) -> None:
        self._stop.set()


def wait_until(predicate, timeout: float = 5.0, interval: float = 0.05) -> bool:
    """Small helper for callers that need to wait on deck state."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return True
        time.sleep(interval)
    return False
