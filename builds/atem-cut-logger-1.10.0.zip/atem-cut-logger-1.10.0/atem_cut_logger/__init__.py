"""ATEM Cut Logger — log ATEM Program-bus switches, export Resolve timelines."""

__version__ = "1.10.0"
APP_NAME = "ATEM Cut Logger"
