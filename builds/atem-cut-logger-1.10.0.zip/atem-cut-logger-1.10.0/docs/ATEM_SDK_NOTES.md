# ATEM Switcher SDK — Integration Notes

This document records the SDK research done **before** production code was written,
and identifies the exact interfaces and callbacks ATEM Cut Logger relies on.

> **Source of these notes.** The Blackmagic ATEM Switchers SDK is macOS/Windows
> only and is distributed by Blackmagic behind a registration wall, so it cannot be
> bundled with this repository. The signatures below were verified against:
>
> * the official *ATEM Switchers SDK* developer manual
>   (`https://documents.blackmagicdesign.com/DeveloperManuals/ATEMSDKManual.pdf`),
> * verbatim copies of `BMDSwitcherAPI.h` as shipped with the SDK, and
> * Blackmagic's own `SwitcherPanel` (Cocoa) and `SwitcherPanelCSharp` sample
>   applications, which demonstrate the exact connect/monitor pattern this app uses.
>
> No protocol reverse-engineering is involved anywhere in this project — all device
> communication goes through Blackmagic's own `BMDSwitcherAPI` library.

---

## 1. How the SDK is delivered on each platform

| Platform | Delivery | How this app binds to it |
| --- | --- | --- |
| **Windows** | `BMDSwitcherAPI(64).dll`, a registered **COM server** installed with *ATEM Switchers* (ATEM Software Control). The SDK ships an IDL/type library; samples use C++ COM or the C# interop assembly. | `atem_cut_logger/backends/windows_com.py` loads the registered type library with `comtypes` and drives the same COM interfaces the official samples use. |
| **macOS** | `BMDSwitcherAPI.framework` installed to `/Library/Frameworks` by ATEM Software Control. The SDK provides `BMDSwitcherAPI.h` plus `BMDSwitcherAPIDispatch.cpp`, which loads the framework at runtime via `CFBundle` — you compile the dispatch file into your app; you do **not** link the framework directly. | `bridge/mac/atem_bridge.cpp` is a tiny helper compiled against the SDK headers (`make` — see `bridge/mac/README.md`). The Python app spawns it and receives newline-delimited JSON events. |

The entry point on both platforms is a switcher *discovery* object:

* Windows: `CoCreateInstance(CLSID_CBMDSwitcherDiscovery, …, IID_IBMDSwitcherDiscovery, …)`
* macOS: `CreateBMDSwitcherDiscoveryInstance()` (declared in `BMDSwitcherAPI.h`)

## 2. Connecting — `IBMDSwitcherDiscovery::ConnectTo`

Verbatim from `BMDSwitcherAPI.h` (macOS flavour; Windows uses `BSTR` instead of
`CFStringRef`):

```cpp
/* Interface IBMDSwitcherDiscovery - Used to discover and connect to switchers */

class IBMDSwitcherDiscovery : public IUnknown
{
public:
    virtual HRESULT ConnectTo (/* in */ CFStringRef deviceAddress,
                               /* out */ IBMDSwitcher** switcherDevice,
                               /* out */ BMDSwitcherConnectToFailure* failReason) = 0;
};
```

`deviceAddress` is the IP address the user typed. On failure, `failReason` is one of
`bmdSwitcherConnectToFailureNoResponse`, `…IncompatibleFirmware`,
`…CorruptData`, `…StateSync`, `…StateSyncTimedOut` — surfaced verbatim in the UI.

## 3. Finding M/E 1 — `IBMDSwitcherMixEffectBlockIterator`

```cpp
IBMDSwitcherMixEffectBlockIterator* iterator = nullptr;
switcher->CreateIterator(IID_IBMDSwitcherMixEffectBlockIterator, (void**)&iterator);

IBMDSwitcherMixEffectBlock* me0 = nullptr;
iterator->Next(&me0);          // FIRST block returned == M/E 1
```

Only the first block returned is used; later blocks (M/E 2…) are deliberately
ignored per the app requirements.

## 4. The exact callback this app is built around

### Modern SDK (7.5 and later, including current 9.x releases)

`IBMDSwitcherMixEffectBlock::AddCallback()` registers an
`IBMDSwitcherMixEffectBlockCallback` (IID `96010829-2029-4DA3-A34B-70368605ABAA`).
Its single method:

```cpp
class IBMDSwitcherMixEffectBlockCallback : public IUnknown
{
public:
    virtual HRESULT Notify (/* in */ BMDSwitcherMixEffectBlockEventType eventType) = 0;
};
```

The event types relevant to this application:

| Event | Meaning | How ATEM Cut Logger treats it |
| --- | --- | --- |
| `bmdSwitcherMixEffectBlockEventTypeProgramInputChanged` | The **Program bus** source of this M/E changed. | **The one event we log.** Read the new source with `IBMDSwitcherMixEffectBlock::GetProgramInput()` and timestamp it. |
| `bmdSwitcherMixEffectBlockEventTypePreviewInputChanged` | Preview bus changed. | **Ignored** (requirement: ignore Preview changes). |
| `bmdSwitcherMixEffectBlockEventTypeInTransitionChanged` | An AUTO transition started or finished. | **Not logged directly** — see §5. At the *start* it's the cue to read the transition's style and length (`IBMDSwitcherTransitionParameters` + the per-style `…Parameters` interface); that description is then attached to the Program change that ends the blend. |
| `bmdSwitcherMixEffectBlockEventTypeTransitionPositionChanged` | AUTO transition progress. | Ignored. |
| `bmdSwitcherMixEffectBlockEventTypeFadeToBlackStateChanged` etc. | Other M/E state. | Ignored. |

New program source is read with:

```cpp
BMDSwitcherVideoSource source;    // int64 enum; matches ATEM input numbers 1..N
me0->GetProgramInput(&source);
```

### Legacy SDK (≤ 6.x) — property-change form

Older SDK versions expose the same information through property IDs instead of
event types (verbatim from a 6.x `BMDSwitcherAPI.h`):

```cpp
class IBMDSwitcherMixEffectBlockCallback : public IUnknown
{
public:
    virtual HRESULT PropertyChanged (/* in */ BMDSwitcherMixEffectBlockPropertyId propertyId) = 0;
};

// bmdSwitcherMixEffectBlockPropertyIdProgramInput = 'pgip'
// bmdSwitcherMixEffectBlockPropertyIdPreviewInput = 'pvip'
// bmdSwitcherMixEffectBlockPropertyIdInTransition = 'intr'
int64_t program;
me0->GetInt(bmdSwitcherMixEffectBlockPropertyIdProgramInput, &program);
```

The macOS bridge supports both forms behind `#if` so it compiles against either SDK
generation. The Windows backend targets the modern type library but falls back to
the property getter for the in-transition flag, and treats every transition
interface as optional — a type library or a switcher that doesn't offer one just
means no transition detail, never an error.

## 5. Why `ProgramInputChanged` gives *transition completion*, not button presses

This is the key behavioural fact the whole logger depends on:

* **CUT** — the ATEM swaps the Program source instantly;
  `ProgramInputChanged` fires at the moment of the cut.
* **AUTO (mix/wipe/dip…)** — during the transition the Program *property* still
  holds the outgoing source. The switcher swaps Program/Preview **when the
  transition completes**, and only then does `ProgramInputChanged` fire.
  `InTransitionChanged` fires at transition start and end, but carries no source
  information, so it is not used for logging.

Both backends therefore pair the two events: `InTransitionChanged` says *how* the
switch is being made and `ProgramInputChanged` says *when* it landed and *to
what*. A Program change with no transition start before it is a hard cut.

Therefore, subscribing to `ProgramInputChanged` alone records **CUT points and
AUTO-transition completion points** — exactly what the requirements ask for — and
never records a T-bar/AUTO press that is cancelled or still in flight.

Duplicate suppression is still done in the app (`session.py`): if a notification
arrives but `GetProgramInput()` returns the same source as the last logged event
(e.g. a cut to the already-live input, or a redundant state-sync notification),
no event is recorded.

## 6. Input names — `IBMDSwitcherInputIterator` / `IBMDSwitcherInput`

Used to pre-fill the camera-mapping table with the switcher's own input labels:

```cpp
IBMDSwitcherInputIterator* inputIterator = nullptr;
switcher->CreateIterator(IID_IBMDSwitcherInputIterator, (void**)&inputIterator);

IBMDSwitcherInput* input = nullptr;
while (inputIterator->Next(&input) == S_OK) {
    BMDSwitcherInputId id;          // int64
    input->GetInputId(&id);
    CFStringRef longName;           // BSTR on Windows
    input->GetLongName(&longName);
    BMDSwitcherPortType type;
    input->GetPortType(&type);      // keep bmdSwitcherPortTypeExternal only
    input->Release();
}
```

Only `bmdSwitcherPortTypeExternal` inputs (physical camera inputs) are offered in
the mapping UI; Color/Bars/MediaPlayer sources are still logged by ID if they hit
Program.

## 7. Disconnect handling — `IBMDSwitcherCallback`

Verbatim:

```cpp
class IBMDSwitcherCallback : public IUnknown
{
public:
    virtual HRESULT Notify (/* in */ BMDSwitcherEventType eventType) = 0;
    // bmdSwitcherEventTypeDisconnected = 'sedi'
};
```

`switcher->AddCallback()` with this interface; on
`bmdSwitcherEventTypeDisconnected` the app stops the clock, keeps every event
already logged, flushes the JSON/CSV log and tells the user.

## 8. Threading note (from the SDK manual / samples)

SDK callbacks arrive on internal SDK threads (Windows: COM apartment threads —
the samples keep a message loop running; macOS: internal dispatch threads — the
Cocoa sample marshals to the main thread). Both native backends therefore do the
minimum inside the callback — capture a monotonic timestamp and the new source,
then hand off to the app's queue. Timestamps are taken **inside the callback** so
GUI latency never skews the logged cut times.
