# Roadmap / backlog

Things deliberately deferred to a later phase, not forgotten.

## Transition-aware logging — done

Transitions are logged with style and length (schema 2) on both the macOS
bridge and the Windows COM backend, exported as true dissolves in the EDL, and
in FCPXML either flattened to a cut at the blend's midpoint (the default) or
written as real `<transition>` elements.

## Other switcher capabilities not yet touched

Things the ATEM SDK exposes that this app doesn't log or use at all yet —
candidates for later phases, in no particular order:

- Downstream keyers (DSK) on/off and level
- Upstream keyers / SuperSource
- Fade-to-black events
- Multiview layout changes
- Audio mixer levels (the SDK exposes per-input fader/mute state)
- HyperDeck/recording control already partly explored in
  `docs/ATEM_SDK_NOTES.md` — record start/stop, clip info

None of these are scoped or started. Flag when one becomes relevant to an
actual production need, rather than building speculatively.

## Logging UI / session management

- [ ] **Session naming** — each logging session gets a user-supplied name (e.g.
  "TVTL 01-08", "Morning news A camera ISO"). Name is embedded in exported
  filenames (e.g. `tvtl-01-08.atemlog.json`). Added after first cut or
  pre-session in settings.

## Export & cleanup features

Requested in session but not yet built or scoped — recorded here so they don't
get lost between sessions.


## Setup TODO (not yet done)

- [ ] Run `bash service/mac/install.sh` **on Graphics 1** (the always-on Mac
  Studio) to install the background service. Not done yet — was set up in the
  repo but never installed on that machine. See `service/mac/README.md`.
