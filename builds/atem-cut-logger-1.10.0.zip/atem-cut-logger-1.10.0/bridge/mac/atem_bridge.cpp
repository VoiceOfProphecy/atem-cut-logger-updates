// atem_bridge — tiny macOS helper between ATEM Cut Logger and the official
// Blackmagic ATEM Switchers SDK.
//
// Usage:   atem-bridge <ip-address>
// Output:  newline-delimited JSON on stdout (see protocol below)
// Input:   "quit" on stdin exits cleanly (or EOF / SIGTERM). "tc" requests an
//          immediate read of the switcher's own timecode generator.
//          "macro <n>" runs switcher macro n.
//          Camera control (Blackmagic cameras over the ATEM's SDI return),
//          addressed as <camera> <category> <parameter> per Blackmagic's
//          Camera Control Protocol (e.g. 1 0 3 = camera 1, lens, iris):
//            "camget <cam> <cat> <param>"          -> one "cam" line
//            "camset <cam> <cat> <param> <v>..."   set absolute value(s)
//            "camoff <cam> <cat> <param> <v>..."   nudge by value(s)
//            "camvoid <cam> <cat> <param>"         one-shot (auto focus...)
//
// Protocol (one JSON object per line):
//   {"type":"connected","product":"ATEM 1 M/E...","program":1}
//   {"type":"input","id":1,"name":"Camera 1"}          (one per external input)
//   {"type":"inputs_done"}
//   {"type":"program","input":2}                        (CUT / AUTO completion)
//   {"type":"preview","input":3}
//   {"type":"cam","cam":1,"cat":0,"param":3,"kind":"f","values":[0.42]}
//   {"type":"transition","in_transition":true,"style":"mix","frames":50}
//   {"type":"macros","macros":[{"index":0,"name":"Lower third"}]}
//   {"type":"macro_run","index":0,"ok":true}
//   {"type":"timecode","timecode":"01:02:03:04","drop_frame":false}  (reply to "tc")
//   {"type":"disconnected"}
//   {"type":"error","message":"..."}
//
// Build (see Makefile): requires BMDSwitcherAPI.h + BMDSwitcherAPIDispatch.cpp
// from the "Blackmagic ATEM Switchers SDK" (Developer section of
// blackmagicdesign.com/support) and ATEM Software Control installed (which
// provides /Library/Frameworks/BMDSwitcherAPI.framework at runtime).
//
// The SDK changed its mix-effect callback between major versions:
//   * SDK >= 7.5: IBMDSwitcherMixEffectBlockCallback::Notify(eventType)
//     with bmdSwitcherMixEffectBlockEventTypeProgramInputChanged, and
//     IBMDSwitcherMixEffectBlock::GetProgramInput(&source).
//   * SDK <= 6.x: ...Callback::PropertyChanged(propertyId) with
//     bmdSwitcherMixEffectBlockPropertyIdProgramInput and GetInt().
// ATEM_LEGACY_SDK selects the old form (see Makefile).
//
// Transition reporting and macros use interfaces a very old SDK may not carry.
// Build with ATEM_NO_EXTRAS (make EXTRAS=0) to leave both out: the logger keeps
// working, transitions are simply reported as plain cuts and the macro buttons
// stay hidden. Camera control likewise needs a newer SDK: ATEM_NO_CAMERA
// (make CAMERA=0) leaves it out.

#include "BMDSwitcherAPI.h"

#include <CoreFoundation/CoreFoundation.h>

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <mutex>
#include <string>
#include <thread>

static std::mutex g_out_mutex;

static void emit(const std::string& json_line)
{
    std::lock_guard<std::mutex> guard(g_out_mutex);
    std::fputs(json_line.c_str(), stdout);
    std::fputc('\n', stdout);
    std::fflush(stdout);
}

static std::string json_escape(const std::string& s)
{
    std::string out;
    for (char c : s) {
        switch (c) {
            case '"':  out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n";  break;
            case '\r': break;
            case '\t': out += "\\t";  break;
            default:   out += c;      break;
        }
    }
    return out;
}

static std::string cf_to_utf8(CFStringRef ref)
{
    if (!ref)
        return "";
    char buffer[512];
    if (CFStringGetCString(ref, buffer, sizeof(buffer), kCFStringEncodingUTF8))
        return buffer;
    return "";
}

static int64_t current_program(IBMDSwitcherMixEffectBlock* me)
{
#ifdef ATEM_LEGACY_SDK
    int64_t value = 0;
    me->GetInt(bmdSwitcherMixEffectBlockPropertyIdProgramInput, &value);
    return value;
#else
    BMDSwitcherInputId source = 0;
    me->GetProgramInput(&source);
    return (int64_t)source;
#endif
}

static int64_t current_preview(IBMDSwitcherMixEffectBlock* me)
{
#ifdef ATEM_LEGACY_SDK
    int64_t value = 0;
    me->GetInt(bmdSwitcherMixEffectBlockPropertyIdPreviewInput, &value);
    return value;
#else
    BMDSwitcherInputId source = 0;
    me->GetPreviewInput(&source);
    return (int64_t)source;
#endif
}

#ifndef ATEM_NO_EXTRAS
// Reads what the switcher is about to do (or is doing): the next transition's
// style, and its length in frames. Each style keeps its rate on its own
// parameters interface, so each is asked for separately and anything the
// switcher doesn't offer is simply skipped.
static void read_transition(IBMDSwitcherMixEffectBlock* me,
                            std::string* styleOut, uint32_t* framesOut)
{
    *styleOut = "mix";
    *framesOut = 0;

    IBMDSwitcherTransitionParameters* params = nullptr;
    if (me->QueryInterface(IID_IBMDSwitcherTransitionParameters,
                           (void**)&params) == S_OK && params) {
        BMDSwitcherTransitionStyle style = bmdSwitcherTransitionStyleMix;
        if (params->GetNextTransitionStyle(&style) == S_OK) {
            switch (style) {
                case bmdSwitcherTransitionStyleMix:     *styleOut = "mix"; break;
                case bmdSwitcherTransitionStyleDip:     *styleOut = "dip"; break;
                case bmdSwitcherTransitionStyleWipe:    *styleOut = "wipe"; break;
                case bmdSwitcherTransitionStyleDVE:     *styleOut = "dve"; break;
                case bmdSwitcherTransitionStyleStinger: *styleOut = "sting"; break;
                default: break;
            }
        }
        params->Release();
    }

    uint32_t rate = 0;
    if (*styleOut == "mix") {
        IBMDSwitcherTransitionMixParameters* mix = nullptr;
        if (me->QueryInterface(IID_IBMDSwitcherTransitionMixParameters,
                               (void**)&mix) == S_OK && mix) {
            mix->GetRate(&rate);
            mix->Release();
        }
    } else if (*styleOut == "dip") {
        IBMDSwitcherTransitionDipParameters* dip = nullptr;
        if (me->QueryInterface(IID_IBMDSwitcherTransitionDipParameters,
                               (void**)&dip) == S_OK && dip) {
            dip->GetRate(&rate);
            dip->Release();
        }
    } else if (*styleOut == "wipe") {
        IBMDSwitcherTransitionWipeParameters* wipe = nullptr;
        if (me->QueryInterface(IID_IBMDSwitcherTransitionWipeParameters,
                               (void**)&wipe) == S_OK && wipe) {
            wipe->GetRate(&rate);
            wipe->Release();
        }
    } else if (*styleOut == "dve") {
        IBMDSwitcherTransitionDVEParameters* dve = nullptr;
        if (me->QueryInterface(IID_IBMDSwitcherTransitionDVEParameters,
                               (void**)&dve) == S_OK && dve) {
            dve->GetRate(&rate);
            dve->Release();
        }
    }
    *framesOut = rate;
}

static bool in_transition(IBMDSwitcherMixEffectBlock* me)
{
#ifdef ATEM_LEGACY_SDK
    bool flag = false;
    me->GetFlag(bmdSwitcherMixEffectBlockPropertyIdInTransition, &flag);
    return flag;
#else
    bool flag = false;
    me->GetInTransition(&flag);
    return flag;
#endif
}
#endif  // ATEM_NO_EXTRAS

// ---------------------------------------------------------------------------
// M/E 1 monitor: the single callback this whole tool is built around.
// ProgramInputChanged fires on CUT and at AUTO-transition completion; Preview
// changes are reported for the tally display; transition-position events are
// deliberately ignored.
// ---------------------------------------------------------------------------
class MixEffectMonitor : public IBMDSwitcherMixEffectBlockCallback
{
public:
    explicit MixEffectMonitor(IBMDSwitcherMixEffectBlock* me)
        : m_refCount(1), m_me(me) {}

#ifdef ATEM_LEGACY_SDK
    HRESULT PropertyChanged(BMDSwitcherMixEffectBlockPropertyId propertyId) override
    {
        if (propertyId == bmdSwitcherMixEffectBlockPropertyIdProgramInput)
            emit("{\"type\":\"program\",\"input\":"
                 + std::to_string(current_program(m_me)) + "}");
        else if (propertyId == bmdSwitcherMixEffectBlockPropertyIdPreviewInput)
            emit("{\"type\":\"preview\",\"input\":"
                 + std::to_string(current_preview(m_me)) + "}");
#ifndef ATEM_NO_EXTRAS
        else if (propertyId == bmdSwitcherMixEffectBlockPropertyIdInTransition)
            report_transition();
#endif
        return S_OK;
    }
#else
    HRESULT Notify(BMDSwitcherMixEffectBlockEventType eventType) override
    {
        if (eventType == bmdSwitcherMixEffectBlockEventTypeProgramInputChanged)
            emit("{\"type\":\"program\",\"input\":"
                 + std::to_string(current_program(m_me)) + "}");
        else if (eventType == bmdSwitcherMixEffectBlockEventTypePreviewInputChanged)
            emit("{\"type\":\"preview\",\"input\":"
                 + std::to_string(current_preview(m_me)) + "}");
#ifndef ATEM_NO_EXTRAS
        else if (eventType == bmdSwitcherMixEffectBlockEventTypeInTransitionChanged)
            report_transition();
#endif
        return S_OK;
    }
#endif

#ifndef ATEM_NO_EXTRAS
    // Emitted when an AUTO transition *starts*. Its completion arrives
    // separately as the Program change, which is the moment that gets logged;
    // this line is what tells the app the cut was a 2-second dissolve rather
    // than a hard cut.
    void report_transition()
    {
        if (!in_transition(m_me))
            return;
        std::string style;
        uint32_t frames = 0;
        read_transition(m_me, &style, &frames);
        emit("{\"type\":\"transition\",\"in_transition\":true,\"style\":\""
             + style + "\",\"frames\":" + std::to_string(frames) + "}");
    }
#endif

    HRESULT QueryInterface(REFIID iid, LPVOID* ppv) override
    {
        if (ppv == nullptr)
            return E_INVALIDARG;
        CFUUIDBytes unknown = CFUUIDGetUUIDBytes(IUnknownUUID);
        if (memcmp(&iid, &unknown, sizeof(REFIID)) == 0 ||
            memcmp(&iid, &IID_IBMDSwitcherMixEffectBlockCallback, sizeof(REFIID)) == 0) {
            *ppv = this;
            AddRef();
            return S_OK;
        }
        *ppv = nullptr;
        return E_NOINTERFACE;
    }
    ULONG AddRef() override { return __sync_add_and_fetch(&m_refCount, 1); }
    ULONG Release() override
    {
        ULONG count = __sync_sub_and_fetch(&m_refCount, 1);
        if (count == 0)
            delete this;
        return count;
    }

private:
    virtual ~MixEffectMonitor() {}
    volatile ULONG m_refCount;
    IBMDSwitcherMixEffectBlock* m_me;
};

// ---------------------------------------------------------------------------
// Switcher monitor: only used for disconnect detection.
// ---------------------------------------------------------------------------
class SwitcherMonitor : public IBMDSwitcherCallback
{
public:
    explicit SwitcherMonitor(CFRunLoopRef runLoop)
        : m_refCount(1), m_runLoop(runLoop) {}

    // SDK >= 8.0 passes a second coreVideoMode argument; older SDKs don't.
#ifdef ATEM_LEGACY_SDK
    HRESULT Notify(BMDSwitcherEventType eventType) override
#else
    HRESULT Notify(BMDSwitcherEventType eventType, BMDSwitcherVideoMode) override
#endif
    {
        if (eventType == bmdSwitcherEventTypeDisconnected) {
            emit("{\"type\":\"disconnected\"}");
            CFRunLoopStop(m_runLoop);
        }
        return S_OK;
    }

    HRESULT QueryInterface(REFIID iid, LPVOID* ppv) override
    {
        if (ppv == nullptr)
            return E_INVALIDARG;
        CFUUIDBytes unknown = CFUUIDGetUUIDBytes(IUnknownUUID);
        if (memcmp(&iid, &unknown, sizeof(REFIID)) == 0 ||
            memcmp(&iid, &IID_IBMDSwitcherCallback, sizeof(REFIID)) == 0) {
            *ppv = this;
            AddRef();
            return S_OK;
        }
        *ppv = nullptr;
        return E_NOINTERFACE;
    }
    ULONG AddRef() override { return __sync_add_and_fetch(&m_refCount, 1); }
    ULONG Release() override
    {
        ULONG count = __sync_sub_and_fetch(&m_refCount, 1);
        if (count == 0)
            delete this;
        return count;
    }

private:
    virtual ~SwitcherMonitor() {}
    volatile ULONG m_refCount;
    CFRunLoopRef m_runLoop;
};

static void emit_inputs(IBMDSwitcher* switcher)
{
    IBMDSwitcherInputIterator* iterator = nullptr;
    if (switcher->CreateIterator(IID_IBMDSwitcherInputIterator,
                                 (void**)&iterator) != S_OK || !iterator)
        return;

    IBMDSwitcherInput* input = nullptr;
    while (iterator->Next(&input) == S_OK && input) {
        BMDSwitcherPortType portType;
        if (input->GetPortType(&portType) == S_OK &&
            portType == bmdSwitcherPortTypeExternal) {
            BMDSwitcherInputId inputId = 0;
            input->GetInputId(&inputId);
            CFStringRef nameRef = nullptr;
            input->GetLongName(&nameRef);
            std::string name = cf_to_utf8(nameRef);
            if (nameRef)
                CFRelease(nameRef);
            emit("{\"type\":\"input\",\"id\":" + std::to_string(inputId)
                 + ",\"name\":\"" + json_escape(name) + "\"}");
        }
        input->Release();
        input = nullptr;
    }
    iterator->Release();
    emit("{\"type\":\"inputs_done\"}");
}

#ifndef ATEM_NO_EXTRAS
// The macro pool names every slot; only valid ones are worth showing.
static void emit_macros(IBMDSwitcher* switcher)
{
    IBMDSwitcherMacroPool* pool = nullptr;
    if (switcher->QueryInterface(IID_IBMDSwitcherMacroPool,
                                 (void**)&pool) != S_OK || !pool)
        return;

    uint32_t maxCount = 0;
    pool->GetMaxCount(&maxCount);
    std::string json = "{\"type\":\"macros\",\"macros\":[";
    bool first = true;
    for (uint32_t index = 0; index < maxCount; ++index) {
        bool valid = false;
        if (pool->IsValid(index, &valid) != S_OK || !valid)
            continue;
        CFStringRef nameRef = nullptr;
        pool->GetName(index, &nameRef);
        std::string name = cf_to_utf8(nameRef);
        if (nameRef)
            CFRelease(nameRef);
        if (!first)
            json += ",";
        first = false;
        json += "{\"index\":" + std::to_string(index) + ",\"name\":\""
                + json_escape(name) + "\"}";
    }
    json += "]}";
    pool->Release();
    emit(json);
}

static void run_macro(IBMDSwitcher* switcher, uint32_t index)
{
    IBMDSwitcherMacroControl* control = nullptr;
    if (switcher->QueryInterface(IID_IBMDSwitcherMacroControl,
                                 (void**)&control) != S_OK || !control) {
        emit("{\"type\":\"error\",\"message\":\"This switcher does not "
             "expose macro control.\"}");
        return;
    }
    HRESULT hr = control->Run(index);
    control->Release();
    emit("{\"type\":\"macro_run\",\"index\":" + std::to_string(index)
         + ",\"ok\":" + (hr == S_OK ? "true" : "false") + "}");
}
#endif  // ATEM_NO_EXTRAS

#ifndef ATEM_NO_CAMERA
// ---------------------------------------------------------------------------
// Camera control. The SDK passes Blackmagic's Camera Control Protocol through
// untouched: every setting is (camera, category, parameter) with a typed list
// of values. Values are read back with their type so the app can show them,
// and every change — ours, a CCU panel's, ATEM Software Control's — is echoed
// as a "cam" line so sliders never drift from the camera.
// ---------------------------------------------------------------------------
static IBMDSwitcherCameraControl* g_cam = nullptr;

static void emit_cam_value(uint32_t cam, uint32_t cat, uint32_t param)
{
    if (!g_cam)
        return;
    BMDSwitcherCameraControlParameterType type;
    uint32_t count = 0;
    if (g_cam->GetParameterInfo(cam, cat, param, &type, &count) != S_OK)
        return;
    std::string kind, values;
    char buf[64];
    auto add = [&](const std::string& v) {
        if (!values.empty()) values += ",";
        values += v;
    };
    uint32_t n = count ? count : 1;
    switch (type) {
        case bmdSwitcherCameraControlParameterTypeVoidBool: {
            kind = "b";
            bool v[16] = {};
            n = n > 16 ? 16 : n;
            if (count && g_cam->GetFlags(cam, cat, param, &n, v) == S_OK)
                for (uint32_t i = 0; i < n; ++i) add(v[i] ? "true" : "false");
            break;
        }
        case bmdSwitcherCameraControlParameterTypeSigned8Bit: {
            kind = "i8";
            int8_t v[16] = {}; n = n > 16 ? 16 : n;
            if (g_cam->GetInt8s(cam, cat, param, &n, v) == S_OK)
                for (uint32_t i = 0; i < n; ++i) add(std::to_string(v[i]));
            break;
        }
        case bmdSwitcherCameraControlParameterTypeSigned16Bit: {
            kind = "i16";
            int16_t v[16] = {}; n = n > 16 ? 16 : n;
            if (g_cam->GetInt16s(cam, cat, param, &n, v) == S_OK)
                for (uint32_t i = 0; i < n; ++i) add(std::to_string(v[i]));
            break;
        }
        case bmdSwitcherCameraControlParameterTypeSigned32Bit: {
            kind = "i32";
            int32_t v[16] = {}; n = n > 16 ? 16 : n;
            if (g_cam->GetInt32s(cam, cat, param, &n, v) == S_OK)
                for (uint32_t i = 0; i < n; ++i) add(std::to_string(v[i]));
            break;
        }
        case bmdSwitcherCameraControlParameterTypeSigned64Bit: {
            kind = "i64";
            int64_t v[16] = {}; n = n > 16 ? 16 : n;
            if (g_cam->GetInt64s(cam, cat, param, &n, v) == S_OK)
                for (uint32_t i = 0; i < n; ++i) add(std::to_string((long long)v[i]));
            break;
        }
        case bmdSwitcherCameraControlParameterTypeFixedPoint16Bit: {
            kind = "f";
            double v[16] = {}; n = n > 16 ? 16 : n;
            if (g_cam->GetFloats(cam, cat, param, &n, v) == S_OK)
                for (uint32_t i = 0; i < n; ++i) {
                    std::snprintf(buf, sizeof(buf), "%.4f", v[i]);
                    add(buf);
                }
            break;
        }
        case bmdSwitcherCameraControlParameterTypeUTF8: {
            kind = "s";
            CFStringRef ref = nullptr;
            if (g_cam->GetString(cam, cat, param, &ref) == S_OK) {
                add("\"" + json_escape(cf_to_utf8(ref)) + "\"");
                if (ref) CFRelease(ref);
            }
            break;
        }
        default:
            return;
    }
    emit("{\"type\":\"cam\",\"cam\":" + std::to_string(cam) + ",\"cat\":"
         + std::to_string(cat) + ",\"param\":" + std::to_string(param)
         + ",\"kind\":\"" + kind + "\",\"values\":[" + values + "]}");
}

// "camset 1 0 3 0.5" / "camoff 1 0 3 -0.05" / "camvoid 1 0 1"
static void camera_command(const char* line)
{
    if (!g_cam) {
        emit("{\"type\":\"error\",\"message\":\"This switcher does not expose camera control.\"}");
        return;
    }
    char verb[16] = {};
    unsigned cam = 0, cat = 0, param = 0;
    int used = 0;
    if (std::sscanf(line, "%15s %u %u %u%n", verb, &cam, &cat, &param, &used) < 4)
        return;
    if (std::strcmp(verb, "camget") == 0) {
        emit_cam_value(cam, cat, param);
        return;
    }
    // Remaining numbers, up to 8 of them.
    double nums[8]; uint32_t n = 0;
    const char* p = line + used;
    char* end = nullptr;
    while (n < 8) {
        double v = std::strtod(p, &end);
        if (end == p) break;
        nums[n++] = v;
        p = end;
    }
    BMDSwitcherCameraControlParameterType type;
    uint32_t count = 0;
    HRESULT hr = g_cam->GetParameterInfo(cam, cat, param, &type, &count);
    bool offset = std::strcmp(verb, "camoff") == 0;
    if (std::strcmp(verb, "camvoid") == 0) {
        hr = g_cam->SetFlags(cam, cat, param, 0, nullptr);
    } else if (hr == S_OK && n) {
        switch (type) {
            case bmdSwitcherCameraControlParameterTypeVoidBool: {
                bool v[8]; for (uint32_t i = 0; i < n; ++i) v[i] = nums[i] != 0;
                hr = offset ? g_cam->ToggleFlags(cam, cat, param, n, v)
                            : g_cam->SetFlags(cam, cat, param, n, v);
                break;
            }
            case bmdSwitcherCameraControlParameterTypeSigned8Bit: {
                int8_t v[8]; for (uint32_t i = 0; i < n; ++i) v[i] = (int8_t)nums[i];
                hr = offset ? g_cam->OffsetInt8s(cam, cat, param, n, v)
                            : g_cam->SetInt8s(cam, cat, param, n, v);
                break;
            }
            case bmdSwitcherCameraControlParameterTypeSigned16Bit: {
                int16_t v[8]; for (uint32_t i = 0; i < n; ++i) v[i] = (int16_t)nums[i];
                hr = offset ? g_cam->OffsetInt16s(cam, cat, param, n, v)
                            : g_cam->SetInt16s(cam, cat, param, n, v);
                break;
            }
            case bmdSwitcherCameraControlParameterTypeSigned32Bit: {
                int32_t v[8]; for (uint32_t i = 0; i < n; ++i) v[i] = (int32_t)nums[i];
                hr = offset ? g_cam->OffsetInt32s(cam, cat, param, n, v)
                            : g_cam->SetInt32s(cam, cat, param, n, v);
                break;
            }
            case bmdSwitcherCameraControlParameterTypeSigned64Bit: {
                int64_t v[8]; for (uint32_t i = 0; i < n; ++i) v[i] = (int64_t)nums[i];
                hr = offset ? g_cam->OffsetInt64s(cam, cat, param, n, v)
                            : g_cam->SetInt64s(cam, cat, param, n, v);
                break;
            }
            case bmdSwitcherCameraControlParameterTypeFixedPoint16Bit:
                hr = offset ? g_cam->OffsetFloats(cam, cat, param, n, nums)
                            : g_cam->SetFloats(cam, cat, param, n, nums);
                break;
            default:
                hr = E_FAIL;
        }
    }
    if (hr != S_OK)
        emit("{\"type\":\"cam_error\",\"cam\":" + std::to_string(cam) + ",\"cat\":"
             + std::to_string(cat) + ",\"param\":" + std::to_string(param) + "}");
}

class CameraMonitor : public IBMDSwitcherCameraControlCallback
{
public:
    CameraMonitor() : m_refCount(1) {}
    HRESULT Notify(BMDSwitcherCameraControlEventType eventType, uint32_t cam,
                   uint32_t cat, uint32_t param) override
    {
        if (eventType == bmdSwitcherCameraControlEventTypeParameterValueChanged)
            emit_cam_value(cam, cat, param);
        return S_OK;
    }
    HRESULT QueryInterface(REFIID iid, LPVOID* ppv) override
    {
        if (ppv == nullptr)
            return E_INVALIDARG;
        CFUUIDBytes unknown = CFUUIDGetUUIDBytes(IUnknownUUID);
        if (memcmp(&iid, &unknown, sizeof(REFIID)) == 0 ||
            memcmp(&iid, &IID_IBMDSwitcherCameraControlCallback, sizeof(REFIID)) == 0) {
            *ppv = this;
            AddRef();
            return S_OK;
        }
        *ppv = nullptr;
        return E_NOINTERFACE;
    }
    ULONG AddRef() override { return __sync_add_and_fetch(&m_refCount, 1); }
    ULONG Release() override
    {
        ULONG count = __sync_sub_and_fetch(&m_refCount, 1);
        if (count == 0)
            delete this;
        return count;
    }
private:
    virtual ~CameraMonitor() {}
    volatile ULONG m_refCount;
};
#endif  // ATEM_NO_CAMERA

static void stdin_watcher(CFRunLoopRef runLoop, IBMDSwitcher* switcher)
{
    char line[512];
    while (std::fgets(line, sizeof(line), stdin)) {
        if (std::strncmp(line, "quit", 4) == 0)
            break;
#ifndef ATEM_NO_CAMERA
        if (std::strncmp(line, "cam", 3) == 0) {
            camera_command(line);
            continue;
        }
#endif
#ifndef ATEM_NO_EXTRAS
        if (std::strncmp(line, "macro ", 6) == 0) {
            run_macro(switcher, (uint32_t)std::strtoul(line + 6, nullptr, 10));
            continue;
        }
#endif
        if (std::strncmp(line, "tc", 2) == 0) {
            // Simple synchronous getter; safe to call off the CFRunLoop thread
            // (the SDK already delivers callbacks from its own internal
            // threads, so it must tolerate concurrent access to this state).
            uint8_t h = 0, m = 0, s = 0, f = 0;
            bool drop = false;
            if (switcher->GetTimeCode(&h, &m, &s, &f, &drop) == S_OK) {
                char buf[16];
                std::snprintf(buf, sizeof(buf), "%02u:%02u:%02u%c%02u",
                              h, m, s, drop ? ';' : ':', f);
                emit(std::string("{\"type\":\"timecode\",\"timecode\":\"") + buf
                     + "\",\"drop_frame\":" + (drop ? "true" : "false") + "}");
            } else {
                emit("{\"type\":\"timecode\",\"timecode\":null}");
            }
        }
    }
    CFRunLoopStop(runLoop);
}

int main(int argc, char* argv[])
{
    if (argc != 2) {
        emit("{\"type\":\"error\",\"message\":\"usage: atem-bridge <ip-address>\"}");
        return 2;
    }

    IBMDSwitcherDiscovery* discovery = CreateBMDSwitcherDiscoveryInstance();
    if (!discovery) {
        emit("{\"type\":\"error\",\"message\":\"BMDSwitcherAPI.framework not found. "
             "Install ATEM Software Control first.\"}");
        return 1;
    }

    CFStringRef address = CFStringCreateWithCString(
        kCFAllocatorDefault, argv[1], kCFStringEncodingUTF8);
    IBMDSwitcher* switcher = nullptr;
    BMDSwitcherConnectToFailure failReason = (BMDSwitcherConnectToFailure)0;
    HRESULT hr = discovery->ConnectTo(address, &switcher, &failReason);
    CFRelease(address);

    if (hr != S_OK || !switcher) {
        const char* why = "unknown error";
        switch (failReason) {
            case bmdSwitcherConnectToFailureNoResponse:
                why = "no response from the switcher at that address"; break;
            case bmdSwitcherConnectToFailureIncompatibleFirmware:
                why = "incompatible switcher firmware"; break;
            case bmdSwitcherConnectToFailureCorruptData:
                why = "corrupt data during connect"; break;
            case bmdSwitcherConnectToFailureStateSync:
                why = "state sync failed during connect"; break;
            case bmdSwitcherConnectToFailureStateSyncTimedOut:
                why = "state sync timed out during connect"; break;
            default: break;
        }
        emit(std::string("{\"type\":\"error\",\"message\":\"Could not connect: ")
             + why + "\"}");
        discovery->Release();
        return 1;
    }

    CFStringRef productRef = nullptr;
    switcher->GetProductName(&productRef);
    std::string product = cf_to_utf8(productRef);
    if (productRef)
        CFRelease(productRef);

    IBMDSwitcherMixEffectBlockIterator* meIterator = nullptr;
    IBMDSwitcherMixEffectBlock* me1 = nullptr;
    if (switcher->CreateIterator(IID_IBMDSwitcherMixEffectBlockIterator,
                                 (void**)&meIterator) != S_OK ||
        !meIterator || meIterator->Next(&me1) != S_OK || !me1) {
        emit("{\"type\":\"error\",\"message\":\"No mix effect block found.\"}");
        if (meIterator) meIterator->Release();
        switcher->Release();
        discovery->Release();
        return 1;
    }
    meIterator->Release();

    emit("{\"type\":\"connected\",\"product\":\"" + json_escape(product)
         + "\",\"program\":" + std::to_string(current_program(me1))
         + ",\"preview\":" + std::to_string(current_preview(me1)) + "}");
    emit_inputs(switcher);
#ifndef ATEM_NO_EXTRAS
    emit_macros(switcher);
#endif

    CFRunLoopRef runLoop = CFRunLoopGetCurrent();
    MixEffectMonitor* meMonitor = new MixEffectMonitor(me1);
    SwitcherMonitor* swMonitor = new SwitcherMonitor(runLoop);
    me1->AddCallback(meMonitor);
    switcher->AddCallback(swMonitor);
#ifndef ATEM_NO_CAMERA
    CameraMonitor* camMonitor = nullptr;
    if (switcher->QueryInterface(IID_IBMDSwitcherCameraControl, (void**)&g_cam) == S_OK && g_cam) {
        camMonitor = new CameraMonitor();
        g_cam->AddCallback(camMonitor);
        emit("{\"type\":\"camera_control\",\"available\":true}");
    }
#endif

    std::thread watcher(stdin_watcher, runLoop, switcher);
    watcher.detach();

    CFRunLoopRun();   // callbacks fire on SDK threads; emit() is mutex-guarded

#ifndef ATEM_NO_CAMERA
    if (g_cam) {
        if (camMonitor) { g_cam->RemoveCallback(camMonitor); camMonitor->Release(); }
        g_cam->Release();
        g_cam = nullptr;
    }
#endif
    me1->RemoveCallback(meMonitor);
    switcher->RemoveCallback(swMonitor);
    meMonitor->Release();
    swMonitor->Release();
    me1->Release();
    switcher->Release();
    discovery->Release();
    return 0;
}
