"""Exercises the Windows backend's transition reading against fake COM objects.

The real backend needs Windows, ``comtypes`` and Blackmagic's registered DLL.
What the SDK hands back, though, is just objects with getters — so the parts
that decide *what gets logged* are testable with stand-ins, the same way
``test_mac_bridge`` tests the bridge protocol without the bridge.
"""

import unittest

from atem_cut_logger.backends.windows_com import (
    TransitionTracker,
    in_transition,
    read_transition,
)


class FakeBmd:
    """Stands in for the comtypes module generated from the type library."""

    bmdSwitcherTransitionStyleMix = 0
    bmdSwitcherTransitionStyleDip = 1
    bmdSwitcherTransitionStyleWipe = 2
    bmdSwitcherTransitionStyleDVE = 3
    bmdSwitcherTransitionStyleStinger = 4
    bmdSwitcherMixEffectBlockPropertyIdInTransition = "intr"

    IBMDSwitcherTransitionParameters = "params"
    IBMDSwitcherTransitionMixParameters = "mix"
    IBMDSwitcherTransitionDipParameters = "dip"
    IBMDSwitcherTransitionWipeParameters = "wipe"
    IBMDSwitcherTransitionDVEParameters = "dve"


class FakeParams:
    def __init__(self, style):
        self._style = style

    def GetNextTransitionStyle(self):
        return self._style


class FakeRate:
    def __init__(self, rate):
        self._rate = rate

    def GetRate(self):
        return self._rate


class FakeMe:
    """A mix-effect block exposing only the interfaces given to it."""

    def __init__(self, interfaces, in_transition=None, legacy_flag=None):
        self._interfaces = interfaces
        if in_transition is not None:
            self.GetInTransition = lambda: in_transition
        if legacy_flag is not None:
            self.GetFlag = lambda prop: legacy_flag

    def QueryInterface(self, interface):
        if interface not in self._interfaces:
            raise OSError("E_NOINTERFACE")
        return self._interfaces[interface]


class ReadTransition(unittest.TestCase):
    def test_style_and_rate_come_from_the_matching_interface(self):
        me = FakeMe({
            "params": FakeParams(FakeBmd.bmdSwitcherTransitionStyleWipe),
            "wipe": FakeRate(37),
            "mix": FakeRate(999),      # must not be consulted for a wipe
        })
        self.assertEqual(read_transition(FakeBmd, me), ("wipe", 37))

    def test_every_style_finds_its_own_rate(self):
        for constant, style in ((0, "mix"), (1, "dip"), (2, "wipe"), (3, "dve")):
            with self.subTest(style=style):
                me = FakeMe({"params": FakeParams(constant), style: FakeRate(25)})
                self.assertEqual(read_transition(FakeBmd, me), (style, 25))

    def test_a_stinger_reports_no_length_so_it_logs_as_a_cut(self):
        """Its length lives in its media, not in a rate — same as the bridge."""
        me = FakeMe({
            "params": FakeParams(FakeBmd.bmdSwitcherTransitionStyleStinger),
            "mix": FakeRate(50),
        })
        self.assertEqual(read_transition(FakeBmd, me), ("sting", 0))

    def test_missing_rate_interface_is_not_an_error(self):
        me = FakeMe({"params": FakeParams(FakeBmd.bmdSwitcherTransitionStyleMix)})
        self.assertEqual(read_transition(FakeBmd, me), ("mix", 0))

    def test_switcher_without_transition_parameters_reads_as_a_plain_mix(self):
        self.assertEqual(read_transition(FakeBmd, FakeMe({})), ("mix", 0))

    def test_an_unknown_style_falls_back_to_mix(self):
        me = FakeMe({"params": FakeParams(97), "mix": FakeRate(12)})
        self.assertEqual(read_transition(FakeBmd, me), ("mix", 12))

    def test_a_getter_that_throws_is_survived(self):
        class Angry:
            def GetNextTransitionStyle(self):
                raise OSError("COM said no")

        me = FakeMe({"params": Angry(), "mix": FakeRate(8)})
        self.assertEqual(read_transition(FakeBmd, me), ("mix", 8))


class InTransition(unittest.TestCase):
    def test_modern_typelib_getter(self):
        self.assertTrue(in_transition(FakeBmd, FakeMe({}, in_transition=True)))
        self.assertFalse(in_transition(FakeBmd, FakeMe({}, in_transition=False)))

    def test_legacy_typelib_property_getter(self):
        self.assertTrue(in_transition(FakeBmd, FakeMe({}, legacy_flag=True)))
        self.assertFalse(in_transition(FakeBmd, FakeMe({}, legacy_flag=False)))

    def test_neither_getter_means_no_transition_reporting(self):
        self.assertFalse(in_transition(FakeBmd, FakeMe({})))


class Tracker(unittest.TestCase):
    """A Program change claims whatever the transition start described."""

    def test_a_program_change_with_nothing_pending_is_a_cut(self):
        self.assertEqual(TransitionTracker().take(), ("cut", 0))

    def test_a_started_transition_is_claimed_once(self):
        tracker = TransitionTracker()
        tracker.started("mix", 50)
        self.assertEqual(tracker.take(), ("mix", 50))
        # The next Program change is a cut again, not a second dissolve.
        self.assertEqual(tracker.take(), ("cut", 0))

    def test_a_second_start_replaces_an_unclaimed_one(self):
        tracker = TransitionTracker()
        tracker.started("mix", 50)
        tracker.started("wipe", 12)
        self.assertEqual(tracker.take(), ("wipe", 12))

    def test_values_are_normalised(self):
        tracker = TransitionTracker()
        tracker.started("", -5)
        self.assertEqual(tracker.take(), ("mix", 0))
