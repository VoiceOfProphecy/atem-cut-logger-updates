import json
import tempfile
import time
import unittest
from pathlib import Path

from atem_cut_logger.package import folder_name, write_package
from atem_cut_logger.prefs import Prefs, list_folder
from atem_cut_logger.session import LogSession
from atem_cut_logger.web.controller import (
    Controller,
    ControllerError,
    SaveLocationError,
)


def logged(tmp, name="TVTL 01-08"):
    c = Controller(prefs=Prefs(Path(tmp) / "prefs"))
    c.on_connected("Test", {1: "Wide", 2: "Ken"}, 1)
    c.update_settings({"rate_key": "25", "start_timecode": "01:00:00:00",
                       "session_name": name})
    c.start_logging()
    c.on_program_changed(2, c.start_mono + 3.0)
    c.on_program_changed(1, c.start_mono + 3.2)   # an accidental blip
    c.on_program_changed(2, c.start_mono + 9.0)
    c.stop_logging()
    return c


class Package(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_writes_every_export_into_a_named_folder(self):
        c = logged(self.tmp.name)
        out = self.dir / "out"
        out.mkdir()
        res = c.save_package(str(out))
        folder = Path(res["folder"])
        self.assertEqual(folder, out / "TVTL 01-08")
        names = sorted(p.name for p in folder.iterdir())
        for expected in ("tvtl-01-08.atemlog.json", "tvtl-01-08.fcpxml",
                         "tvtl-01-08.edl", "tvtl-01-08.csv",
                         "tvtl-01-08-cleanup.txt", "tvtl-01-08-markers.fcpxml",
                         "tvtl-01-08-cleaned.fcpxml"):
            self.assertIn(expected, names)
        self.assertTrue(res["issues"])            # the blip was flagged
        self.assertFalse(c.unsaved)               # saving clears the marker

    def test_second_save_does_not_overwrite(self):
        c = logged(self.tmp.name)
        a = c.save_package(str(self.dir))["folder"]
        b = c.save_package(str(self.dir))["folder"]
        self.assertNotEqual(a, b)
        self.assertTrue(b.endswith("(2)"))

    def test_cleanup_can_be_skipped(self):
        c = logged(self.tmp.name)
        res = c.save_package(str(self.dir), run_cleanup=False)
        self.assertFalse(any("cleanup" in f for f in res["files"]))

    def test_missing_folder_is_refused_with_a_fallback(self):
        c = logged(self.tmp.name)
        with self.assertRaises(SaveLocationError) as ctx:
            c.save_package(str(self.dir / "NAS-not-mounted"))
        self.assertTrue(ctx.exception.fallback)
        self.assertTrue(c.unsaved)                # nothing was lost

    def test_default_folder_comes_from_prefs(self):
        c = logged(self.tmp.name)
        c.update_prefs({"default_save_dir": str(self.dir)})
        res = c.save_package()
        self.assertTrue(res["folder"].startswith(str(self.dir)))

    def test_refuses_while_logging_or_empty(self):
        c = Controller(prefs=Prefs(self.dir / "p"))
        with self.assertRaises(ControllerError):
            c.save_package(str(self.dir))

    def test_folder_name_strips_unsafe_characters(self):
        s = LogSession(name='Show: "A/B"?')
        self.assertEqual(folder_name(s), "Show- -A-B")
        self.assertTrue(folder_name(LogSession()).startswith("Session "))

    def test_failed_write_leaves_no_half_folder(self):
        s = LogSession(name="X")
        with self.assertRaises(ValueError):
            write_package(s, self.dir)            # no events
        self.assertEqual(list(self.dir.iterdir()), [])


class PrefsTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_round_trip_and_bad_file(self):
        p = Prefs(self.dir)
        p.update({"default_save_dir": str(self.dir), "run_cleanup": False,
                  "cleanup": {"accidental_cut_seconds": 0.3}})
        again = Prefs(self.dir)
        self.assertEqual(again.default_save_dir, str(self.dir))
        self.assertFalse(again.run_cleanup)
        self.assertEqual(again.cleanup_config().accidental_cut_seconds, 0.3)
        (self.dir / "prefs.json").write_text("{not json")
        self.assertTrue(Prefs(self.dir).run_cleanup)   # defaults, no crash

    def test_unavailable_default_is_reported(self):
        p = Prefs(self.dir)
        p.update({"default_save_dir": str(self.dir / "gone")})
        self.assertIn("isn't available", p.to_payload()["save_dir_problem"])

    def test_logo_variants(self):
        p = Prefs(self.dir)
        p.set_logo("brand.png", b"\x89PNG....", "dark")
        self.assertTrue(p.logo_version("dark"))
        self.assertFalse(p.logo_version("light"))
        p.set_logo("brand.svg", b"<svg/>", "dark")   # replaces, not adds
        self.assertEqual(p.logo_path("dark").suffix, ".svg")
        with self.assertRaises(Exception):
            p.set_logo("brand.exe", b"x")
        p.remove_logo("dark")
        self.assertIsNone(p.logo_path("dark"))

    def test_list_folder_falls_back_when_missing(self):
        res = list_folder(str(self.dir / "nope"))
        self.assertTrue(res["note"])
        self.assertTrue(Path(res["path"]).is_dir())


class FakeTimecodeBackend:
    def __init__(self, tc="10:00:00:00"):
        self.tc = tc

    def get_current_timecode(self, timeout=1.0):
        return (self.tc, False)

    def disconnect(self):
        pass


class LiveTimecodeAndResume(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()

    def tearDown(self):
        self.tmp.cleanup()

    def controller(self):
        c = Controller(prefs=Prefs(Path(self.tmp.name)))
        c.backend = FakeTimecodeBackend()
        c.on_connected("Test", {1: "Wide", 2: "Ken"}, 1)
        c.update_settings({"rate_key": "25"})
        return c

    def test_clock_shows_switcher_timecode_while_idle(self):
        c = self.controller()
        c._set_tc_anchor(c._read_switcher_timecode(c.backend))
        clock = c.current_clock()
        self.assertTrue(clock["live"])
        self.assertFalse(clock["running"])
        self.assertTrue(clock["timecode"].startswith("10:00:0"))
        c.shutdown()

    def test_stale_reading_is_dropped(self):
        c = self.controller()
        c._tc_anchor = (0, time.monotonic() - 60, False)
        self.assertFalse(c.current_clock()["live"])
        c.shutdown()

    def test_resume_appends_instead_of_starting_over(self):
        c = self.controller()
        c.start_logging()                       # start TC comes from the switcher
        self.assertEqual(c.session.start_timecode, "10:00:00:00")
        c.on_program_changed(2, c.start_mono + 5.0)
        c.stop_logging()
        before = len(c.session.events)
        c.backend.tc = "10:01:00:00"            # a minute later
        c.program_input = 1
        c.start_logging(resume=True)
        c.on_program_changed(2, time.monotonic() + 1.0)
        c.stop_logging()
        self.assertEqual(len(c.session.events), before + 2)
        self.assertEqual(c.session.start_timecode, "10:00:00:00")
        # the resumed cut sits at the switcher's real position, gap kept
        self.assertTrue(c.session.events[before].timecode.startswith("10:01:00"))
        c.shutdown()


if __name__ == "__main__":
    unittest.main()
