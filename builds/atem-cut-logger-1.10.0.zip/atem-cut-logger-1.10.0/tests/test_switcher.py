"""Switcher section: protected macros, camera control, preview tally."""

import tempfile
import unittest
from pathlib import Path

from atem_cut_logger import camera_params
from atem_cut_logger.prefs import Prefs
from atem_cut_logger.web.controller import Controller, ControllerError


class FakeBackend:
    def __init__(self):
        self.macros_run, self.camera_calls = [], []

    def run_macro(self, index):
        self.macros_run.append(index)

    def camera(self, verb, cam, cat, param, values=None):
        self.camera_calls.append((verb, cam, cat, param, values))

    def disconnect(self):
        pass


class SwitcherTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.c = Controller(prefs=Prefs(Path(self.tmp.name)))
        self.b = FakeBackend()
        self.c.backend = self.b
        self.c.on_connected("ATEM", {1: "Cam 1", 2: "Cam 2"}, 1)
        self.c.on_macros([{"index": 0, "name": "AUDIO ON"}, {"index": 19, "name": "CLOSE IRIS"}])
        self.c.on_camera_available(True)

    def tearDown(self):
        self.c.shutdown()
        self.tmp.cleanup()

    def test_new_macros_are_protected(self):
        with self.assertRaises(ControllerError):
            self.c.run_macro(19)
        self.assertEqual(self.b.macros_run, [])
        self.c.run_macro(19, held=True)
        self.assertEqual(self.b.macros_run, [19])

    def test_unprotected_macro_runs_on_click(self):
        self.c.set_macro_settings("AUDIO ON", protected=False)
        self.c.run_macro(0)
        self.assertEqual(self.b.macros_run, [0])

    def test_unknown_macro_setting_refused(self):
        with self.assertRaises(ControllerError):
            self.c.set_macro_settings("NOPE", protected=False)

    def test_camera_values_are_clamped_and_merged(self):
        self.c.on_camera_value(1, 1, 2, "i16", [4500, 3])
        self.c.camera_set(1, "wb_tint", 99)
        self.assertEqual(self.b.camera_calls[-1], ("set", 1, 1, 2, [4500, 50]))
        self.c.camera_set(1, "auto_focus", None)
        self.assertEqual(self.b.camera_calls[-1][:4], ("void", 1, 0, 1))

    def test_refresh_asks_each_parameter_once(self):
        self.c.camera_refresh(2)
        asked = [(c[2], c[3]) for c in self.b.camera_calls]
        self.assertEqual(len(asked), len(set(asked)))
        self.assertIn((0, 3), asked)

    def test_preview_is_tracked_not_logged(self):
        self.c.on_preview_changed(2)
        self.assertEqual(self.c.snapshot()["preview_input"], 2)
        self.assertEqual(self.c.session.events, [])

    def test_values_for_fills_neutral_defaults(self):
        c = camera_params.BY_ID["saturation"]
        self.assertEqual(camera_params.values_for(c, 1.4, None), [0, 1.4])


if __name__ == "__main__":
    unittest.main()
