"""Signal trace: outputs are blanked one at a time and always restored."""

import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

from atem_cut_logger.prefs import Prefs
from atem_cut_logger.recorders import RecorderConfig
from atem_cut_logger.web import controller as ctl
from atem_cut_logger.web.controller import Controller, ControllerError


class Hub:
    def __init__(self):
        self.routing = [0, 1, 2, 3]      # output -> input; input 3 has no picture
        self.log = []

    def route(self, pairs):
        for o, i in pairs.items():
            self.routing[o] = i
            self.log.append((o, i))

    def state(self):
        s = mock.Mock()
        s.to_dict.return_value = {"inputs": ["Cam 1", "Cam 2", "PGM", "Input 4"],
                                  "outputs": ["ISO A", "Output 2", "ISO C", "Output 4"],
                                  "routing": list(self.routing), "locks": ["U"] * 4}
        return s


class TraceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.c = Controller(prefs=Prefs(Path(self.tmp.name)))
        self.c.prefs.set_router(host="hub")
        self.c.recorders.set_configs([{"name": "Deck A", "host": "a"}, {"name": "Deck B", "host": "b"},
                                      {"name": "Deck C", "host": "c"}])
        self.hub = Hub()
        # Deck A is fed by output 1, Deck B by output 2, Deck C by output 3
        # (currently dark: output 3 shows input 3, which has no picture).
        feeds = {"a": 1, "b": 2, "c": 3}
        self.c._deck_signals = lambda: {h: ("none" if self.hub.routing[o] == 3 else "1080p30")
                                        for h, o in feeds.items()}
        self.c.recorders.any_recording = lambda: False
        patch_hub = mock.patch.object(ctl, "Videohub", lambda host: self.hub)
        patch_sleep = mock.patch.object(ctl.time, "sleep", lambda s: None)
        patch_hub.start(); patch_sleep.start()
        self.addCleanup(patch_hub.stop); self.addCleanup(patch_sleep.stop)

    def tearDown(self):
        self.c.shutdown()
        self.tmp.cleanup()

    def wait(self):
        for _ in range(200):
            if not self.c.trace["running"]:
                return
            time.sleep(0.01)
        self.fail("trace didn't finish")

    def test_trace_finds_feeds_and_restores_every_route(self):
        self.c.trace_start(blank_input=3, live_input=0)
        self.wait()
        feeds = {r["output"]: r["feeds"] for r in self.c.trace["results"]}
        self.assertEqual(feeds[1], ["Deck A"])
        self.assertEqual(feeds[2], ["Deck B"])
        self.assertEqual(feeds[0], [])
        self.assertEqual(self.hub.routing, [0, 1, 2, 3])

    def test_dark_deck_found_with_test_source(self):
        # Output 3 already shows the blank source, so only the live probe can find Deck C.
        self.c.trace_start(blank_input=3, live_input=0, outputs=[3])
        self.wait()
        self.assertEqual(self.c.trace["results"], [])   # skipped: already on the blank input
        self.hub.routing[3] = 2                           # now it shows PGM
        self.c._deck_signals = lambda: {"a": "x", "b": "x", "c": "none" if self.hub.routing[3] == 3 else "x"}
        self.c.trace_start(blank_input=3, outputs=[3])
        self.wait()
        self.assertEqual(self.c.trace["results"][0]["feeds"], ["Deck C"])

    def test_refused_while_logging(self):
        self.c.logging = True
        with self.assertRaises(ControllerError):
            self.c.trace_start(blank_input=3)
        self.assertEqual(self.hub.log, [])

    def test_refused_while_recording(self):
        self.c.recorders.any_recording = lambda: True
        with self.assertRaises(ControllerError):
            self.c.trace_start(blank_input=3)


if __name__ == "__main__":
    unittest.main()
