import json
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from pathlib import Path
from urllib.error import HTTPError

from atem_cut_logger.web.controller import Controller
from atem_cut_logger.web.server import make_server
from atem_cut_logger.release_channel import ReleaseChannel
from atem_cut_logger.updates import UpdateManager


class WebServerIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.httpd = make_server("127.0.0.1", 0)
        cls.port = cls.httpd.server_address[1]
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.controller.shutdown()
        cls.httpd.shutdown()

    def url(self, path):
        return f"http://127.0.0.1:{self.port}{path}"

    def get(self, path):
        with urllib.request.urlopen(self.url(path), timeout=5) as r:
            return r.status, r.read(), dict(r.headers)

    def post(self, path, obj=None):
        data = json.dumps(obj or {}).encode()
        req = urllib.request.Request(self.url(path), data=data,
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=5) as r:
            return r.status, json.loads(r.read())

    def test_state_endpoint(self):
        status, body, _ = self.get("/api/state")
        self.assertEqual(status, 200)
        self.assertIn("connected", json.loads(body))

    def test_full_session_over_http(self):
        # connect the simulator
        self.post("/api/connect", {"mode": "simulator"})
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            snap = json.loads(self.get("/api/state")[1])
            if snap["connected"]:
                break
            time.sleep(0.05)
        self.assertTrue(snap["connected"])

        self.post("/api/settings", {"rate_key": "25", "start_timecode": "00:00:00:00"})
        self.post("/api/logging/start")
        self.post("/api/simulate/cut", {"input_id": 4})
        self.post("/api/flag", {"note": "dead feed"})
        time.sleep(0.1)
        self.post("/api/logging/stop")

        snap = json.loads(self.get("/api/state")[1])
        self.assertTrue(snap["can_export"])
        self.assertIn(4, [e["input"] for e in snap["events"]])
        self.assertEqual(snap["flags"][0]["note"], "dead feed")

        status, xml, _ = self.get("/api/export/flags-fcpxml")
        self.assertEqual(status, 200)
        self.assertIn("dead feed", xml.decode())

        # exports download with a filename
        status, body, headers = self.get("/api/export/json")
        self.assertEqual(status, 200)
        self.assertIn("attachment", headers.get("Content-Disposition", ""))
        self.assertIn("events", json.loads(body))

        status, xml, headers = self.get("/api/export/fcpxml")
        self.assertIn("<fcpxml", xml.decode())

        # analysis summary
        status, summary = self.post("/api/analyze", {"config": {"min_shot_seconds": 5}})
        self.assertIn("issues", summary)
        self.assertIn("screen_time", summary)

        self.post("/api/disconnect")

    def test_bad_request_returns_400(self):
        with self.assertRaises(HTTPError) as ctx:
            self.post("/api/connect", {"mode": "atem", "ip": ""})
        self.assertEqual(ctx.exception.code, 400)

    def test_sse_stream_primes_state(self):
        req = urllib.request.Request(self.url("/api/stream"))
        with urllib.request.urlopen(req, timeout=5) as r:
            line = r.readline().decode()
            self.assertTrue(line.startswith("data: "))
            payload = json.loads(line[len("data: "):])
            self.assertEqual(payload["type"], "state")

    def test_dns_rebinding_host_blocked(self):
        # A request arriving under an attacker-controlled domain is refused,
        # even though it reaches the socket (DNS-rebinding defense).
        req = urllib.request.Request(self.url("/api/state"),
                                     headers={"Host": "evil.example.com"})
        with self.assertRaises(HTTPError) as ctx:
            urllib.request.urlopen(req, timeout=5)
        self.assertEqual(ctx.exception.code, 403)

    def test_ip_host_allowed(self):
        req = urllib.request.Request(self.url("/api/state"),
                                     headers={"Host": f"127.0.0.1:{self.port}"})
        with urllib.request.urlopen(req, timeout=5) as r:
            self.assertEqual(r.status, 200)

    def test_path_traversal_blocked(self):
        # Raw dotted path must not escape the static directory.
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}/../server.py")
        try:
            with urllib.request.urlopen(req, timeout=5) as r:
                body = r.read()
            self.assertNotIn(b"Controller", body)  # never served source
        except HTTPError as e:
            self.assertEqual(e.code, 404)

    def test_oversized_body_rejected(self):
        # The server refuses before allocating the body (DoS protection), so the
        # client sees either a clean 400 or a closed connection — never success.
        big = b'{"x":"' + b"a" * (17 * 1024 * 1024) + b'"}'
        req = urllib.request.Request(self.url("/api/settings"), data=big,
                                     headers={"Content-Type": "application/json"})
        try:
            urllib.request.urlopen(req, timeout=10)
            self.fail("oversized body should have been rejected")
        except HTTPError as e:
            self.assertEqual(e.code, 400)
        except urllib.error.URLError:
            pass  # connection closed early — also a valid rejection


class WebServerEmptyExports(unittest.TestCase):
    def setUp(self):
        self.httpd = make_server("127.0.0.1", 0)
        self.port = self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def tearDown(self):
        self.httpd.controller.shutdown(); self.httpd.shutdown()

    def test_export_with_no_events_is_400_not_500(self):
        # Fresh session, no events: export must fail cleanly as 400.
        for path in ("/api/export/fcpxml", "/api/analyze/markers", "/api/export/flags-fcpxml"):
            with self.assertRaises(HTTPError) as ctx:
                urllib.request.urlopen(f"http://127.0.0.1:{self.port}{path}", timeout=5)
            self.assertEqual(ctx.exception.code, 400, path)

    def test_flag_before_logging_is_400(self):
        data = json.dumps({}).encode()
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}/api/flag", data=data,
            headers={"Content-Type": "application/json"})
        with self.assertRaises(HTTPError) as ctx:
            urllib.request.urlopen(req, timeout=5)
        self.assertEqual(ctx.exception.code, 400)

    def _post(self, path, token, body=None):
        data = json.dumps(body or {}).encode()
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}{path}", data=data,
            headers={"Content-Type": "application/json",
                     "X-Control-Token": token, "X-Control-Label": token})
        with urllib.request.urlopen(req, timeout=5) as r:
            return r.status

    def test_control_lock_blocks_other_device(self):
        # Device A claims control; device B is blocked from mutating (403),
        # then can force a take-over.
        self.assertEqual(self._post("/api/control/claim", "A", {"label": "A"}), 200)
        with self.assertRaises(HTTPError) as ctx:
            self._post("/api/settings", "B", {"rate_key": "30"})
        self.assertEqual(ctx.exception.code, 403)
        # A can still drive
        self.assertEqual(self._post("/api/settings", "A", {"rate_key": "30"}), 200)
        # B forces control, then succeeds
        self.assertEqual(
            self._post("/api/control/claim", "B", {"label": "B", "force": True}), 200)
        self.assertEqual(self._post("/api/settings", "B", {"rate_key": "25"}), 200)


if __name__ == "__main__":
    unittest.main()


class UpdateEndpoints(unittest.TestCase):
    """The update API over a feed that cannot answer.

    That's the interesting case for the HTTP layer: an unreachable feed must
    surface as a plain 400 with a readable reason instead of hanging or
    500-ing — and pointing the channel at a dead local port keeps the tests
    from ever reaching the real feed.
    """

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        dead_feed = ReleaseChannel("http://127.0.0.1:9/manifest.json")
        controller = Controller(updates=UpdateManager(
            root=Path(cls.tmp.name), release_channel=dead_feed))
        cls.httpd = make_server("127.0.0.1", 0, controller)
        cls.port = cls.httpd.server_address[1]
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.controller.shutdown()
        cls.httpd.shutdown()
        cls.tmp.cleanup()

    def url(self, path):
        return f"http://127.0.0.1:{self.port}{path}"

    def test_status_endpoint_reports_the_release_channel(self):
        with urllib.request.urlopen(self.url("/api/update/status"), timeout=5) as r:
            body = json.loads(r.read())
        self.assertEqual(body["channel"], "release")
        self.assertTrue(body["supported"])
        self.assertFalse(body["update_available"])

    def test_state_snapshot_carries_update_status(self):
        with urllib.request.urlopen(self.url("/api/state"), timeout=5) as r:
            body = json.loads(r.read())
        self.assertIn("update", body)
        self.assertFalse(body["update"]["update_available"])

    def test_unreachable_feed_fails_with_400_not_500(self):
        for path in ("/api/update/check", "/api/update/apply"):
            req = urllib.request.Request(
                self.url(path), data=b"{}",
                headers={"Content-Type": "application/json"},
            )
            with self.assertRaises(HTTPError) as ctx:
                urllib.request.urlopen(req, timeout=5)
            self.assertEqual(ctx.exception.code, 400, path)


class WebServerTransitionOption(unittest.TestCase):
    """The FCPXML export honours the transitions setting over HTTP."""

    def setUp(self):
        controller = Controller()
        session = controller.session
        session.rate_key = "25"
        session.start_timecode = "01:00:00:00"
        session.begin()
        session.add_program_change(1, 0.0)
        session.add_program_change(2, 10.0, "mix", 50)   # a 2-second dissolve
        session.end(20.0)
        self.httpd = make_server("127.0.0.1", 0, controller)
        self.port = self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def tearDown(self):
        self.httpd.controller.shutdown(); self.httpd.shutdown()

    def fetch(self):
        url = f"http://127.0.0.1:{self.port}/api/export/fcpxml"
        with urllib.request.urlopen(url, timeout=5) as r:
            return r.read().decode()

    def settings(self, obj):
        data = json.dumps(obj).encode()
        req = urllib.request.Request(
            f"http://127.0.0.1:{self.port}/api/settings", data=data,
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=5) as r:
            r.read()

    def test_off_by_default(self):
        self.assertNotIn("<transition", self.fetch())

    def test_on_writes_transition_elements(self):
        self.settings({"fcpxml_transitions": True})
        self.assertIn('<transition name="Cross Dissolve"', self.fetch())
