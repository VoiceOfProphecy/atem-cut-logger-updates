"""TV control: the tiny MQTT client, the Hisense topics, Wake-on-LAN, config."""

import socket
import struct
import threading
import unittest

from atem_cut_logger.displays import (
    MQTT, DisplayConfig, DisplayError, HisenseVidaa, catalog, normalise_mac,
)


class MqttTests(unittest.TestCase):
    def test_connect_publish_and_collect(self):
        a, b = socket.socketpair()
        got = []

        def broker():
            head = b.recv(1)[0]
            length = b.recv(1)[0]
            got.append((head, b.recv(length)))
            b.sendall(b"\x20\x02\x00\x00")                     # CONNACK ok
            head = b.recv(1)[0]; length = b.recv(1)[0]
            got.append((head, b.recv(length)))
            topic = b"/remoteapp/mobile/x/state"
            body = struct.pack("!H", len(topic)) + topic + b'{"statetype":"livetv"}'
            b.sendall(bytes([0x30, len(body)]) + body)

        t = threading.Thread(target=broker); t.start()
        m = MQTT(a)
        m.connect("client", "hisenseservice", "multimqttservice")
        m.publish("/remoteapp/tv/remote_service/c$normal/actions/sendkey", "KEY_POWER")
        replies = m.collect(0.5)
        t.join()
        self.assertEqual(got[0][0], 0x10)
        self.assertIn(b"hisenseservice", got[0][1])
        self.assertEqual(got[1][0], 0x30)
        self.assertTrue(got[1][1].endswith(b"KEY_POWER"))
        self.assertEqual(replies, [("/remoteapp/mobile/x/state", '{"statetype":"livetv"}')])

    def test_refused_login_is_explained(self):
        a, b = socket.socketpair()
        b.sendall(b"\x20\x02\x00\x05")
        with self.assertRaises(DisplayError):
            MQTT(a).connect("c", "u", "p")


class HisenseTests(unittest.TestCase):
    def setUp(self):
        self.tv = HisenseVidaa(DisplayConfig(name="Stage", host="10.0.0.9"))
        self.sent = []
        self.tv._session = lambda pubs, listen=0.0: self.sent.extend(pubs) or []

    def test_key_topic(self):
        self.tv.send_key("KEY_VOLUMEUP")
        topic, payload = self.sent[0]
        self.assertRegex(topic, r"^/remoteapp/tv/remote_service/acl-[0-9a-f]{12}\$normal/actions/sendkey$")
        self.assertEqual(payload, "KEY_VOLUMEUP")

    def test_unknown_key_is_refused(self):
        with self.assertRaises(DisplayError):
            self.tv.send_key("KEY_SELF_DESTRUCT")
        self.assertEqual(self.sent, [])

    def test_volume_is_clamped(self):
        self.tv.set_volume(250)
        self.assertEqual(self.sent[0][1], "100")


class ConfigTests(unittest.TestCase):
    def test_mac_forms(self):
        self.assertEqual(normalise_mac("0011.2233.44ff"), "00:11:22:33:44:FF")
        self.assertEqual(normalise_mac("nope"), "")
        with self.assertRaises(DisplayError):
            DisplayConfig.from_dict({"host": "1.2.3.4", "mac": "12:34"})

    def test_catalog_lists_every_button(self):
        hisense = next(c for c in catalog() if c["kind"] == "hisense")
        self.assertIn({"key": "KEY_POWER", "label": "Power"}, hisense["keys"])
        self.assertIn("sources", hisense["features"])


if __name__ == "__main__":
    unittest.main()
