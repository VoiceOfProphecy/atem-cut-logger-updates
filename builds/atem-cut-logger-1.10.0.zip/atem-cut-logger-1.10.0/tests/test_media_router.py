"""Recorders tab (media, formatting) and the Videohub router, against fakes.

Formatting is the dangerous one, so most cases here are about it refusing:
wrong confirmation word, a card swapped since it was reviewed, a deck that
started recording.
"""

import socket
import tempfile
import threading
import unittest
import unittest.mock
from pathlib import Path

from atem_cut_logger.prefs import Prefs
from atem_cut_logger.recorders import (
    HyperDeck,
    RecorderConfig,
    RecorderError,
    clean_volume_name,
    parse_commands,
    parse_disk_list,
)
from atem_cut_logger.videohub import Videohub, apply_blocks, parse_blocks, VideohubState
from atem_cut_logger.web.controller import Controller, ControllerError


def _listen():
    sock = socket.socket()
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("127.0.0.1", 0))
    sock.listen(8)
    return sock


class MediaDeck:
    """A two-slot HyperDeck Studio Mini with clips on slot 1."""

    COMMANDS = (
        '<command name="format"><parameter name="slot id"/><parameter name="prepare"/>'
        '<parameter name="name"/><parameter name="confirm"/></command>',
        '<command name="configuration"><parameter name="timecode preset"/>'
        '<parameter name="record prefix"/></command>',
        '<command name="slot info"><parameter name="slot id"/></command>',
    )

    def __init__(self):
        self.recording = False
        self.volume = "CARD A"
        self.clips = ["TVTL 01-08_0001.mov", "TVTL 01-08 pickup.mov"]
        self.commands: list[str] = []
        self.formatted: list[str] = []
        self._sock = _listen()
        self.port = self._sock.getsockname()[1]
        threading.Thread(target=self._serve, daemon=True).start()

    def config(self):
        return RecorderConfig(name="ISO 1", host="127.0.0.1", port=self.port)

    def _serve(self):
        while True:
            try:
                conn, _ = self._sock.accept()
            except OSError:
                return
            threading.Thread(target=self._session, args=(conn,), daemon=True).start()

    def _session(self, conn):
        with conn:
            conn.sendall(b"500 connection info:\r\nprotocol version: 1.11\r\n\r\n")
            buffer = b""
            while True:
                chunk = conn.recv(4096)
                if not chunk:
                    return
                buffer += chunk
                while b"\r\n" in buffer:
                    line, _, buffer = buffer.partition(b"\r\n")
                    conn.sendall(self._respond(line.decode().strip()).encode())

    def _respond(self, c: str) -> str:
        self.commands.append(c)
        if c == "device info":
            return "204 device info:\r\nmodel: HyperDeck Studio Mini\r\nprotocol version: 1.11\r\nslot count: 2\r\n\r\n"
        if c == "transport info":
            status = "record" if self.recording else "preview"
            return f"208 transport info:\r\nstatus: {status}\r\nslot id: 1\r\n\r\n"
        if c == "configuration":
            return "211 configuration:\r\ntimecode preset: 00:00:00:00\r\nrecord prefix: ISO\r\n\r\n"
        if c == "commands":
            return "212 commands:\r\n<commands>\r\n" + "\r\n".join(self.COMMANDS) + "\r\n</commands>\r\n\r\n"
        if c == "slot info: slot id: 1":
            return f"202 slot info:\r\nslot id: 1\r\nstatus: mounted\r\nvolume name: {self.volume}\r\nrecording time: 3600\r\n\r\n"
        if c == "slot info: slot id: 2":
            return "105 no disk\r\n"
        if c == "disk list: slot id: 1":
            rows = "".join(f"{i}: {n} QuickTimeProRes 1080p30 00:10:00:00\r\n"
                           for i, n in enumerate(self.clips, 1))
            return f"206 disk list:\r\nslot id: 1\r\n{rows}\r\n"
        if c.startswith("disk list"):
            return "105 no disk\r\n"
        if c.startswith("format: slot id: 1 prepare:"):
            self.formatted.append(c)
            return "216 format ready\r\nTOKEN42\r\n\r\n"
        if c == "format: confirm: TOKEN42":
            self.formatted.append(c)
            self.clips = []
            return "200 ok\r\n"
        if c.startswith("configuration:"):
            return "200 ok\r\n"
        return "100 syntax error\r\n"


class ParsingTests(unittest.TestCase):
    def test_disk_list_keeps_spaces_in_names(self):
        clips = parse_disk_list(["slot id: 1", "2: My Show take 3.mov QuickTimeProRes 1080p30 00:01:02:03"])
        self.assertEqual(clips[0]["name"], "My Show take 3.mov")
        self.assertEqual(clips[0]["duration"], "00:01:02:03")

    def test_commands_tolerates_unclosed_tags(self):
        params = parse_commands(['<command name="shuttle"><parameter name="speed"></command>',
                                 '<command name="format"><parameter name="prepare"/></command>'])
        self.assertEqual(params["format"], {"prepare"})
        self.assertIn("shuttle", params)

    def test_volume_names_are_checked(self):
        self.assertEqual(clean_volume_name("  TVTL   A "), "TVTL A")
        with self.assertRaises(RecorderError):
            clean_volume_name("bad:name")
        with self.assertRaises(RecorderError):
            clean_volume_name("x" * 33)


class DeckTests(unittest.TestCase):
    def setUp(self):
        self.deck = MediaDeck()

    def test_info_lists_slots_and_clips(self):
        info = HyperDeck(self.deck.config()).info()
        self.assertEqual([s["status"] for s in info["slots"]], ["mounted", "empty"])
        self.assertEqual(len(info["slots"][0]["clips"]), 2)
        self.assertTrue(info["can_name_disk"])
        self.assertIn("timecode preset", info["settable"])

    def test_format_sends_prepare_then_confirm(self):
        HyperDeck(self.deck.config()).format_slot(1, "exFAT", "TVTL A")
        self.assertEqual(self.deck.formatted,
                         ["format: slot id: 1 prepare: exFAT name: TVTL A",
                          "format: confirm: TOKEN42"])

    def test_unknown_settings_never_reach_the_deck(self):
        with self.assertRaises(RecorderError):
            HyperDeck(self.deck.config()).set_config({"network: dhcp": "false"})
        self.assertFalse(any(c.startswith("configuration:") for c in self.deck.commands))


class FormatFlowTests(unittest.TestCase):
    def setUp(self):
        self.deck = MediaDeck()
        self.tmp = tempfile.TemporaryDirectory()
        self.c = Controller(prefs=Prefs(Path(self.tmp.name)))
        self.c.set_recorders([self.deck.config().to_dict()])

    def tearDown(self):
        self.c.shutdown()
        self.tmp.cleanup()

    def test_review_then_confirm_formats(self):
        r = self.c.format_review("127.0.0.1", 1)
        self.assertEqual(len(r["slot"]["clips"]), 2)
        self.c.format_confirm(r["review_id"], "exFAT", "NEW", "erase")
        self.assertIn("format: confirm: TOKEN42", self.deck.formatted)

    def test_wrong_word_erases_nothing(self):
        r = self.c.format_review("127.0.0.1", 1)
        with self.assertRaises(ControllerError):
            self.c.format_confirm(r["review_id"], "exFAT", "", "yes")
        self.assertEqual(self.deck.formatted, [])

    def test_swapped_card_erases_nothing(self):
        r = self.c.format_review("127.0.0.1", 1)
        self.deck.volume = "SOMEONE ELSES CARD"
        with self.assertRaises(ControllerError):
            self.c.format_confirm(r["review_id"], "exFAT", "", "ERASE")
        self.assertEqual(self.deck.formatted, [])

    def test_recording_deck_is_refused(self):
        self.deck.recording = True
        with self.assertRaises(ControllerError):
            self.c.format_review("127.0.0.1", 1)

    def test_review_is_single_use(self):
        r = self.c.format_review("127.0.0.1", 1)
        self.c.format_confirm(r["review_id"], "exFAT", "", "ERASE")
        with self.assertRaises(ControllerError):
            self.c.format_confirm(r["review_id"], "exFAT", "", "ERASE")

    def test_empty_slot_cannot_be_reviewed(self):
        with self.assertRaises(ControllerError):
            self.c.format_review("127.0.0.1", 2)


PRELUDE = (
    "PROTOCOL PREAMBLE:\nVersion: 2.8\n\n"
    "VIDEOHUB DEVICE:\nDevice present: true\nModel name: Smart Videohub 4x4\n"
    "Video inputs: 4\nVideo outputs: 4\n\n"
    "INPUT LABELS:\n0 Camera 1\n1 Camera 2\n2 Input 3\n3 PGM\n\n"
    "OUTPUT LABELS:\n0 ATEM 1\n1 ATEM 2\n2 Output 3\n3 Stage TV\n\n"
    "VIDEO OUTPUT LOCKS:\n0 U\n1 U\n2 U\n3 L\n\n"
    "VIDEO OUTPUT ROUTING:\n0 0\n1 1\n2 2\n3 3\n\n"
    "END PRELUDE:\n\n"
)


class FakeHub:
    def __init__(self):
        self.received: list[str] = []
        self._sock = _listen()
        self.port = self._sock.getsockname()[1]
        threading.Thread(target=self._serve, daemon=True).start()

    def _serve(self):
        while True:
            try:
                conn, _ = self._sock.accept()
            except OSError:
                return
            with conn:
                conn.sendall(PRELUDE.encode())
                conn.settimeout(0.5)
                try:
                    data = conn.recv(4096)
                except OSError:
                    continue
                if data:
                    self.received.append(data.decode())
                    conn.sendall(b"ACK\n\n")


class VideohubTests(unittest.TestCase):
    def test_prelude_parses(self):
        state = apply_blocks(VideohubState(), parse_blocks(PRELUDE))
        self.assertEqual(state.inputs[3], "PGM")
        self.assertEqual(state.outputs[3], "Stage TV")
        self.assertEqual(state.locks[3], "L")
        self.assertEqual(state.routing, [0, 1, 2, 3])

    def test_route_and_label_blocks(self):
        hub = FakeHub()
        v = Videohub("127.0.0.1", hub.port)
        v.route({3: 0, 1: 2})
        v.set_labels("input", {2: "Camera  3"})
        self.assertEqual(hub.received[0], "VIDEO OUTPUT ROUTING:\n1 2\n3 0\n\n")
        self.assertEqual(hub.received[1], "INPUT LABELS:\n2 Camera 3\n\n")

    def test_presets_round_trip(self):
        hub = FakeHub()
        with tempfile.TemporaryDirectory() as tmp:
            c = Controller(prefs=Prefs(Path(tmp)))
            try:
                c.router_set_host("127.0.0.1")
                with unittest.mock.patch("atem_cut_logger.web.controller.Videohub",
                                         lambda host: Videohub(host, hub.port)):
                    c.router_save_preset("Show")
                    c.router_apply_preset("Show")
                self.assertEqual(c.prefs.router["presets"][0]["routes"]["3"], 3)
                self.assertIn("VIDEO OUTPUT ROUTING:\n0 0\n1 1\n2 2\n3 3\n\n", hub.received)
            finally:
                c.shutdown()


if __name__ == "__main__":
    unittest.main()
