#!/bin/bash
# ATEM Cut Logger — installer for macOS.
#
# You normally don't run this directly: double-click
# "Install ATEM Cut Logger (Mac).command" in the folder you just unzipped.
#
# What it does:
#   1. deletes any previous install at ~/ATEM Cut Logger
#   2. copies this downloaded copy there
#   3. puts a double-clickable "Start ATEM Cut Logger" on the Desktop
# Re-running it IS the way to reinstall/upgrade — it always replaces.

set -u

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
INSTALL_DIR="$HOME/ATEM Cut Logger"
DESKTOP_LAUNCHER="$HOME/Desktop/Start ATEM Cut Logger.command"
APP_LAUNCHER="Start ATEM Cut Logger (Mac).command"
APP_BUNDLE="$HOME/Applications/ATEM Cut Logger.app"
APP_BINARY="ATEM Cut Logger"

say() { printf '%s\n' "$*"; }
fail() { printf '\n  ✗ %s\n\n' "$*" >&2; exit 1; }

say ""
say "  ATEM Cut Logger — installer"
say "  ------------------------------------------------"

# --- 1. Sanity: are we inside a real copy of the app? ----------------------
[ -d "$SOURCE_DIR/atem_cut_logger" ] || fail "This doesn't look like the app folder ($SOURCE_DIR)."

# --- 2. Python present? ----------------------------------------------------
if ! command -v python3 >/dev/null 2>&1; then
    say ""
    say "  Python 3 is not installed yet."
    say "  Opening python.org — install it (big yellow button), then"
    say "  double-click this installer again."
    open "https://www.python.org/downloads/" 2>/dev/null || true
    fail "Install Python 3 first."
fi
say "  Python  : $(python3 --version 2>&1)"

# --- 3. Don't install a folder onto itself --------------------------------
if [ "$SOURCE_DIR" = "$INSTALL_DIR" ]; then
    say "  Already installed in place — refreshing the Desktop shortcut only."
else
    # The Blackmagic SDK files and the compiled bridge live inside the install
    # and are not in the repo (licensed / build output), so carry them across
    # instead of making the operator re-copy the SDK after every upgrade.
    keep=""
    if [ -e "$INSTALL_DIR" ]; then
        keep="$(mktemp -d)"
        for f in BMDSwitcherAPI.h BMDSwitcherAPIDispatch.cpp atem-bridge; do
            [ -e "$INSTALL_DIR/bridge/mac/$f" ] && cp -p "$INSTALL_DIR/bridge/mac/$f" "$keep/"
        done
        [ -n "$(ls -A "$keep" 2>/dev/null)" ] \
            && say "  Keeping your ATEM SDK files and built bridge."
        say "  Removing the old install at: $INSTALL_DIR"
        rm -rf "$INSTALL_DIR" || fail "Could not remove $INSTALL_DIR"
    fi
    say "  Installing to: $INSTALL_DIR"
    mkdir -p "$INSTALL_DIR" || fail "Could not create $INSTALL_DIR"
    # Copy everything, including .git if this is a clone (keeps auto-update).
    (cd "$SOURCE_DIR" && tar -cf - .) | (cd "$INSTALL_DIR" && tar -xf -) \
        || fail "Could not copy the app files."
    if [ -n "$keep" ] && [ -n "$(ls -A "$keep" 2>/dev/null)" ]; then
        cp -p "$keep"/* "$INSTALL_DIR/bridge/mac/" 2>/dev/null
    fi
    [ -n "$keep" ] && rm -rf "$keep"
fi

chmod +x "$INSTALL_DIR/$APP_LAUNCHER" 2>/dev/null

# --- 4. Real .app bundle (proper icon, sits with your other apps) ----------
version="$(cd "$INSTALL_DIR" && python3 -c 'import atem_cut_logger as a; print(a.__version__)' 2>/dev/null)"

mkdir -p "$HOME/Applications"
rm -rf "$APP_BUNDLE"
mkdir -p "$APP_BUNDLE/Contents/MacOS" "$APP_BUNDLE/Contents/Resources"

# The bundle is a thin wrapper: it opens the launcher in Terminal, so you still
# see the network address and can stop the app by closing the window.
cat > "$APP_BUNDLE/Contents/MacOS/$APP_BINARY" <<BUNDLE_EXEC
#!/bin/bash
exec open -a Terminal "$INSTALL_DIR/$APP_LAUNCHER"
BUNDLE_EXEC
chmod +x "$APP_BUNDLE/Contents/MacOS/$APP_BINARY"

cat > "$APP_BUNDLE/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleName</key><string>ATEM Cut Logger</string>
    <key>CFBundleDisplayName</key><string>ATEM Cut Logger</string>
    <key>CFBundleIdentifier</key><string>com.oceanic7777.atemcutlogger</string>
    <key>CFBundleExecutable</key><string>$APP_BINARY</string>
    <key>CFBundleIconFile</key><string>AppIcon</string>
    <key>CFBundlePackageType</key><string>APPL</string>
    <key>CFBundleShortVersionString</key><string>${version:-1.0.0}</string>
    <key>CFBundleVersion</key><string>${version:-1.0.0}</string>
    <key>NSHighResolutionCapable</key><true/>
</dict>
</plist>
PLIST

if [ -f "$INSTALL_DIR/assets/AppIcon.icns" ]; then
    cp "$INSTALL_DIR/assets/AppIcon.icns" "$APP_BUNDLE/Contents/Resources/AppIcon.icns"
fi
# Nudge Finder/Dock to pick up the icon rather than caching a generic one.
touch "$APP_BUNDLE"

# Downloaded ZIPs are quarantined by macOS; clearing it means the Desktop
# icon opens on a normal double-click instead of being blocked.
xattr -dr com.apple.quarantine "$INSTALL_DIR" 2>/dev/null
xattr -dr com.apple.quarantine "$APP_BUNDLE" 2>/dev/null

# --- 5. Main Applications folder -------------------------------------------
# The bundle is built in ~/Applications (always writable), then moved to the
# main /Applications folder where people look for apps. That folder needs an
# administrator: if this account isn't one, macOS asks for an admin password,
# and cancelling simply leaves the app in ~/Applications.
MAIN_BUNDLE="/Applications/$APP_BINARY.app"
if [ -w /Applications ]; then
    rm -rf "$MAIN_BUNDLE" && cp -R "$APP_BUNDLE" "$MAIN_BUNDLE" && rm -rf "$APP_BUNDLE" \
        && APP_BUNDLE="$MAIN_BUNDLE"
elif [ -z "${ACL_NO_ADMIN:-}" ]; then
    say "  Putting the app in the main Applications folder — macOS may ask"
    say "  for an administrator's name and password (Cancel keeps it in"
    say "  your own Applications folder instead)."
    if osascript -e "do shell script \"rm -rf '$MAIN_BUNDLE' && cp -R '$APP_BUNDLE' '$MAIN_BUNDLE'\" with administrator privileges" >/dev/null 2>&1; then
        rm -rf "$APP_BUNDLE"
        APP_BUNDLE="$MAIN_BUNDLE"
    fi
fi

# --- 6. Desktop alias ------------------------------------------------------
# An older install left a plain .command here; the .app replaces it.
rm -f "$DESKTOP_LAUNCHER" "$HOME/Desktop/ATEM Cut Logger" \
      "$HOME/Desktop/ATEM Cut Logger alias" 2>/dev/null
osascript -e "tell application \"Finder\" to make alias file to POSIX file \"$APP_BUNDLE\" at desktop" >/dev/null 2>&1 \
    || ln -sfn "$APP_BUNDLE" "$HOME/Desktop/ATEM Cut Logger"

built="$(cd "$INSTALL_DIR" && git log -1 --format='%h, %cd' --date=short 2>/dev/null)"

say ""
say "  ✓ Installed."
say "  ------------------------------------------------"
say "  App folder : $INSTALL_DIR"
[ -n "$version" ] && say "  Version    : $version${built:+  (build $built)}"
say ""
say "  App icon   : $APP_BUNDLE"
say ""
say "  To start it: double-click  \"ATEM Cut Logger\"  on your Desktop,"
if [ "$APP_BUNDLE" = "$MAIN_BUNDLE" ]; then
    say "  or find it in the Applications folder."
else
    say "  or find it in your Home folder's Applications."
fi
say "  Drag that icon onto the Dock (left of the divider) to keep it there."
say ""
