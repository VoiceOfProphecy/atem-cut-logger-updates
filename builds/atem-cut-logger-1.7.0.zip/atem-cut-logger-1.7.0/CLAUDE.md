# Working in this repo

## Bump the version on every change

`atem_cut_logger/__init__.py` holds `__version__`. Any change that a user could
notice — a feature, a fix, a launcher or installer change — bumps it **in the
same commit**, with a matching entry at the top of `CHANGELOG.md`. Features bump
MINOR, fixes bump PATCH, anything that breaks saved logs or exports bumps MAJOR.

This is how the operator knows which build a machine is running: the version is
printed by the launcher, shown in the web UI header, and written into the
installed `.app`. A change that ships without a bump is invisible to them.

`tests/test_version.py` fails if the version and the changelog's top heading
disagree, so this can't be forgotten silently.

## Everything else

- Standard library only, on both the backend and the front end — no npm, no
  build step, no third-party Python packages.
- `python3 -m unittest discover -s tests` before pushing.
