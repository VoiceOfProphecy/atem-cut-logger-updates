# Security notes

This documents the web app's threat model and the hardening in place, so you
can decide how to deploy it on your production network.

## Trust model (read this first)

The web app has **no login/authentication**. It is designed to run on **one
trusted machine on a trusted production network**. Anyone who can reach the port
can operate the tool (start/stop logging, change settings, export files). That
is appropriate for a control-room/production LAN with one operator, and matches
how most broadcast utilities on a closed network behave.

Bind scope is your choice:

| How you start it | Who can reach it |
| --- | --- |
| `python -m atem_cut_logger.web` (default) | only the machine it runs on (localhost) |
| `--host 0.0.0.0` (the double-click launchers) | any device on the same network |

Use `0.0.0.0` **only on a network you trust** (ideally a dedicated production
VLAN, not the guest/office Wi-Fi). If you ever need it on a less-trusted network,
put it behind a reverse proxy that adds authentication and TLS, or add the
optional access token described below.

## What an attacker on the network could and couldn't do

Because there's no auth, someone already on the network could *use* the tool
(annoying, not a network breach). But the surface is deliberately small:

- **No arbitrary file read/write.** There is no endpoint that opens a path you
  give it. ISO/audio paths are only stored as text in the log; the server never
  opens them. Static files are served from one directory with path-traversal
  blocked.
- **No code/command execution.** Loaded logs are parsed as plain JSON (no
  `eval`, no pickle). The macOS ATEM bridge is launched with an argument list,
  never a shell, so the IP address cannot inject commands.
- **No credentials to steal.** The app stores and transmits none.

## Hardening in place

- **DNS-rebinding protection.** The server rejects requests whose `Host` header
  is an arbitrary domain name; only `localhost`, IP literals, and this machine's
  own hostname are accepted. This stops a malicious website (that the operator
  happens to visit) from scripting the local app through the browser.
- **Path-traversal blocked.** Static file requests are confined to the app's
  `static/` directory using a robust containment check.
- **Request-size cap.** Request bodies over 16 MB are refused before allocation,
  preventing trivial memory-exhaustion.
- **No information leakage on errors.** Bad input returns a clean `400` with a
  short message; unexpected errors return a generic `500` with no traceback.
- **Loopback by default.** You have to opt in to network exposure with
  `--host 0.0.0.0`.

## Recommendations for your rollout

1. Start on **one control-room machine**, on your **production VLAN**.
2. If access beyond that machine isn't needed yet, keep the default (localhost).
3. When you do expose it, prefer a dedicated production network segment.
4. Consider enabling OS firewall rules so only the intended subnet can reach the
   port.

## Optional: access token (not enabled)

If you later want a shared secret even on the LAN, the cleanest addition is a
token checked on every `/api/*` request (passed as a header or query param and
stored in the browser). It's a small change; ask and it can be added without
disturbing the double-click flow (the launcher can bake the token into the URL
it opens).

## Not a security risk, but worth knowing

- **One shared session, one driver.** All viewers see the same live session; a
  control lock ensures only one device can *drive* it at a time (others are
  view-only until they explicitly Take control). This is a coordination lock,
  not authentication — it prevents accidental overrides between trusted
  operators, not a determined attacker on the network.
- **Crash-safe autosave.** The session is continuously autosaved while logging
  and recovered on the next launch, so a power loss mid-show no longer means a
  lost log. The autosave file lives under the user's home directory.

Reporting: this is an internal tool; raise issues on the repository's PR/issues.
