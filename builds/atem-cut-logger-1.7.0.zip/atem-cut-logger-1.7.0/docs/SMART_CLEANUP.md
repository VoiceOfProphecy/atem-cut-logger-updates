# Smart Cleanup

Smart Cleanup is a **non-destructive analysis stage** that reads a logged
switch session and flags likely editing problems, then exports the findings in
three forms. It never modifies or overwrites the original switch log or the
original timeline XML.

![Smart Cleanup dialog](smart-cleanup.png)

## What it checks

All thresholds are configurable (GUI spinboxes, CLI flags, or a saved JSON
config). Each rule can be turned off independently.

| Rule | Flags when… | Default |
| --- | --- | --- |
| **Minimum shot duration** | a shot is shorter than the minimum (but not accidental) | `< 1.0 s` |
| **Maximum shot duration** | a single camera is held longer than the maximum | `> 120 s` |
| **Accidental cut** | a cut's shot is shorter than the accidental threshold | `< 0.5 s` |
| **Rapid back-and-forth** | A→B→A where the middle shot is very short | middle `< 2.0 s` |
| **Repeated camera** | the same camera is returned to N times inside a window | `4×` in `10 s` |
| **Wide over/under-use** | the designated wide camera is on Program too much / too little | `<10%` or `>60%` |

The wide-camera checks activate only once you designate which ATEM input is the
wide shot. "Accidental cut" always takes precedence over "short shot" at the
same location, so each blip is reported once.

## What it exports

1. **Human-readable report** (`.txt` or `.csv`) — timecode, detected issue,
   current camera, and a suggested review action, with a camera screen-time
   summary at the top.
2. **Resolve timeline markers** (`.fcpxml`) — the normal cut timeline with a
   marker dropped at each flagged location, so you can jump between problems in
   DaVinci Resolve.
3. **Cleaned timeline** (`.fcpxml`, optional) — a copy of the timeline with only
   the sub-threshold **accidental cuts** removed (the previous camera continues
   over each blip; a redundant same-camera return is collapsed too). Legitimate
   cuts are never removed. The original log and XML are left untouched.

## Using it

### GUI

Log or open a session, then click **Smart Cleanup…**. Adjust the rules, pick the
wide camera, press **Analyze**, and use the three export buttons.

### Command line

```sh
# Report + markers + cleaned timeline, with a designated wide camera
python -m atem_cut_logger analyze show.atemlog.json \
    --report show-cleanup.txt \
    --markers show-markers.fcpxml \
    --clean show-cleaned.fcpxml \
    --wide-camera 1 --min-shot 1.5 --accidental 0.4

# Just print the report to the terminal
python -m atem_cut_logger analyze show.atemlog.json

# Reuse a saved house-style rule set
python -m atem_cut_logger analyze show.atemlog.json --config house-rules.json --report out.csv
```

Individual flags override values from `--config`, which overrides the defaults.

## Architecture (and the Descript future phase)

The analysis lives in `atem_cut_logger/analysis/`:

| File | Role |
| --- | --- |
| `config.py` | `CleanupConfig` — thresholds + per-rule enable flags, JSON I/O |
| `model.py` | `Shot`, `Issue`, `AnalysisResult`, shot derivation, screen-time |
| `rules.py` | the rules + a **rule registry** (`RULES`) |
| `analyzer.py` | runs the registry, resolves overlaps |
| `report.py` / `markers.py` / `cleaned.py` | the three exports |
| `transcript.py` | speaker-transcript model + Descript loader (seam only) |

Rules are just functions registered in `RULES`, so adding a check is additive.
`transcript.py` already imports a **speaker-labelled Descript transcript** and can
answer "who was speaking at frame N?". The rule that compares the active speaker
against the selected camera is intentionally **left for a later phase**
(`speaker_camera_mismatch` is a documented no-op today). There is deliberately
**no face recognition and no automatic reframing** anywhere in this project.

## Single-camera stretch (`solo_stretch`)

Cuts can keep happening while coverage quietly collapses onto one angle — a
long stretch where one camera holds nearly all the screen time, with only
glances elsewhere. `max_shot` can't see this, because no individual shot is
long.

The rule walks a window (`solo_window_seconds`, default 180 s) across the show
and flags the start of each run where one input holds at least `solo_fraction`
(default 0.9) of that window. One issue per run, not per shot: a twenty-minute
single-camera stretch is one editorial fact. The trailing partial window is
skipped, since a short window at the end would exaggerate whoever is on air.
