# ATEM Cut Logger

A small desktop utility (macOS / Windows) that connects to a Blackmagic
**ATEM** switcher, logs every **Program-bus** change on **M/E 1** during a live
production, and exports a **DaVinci Resolve-compatible FCPXML timeline** that
recreates the live switch from your separately recorded camera ISO files.

![ATEM Cut Logger](docs/screenshot.png)

* Uses the **official Blackmagic ATEM Switchers SDK** — no protocol
  reverse-engineering. The exact interfaces/callbacks used are documented in
  [`docs/ATEM_SDK_NOTES.md`](docs/ATEM_SDK_NOTES.md).
* Records **CUT and AUTO-transition completion** moments (the SDK changes the
  Program source only when a transition completes), ignores Preview-bus
  changes, and suppresses duplicate notifications when the source didn't change.
* Supports **23.976, 24, 25, 29.97 and 30 fps**, with explicit
  **drop-frame / non-drop-frame** handling (DF is offered only for 29.97 and
  nonexistent DF labels like `00:01:00;00` are rejected).
* The saved **JSON log is the source of truth**: reopen it any time
  (*File ▸ Open Log for Export…*) and regenerate CSV or FCPXML without the ATEM.
* Includes a **Test Mode** simulator — full workflow, no hardware needed.
* **Smart Cleanup** — a non-destructive analysis pass that flags likely editing
  problems (short/long shots, accidental cuts, rapid back-and-forth, repeated
  cameras, wide-camera over/under-use) and exports a report, Resolve markers, and
  an optional cleaned timeline. See [`docs/SMART_CLEANUP.md`](docs/SMART_CLEANUP.md).
* Two front ends over one shared engine: a **desktop app** (tkinter) and a
  modern, themeable **local web app** you can reach from a laptop or tablet on
  the production network. See [`docs/WEB_APP.md`](docs/WEB_APP.md).

## Ways to run it

```sh
python -m atem_cut_logger.web     # modern local web app (recommended)
python -m atem_cut_logger         # desktop app (tkinter)
python -m atem_cut_logger log     # headless CLI logging
python -m atem_cut_logger analyze # headless Smart Cleanup
```

---

## Workflow

1. Enter the ATEM's IP address and click **Connect** (or click **Test Mode**).
   The current Program input is shown immediately.
2. Set the **frame rate**, **start timecode** (the **Now** button fills in the
   current wall-clock time; drop-frame is selectable for 29.97), export
   resolution, and optionally the **continuous program-audio file**.
3. Double-click rows in the **camera mapping** table to name each ATEM input
   and pick its ISO media file.
4. Click **● Start Logging**. Every Program change is captured with elapsed
   time, SMPTE timecode, ATEM input ID and mapped camera name. The first event
   is whatever was on Program at start, so the timeline is covered from 0:00.
5. Click **■ Stop Logging**, then:
   * **Save Log (JSON)** — lossless session log (source of truth),
   * **Export CSV** — human-readable log,
   * **Export Resolve Timeline (FCPXML)** — cuts on V1, continuous program
     audio on A1.
6. In DaVinci Resolve: **File ▸ Import ▸ Timeline…**, pick the `.fcpxml`, and
   relink to your ISO files if they moved.

### ISO sync models

The exporter needs to know how your ISO recordings relate to the timeline:

* **“started with logging”** (default) — you started the ISO recorders at the
  same moment you clicked *Start Logging* (e.g. ATEM Mini ISO starts all
  records together). Source positions = elapsed time into each file.
* **“timecode-synced”** — the ISO files carry production timecode (jam sync /
  ATEM TC). Source positions use absolute timecode.

The program-feed audio is kept as **one continuous clip** on its own track;
only the camera video is cut.

---

## Installation

Requires **Python 3.10+** (the python.org installer includes tkinter on both
macOS and Windows).

```sh
git clone https://github.com/Oceanic7777/ATEM-XML-Export-Utility.git
cd ATEM-XML-Export-Utility
python -m atem_cut_logger        # launches the GUI
```

Test Mode and all exports work out of the box on any OS, with **no
dependencies** beyond the standard library. Connecting to real hardware needs
one extra step per platform:

### Windows

1. Install **ATEM Software Control** (ATEM Switchers package from
   [blackmagicdesign.com/support](https://www.blackmagicdesign.com/support)).
   It registers the SDK COM server (`BMDSwitcherAPI64.dll`) the app uses.
2. `pip install comtypes`
3. Run `python -m atem_cut_logger`, enter the ATEM's IP, **Connect**.

### macOS

1. Install **ATEM Software Control** (provides
   `/Library/Frameworks/BMDSwitcherAPI.framework`).
2. Build the tiny SDK bridge once — see
   [`bridge/mac/README.md`](bridge/mac/README.md):

   ```sh
   xcode-select --install                  # if you don't have the CLT yet
   # copy BMDSwitcherAPI.h + BMDSwitcherAPIDispatch.cpp from the
   # Blackmagic ATEM Switchers SDK into bridge/mac/, then:
   cd bridge/mac && make
   ```

3. Run `python3 -m atem_cut_logger`, enter the ATEM's IP, **Connect**.

> The SDK header and dispatch file are Blackmagic-licensed and can't be
> redistributed here; the free SDK download is in the *Developer* section of
> Blackmagic's support page.

---

## Headless CLI

The prototype workflow is also scriptable:

```sh
# 60-second test-mode session, 29.97 DF, starting at 01:00:00;00
python -m atem_cut_logger log --simulate --duration 60 \
    --rate 29.97 --drop-frame --start-tc "01:00:00;00" \
    --out show.atemlog.json --csv show.csv

# real switcher instead of the simulator
python -m atem_cut_logger log --ip 192.168.10.240 --rate 25 --duration 3600 \
    --out show.atemlog.json

# regenerate exports later from the saved log (no ATEM needed)
python -m atem_cut_logger export show.atemlog.json \
    --csv show.csv --fcpxml show.fcpxml --width 1920 --height 1080

# Smart Cleanup: analyse the log and export a report, markers, cleaned timeline
python -m atem_cut_logger analyze show.atemlog.json \
    --report show-cleanup.txt --markers show-markers.fcpxml \
    --clean show-cleaned.fcpxml --wide-camera 1
```

## File formats

* **`*.atemlog.json`** — session log: frame rate, DF flag, start timecode,
  input→camera/file mappings, program-audio file, and every event
  (`elapsed`, `frame`, `timecode`, `input`, `camera`). Everything else is
  derived from this file.
* **CSV** — `event, elapsed_seconds, timecode, atem_input, camera, iso_file`.
* **FCPXML 1.8** — one `asset-clip` per cut on the primary storyline
  (video-only assets, so audio is never chopped), plus a single lane-−1
  `audio` element spanning the whole show for the program feed. All times are
  exact rationals (`1001/30000s`-style), frame-aligned, with `tcStart` /
  `tcFormat` (`DF`/`NDF`) carried through. Missing ISO files export as clearly
  named offline placeholders you can relink in Resolve.

## Development

```sh
python -m unittest discover -s tests    # 29 tests, no hardware required
```

Layout:

| Path | Purpose |
| --- | --- |
| `atem_cut_logger/timecode.py` | SMPTE math (all 5 rates, DF/NDF) |
| `atem_cut_logger/session.py` | switch log, dedup, JSON/CSV |
| `atem_cut_logger/fcpxml.py` | Resolve timeline export |
| `atem_cut_logger/backends/` | simulator, Windows COM, macOS bridge client |
| `atem_cut_logger/analysis/` | Smart Cleanup: rules, report, markers, cleaned timeline, Descript seam |
| `atem_cut_logger/web/` | local web app: controller, stdlib HTTP/SSE server, static UI |
| `atem_cut_logger/gui/app.py` | tkinter desktop app |
| `bridge/mac/` | C++ helper built against the official SDK |
| `docs/ATEM_SDK_NOTES.md` | exact SDK interfaces/callbacks used, and why |

## Version

The running version is printed by the launcher and shown in the web UI header.
Every user-visible change bumps `__version__` and adds an entry to
[`CHANGELOG.md`](CHANGELOG.md) — see [`CLAUDE.md`](CLAUDE.md).
