# Changelog

Every user-visible change bumps `__version__` in `atem_cut_logger/__init__.py`
and gets a line here. The version is printed by the launcher, shown in the web
UI header, and baked into the installed `.app`, so it's how you tell at a glance
which build a machine is running.

Numbering: `MAJOR.MINOR.PATCH` — features bump MINOR, fixes bump PATCH, a change
that breaks saved logs or exports bumps MAJOR.

## 1.7.0

- **Transition-aware logging** — dissolves, dips, wipes and DVE moves are
  logged with their style and length instead of passing as hard cuts (log
  schema 2; schema 1 files still load). The EDL exports them as true CMX
  dissolves positioned where the blend began, and the FCPXML timeline cuts at
  the blend's midpoint rather than at its end, where the switcher reports it.
- **Macro buttons** — the switcher's macros appear in the UI and can be fired
  from any device driving the session; firing one leaves a note in the log at
  that timecode.
- The log table gained a Transition column, and the CSV two columns.
- The bridge can be built without either feature (`make EXTRAS=0`) for SDKs
  that lack the interfaces.

## 1.6.0

- **Recorder control** — list HyperDecks (or anything speaking Blackmagic's
  port-9993 protocol) in the new Recorders card, then Record all / Stop all
  from the UI, with each deck's transport state and timecode shown live. Decks
  are contacted in parallel, so one dead recorder reports its own error instead
  of holding up the others, and the clip is named after the session.
- **Auto-start logging when recording starts** — including when someone presses
  record on the deck itself. Recorders travel in session templates.

## 1.5.0

- **EDL export** — a CMX3600 edit list alongside the JSON, CSV and FCPXML, for
  editors on Avid, Premiere or older Resolve. Cuts carry the camera name and
  the ISO path as comments, and error flags and notes ride along as comments at
  their own timecode instead of being dropped.
- **Single-camera stretch rule** in Smart Cleanup — flags runs where coverage
  collapsed onto one angle even though cuts kept happening, which the long-shot
  rule can't see. One issue per run, tunable via `solo_window_seconds` and
  `solo_fraction`.

## 1.4.0

- **Updates without a GitHub login.** A copy installed from a ZIP now follows a
  public update feed instead of reporting that it can't update itself: it reads
  a manifest, verifies the build against its SHA-256, checks the build declares
  the version the feed promised, and keeps the licensed SDK files and compiled
  bridge. Clone installs still fast-forward over git; the channel is picked
  automatically.
- `scripts/publish_release.py` builds the zip and manifest for the feed, taking
  the version and release notes from the package and the changelog.

## 1.3.0

- **Session templates** — save a show's setup (frame rate, drop-frame,
  resolution, ISO sync, program audio file and the whole camera mapping) and
  load it before the next show. Templates deliberately leave out the start
  timecode and session name, which belong to a single show; they're JSON files
  in `~/.atem_cut_logger/templates`, so they copy between machines.
- **New session** — clears the log for the next show while keeping cameras and
  settings. Warns first when the current log has cuts that were never exported.
- The header now shows an "Unsaved log" hint while a log has unexported work.

## 1.2.0

- **Self-update.** The version badge in the header is now a "check for
  updates" button, the app checks on its own every 6 hours, and when an update
  is waiting a banner offers "Update & restart" — it fast-forwards the install,
  rebuilds the ATEM bridge if the SDK is present, and relaunches itself with
  the same options. Never while logging; never over local edits (it refuses and
  says why rather than discarding work). A ZIP install says so instead, since
  only a git clone can update itself.
- `--update-check-hours` on the web entry point sets the interval (0 disables
  the automatic check; the manual button still works).

## 1.1.1

- Installer keeps the Blackmagic SDK files (`BMDSwitcherAPI.h`,
  `BMDSwitcherAPIDispatch.cpp`) and the compiled `atem-bridge` across an
  upgrade. Before, every reinstall wiped them and the switcher connection had
  to be set up again from the SDK download.

## 1.1.0

- Session naming: name a session (e.g. "TVTL 01-08") and exports are named from
  it — `tvtl-01-08.atemlog.json`, `.csv`, `.fcpxml`.
- Editorial notes on the timeline, for the editor picking the log up later.
- macOS installer (`Install ATEM Cut Logger (Mac).command`): replaces any older
  install, builds `~/Applications/ATEM Cut Logger.app` with a real icon, and
  puts an alias on the Desktop.
- Launcher hardened: reports a missing Python instead of closing silently,
  can't hang on a git credential prompt, prints the version before starting.
- Run guide rewritten around the installer; roadmap now carries every
  outstanding feature request.

## 1.0.0

First working version: live Program-bus logging over the macOS bridge and the
Windows COM backend, Test Mode, Smart Cleanup, Mark Error, CSV/FCPXML export,
auto-detected start timecode, the network-accessible web app, and the optional
macOS background service.
