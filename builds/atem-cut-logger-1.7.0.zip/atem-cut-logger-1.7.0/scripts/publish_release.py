#!/usr/bin/env python3
"""Publish the current source tree to the public update feed.

The private repo holds the work; a public repo holds what a running copy needs
to update itself. This script turns the checkout it's run from into that feed's
next release:

    python3 scripts/publish_release.py --feed ../atem-cut-logger-updates

It writes ``builds/atem-cut-logger-<version>.zip`` and ``manifest.json`` into
the feed checkout. Committing and pushing is left to the caller, so the change
can be inspected first.

The version comes from ``atem_cut_logger/__init__.py`` and the notes from the
matching section of ``CHANGELOG.md`` — publishing can't drift from what the app
reports or from what the changelog says shipped.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent

# What a running install needs. Everything else (git metadata, the operator's
# licensed SDK files, build output) is deliberately left out.
INCLUDE = [
    "atem_cut_logger", "bridge", "docs", "scripts", "service", "tests",
    "assets", "README.md", "CHANGELOG.md", "CLAUDE.md", "HOW-TO-RUN.txt",
    "Install ATEM Cut Logger (Mac).command",
    "Start ATEM Cut Logger (Mac).command",
    "Start ATEM Cut Logger (Windows).bat",
]
EXCLUDE_NAMES = {"__pycache__", ".DS_Store", "atem-bridge",
                 "BMDSwitcherAPI.h", "BMDSwitcherAPIDispatch.cpp"}


def current_version() -> str:
    init = (REPO_ROOT / "atem_cut_logger" / "__init__.py").read_text(encoding="utf-8")
    match = re.search(r'__version__\s*=\s*"([^"]+)"', init)
    if not match:
        sys.exit("Could not read __version__.")
    return match.group(1)


def changelog_notes(version: str) -> list[str]:
    """The bullet headlines under this version's heading in CHANGELOG.md."""
    text = (REPO_ROOT / "CHANGELOG.md").read_text(encoding="utf-8")
    section = re.split(rf"^## {re.escape(version)}\s*$", text, flags=re.M)
    if len(section) < 2:
        return []
    body = re.split(r"^## ", section[1], flags=re.M)[0]
    notes = []
    for line in body.splitlines():
        if line.startswith("- "):
            note = re.sub(r"[*`]", "", line[2:]).strip()
            notes.append(note.split(" — ")[0].rstrip(".") if " — " in note else note)
    return notes[:10]


def wanted(path: Path) -> bool:
    return not any(part in EXCLUDE_NAMES for part in path.parts)


def build_zip(destination: Path, version: str) -> bytes:
    top = f"atem-cut-logger-{version}"
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as zf:
        for entry in INCLUDE:
            source = REPO_ROOT / entry
            if not source.exists():
                continue
            if source.is_file():
                zf.write(source, f"{top}/{entry}")
                continue
            for path in sorted(source.rglob("*")):
                if path.is_file() and wanted(path.relative_to(REPO_ROOT)):
                    zf.write(path, f"{top}/{path.relative_to(REPO_ROOT)}")
    return destination.read_bytes()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--feed", required=True, type=Path,
                        help="Checkout of the public update-feed repository")
    parser.add_argument("--dry-run", action="store_true",
                        help="Print what would be published and stop")
    args = parser.parse_args()

    version = current_version()
    notes = changelog_notes(version)
    if not notes:
        print(f"warning: CHANGELOG.md has no section for {version}", file=sys.stderr)

    dirty = subprocess.run(["git", "status", "--porcelain"], cwd=REPO_ROOT,
                           capture_output=True, text=True).stdout.strip()
    if dirty:
        print("warning: publishing a tree with uncommitted changes", file=sys.stderr)

    zip_rel = f"builds/atem-cut-logger-{version}.zip"
    if args.dry_run:
        print(f"version : {version}")
        print(f"zip     : {zip_rel}")
        for note in notes:
            print(f"note    : {note}")
        return 0

    feed = args.feed.expanduser().resolve()
    if not feed.is_dir():
        sys.exit(f"Feed checkout not found: {feed}")

    blob = build_zip(feed / zip_rel, version)
    manifest = {
        "version": version,
        "published": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "notes": notes,
        "zip": zip_rel,
        "sha256": hashlib.sha256(blob).hexdigest(),
    }
    (feed / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")

    print(f"Wrote {zip_rel} ({len(blob) / 1024:.0f} KB) and manifest.json to {feed}")
    print("Now: git -C <feed> add -A && git -C <feed> commit -m "
          f"'Publish {version}' && git -C <feed> push")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
