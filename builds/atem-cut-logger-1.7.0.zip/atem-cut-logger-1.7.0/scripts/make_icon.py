#!/usr/bin/env python3
"""Generate the ATEM Cut Logger app icon (PNG + .icns) — stdlib only.

The mark: a dark rounded square (the switcher chassis), a red record dot, and
a white slit cutting through it — record + cut, the two things the app is about.
Legible down to 16px because it's only two shapes.

Run from the repo root:  python3 scripts/make_icon.py
Writes assets/AppIcon.icns and assets/icon_1024.png. Both are committed, so
this only needs re-running when the artwork changes.
"""

from __future__ import annotations

import math
import struct
import zlib
from pathlib import Path

SIZE = 1024
OUT_DIR = Path(__file__).resolve().parent.parent / "assets"

BG_TOP = (0x24, 0x28, 0x2F)
BG_BOTTOM = (0x14, 0x16, 0x1A)
RING = (0x3A, 0x40, 0x4A)
RED = (0xE5, 0x48, 0x4D)
RED_DARK = (0xB4, 0x33, 0x38)
WHITE = (0xF5, 0xF6, 0xF8)


def _mix(a, b, t):
    return tuple(round(x + (y - x) * t) for x, y in zip(a, b))


def _over(dst, src, alpha):
    return tuple(round(d + (s - d) * alpha) for d, s in zip(dst, src))


def _cov(dist, feather=1.0):
    """Coverage from a signed distance (negative = inside), anti-aliased."""
    return min(1.0, max(0.0, 0.5 - dist / feather))


def _sd_round_rect(x, y, cx, cy, half, radius):
    dx = abs(x - cx) - (half - radius)
    dy = abs(y - cy) - (half - radius)
    ax, ay = max(dx, 0.0), max(dy, 0.0)
    return math.hypot(ax, ay) + min(max(dx, dy), 0.0) - radius


def render(size: int = SIZE) -> list[list[tuple[int, int, int, int]]]:
    s = size
    cx = cy = s / 2.0
    chassis_half = s * 0.46
    chassis_radius = s * 0.215
    dot_r = s * 0.245
    slit_half_w = s * 0.037
    slit_half_h = s * 0.33

    rows = []
    for py in range(s):
        y = py + 0.5
        row = []
        # Vertical gradient for the chassis face.
        base = _mix(BG_TOP, BG_BOTTOM, y / s)
        for px in range(s):
            x = px + 0.5
            d_chassis = _sd_round_rect(x, y, cx, cy, chassis_half, chassis_radius)
            a_chassis = _cov(d_chassis, 1.6)
            if a_chassis <= 0.0:
                row.append((0, 0, 0, 0))
                continue

            color = base
            # Hairline inner bevel so the shape reads on dark backgrounds too.
            edge = _cov(d_chassis + s * 0.012, 1.6) - _cov(d_chassis + s * 0.004, 1.6)
            if edge > 0:
                color = _over(color, RING, edge * 0.9)

            # Record dot, slightly darker at the bottom for depth.
            d_dot = math.hypot(x - cx, y - cy) - dot_r
            a_dot = _cov(d_dot, 1.6)
            if a_dot > 0:
                shade = _mix(RED, RED_DARK, max(0.0, (y - (cy - dot_r)) / (2 * dot_r)))
                color = _over(color, shade, a_dot)

            # The cut: a white slit straight through the dot.
            d_slit = max(abs(x - cx) - slit_half_w, abs(y - cy) - slit_half_h)
            a_slit = _cov(d_slit, 1.6)
            if a_slit > 0:
                color = _over(color, WHITE, a_slit)

            row.append((color[0], color[1], color[2], round(a_chassis * 255)))
        rows.append(row)
    return rows


def downsample(rows, target: int):
    src = len(rows)
    if src == target:
        return rows
    step = src / target
    out = []
    for ty in range(target):
        y0, y1 = int(ty * step), int((ty + 1) * step)
        row = []
        for tx in range(target):
            x0, x1 = int(tx * step), int((tx + 1) * step)
            r = g = b = a = n = 0
            for sy in range(y0, y1):
                line = rows[sy]
                for sx in range(x0, x1):
                    pr, pg, pb, pa = line[sx]
                    # Premultiply so transparent pixels don't darken the edge.
                    r += pr * pa
                    g += pg * pa
                    b += pb * pa
                    a += pa
                    n += 1
            if a:
                row.append((round(r / a), round(g / a), round(b / a), round(a / n)))
            else:
                row.append((0, 0, 0, 0))
        out.append(row)
    return out


def to_png(rows) -> bytes:
    size = len(rows)
    raw = bytearray()
    for row in rows:
        raw.append(0)  # filter type 0
        for px in row:
            raw += bytes(px)

    def chunk(tag: bytes, data: bytes) -> bytes:
        return (struct.pack(">I", len(data)) + tag + data
                + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))

    header = struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", header)
            + chunk(b"IDAT", zlib.compress(bytes(raw), 9)) + chunk(b"IEND", b""))


# icns entry types that accept a raw PNG payload, and the pixel size each wants.
ICNS_ENTRIES = [
    (b"icp4", 16), (b"icp5", 32), (b"ic11", 32), (b"ic12", 64),
    (b"ic07", 128), (b"ic13", 256), (b"ic08", 256), (b"ic14", 512),
    (b"ic09", 512), (b"ic10", 1024),
]


def to_icns(png_by_size: dict[int, bytes]) -> bytes:
    body = b"".join(
        tag + struct.pack(">I", len(png_by_size[px]) + 8) + png_by_size[px]
        for tag, px in ICNS_ENTRIES
    )
    return b"icns" + struct.pack(">I", len(body) + 8) + body


def main() -> None:
    OUT_DIR.mkdir(exist_ok=True)
    master = render(SIZE)
    sizes = sorted({px for _, px in ICNS_ENTRIES})
    png_by_size = {px: to_png(downsample(master, px)) for px in sizes}
    png_by_size[SIZE] = to_png(master)

    (OUT_DIR / "icon_1024.png").write_bytes(png_by_size[SIZE])
    (OUT_DIR / "AppIcon.icns").write_bytes(to_icns(png_by_size))
    print(f"wrote {OUT_DIR/'icon_1024.png'} and {OUT_DIR/'AppIcon.icns'}")


if __name__ == "__main__":
    main()
