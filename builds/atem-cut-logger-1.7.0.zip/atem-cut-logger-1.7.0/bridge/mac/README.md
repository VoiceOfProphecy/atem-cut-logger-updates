# macOS ATEM bridge

`atem-bridge` is a ~300-line helper that links ATEM Cut Logger to the
**official Blackmagic ATEM Switchers SDK** on macOS. The Python app spawns it
with the switcher's IP address and reads newline-delimited JSON events
(current Program input, input names, Program changes, disconnects).

## Build

1. Install the Xcode command line tools:

   ```sh
   xcode-select --install
   ```

2. Install **ATEM Software Control** (from the ATEM Switchers package on
   [blackmagicdesign.com/support](https://www.blackmagicdesign.com/support)).
   This provides `/Library/Frameworks/BMDSwitcherAPI.framework`, which the
   bridge loads at runtime.

3. Download the **Blackmagic ATEM Switchers SDK** from the *Developer* section
   of the same support page, and copy these two files from
   `Switchers/Mac/include/` into this directory:

   * `BMDSwitcherAPI.h`
   * `BMDSwitcherAPIDispatch.cpp`

   (They are Blackmagic-licensed and therefore not committed to this repo.)

4. Build:

   ```sh
   make            # current SDK (7.5+)
   make LEGACY=1   # only if you use an SDK older than 7.x
   make EXTRAS=0   # if transition/macro interfaces are missing from your SDK
   ```

   `EXTRAS=0` drops transition reporting and macro control — cuts are still
   logged exactly as before, transitions just export as hard cuts and the macro
   buttons stay hidden.

The app looks for the resulting `atem-bridge` binary in this directory
(or on `PATH`, or via the `ATEM_BRIDGE` environment variable).

## Protocol

One JSON object per line on stdout:

```json
{"type":"connected","product":"ATEM 1 M/E Production Studio 4K","program":1}
{"type":"input","id":1,"name":"Camera 1"}
{"type":"inputs_done"}
{"type":"macros","macros":[{"index":0,"name":"Lower third"}]}
{"type":"transition","in_transition":true,"style":"mix","frames":50}
{"type":"program","input":2}
{"type":"macro_run","index":0,"ok":true}
{"type":"disconnected"}
{"type":"error","message":"Could not connect: no response..."}
```

`program` events are emitted from
`IBMDSwitcherMixEffectBlockCallback::Notify` when
`bmdSwitcherMixEffectBlockEventTypeProgramInputChanged` fires on M/E 1 — i.e.
on CUTs and at AUTO-transition completion, never for Preview changes. See
`docs/ATEM_SDK_NOTES.md` at the repo root for the full interface rationale.
