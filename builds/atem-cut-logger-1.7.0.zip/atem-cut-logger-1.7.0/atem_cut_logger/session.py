"""The switch log: the source of truth for everything the app exports.

A :class:`LogSession` records the production settings and every Program-bus
change. It serialises losslessly to JSON so a session saved during the show
can be re-opened later to regenerate the CSV or the Resolve timeline.
"""

from __future__ import annotations

import csv
import io
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone

from .timecode import (
    FRAME_RATES,
    FrameRate,
    TimecodeError,
    event_timecode,
    frames_to_timecode,
    parse_timecode,
    seconds_to_frames,
)

SCHEMA_VERSION = 2
# Schema 1 had no transition fields; it still loads (every event reads as a cut).
SUPPORTED_SCHEMAS = (1, 2)

# Transition kinds the switcher can report. "cut" is a hard cut; the rest are
# AUTO transitions, where the logged moment is the transition's *completion*.
CUT = "cut"


@dataclass
class CameraMapping:
    """User mapping of one ATEM input number to a camera angle / ISO file."""

    input_id: int
    name: str = ""        # camera/angle label used in exports, e.g. "CAM 1 Wide"
    file: str = ""        # path to the ISO media file (optional until export)

    def label(self) -> str:
        return self.name or f"Input {self.input_id}"


@dataclass
class SwitchEvent:
    """One Program-bus change (or the initial program at logging start)."""

    elapsed: float        # seconds since logging started
    frame: int            # frames since logging started (at the session rate)
    timecode: str         # absolute SMPTE timecode of the cut
    input_id: int         # ATEM input number now on Program
    camera: str           # mapped camera label at time of export/logging
    transition: str = CUT     # "cut", "mix", "dip", "wipe", "dve", "sting"
    transition_frames: int = 0  # length of an AUTO transition, 0 for a cut

    @property
    def is_transition(self) -> bool:
        return self.transition != CUT and self.transition_frames > 0

    @property
    def transition_start_frame(self) -> int:
        """Where the blend began — the logged frame is where it finished."""
        return max(0, self.frame - self.transition_frames)


@dataclass
class ErrorFlag:
    """A moment the operator manually marked as a problem while logging —
    e.g. a dead feed, wrong camera, audio dropout. Never auto-detected; this
    is purely a "mark this spot for review later" button, independent of the
    Smart Cleanup analysis (which only flags shot-duration/pattern issues)."""

    elapsed: float         # seconds since logging started
    frame: int             # frames since logging started (at the session rate)
    timecode: str          # absolute SMPTE timecode of the flagged moment
    note: str = ""         # optional short description, addable later


@dataclass
class TimelineNote:
    """An editorial note at a specific timecode — graphics cue, broll timing,
    or any production note that should be included in the final edit log."""

    elapsed: float         # seconds since logging started
    frame: int             # frames since logging started (at the session rate)
    timecode: str          # absolute SMPTE timecode of the note
    text: str              # the note itself (required)


@dataclass
class LogSession:
    rate_key: str = "25"
    drop_frame: bool = False
    start_timecode: str = "00:00:00:00"
    started_wall_clock: str = ""          # ISO-8601, informational only
    switcher_product: str = ""            # e.g. "ATEM Mini Extreme ISO"
    name: str = ""                        # user-supplied session name (e.g., "TVTL 01-08")
    mappings: dict[int, CameraMapping] = field(default_factory=dict)
    audio_file: str = ""                  # continuous program-audio recording
    duration: float = 0.0                 # elapsed seconds when Stop was pressed
    events: list[SwitchEvent] = field(default_factory=list)
    flags: list[ErrorFlag] = field(default_factory=list)
    notes: list[TimelineNote] = field(default_factory=list)

    # ------------------------------------------------------------------ setup

    @property
    def rate(self) -> FrameRate:
        return FRAME_RATES[self.rate_key]

    @property
    def start_frames(self) -> int:
        return parse_timecode(self.start_timecode, self.rate, self.drop_frame)

    def validate(self) -> None:
        if self.rate_key not in FRAME_RATES:
            raise TimecodeError(f"Unsupported frame rate '{self.rate_key}'.")
        # Raises with a clear message if TC or DF flag is invalid:
        self.start_frames

    def camera_label(self, input_id: int) -> str:
        mapping = self.mappings.get(input_id)
        return mapping.label() if mapping else f"Input {input_id}"

    def export_basename(self) -> str:
        """Return a safe filename base for exports (no extension).

        Uses session name if set; otherwise generates from start timecode.
        """
        if self.name:
            # Slugify: lowercase, alphanumeric + dash/underscore only
            slug = "".join(c if c.isalnum() or c in "-_" else "-"
                          for c in self.name.lower())
            # Collapse multiple dashes
            while "--" in slug:
                slug = slug.replace("--", "-")
            return slug.strip("-_")
        # Fallback: use start timecode with dashes instead of colons
        return self.start_timecode.replace(":", "-")

    # ---------------------------------------------------------------- logging

    def begin(self) -> None:
        self.validate()
        self.events.clear()
        self.flags.clear()
        self.notes.clear()
        self.duration = 0.0
        self.started_wall_clock = datetime.now(timezone.utc).astimezone().isoformat(
            timespec="seconds"
        )

    def add_program_change(
        self,
        input_id: int,
        elapsed: float,
        transition: str = CUT,
        transition_frames: int = 0,
    ) -> SwitchEvent | None:
        """Record a Program change; returns None if it is a duplicate.

        Duplicates happen when the SDK re-notifies without a real source change
        (state sync) or the operator cuts to the input already on air.
        """
        if self.events and self.events[-1].input_id == input_id:
            return None

        frame, tc = event_timecode(
            self.start_frames, elapsed, self.rate, self.drop_frame
        )

        if self.events and self.events[-1].frame == frame:
            # Two changes inside one frame: the later source wins the frame.
            prior = self.events.pop()
            if self.events and self.events[-1].input_id == input_id:
                # ...and if that makes it a no-op cut, drop the frame entirely.
                return None
            del prior

        event = SwitchEvent(
            elapsed=elapsed,
            frame=frame,
            timecode=tc,
            input_id=input_id,
            camera=self.camera_label(input_id),
            transition=transition or CUT,
            transition_frames=max(0, int(transition_frames)),
        )
        self.events.append(event)
        return event

    def end(self, elapsed: float) -> None:
        self.duration = max(
            elapsed, self.events[-1].elapsed if self.events else 0.0
        )

    def add_error_flag(self, elapsed: float, note: str = "") -> ErrorFlag:
        """Mark ``elapsed`` seconds since logging started as a problem moment.

        Deliberately dumb and fast: no validation beyond what timecode math
        needs, so it never blocks the operator from marking a spot live.
        """
        frame, tc = event_timecode(
            self.start_frames, elapsed, self.rate, self.drop_frame
        )
        flag = ErrorFlag(elapsed=elapsed, frame=frame, timecode=tc, note=note.strip())
        self.flags.append(flag)
        return flag

    def add_note(self, elapsed: float, text: str) -> TimelineNote:
        """Log an editorial note at a specific timecode — graphics cue, broll
        timing, or production notes for later editorial review. Fast and
        validation-free, like add_error_flag."""
        frame, tc = event_timecode(
            self.start_frames, elapsed, self.rate, self.drop_frame
        )
        note = TimelineNote(elapsed=elapsed, frame=frame, timecode=tc, text=text.strip())
        self.notes.append(note)
        return note

    def remove_flag(self, index: int) -> None:
        """Undo a misclick. Raises IndexError for an out-of-range index."""
        del self.flags[index]

    def set_flag_note(self, index: int, note: str) -> None:
        """Add or edit a flag's note after the fact — the button itself never
        requires typing anything live."""
        self.flags[index].note = note.strip()

    def resync_event_timecodes(self) -> None:
        """Recompute every event's, flag's, and note's absolute timecode string
        from the current start_timecode/rate/drop_frame.

        Each element's ``frame`` (position relative to when logging started)
        never changes once recorded. Its absolute ``timecode`` label is
        derived from that plus ``start_frames`` and is only ever stored as
        a convenience — exports always recompute positions from
        ``start_frames + frame`` live. Call this after correcting a wrong
        Start Timecode post-hoc.
        """
        start = self.start_frames
        for event in self.events:
            event.timecode = frames_to_timecode(
                start + event.frame, self.rate, self.drop_frame
            )
        for flag in self.flags:
            flag.timecode = frames_to_timecode(
                start + flag.frame, self.rate, self.drop_frame
            )
        for note in self.notes:
            note.timecode = frames_to_timecode(
                start + note.frame, self.rate, self.drop_frame
            )

    @property
    def duration_frames(self) -> int:
        frames = seconds_to_frames(self.duration, self.rate)
        if self.events:
            # Never let the timeline end before (or at) the last cut.
            frames = max(frames, self.events[-1].frame + 1)
        return frames

    @property
    def end_timecode(self) -> str:
        return frames_to_timecode(
            self.start_frames + self.duration_frames, self.rate, self.drop_frame
        )

    # ------------------------------------------------------------ persistence

    def to_json(self) -> str:
        payload = {
            "schema": SCHEMA_VERSION,
            "app": "ATEM Cut Logger",
            "frame_rate": self.rate_key,
            "drop_frame": self.drop_frame,
            "start_timecode": self.start_timecode,
            "started_wall_clock": self.started_wall_clock,
            "switcher_product": self.switcher_product,
            "session_name": self.name,
            "duration_seconds": self.duration,
            "audio_file": self.audio_file,
            "inputs": [
                {"input": m.input_id, "name": m.name, "file": m.file}
                for m in sorted(self.mappings.values(), key=lambda m: m.input_id)
            ],
            "events": [
                {
                    "elapsed": round(e.elapsed, 6),
                    "frame": e.frame,
                    "timecode": e.timecode,
                    "input": e.input_id,
                    "camera": e.camera,
                    "transition": e.transition,
                    "transition_frames": e.transition_frames,
                }
                for e in self.events
            ],
            "flags": [
                {
                    "elapsed": round(f.elapsed, 6),
                    "frame": f.frame,
                    "timecode": f.timecode,
                    "note": f.note,
                }
                for f in self.flags
            ],
            "notes": [
                {
                    "elapsed": round(n.elapsed, 6),
                    "frame": n.frame,
                    "timecode": n.timecode,
                    "text": n.text,
                }
                for n in self.notes
            ],
        }
        return json.dumps(payload, indent=2)

    @classmethod
    def from_json(cls, text: str) -> "LogSession":
        data = json.loads(text)
        if data.get("schema") not in SUPPORTED_SCHEMAS:
            raise ValueError(
                f"Unsupported log schema {data.get('schema')!r}; "
                f"expected one of {', '.join(str(v) for v in SUPPORTED_SCHEMAS)}."
            )
        session = cls(
            rate_key=data["frame_rate"],
            drop_frame=bool(data["drop_frame"]),
            start_timecode=data["start_timecode"],
            started_wall_clock=data.get("started_wall_clock", ""),
            switcher_product=data.get("switcher_product", ""),
            name=data.get("session_name", ""),
            audio_file=data.get("audio_file", ""),
            duration=float(data.get("duration_seconds", 0.0)),
        )
        for item in data.get("inputs", []):
            mapping = CameraMapping(
                input_id=int(item["input"]),
                name=item.get("name", ""),
                file=item.get("file", ""),
            )
            session.mappings[mapping.input_id] = mapping
        for item in data.get("events", []):
            session.events.append(
                SwitchEvent(
                    elapsed=float(item["elapsed"]),
                    frame=int(item["frame"]),
                    timecode=item["timecode"],
                    input_id=int(item["input"]),
                    camera=item.get("camera", ""),
                    # Schema 1 logs predate transitions: every event is a cut.
                    transition=item.get("transition", CUT),
                    transition_frames=int(item.get("transition_frames", 0)),
                )
            )
        # "flags" is new; absent in logs saved before this feature existed —
        # .get(..., []) keeps those older files loading exactly as before.
        for item in data.get("flags", []):
            session.flags.append(
                ErrorFlag(
                    elapsed=float(item["elapsed"]),
                    frame=int(item["frame"]),
                    timecode=item["timecode"],
                    note=item.get("note", ""),
                )
            )
        # "notes" is new; same backward-compatibility approach.
        for item in data.get("notes", []):
            session.notes.append(
                TimelineNote(
                    elapsed=float(item["elapsed"]),
                    frame=int(item["frame"]),
                    timecode=item["timecode"],
                    text=item.get("text", ""),
                )
            )
        session.validate()
        return session

    def to_csv(self) -> str:
        buf = io.StringIO()
        writer = csv.writer(buf, lineterminator="\n")
        writer.writerow(
            ["event", "elapsed_seconds", "timecode", "atem_input", "camera",
             "iso_file", "transition", "transition_frames"]
        )
        for i, e in enumerate(self.events, start=1):
            mapping = self.mappings.get(e.input_id)
            writer.writerow(
                [
                    i,
                    f"{e.elapsed:.3f}",
                    e.timecode,
                    e.input_id,
                    e.camera,
                    mapping.file if mapping else "",
                    e.transition,
                    e.transition_frames,
                ]
            )
        return buf.getvalue()
