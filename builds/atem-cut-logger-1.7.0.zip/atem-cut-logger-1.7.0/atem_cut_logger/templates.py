"""Session templates — the setup for a recurring show, saved once and reloaded.

A template is everything you'd otherwise retype before each show: frame rate,
drop-frame, resolution, ISO sync mode, the audio file path and the whole camera
mapping. It deliberately does **not** carry the start timecode or the session
name, because those are per-show and copying them across would silently produce
a log stamped with yesterday's timecode.

Templates are plain JSON files under ``~/.atem_cut_logger/templates`` so they
can be copied between machines with Finder.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

TEMPLATE_SUFFIX = ".template.json"
MAX_NAME_LENGTH = 60


class TemplateError(Exception):
    """A user-facing template problem (bad name, missing file, unreadable JSON)."""


def default_template_dir() -> Path:
    return Path.home() / ".atem_cut_logger" / "templates"


def slugify(name: str) -> str:
    """Filename-safe form of a template name; also the on-disk identity."""
    slug = re.sub(r"[^a-z0-9]+", "-", name.strip().lower()).strip("-")
    return slug[:MAX_NAME_LENGTH]


class TemplateStore:
    """File-backed template collection. Every method is safe to call on a
    machine where the directory doesn't exist yet."""

    def __init__(self, directory: Path | None = None) -> None:
        self.dir = Path(directory) if directory else default_template_dir()

    # ------------------------------------------------------------------ paths

    def _path(self, name: str) -> Path:
        slug = slugify(name)
        if not slug:
            raise TemplateError("Give the template a name.")
        return self.dir / f"{slug}{TEMPLATE_SUFFIX}"

    # ------------------------------------------------------------------- read

    def list(self) -> list[dict]:
        """All templates, newest-modified first, as ``{name, slug, cameras}``."""
        if not self.dir.is_dir():
            return []
        found = []
        for path in self.dir.glob(f"*{TEMPLATE_SUFFIX}"):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue  # a corrupt file must not break the list
            found.append({
                "name": data.get("name") or path.name[: -len(TEMPLATE_SUFFIX)],
                "slug": path.name[: -len(TEMPLATE_SUFFIX)],
                "rate_key": data.get("rate_key", ""),
                "cameras": len(data.get("mappings") or []),
                "modified": path.stat().st_mtime,
            })
        return sorted(found, key=lambda t: t["modified"], reverse=True)

    def load(self, name: str) -> dict:
        path = self._path(name)
        if not path.is_file():
            raise TemplateError(f"No template named {name!r}.")
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise TemplateError(f"Could not read that template: {exc}") from exc
        if not isinstance(data, dict):
            raise TemplateError("That template file isn't a template.")
        return data

    # ------------------------------------------------------------------ write

    def save(self, name: str, payload: dict) -> dict:
        name = name.strip()
        if not name:
            raise TemplateError("Give the template a name.")
        path = self._path(name)
        data = {**payload, "name": name[:MAX_NAME_LENGTH]}
        try:
            self.dir.mkdir(parents=True, exist_ok=True)
            tmp = path.with_suffix(".tmp")
            tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
            tmp.replace(path)  # atomic: never leave a half-written template
        except OSError as exc:
            raise TemplateError(f"Could not save the template: {exc}") from exc
        return data

    def delete(self, name: str) -> None:
        path = self._path(name)
        try:
            path.unlink()
        except FileNotFoundError:
            raise TemplateError(f"No template named {name!r}.") from None
        except OSError as exc:
            raise TemplateError(f"Could not delete the template: {exc}") from exc
