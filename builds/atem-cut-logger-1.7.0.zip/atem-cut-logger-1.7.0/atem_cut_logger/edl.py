"""CMX3600 EDL export — the interchange format every edit system still reads.

FCPXML carries more (ISO file paths, markers, flags), but an editor on Avid,
Premiere or an older Resolve version will take an EDL from anyone. This writes
the plain, widely-accepted subset:

    TITLE:   TVTL 01-08
    FCM: NON-DROP FRAME

    001  CAM1     V     C        01:00:00:00 01:00:04:10 01:00:00:00 01:00:04:10
    * FROM CLIP NAME: CAM 1 Wide

One event per shot, source timecode equal to record timecode because every ISO
ran with the same house clock the switcher was stamping — which is the whole
reason the logger reads the switcher's own generator.

A logged AUTO transition becomes a real dissolve: the outgoing reel gets a
zero-length ``C`` event at the blend's start and the incoming reel a ``D`` with
the blend's length in frames, which is how CMX3600 has always spelled it. Hard
cuts stay a single ``C``.

Drop-frame is honoured: the ``FCM`` line switches, and drop-frame timecodes use
semicolon separators as the format requires.
"""

from __future__ import annotations

from .session import LogSession
from .timecode import frames_to_timecode

# Reel names are the one genuinely fussy part of CMX3600: 8 characters, no
# spaces. Everything else about a shot travels in the FROM CLIP NAME comment.
REEL_LENGTH = 8


def reel_name(session: LogSession, input_id: int) -> str:
    """An 8-character reel id derived from the camera name, e.g. ``CAM1WIDE``."""
    label = session.camera_label(input_id)
    cleaned = "".join(c for c in label.upper() if c.isalnum())
    if not cleaned:
        cleaned = f"INPUT{input_id}"
    return cleaned[:REEL_LENGTH] or f"IN{input_id}"


def _tc(frames: int, session: LogSession) -> str:
    """Absolute timecode, in the separator style the EDL format expects."""
    text = frames_to_timecode(frames, session.rate, session.drop_frame)
    # frames_to_timecode already uses ';' for drop-frame, which is what CMX
    # wants; this keeps the intent explicit if that ever changes.
    return text


def export_edl(session: LogSession, title: str = "") -> str:
    """Render the switch log as a CMX3600 EDL.

    Notes and error flags become comment lines at their own event, so an editor
    reading the EDL sees them in place instead of losing them.
    """
    if not session.events:
        raise ValueError("No events to export.")

    start = session.start_frames
    total = session.duration_frames
    lines: list[str] = []
    lines.append(f"TITLE:   {(title or session.name or 'ATEM CUT LOG')[:70]}")
    lines.append("FCM: DROP FRAME" if session.drop_frame else "FCM: NON-DROP FRAME")
    lines.append("")

    events = session.events
    for i, event in enumerate(events):
        end_frame = events[i + 1].frame if i + 1 < len(events) else total
        if end_frame <= event.frame:
            continue  # zero-length shot: nothing an editor could use

        # A dissolve starts before the frame the switcher reported: that frame
        # is where the blend *finished*.
        blend = event.transition_frames if event.is_transition else 0
        cut_frame = event.transition_start_frame if blend else event.frame
        record_in = _tc(start + cut_frame, session)
        record_out = _tc(start + end_frame, session)
        reel = reel_name(session, event.input_id)

        if blend and i > 0:
            outgoing = reel_name(session, events[i - 1].input_id)
            # The outgoing reel holds for zero frames at the blend's start...
            lines.append(
                f"{i + 1:03d}  {outgoing:<8} V     C        "
                f"{record_in} {record_in} {record_in} {record_in}"
            )
            # ...and the incoming reel dissolves in over `blend` frames.
            lines.append(
                f"{i + 1:03d}  {reel:<8} V     D    {blend:03d} "
                f"{record_in} {record_out} {record_in} {record_out}"
            )
            lines.append(f"* EFFECT NAME: CROSS DISSOLVE ({event.transition})")
        else:
            lines.append(
                f"{i + 1:03d}  {reel:<8} V     C        "
                f"{record_in} {record_out} {record_in} {record_out}"
            )
        lines.append(f"* FROM CLIP NAME: {event.camera}")
        mapping = session.mappings.get(event.input_id)
        if mapping and mapping.file:
            lines.append(f"* SOURCE FILE: {mapping.file}")

    for flag in session.flags:
        note = flag.note or "flagged during recording"
        lines.append(f"* ERROR FLAG AT {_tc(start + flag.frame, session)}: {note}")
    for note in session.notes:
        lines.append(f"* NOTE AT {_tc(start + note.frame, session)}: {note.text}")

    return "\n".join(lines) + "\n"
