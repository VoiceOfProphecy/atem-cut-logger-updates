"""Command line interface.

``python -m atem_cut_logger``                 launch the desktop GUI
``python -m atem_cut_logger log --simulate``  headless logging (prototype/CI)
``python -m atem_cut_logger export ...``      regenerate exports from a saved log
"""

from __future__ import annotations

import argparse
import queue
import sys
import time
from pathlib import Path

from . import APP_NAME, __version__
from .backends import create_backend
from .session import CameraMapping, LogSession
from .timecode import FRAME_RATES


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="atem_cut_logger", description=APP_NAME)
    parser.add_argument("--version", action="version", version=f"{APP_NAME} {__version__}")
    sub = parser.add_subparsers(dest="command")

    log = sub.add_parser("log", help="Log Program changes headlessly (no GUI).")
    src = log.add_mutually_exclusive_group(required=True)
    src.add_argument("--ip", help="ATEM switcher IP address")
    src.add_argument("--simulate", action="store_true", help="Test mode (no ATEM needed)")
    log.add_argument("--rate", choices=sorted(FRAME_RATES), default="25")
    log.add_argument("--drop-frame", action="store_true",
                     help="Use drop-frame timecode (29.97 only)")
    log.add_argument("--start-tc", default="00:00:00:00", metavar="HH:MM:SS:FF")
    log.add_argument("--duration", type=float, default=30.0,
                     help="Seconds to log before stopping (default 30)")
    log.add_argument("--out", type=Path, default=Path("session.atemlog.json"),
                     help="Session log JSON (the source of truth)")
    log.add_argument("--csv", type=Path, help="Also write a CSV log here")

    export = sub.add_parser("export", help="Regenerate exports from a saved session log.")
    export.add_argument("session", type=Path, help="A .atemlog.json file")
    export.add_argument("--csv", type=Path, help="Write CSV log")
    export.add_argument("--fcpxml", type=Path, help="Write Resolve-compatible FCPXML timeline")
    export.add_argument("--width", type=int, default=1920)
    export.add_argument("--height", type=int, default=1080)
    export.add_argument("--tc-synced-isos", action="store_true",
                        help="ISO files carry production timecode (default: ISOs "
                             "started recording exactly when logging started)")

    analyze = sub.add_parser(
        "analyze",
        help="Smart Cleanup: analyse a saved log for likely editing problems.",
    )
    analyze.add_argument("session", type=Path, help="A .atemlog.json file")
    analyze.add_argument("--report", type=Path,
                         help="Write a human-readable report (.txt or .csv by extension)")
    analyze.add_argument("--markers", type=Path,
                         help="Write a Resolve FCPXML timeline with markers at each issue")
    analyze.add_argument("--clean", type=Path,
                         help="Write a cleaned FCPXML with accidental cuts removed "
                              "(never touches the original log or XML)")
    analyze.add_argument("--config", type=Path, help="Rules config JSON")
    analyze.add_argument("--min-shot", type=float, help="Minimum shot seconds")
    analyze.add_argument("--max-shot", type=float, help="Maximum shot seconds")
    analyze.add_argument("--accidental", type=float,
                         help="Accidental-cut threshold seconds")
    analyze.add_argument("--back-forth", type=float,
                         help="Rapid back-and-forth window seconds")
    analyze.add_argument("--repeat-window", type=float, help="Repeat window seconds")
    analyze.add_argument("--repeat-count", type=int, help="Repeat count threshold")
    analyze.add_argument("--wide-camera", type=int,
                         help="ATEM input number of the designated wide camera")
    analyze.add_argument("--width", type=int, default=1920)
    analyze.add_argument("--height", type=int, default=1080)
    analyze.add_argument("--tc-synced-isos", action="store_true")
    return parser


class _QueueListener:
    """Forwards backend events into a queue the main thread drains."""

    def __init__(self) -> None:
        self.q: queue.Queue = queue.Queue()

    def on_connected(self, product_name, inputs, program):
        self.q.put(("connected", product_name, inputs, program))

    def on_program_changed(self, input_id, monotonic_time):
        self.q.put(("program", input_id, monotonic_time))

    def on_disconnected(self, reason):
        self.q.put(("disconnected", reason))

    def on_error(self, message):
        self.q.put(("error", message))


def _cmd_log(args: argparse.Namespace) -> int:
    session = LogSession(
        rate_key=args.rate, drop_frame=args.drop_frame, start_timecode=args.start_tc
    )
    session.validate()

    listener = _QueueListener()
    backend = create_backend("simulator" if args.simulate else "atem", listener)
    backend.connect(args.ip or "")

    print(f"{APP_NAME} — waiting for switcher...", flush=True)
    start_mono: float | None = None
    deadline: float | None = None
    try:
        while True:
            timeout = None if deadline is None else max(0.05, deadline - time.monotonic())
            try:
                msg = listener.q.get(timeout=timeout)
            except queue.Empty:
                break
            kind = msg[0]
            if kind == "connected":
                _, product, inputs, program = msg
                session.switcher_product = product
                for input_id, name in inputs.items():
                    session.mappings[input_id] = CameraMapping(input_id, name)
                session.begin()
                start_mono = time.monotonic()
                deadline = start_mono + args.duration
                session.add_program_change(program, 0.0)
                print(f"Connected to {product}. Program is input {program}. "
                      f"Logging for {args.duration:g}s...")
            elif kind == "program" and start_mono is not None:
                _, input_id, t = msg
                event = session.add_program_change(input_id, t - start_mono)
                if event:
                    print(f"  {event.timecode}  ->  input {event.input_id} ({event.camera})")
            elif kind == "disconnected":
                print(f"Disconnected: {msg[1]}")
                break
            elif kind == "error":
                print(f"Error: {msg[1]}", file=sys.stderr)
                return 1
            if deadline is not None and time.monotonic() >= deadline:
                break
    except KeyboardInterrupt:
        print("\nStopped by user.")
    finally:
        if start_mono is not None:
            session.end(time.monotonic() - start_mono)
        backend.disconnect()

    if start_mono is None:
        print("Never connected; nothing logged.", file=sys.stderr)
        return 1

    args.out.write_text(session.to_json(), encoding="utf-8")
    print(f"Saved session log: {args.out}  ({len(session.events)} events)")
    if args.csv:
        args.csv.write_text(session.to_csv(), encoding="utf-8")
        print(f"Saved CSV log:     {args.csv}")
    return 0


def _cmd_export(args: argparse.Namespace) -> int:
    session = LogSession.from_json(args.session.read_text(encoding="utf-8"))
    if not args.csv and not args.fcpxml:
        print("Nothing to do: pass --csv and/or --fcpxml.", file=sys.stderr)
        return 2
    if args.csv:
        args.csv.write_text(session.to_csv(), encoding="utf-8")
        print(f"Saved CSV log: {args.csv}")
    if args.fcpxml:
        from .fcpxml import export_fcpxml

        xml = export_fcpxml(
            session,
            width=args.width,
            height=args.height,
            tc_synced_isos=args.tc_synced_isos,
            project_name=args.session.stem.replace(".atemlog", ""),
        )
        args.fcpxml.write_text(xml, encoding="utf-8")
        print(f"Saved FCPXML timeline: {args.fcpxml}")
    return 0


def _cmd_analyze(args: argparse.Namespace) -> int:
    from .analysis import CleanupConfig, analyze
    from .analysis.cleaned import export_cleaned_fcpxml
    from .analysis.markers import export_markers_fcpxml
    from .analysis.report import render_csv, render_text

    session = LogSession.from_json(args.session.read_text(encoding="utf-8"))

    if args.config:
        config = CleanupConfig.from_json(args.config.read_text(encoding="utf-8"))
    else:
        config = CleanupConfig()
    # Individual flags override the config file / defaults.
    overrides = {
        "min_shot_seconds": args.min_shot,
        "max_shot_seconds": args.max_shot,
        "accidental_cut_seconds": args.accidental,
        "back_forth_seconds": args.back_forth,
        "repeat_window_seconds": args.repeat_window,
        "repeat_count": args.repeat_count,
        "wide_camera_input": args.wide_camera,
    }
    for key, value in overrides.items():
        if value is not None:
            setattr(config, key, value)
    config.validate()

    result = analyze(session, config)
    stem = args.session.stem.replace(".atemlog", "")

    wrote_anything = False
    if args.report:
        text = (
            render_csv(result)
            if args.report.suffix.lower() == ".csv"
            else render_text(result)
        )
        args.report.write_text(text, encoding="utf-8")
        print(f"Saved report: {args.report}")
        wrote_anything = True
    if args.markers:
        xml = export_markers_fcpxml(
            result, width=args.width, height=args.height,
            tc_synced_isos=args.tc_synced_isos,
            project_name=f"{stem} — Markers",
        )
        args.markers.write_text(xml, encoding="utf-8")
        print(f"Saved markers timeline: {args.markers}")
        wrote_anything = True
    if args.clean:
        xml, clean = export_cleaned_fcpxml(
            result, width=args.width, height=args.height,
            tc_synced_isos=args.tc_synced_isos,
            project_name=f"{stem} — Cleaned",
        )
        args.clean.write_text(xml, encoding="utf-8")
        print(f"Saved cleaned timeline: {args.clean} "
              f"({clean.removed_count} accidental cut(s) removed, "
              f"{clean.merged_count} redundant cut(s) collapsed)")
        wrote_anything = True

    if not wrote_anything:
        # Default action: print the report to stdout.
        print(render_text(result))
    else:
        print(f"Analysis complete: {len(result.issues)} issue(s) found.")
    return 0


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    if args.command == "log":
        return _cmd_log(args)
    if args.command == "export":
        return _cmd_export(args)
    if args.command == "analyze":
        return _cmd_analyze(args)
    # No subcommand: launch the GUI.
    from .gui.app import run_gui

    return run_gui()


if __name__ == "__main__":
    raise SystemExit(main())
