"""HyperDeck (and compatible) recorder control over the Blackmagic TCP protocol.

Blackmagic's recorders speak a plain line protocol on port 9993 — the same one
ATEM Software Control uses — so this needs no SDK and no extra dependency:

    <- 500 connection info:
    <- protocol version: 1.11
    <- (blank line ends the block)
    -> record\\r\\n
    <- 200 ok

Used for two things:

* start/stop every recorder from the web UI, so the operator doesn't walk the
  rack before a show;
* notice when a deck *starts recording on its own* and begin logging in step
  with it, which is the case that actually keeps the log's timecode honest.

Every deck is independent: one unreachable recorder reports its own error and
never blocks the others, because a show doesn't stop for a dead deck.
"""

from __future__ import annotations

import socket
import threading
import time
from dataclasses import dataclass

HYPERDECK_PORT = 9993
CONNECT_TIMEOUT = 4.0
COMMAND_TIMEOUT = 6.0
# Blackmagic response codes this module cares about.
OK_CODES = {200, 201, 208, 500}


class RecorderError(Exception):
    """A user-facing recorder problem (unreachable deck, refused command)."""


@dataclass
class RecorderConfig:
    """One configured deck. ``name`` is the operator's label, not the device's."""

    name: str
    host: str
    port: int = HYPERDECK_PORT

    def to_dict(self) -> dict:
        return {"name": self.name, "host": self.host, "port": self.port}

    @classmethod
    def from_dict(cls, data: dict) -> "RecorderConfig":
        host = str(data.get("host", "")).strip()
        if not host:
            raise RecorderError("A recorder needs an IP address.")
        try:
            port = int(data.get("port") or HYPERDECK_PORT)
        except (TypeError, ValueError):
            raise RecorderError("Recorder port must be a number.") from None
        if not (1 <= port <= 65535):
            raise RecorderError("Recorder port must be between 1 and 65535.")
        return cls(name=str(data.get("name", "")).strip() or host,
                   host=host, port=port)


@dataclass
class RecorderStatus:
    """What the UI shows for one deck."""

    name: str
    host: str
    reachable: bool = False
    recording: bool = False
    status: str = ""          # the deck's own transport status word
    timecode: str = ""
    clip: str = ""
    error: str = ""

    def to_dict(self) -> dict:
        return {
            "name": self.name, "host": self.host, "reachable": self.reachable,
            "recording": self.recording, "status": self.status,
            "timecode": self.timecode, "clip": self.clip, "error": self.error,
        }


class HyperDeck:
    """A short-lived connection to one deck. Not kept open between commands:
    a recorder that goes away mid-show must not leave the app holding a dead
    socket, and the protocol is cheap to reconnect."""

    def __init__(self, config: RecorderConfig, timeout: float = COMMAND_TIMEOUT):
        self.config = config
        self.timeout = timeout

    # ------------------------------------------------------------- protocol

    def _read_block(self, sock: socket.socket, buffer: bytearray) -> tuple[int, list[str]]:
        """Read one response block: a status line, optionally followed by
        indented lines ended by a blank line."""
        while b"\r\n" not in buffer:
            chunk = sock.recv(4096)
            if not chunk:
                raise RecorderError("The recorder closed the connection.")
            buffer += chunk
        line, _, rest = bytes(buffer).partition(b"\r\n")
        buffer[:] = rest
        header = line.decode("utf-8", "replace").strip()
        code = int(header.split()[0]) if header[:1].isdigit() else 0
        lines: list[str] = []
        if header.endswith(":"):
            while True:
                while b"\r\n" not in buffer:
                    chunk = sock.recv(4096)
                    if not chunk:
                        return code, lines
                    buffer += chunk
                line, _, rest = bytes(buffer).partition(b"\r\n")
                buffer[:] = rest
                text = line.decode("utf-8", "replace").strip()
                if not text:
                    break
                lines.append(text)
        return code, lines

    def command(self, *commands: str) -> list[tuple[int, list[str]]]:
        """Connect, send commands in order, return each response block."""
        results: list[tuple[int, list[str]]] = []
        try:
            with socket.create_connection(
                (self.config.host, self.config.port), timeout=CONNECT_TIMEOUT
            ) as sock:
                sock.settimeout(self.timeout)
                buffer = bytearray()
                self._read_block(sock, buffer)  # the connection banner
                for command in commands:
                    sock.sendall((command + "\r\n").encode("utf-8"))
                    code, lines = self._read_block(sock, buffer)
                    if code not in OK_CODES:
                        detail = lines[0] if lines else f"code {code}"
                        raise RecorderError(
                            f"{self.config.name} refused '{command}': {detail}"
                        )
                    results.append((code, lines))
        except RecorderError:
            raise
        except (OSError, ValueError) as exc:
            raise RecorderError(f"{self.config.name} ({self.config.host}): {exc}") from exc
        return results

    # -------------------------------------------------------------- actions

    @staticmethod
    def _fields(lines: list[str]) -> dict[str, str]:
        out = {}
        for line in lines:
            key, _, value = line.partition(":")
            out[key.strip().lower()] = value.strip()
        return out

    def transport(self) -> dict[str, str]:
        (_code, lines), = self.command("transport info")
        return self._fields(lines)

    def start_recording(self, clip_name: str = "") -> None:
        self.command(f"record: name: {clip_name}" if clip_name else "record")

    def stop_recording(self) -> None:
        self.command("stop")

    def status(self) -> RecorderStatus:
        state = RecorderStatus(name=self.config.name, host=self.config.host)
        try:
            fields = self.transport()
        except RecorderError as exc:
            state.error = str(exc)
            return state
        state.reachable = True
        state.status = fields.get("status", "")
        state.recording = state.status.lower() == "record"
        state.timecode = fields.get("timecode", "")
        state.clip = fields.get("clip id", "") or fields.get("clip", "")
        return state


class RecorderPool:
    """The configured decks, driven together.

    Each deck is contacted on its own thread so one slow or dead recorder
    can't hold up the rest — the UI gets a full picture in roughly the time
    the slowest *reachable* deck takes.
    """

    def __init__(self, configs: list[RecorderConfig] | None = None,
                 factory=HyperDeck) -> None:
        self._lock = threading.RLock()
        self._configs: list[RecorderConfig] = list(configs or [])
        self._factory = factory

    # ------------------------------------------------------------- config

    @property
    def configs(self) -> list[RecorderConfig]:
        with self._lock:
            return list(self._configs)

    def set_configs(self, data: list[dict]) -> list[RecorderConfig]:
        configs = [RecorderConfig.from_dict(item) for item in data]
        seen: set[tuple[str, int]] = set()
        for config in configs:
            key = (config.host, config.port)
            if key in seen:
                raise RecorderError(f"{config.host} is listed twice.")
            seen.add(key)
        with self._lock:
            self._configs = configs
        return configs

    def to_payload(self) -> list[dict]:
        return [c.to_dict() for c in self.configs]

    # ------------------------------------------------------------ commands

    def _fan_out(self, action) -> list[RecorderStatus]:
        configs = self.configs
        results: list[RecorderStatus | None] = [None] * len(configs)

        def run(index: int, config: RecorderConfig) -> None:
            deck = self._factory(config)
            try:
                results[index] = action(deck, config)
            except RecorderError as exc:
                results[index] = RecorderStatus(name=config.name, host=config.host,
                                                error=str(exc))

        threads = [
            threading.Thread(target=run, args=(i, c), daemon=True)
            for i, c in enumerate(configs)
        ]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(timeout=COMMAND_TIMEOUT + CONNECT_TIMEOUT + 1)
        return [
            r if r is not None
            else RecorderStatus(name=c.name, host=c.host, error="Timed out.")
            for r, c in zip(results, configs)
        ]

    def status_all(self) -> list[RecorderStatus]:
        return self._fan_out(lambda deck, _c: deck.status())

    def record_all(self, clip_name: str = "") -> list[RecorderStatus]:
        def action(deck, _config):
            deck.start_recording(clip_name)
            return deck.status()
        return self._fan_out(action)

    def stop_all(self) -> list[RecorderStatus]:
        def action(deck, _config):
            deck.stop_recording()
            return deck.status()
        return self._fan_out(action)

    def any_recording(self) -> bool:
        return any(s.recording for s in self.status_all())


class RecorderWatcher:
    """Polls the decks so logging can start when recording does.

    Deliberately a poll rather than the protocol's ``notify`` push: a persistent
    connection per deck would have to be babysat across network blips for the
    whole show, and a few seconds of latency costs nothing here — the log's
    start timecode comes from the switcher's generator, not from when this
    noticed.
    """

    def __init__(self, pool: RecorderPool, on_recording_started,
                 interval: float = 5.0) -> None:
        self.pool = pool
        self.interval = interval
        self._on_started = on_recording_started
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._was_recording = False
        self.enabled = False
        self.last: list[RecorderStatus] = []

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()

        def run() -> None:
            while not self._stop.wait(self.interval):
                if not self.enabled or not self.pool.configs:
                    continue
                statuses = self.pool.status_all()
                self.last = statuses
                recording = any(s.recording for s in statuses)
                if recording and not self._was_recording:
                    try:
                        self._on_started()
                    except Exception:
                        pass  # a refusal (already logging) is not the watcher's problem
                self._was_recording = recording

        self._thread = threading.Thread(target=run, name="recorder-watch", daemon=True)
        self._thread.start()

    def poll_once(self) -> list[RecorderStatus]:
        """Used by tests and by the UI's manual refresh."""
        statuses = self.pool.status_all()
        self.last = statuses
        recording = any(s.recording for s in statuses)
        if recording and not self._was_recording and self.enabled:
            self._on_started()
        self._was_recording = recording
        return statuses

    def stop(self) -> None:
        self._stop.set()


def wait_until(predicate, timeout: float = 5.0, interval: float = 0.05) -> bool:
    """Small helper for callers that need to wait on deck state."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return True
        time.sleep(interval)
    return False
