"""Self-update over git — the "Check for updates" machinery behind the UI.

An install that came from ``git clone`` knows where it came from, so updating is
``git fetch`` + a fast-forward merge. That's all this module does, wrapped so the
web app can drive it: a background check on a timer, a manual check, and an
apply step that rebuilds the macOS bridge and re-execs the server.

Deliberate rules, in order of importance for a live show:

* **Never update while logging.** A restart mid-show would lose the session.
* **Never rewrite the operator's work.** The apply is fast-forward only; local
  edits or a diverged branch make it refuse and say so, rather than resolving
  anything by force.
* **Never hang.** Every git call has a timeout and runs with
  ``GIT_TERMINAL_PROMPT=0``, so a private remote without stored credentials
  fails fast instead of blocking on a password prompt.

Two channels, picked automatically:

* **git** — the install is a clone, so it fast-forwards from its own remote.
* **release** — anything else (a ZIP install) follows the public feed in
  :mod:`.release_channel`, which needs no GitHub login on the machine.
"""

from __future__ import annotations

import os
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Callable

from . import __version__
from .release_channel import DEFAULT_FEED_URL, ReleaseChannel, ReleaseError, is_newer

# Long enough for a slow network on a fetch, short enough that a wedged git
# never becomes a hung UI.
GIT_TIMEOUT = 60
DEFAULT_INTERVAL_HOURS = 6.0


def repo_root() -> Path:
    """The install directory (the package's parent), where .git would live."""
    return Path(__file__).resolve().parent.parent


class UpdateError(Exception):
    """Something the operator should read: not a clone, dirty tree, no network."""


class UpdateManager:
    """Owns update state and the timer thread. Thread-safe; cheap to construct."""

    def __init__(
        self,
        root: Path | None = None,
        interval_hours: float = DEFAULT_INTERVAL_HOURS,
        on_change: Callable[[], None] | None = None,
        is_busy: Callable[[], bool] | None = None,
        feed_url: str = DEFAULT_FEED_URL,
        release_channel: ReleaseChannel | None = None,
    ) -> None:
        self.root = Path(root) if root else repo_root()
        self.interval_hours = float(interval_hours)
        self._on_change = on_change
        # Returns True when an update must not be applied right now (logging).
        self._is_busy = is_busy or (lambda: False)

        # Used when the install isn't a clone: the public, login-free feed.
        self.releases = release_channel or ReleaseChannel(feed_url)

        self._lock = threading.RLock()
        self._manifest: dict | None = None
        self._checking = False
        self._applying = False
        self._available = False
        self._behind = 0
        self._available_version = ""
        self._summary: list[str] = []
        self._last_checked: float | None = None
        self._error = ""
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        # Set by the entry point so a restart can rebuild the same command.
        self.restart_argv: list[str] | None = None
        # status() is called on every UI snapshot, so the commit id is resolved
        # once and refreshed only when an update actually lands.
        self._commit_cache: str | None = None

    # ----------------------------------------------------------- git plumbing

    def _git(self, *args: str, timeout: int = GIT_TIMEOUT) -> str:
        env = dict(os.environ)
        env["GIT_TERMINAL_PROMPT"] = "0"  # fail instead of prompting for a login
        env.setdefault("GIT_ASKPASS", "true")
        try:
            proc = subprocess.run(
                ["git", *args], cwd=self.root, env=env, timeout=timeout,
                capture_output=True, text=True,
            )
        except FileNotFoundError:
            raise UpdateError("git is not installed on this machine.") from None
        except subprocess.TimeoutExpired:
            raise UpdateError("git timed out — check the network connection.") from None
        if proc.returncode != 0:
            detail = (proc.stderr or proc.stdout or "").strip().splitlines()
            raise UpdateError(detail[-1] if detail else f"git {args[0]} failed.")
        return proc.stdout.strip()

    def is_clone(self) -> bool:
        return (self.root / ".git").exists()

    @property
    def channel(self) -> str:
        """'git' for a clone, 'release' for a ZIP install following the feed."""
        return "git" if self.is_clone() else "release"

    def unsupported_reason(self) -> str:
        """Empty string when updates work here; otherwise why they don't.

        Both channels work unattended, so the only real blocker is an install
        directory this process can't write to.
        """
        if not os.access(self.root, os.W_OK):
            return (
                f"{self.root} isn't writable by this user, so updates can't be "
                "installed. Move the app into your Home folder (the installer "
                "does this) and try again."
            )
        return ""

    def _branch(self) -> str:
        name = self._git("rev-parse", "--abbrev-ref", "HEAD")
        return "main" if name == "HEAD" else name  # detached: compare with main

    def _commit(self) -> str:
        if self._commit_cache is None:
            try:
                self._commit_cache = self._git("rev-parse", "--short", "HEAD")
            except UpdateError:
                self._commit_cache = ""
        return self._commit_cache

    def _dirty(self) -> bool:
        return bool(self._git("status", "--porcelain"))

    # --------------------------------------------------------------- status

    def status(self) -> dict:
        with self._lock:
            return {
                "version": __version__,
                "commit": self._commit() if self.is_clone() else "",
                "supported": not self.unsupported_reason(),
                "reason": self.unsupported_reason(),
                "checking": self._checking,
                "applying": self._applying,
                "update_available": self._available,
                "commits_behind": self._behind,
                "channel": self.channel,
                "available_version": self._available_version,
                "summary": list(self._summary),
                "last_checked": self._last_checked,
                "error": self._error,
                "interval_hours": self.interval_hours,
            }

    def _changed(self) -> None:
        if self._on_change:
            try:
                self._on_change()
            except Exception:
                pass  # a UI broadcast must never break the update itself

    # ---------------------------------------------------------------- check

    def check(self) -> dict:
        """Look for a newer version on whichever channel applies."""
        reason = self.unsupported_reason()
        if reason:
            raise UpdateError(reason)
        with self._lock:
            if self._checking:
                return self.status()
            self._checking = True
            self._error = ""
        try:
            if self.channel == "git":
                self._check_git()
            else:
                self._check_release()
            with self._lock:
                self._last_checked = time.time()
        except UpdateError as exc:
            with self._lock:
                self._error = str(exc)
                self._last_checked = time.time()
            raise
        finally:
            with self._lock:
                self._checking = False
            self._changed()
        return self.status()

    def _check_git(self) -> None:
        branch = self._branch()
        self._git("fetch", "--quiet", "origin", branch)
        remote = f"origin/{branch}"
        behind = int(self._git("rev-list", "--count", f"HEAD..{remote}") or 0)
        summary: list[str] = []
        if behind:
            log = self._git("log", "--format=%s", f"HEAD..{remote}")
            summary = [line for line in log.splitlines() if line][:10]
        with self._lock:
            self._behind = behind
            self._available = behind > 0
            self._summary = summary
            self._available_version = ""

    def _check_release(self) -> None:
        try:
            manifest = self.releases.fetch_manifest()
        except ReleaseError as exc:
            raise UpdateError(str(exc)) from exc
        version = str(manifest["version"])
        newer = is_newer(version, __version__)
        with self._lock:
            self._manifest = manifest
            self._available = newer
            self._behind = 1 if newer else 0
            self._available_version = version if newer else ""
            notes = manifest.get("notes") or []
            self._summary = [str(n) for n in notes][:10] if newer else []

    # ---------------------------------------------------------------- apply

    def apply(self) -> dict:
        """Fast-forward to the fetched commits and rebuild the bridge.

        Returns ``{"updated": bool, "version": str, "bridge": str}``. The caller
        decides whether to restart afterwards.
        """
        reason = self.unsupported_reason()
        if reason:
            raise UpdateError(reason)
        if self._is_busy():
            raise UpdateError(
                "Not while logging — stop the session first, then update."
            )
        with self._lock:
            if self._applying:
                raise UpdateError("An update is already being installed.")
            self._applying = True
        try:
            updated = (self._apply_git() if self.channel == "git"
                       else self._apply_release())
            bridge = self._rebuild_bridge() if updated else "skipped"
            with self._lock:
                self._available = False
                self._behind = 0
                self._summary = []
                self._available_version = ""
                self._error = ""
            return {
                "updated": updated,
                "version": self._read_version(),
                "commit": self._commit() if self.is_clone() else "",
                "bridge": bridge,
                "channel": self.channel,
            }
        finally:
            with self._lock:
                self._applying = False
            self._changed()

    def _apply_git(self) -> bool:
        if self._dirty():
            raise UpdateError(
                "This copy has local changes, so it can't be fast-forwarded. "
                "Reinstall from a fresh download instead."
            )
        branch = self._branch()
        self._git("fetch", "--quiet", "origin", branch)
        before = self._commit()
        self._git("merge", "--ff-only", f"origin/{branch}")
        self._commit_cache = None  # HEAD moved
        return before != self._commit()

    def _apply_release(self) -> bool:
        with self._lock:
            manifest = self._manifest
        if manifest is None:
            self._check_release()
            with self._lock:
                manifest = self._manifest
        if manifest is None or not is_newer(str(manifest["version"]), __version__):
            return False
        try:
            self.releases.install(manifest, self.root)
        except ReleaseError as exc:
            raise UpdateError(str(exc)) from exc
        return True

    def _read_version(self) -> str:
        """Read the version off disk — the running process still has the old one."""
        init = self.root / "atem_cut_logger" / "__init__.py"
        try:
            for line in init.read_text(encoding="utf-8").splitlines():
                if line.startswith("__version__"):
                    return line.split("=", 1)[1].strip().strip('"\'')
        except OSError:
            pass
        return __version__

    def _rebuild_bridge(self) -> str:
        """Recompile the macOS bridge when its SDK files are present.

        Absent SDK means this machine never talked to a real switcher, so
        there's nothing to rebuild and that isn't an error.
        """
        bridge_dir = self.root / "bridge" / "mac"
        if not (bridge_dir / "BMDSwitcherAPI.h").is_file():
            return "skipped"
        try:
            proc = subprocess.run(
                ["make", "-C", str(bridge_dir)], capture_output=True,
                text=True, timeout=GIT_TIMEOUT,
            )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return "failed"
        return "rebuilt" if proc.returncode == 0 else "failed"

    # -------------------------------------------------------------- restart

    def restart(self, delay: float = 0.7) -> None:
        """Re-exec this process so the new code is actually running.

        Delayed on a thread so the HTTP response for the request that asked for
        the restart still reaches the browser.
        """
        argv = self.restart_argv or [sys.executable, "-m", "atem_cut_logger.web"]

        def run() -> None:
            time.sleep(delay)
            try:
                os.execv(argv[0], argv)
            except OSError:
                os._exit(1)  # the launcher window shows it stopped; better than a zombie

        threading.Thread(target=run, name="update-restart", daemon=True).start()

    # ----------------------------------------------------------- background

    def start_background(self, check_now_delay: float = 20.0) -> None:
        """Check on a timer: shortly after launch, then every interval_hours."""
        if self._thread or self.unsupported_reason():
            return
        self._stop.clear()

        def run() -> None:
            first = True
            while not self._stop.wait(
                check_now_delay if first else self.interval_hours * 3600
            ):
                first = False
                try:
                    self.check()
                except UpdateError:
                    pass  # already recorded in status; retried on the next tick

        self._thread = threading.Thread(target=run, name="update-check", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
