"""Updates over a public feed — the route that needs no GitHub login anywhere.

The private repo holds the work (issues, PRs, history); a small **public**
repository holds only what a running copy needs to update itself: a
``manifest.json`` naming the current version, and the matching build as a zip.
Every Mac can read those anonymously, so an install that came from a ZIP still
updates itself with nothing to log into. Same shape as the VOP Ingest feed,
minus Sparkle (this app isn't a Cocoa app, it's Python).

manifest.json::

    {
      "version": "1.4.0",
      "published": "2026-09-02T20:40:00Z",
      "notes": ["Session templates", "EDL export"],
      "zip": "builds/atem-cut-logger-1.4.0.zip",   # relative to the feed
      "sha256": "9f86d0…"
    }

The download is verified against that digest before anything is written into
the install, and the extracted tree has to look like this app (and declare the
version the manifest promised) before it replaces the running one.
"""

from __future__ import annotations

import hashlib
import json
import shutil
import tempfile
import urllib.error
import urllib.request
import zipfile
from pathlib import Path
from urllib.parse import urljoin

DEFAULT_FEED_URL = (
    "https://raw.githubusercontent.com/"
    "VoiceOfProphecy/atem-cut-logger-updates/main/manifest.json"
)
HTTP_TIMEOUT = 30
MAX_DOWNLOAD_BYTES = 64 * 1024 * 1024   # a source build is ~1 MB; this is abuse-proofing

# Files and directories inside the install that a published build must never
# overwrite: the licensed Blackmagic headers and the binary compiled from them.
PRESERVE = ("bridge/mac/BMDSwitcherAPI.h",
            "bridge/mac/BMDSwitcherAPIDispatch.cpp",
            "bridge/mac/atem-bridge")


class ReleaseError(Exception):
    """A user-facing feed problem: offline, malformed manifest, bad download."""


def parse_version(text: str) -> tuple[int, ...]:
    """``"1.10.2"`` -> ``(1, 10, 2)``. Unparseable parts sort as 0."""
    parts = []
    for chunk in str(text).strip().split("."):
        digits = "".join(c for c in chunk if c.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts or (0,))


def is_newer(candidate: str, current: str) -> bool:
    return parse_version(candidate) > parse_version(current)


class ReleaseChannel:
    """Reads the public feed and installs what it points at."""

    def __init__(self, feed_url: str = DEFAULT_FEED_URL) -> None:
        self.feed_url = feed_url

    # ------------------------------------------------------------------ read

    def _get(self, url: str, limit: int = MAX_DOWNLOAD_BYTES) -> bytes:
        # Cache-busting matters: raw.githubusercontent caches aggressively and a
        # stale manifest would hide a release for minutes.
        request = urllib.request.Request(
            url, headers={"Cache-Control": "no-cache", "Pragma": "no-cache"}
        )
        try:
            with urllib.request.urlopen(request, timeout=HTTP_TIMEOUT) as response:
                data = response.read(limit + 1)
        except urllib.error.HTTPError as exc:
            if exc.code == 404:
                raise ReleaseError(
                    "The update feed isn't published yet (404)."
                ) from exc
            raise ReleaseError(f"Update feed error ({exc.code}).") from exc
        except (urllib.error.URLError, OSError) as exc:
            raise ReleaseError(f"Could not reach the update feed: {exc}") from exc
        if len(data) > limit:
            raise ReleaseError("The update download was unreasonably large.")
        return data

    def fetch_manifest(self) -> dict:
        raw = self._get(self.feed_url, limit=1024 * 1024)
        try:
            manifest = json.loads(raw)
        except ValueError as exc:
            raise ReleaseError("The update feed isn't valid JSON.") from exc
        if not isinstance(manifest, dict) or "version" not in manifest:
            raise ReleaseError("The update feed is missing a version.")
        if not manifest.get("zip"):
            raise ReleaseError("The update feed doesn't point at a build.")
        return manifest

    def zip_url(self, manifest: dict) -> str:
        """Absolute URL of the build, allowing a feed-relative path."""
        zip_ref = str(manifest["zip"])
        if zip_ref.startswith(("http://", "https://")):
            return zip_ref
        return urljoin(self.feed_url, zip_ref)

    # --------------------------------------------------------------- install

    def download(self, manifest: dict, into: Path) -> Path:
        """Fetch the build and verify its digest before it touches anything."""
        expected = str(manifest.get("sha256") or "").lower()
        if not expected:
            raise ReleaseError("The update feed doesn't publish a checksum.")
        blob = self._get(self.zip_url(manifest))
        actual = hashlib.sha256(blob).hexdigest()
        if actual != expected:
            raise ReleaseError(
                "The downloaded update didn't match its checksum — refusing to "
                "install it."
            )
        path = into / "update.zip"
        path.write_bytes(blob)
        return path

    def _extract(self, archive: Path, into: Path) -> Path:
        """Unpack, refusing any entry that would escape the target directory."""
        with zipfile.ZipFile(archive) as zf:
            for name in zf.namelist():
                target = (into / name).resolve()
                if not str(target).startswith(str(into.resolve())):
                    raise ReleaseError("The update archive contained a bad path.")
            zf.extractall(into)
        # Builds are published with a single top-level directory.
        entries = [p for p in into.iterdir() if p.is_dir()]
        root = entries[0] if len(entries) == 1 else into
        if not (root / "atem_cut_logger" / "__init__.py").is_file():
            raise ReleaseError("The update archive doesn't look like this app.")
        return root

    @staticmethod
    def _version_of(tree: Path) -> str:
        init = tree / "atem_cut_logger" / "__init__.py"
        for line in init.read_text(encoding="utf-8").splitlines():
            if line.startswith("__version__"):
                return line.split("=", 1)[1].strip().strip('"\'')
        return ""

    def install(self, manifest: dict, target: Path) -> str:
        """Download, verify and copy a published build over ``target``.

        Returns the installed version. The caller restarts; nothing here
        touches the operator's data, which lives in ~/.atem_cut_logger.
        """
        target = Path(target)
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp = Path(tmpdir)
            archive = self.download(manifest, tmp)
            tree = self._extract(archive, tmp / "unpacked")

            found = self._version_of(tree)
            promised = str(manifest["version"])
            if found != promised:
                raise ReleaseError(
                    f"The published build says {found or '?'} but the feed "
                    f"promised {promised} — refusing to install it."
                )

            # Keep the licensed SDK files and the compiled bridge: they are not
            # part of any build, and re-fetching them is a manual chore.
            keep: dict[str, bytes] = {}
            for rel in PRESERVE:
                path = target / rel
                if path.is_file():
                    keep[rel] = path.read_bytes()

            for item in tree.iterdir():
                destination = target / item.name
                if item.is_dir():
                    shutil.copytree(item, destination, dirs_exist_ok=True)
                else:
                    shutil.copy2(item, destination)

            for rel, blob in keep.items():
                path = target / rel
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(blob)
                if rel.endswith("atem-bridge"):
                    path.chmod(0o755)
        return promised
