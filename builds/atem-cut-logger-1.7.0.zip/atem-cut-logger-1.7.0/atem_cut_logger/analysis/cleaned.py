"""Build a *cleaned* timeline that removes only sub-threshold accidental cuts.

Guarantees:

* The original :class:`LogSession` is never mutated — a deep copy is made.
* Only cuts whose shot is shorter than ``accidental_cut_seconds`` are removed.
  Removing a cut means the previous camera simply continues over that span
  (the accidental blip is undone); no media is trimmed anywhere else.
* The initial program is never removed (it is not a cut).
* If undoing a blip leaves two identical cameras adjacent, the now-redundant
  cut is collapsed too, exactly like the live de-duplication does.

The cleaned session is a normal :class:`LogSession`, so it exports through the
existing :func:`atem_cut_logger.fcpxml.export_fcpxml` unchanged.
"""

from __future__ import annotations

import copy
from dataclasses import dataclass

from ..fcpxml import export_fcpxml
from ..session import LogSession
from .config import CleanupConfig
from .model import AnalysisResult, build_shots


@dataclass
class CleanResult:
    session: LogSession           # the new, cleaned session (original untouched)
    removed_frames: list[int]     # accidental (sub-threshold) cuts removed
    merged_frames: list[int]      # redundant same-camera cuts collapsed as a result

    @property
    def removed_count(self) -> int:
        return len(self.removed_frames)

    @property
    def merged_count(self) -> int:
        return len(self.merged_frames)


def build_cleaned_session(
    session: LogSession, config: CleanupConfig | None = None
) -> CleanResult:
    """Return a deep-copied session with accidental cuts removed."""
    config = config or CleanupConfig()
    session.validate()

    cleaned = copy.deepcopy(session)
    if not config.enable_accidental or len(cleaned.events) < 2:
        return CleanResult(session=cleaned, removed_frames=[], merged_frames=[])

    rate = cleaned.rate
    accidental_frames = config.accidental_cut_seconds * rate.num / rate.den
    original_events = cleaned.events
    shots = build_shots(session)  # original boundaries decide what's accidental

    kept = [original_events[0]]
    removed: list[int] = []   # sub-threshold cuts (the only ones we target)
    merged: list[int] = []    # redundant same-camera cuts left behind by a removal
    for i in range(1, len(original_events)):
        shot = shots[i]
        if shot.duration_frames < accidental_frames:
            removed.append(original_events[i].frame)
            continue  # drop this cut; previous camera continues
        if original_events[i].input_id == kept[-1].input_id:
            # Removing the blip left the same camera on both sides: this return
            # cut is now a no-op the log would never contain, so collapse it.
            merged.append(original_events[i].frame)
            continue
        kept.append(original_events[i])

    cleaned.events = kept
    return CleanResult(session=cleaned, removed_frames=removed, merged_frames=merged)


def export_cleaned_fcpxml(
    result: AnalysisResult,
    *,
    width: int = 1920,
    height: int = 1080,
    tc_synced_isos: bool = False,
    project_name: str = "ATEM Smart Cleanup — Cleaned",
) -> tuple[str, CleanResult]:
    """Return (fcpxml_string, CleanResult) for the cleaned timeline."""
    clean = build_cleaned_session(result.session, result.config)
    xml = export_fcpxml(
        clean.session,
        width=width,
        height=height,
        tc_synced_isos=tc_synced_isos,
        project_name=project_name,
    )
    return xml, clean
