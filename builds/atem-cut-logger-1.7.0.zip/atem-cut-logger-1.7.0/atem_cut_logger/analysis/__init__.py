"""Smart Cleanup: non-destructive analysis of a logged switch session.

Public API::

    from atem_cut_logger.analysis import analyze, CleanupConfig
    result = analyze(session, CleanupConfig(min_shot_seconds=1.5))
    for issue in result.issues:
        ...

Exports (report / markers / cleaned timeline) live in sibling modules and are
imported lazily to keep the core dependency-free.
"""

from __future__ import annotations

from .analyzer import analyze
from .config import CleanupConfig
from .model import (
    ERROR,
    INFO,
    WARNING,
    AnalysisResult,
    Issue,
    Shot,
    build_shots,
    camera_screen_time,
)

__all__ = [
    "analyze",
    "CleanupConfig",
    "AnalysisResult",
    "Issue",
    "Shot",
    "build_shots",
    "camera_screen_time",
    "INFO",
    "WARNING",
    "ERROR",
]
