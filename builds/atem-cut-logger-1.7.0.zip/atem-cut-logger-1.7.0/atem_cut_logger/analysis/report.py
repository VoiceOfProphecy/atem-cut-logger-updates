"""Human-readable Smart Cleanup report.

Two forms are offered:

* :func:`render_text` — a padded, skimmable report for humans (timecode,
  detected issue, current camera, suggested review action), with a summary
  header of camera screen-time.
* :func:`render_csv` — the same issues as a spreadsheet for filtering/sorting.

Both are pure functions of an :class:`AnalysisResult`; nothing is written to
disk here.
"""

from __future__ import annotations

import csv
import io

from ..timecode import frames_to_timecode
from .model import AnalysisResult


def _screen_time_lines(result: AnalysisResult) -> list[str]:
    session = result.session
    screen = result.screen_time()
    lines: list[str] = []
    for input_id in sorted(screen):
        frames, fraction, count = screen[input_id]
        span = frames_to_timecode(frames, session.rate, session.drop_frame)
        label = session.camera_label(input_id)
        lines.append(
            f"  {label} (input {input_id}): {fraction * 100:5.1f}%  "
            f"[{span}, {count} shot{'s' if count != 1 else ''}]"
        )
    return lines


def render_text(result: AnalysisResult) -> str:
    session = result.session
    df = "DF" if session.drop_frame else "NDF"
    out: list[str] = []
    out.append("ATEM Cut Logger — Smart Cleanup Report")
    out.append("=" * 60)
    product = session.switcher_product or "unknown switcher"
    out.append(
        f"Session : {product} | {session.rate_key} fps {df} | start {session.start_timecode}"
    )
    out.append(
        f"Duration: {session.end_timecode} | "
        f"{len(session.events)} cuts | {len(result.shots)} shots"
    )
    out.append("")
    out.append("Camera screen time:")
    out.extend(_screen_time_lines(result))
    out.append("")

    counts = result.issues_by_type()
    if not result.issues:
        out.append("No issues detected. 🎉")
        return "\n".join(out) + "\n"

    out.append(f"Issues found: {len(result.issues)}")
    for issue_type in sorted(counts):
        out.append(f"  {issue_type}: {counts[issue_type]}")
    out.append("")

    header = f"{'TIMECODE':<14}{'ISSUE':<22}{'CAMERA':<18}SUGGESTION"
    out.append(header)
    out.append("-" * len(header))
    for issue in result.issues:
        out.append(
            f"{issue.timecode:<14}{issue.title:<22}{issue.camera:<18}{issue.suggestion}"
        )
        if issue.detail:
            out.append(f"{'':<14}{'':<22}{'':<18}({issue.detail})")
    return "\n".join(out) + "\n"


def render_csv(result: AnalysisResult) -> str:
    buf = io.StringIO()
    writer = csv.writer(buf, lineterminator="\n")
    writer.writerow(
        ["timecode", "issue_type", "issue", "severity", "camera",
         "atem_input", "detail", "suggested_action"]
    )
    for issue in result.issues:
        writer.writerow(
            [
                issue.timecode,
                issue.issue_type,
                issue.title,
                issue.severity,
                issue.camera,
                "" if issue.input_id is None else issue.input_id,
                issue.detail,
                issue.suggestion,
            ]
        )
    return buf.getvalue()
