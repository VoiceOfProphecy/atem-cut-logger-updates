"""Data types shared across the analysis stage.

A :class:`Shot` is a derived view over the switch log (the span one camera is
on Program). The log itself stays the source of truth — shots are recomputed
on demand and never persisted.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from ..session import LogSession
from ..timecode import frames_to_timecode

# Severity ordering, low -> high, for sorting and reporting.
INFO = "info"
WARNING = "warning"
ERROR = "error"
_SEVERITY_RANK = {INFO: 0, WARNING: 1, ERROR: 2}


def severity_rank(severity: str) -> int:
    return _SEVERITY_RANK.get(severity, 0)


def frames_to_seconds(frames: int, session: LogSession) -> float:
    rate = session.rate
    return frames * rate.den / rate.num


@dataclass
class Shot:
    """One continuous on-air span of a single camera."""

    index: int            # position in the shot list (0-based)
    event_index: int      # index of the SwitchEvent that starts this shot
    input_id: int
    camera: str
    start_frame: int      # logging-relative frame the shot begins
    end_frame: int        # logging-relative frame the shot ends (exclusive)
    timecode: str         # absolute SMPTE timecode of the shot's start

    @property
    def duration_frames(self) -> int:
        return self.end_frame - self.start_frame

    def duration_seconds(self, session: LogSession) -> float:
        return frames_to_seconds(self.duration_frames, session)

    @property
    def is_cut(self) -> bool:
        """True if this shot begins with an actual cut (not the initial program)."""
        return self.event_index > 0


@dataclass
class Issue:
    """One detected editing problem, anchored to a timeline frame."""

    frame: int                    # logging-relative frame the issue is anchored at
    timecode: str                 # absolute SMPTE timecode
    issue_type: str               # machine key, e.g. "accidental_cut"
    title: str                    # short human label, e.g. "Accidental cut"
    severity: str                 # INFO / WARNING / ERROR
    camera: str                   # camera on Program at the issue
    input_id: int | None          # ATEM input, or None for session-level issues
    detail: str                   # specifics, e.g. "0.40 s shot"
    suggestion: str               # suggested review action
    event_index: int | None = None  # SwitchEvent this refers to, if any


def build_shots(session: LogSession) -> list[Shot]:
    """Derive the ordered list of shots from the switch log."""
    shots: list[Shot] = []
    events = session.events
    total = session.duration_frames
    for i, ev in enumerate(events):
        end_frame = events[i + 1].frame if i + 1 < len(events) else total
        shots.append(
            Shot(
                index=i,
                event_index=i,
                input_id=ev.input_id,
                camera=ev.camera or session.camera_label(ev.input_id),
                start_frame=ev.frame,
                end_frame=end_frame,
                timecode=ev.timecode,
            )
        )
    return shots


def camera_screen_time(
    shots: list[Shot], total_frames: int
) -> dict[int, tuple[int, float, int]]:
    """Map input_id -> (frames_on_air, fraction_of_show, shot_count)."""
    totals: dict[int, list[int]] = {}
    for shot in shots:
        frames, count = totals.setdefault(shot.input_id, [0, 0])
        totals[shot.input_id] = [frames + shot.duration_frames, count + 1]
    denom = total_frames or 1
    return {
        input_id: (frames, frames / denom, count)
        for input_id, (frames, count) in totals.items()
    }


@dataclass
class AnalysisContext:
    """Everything a rule needs. ``transcript`` is the seam for a future
    speaker-vs-camera rule (Descript import); it is ``None`` today."""

    session: LogSession
    config: "object"          # CleanupConfig; annotated loosely to avoid import cycle
    shots: list[Shot]
    transcript: "object | None" = None

    def timecode_at(self, frame: int) -> str:
        return frames_to_timecode(
            self.session.start_frames + frame,
            self.session.rate,
            self.session.drop_frame,
        )


@dataclass
class AnalysisResult:
    session: LogSession
    config: "object"
    shots: list[Shot]
    issues: list[Issue] = field(default_factory=list)

    @property
    def total_frames(self) -> int:
        return self.session.duration_frames

    def screen_time(self) -> dict[int, tuple[int, float, int]]:
        return camera_screen_time(self.shots, self.total_frames)

    def issues_by_type(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for issue in self.issues:
            counts[issue.issue_type] = counts.get(issue.issue_type, 0) + 1
        return counts

    def accidental_frames(self) -> list[int]:
        """Frames of shots flagged accidental (used by the cleaned export)."""
        return [i.frame for i in self.issues if i.issue_type == "accidental_cut"]
