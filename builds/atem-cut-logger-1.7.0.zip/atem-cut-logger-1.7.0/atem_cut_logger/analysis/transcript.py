"""Speaker-transcript model — the seam for a future Descript-based rule.

Scope today: import a speaker-labelled transcript and answer "who was speaking
at frame N?". This is deliberately the *only* thing implemented here. The
actual rule that compares the active speaker against the selected camera is a
later phase and is intentionally left unwritten (see
:func:`speaker_camera_mismatch`). There is **no** face recognition and **no**
automatic reframing anywhere in this project.

Descript can export a transcript as JSON. Real exports vary by version, so the
loader is tolerant: it accepts a list of segments (or a ``{"segments": [...]}``
wrapper) where each segment has a speaker label and a start/end time in
seconds. Times are converted to logging-relative frames using the session's
frame rate so they line up with the switch log.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..session import LogSession


@dataclass(frozen=True)
class SpeakerSegment:
    speaker: str
    start_frame: int      # logging-relative
    end_frame: int        # logging-relative, exclusive


@dataclass
class Transcript:
    segments: list[SpeakerSegment]

    def active_speaker_at(self, frame: int) -> str | None:
        """The speaker whose segment contains ``frame``, or None."""
        for seg in self.segments:
            if seg.start_frame <= frame < seg.end_frame:
                return seg.speaker
        return None

    def speakers(self) -> set[str]:
        return {seg.speaker for seg in self.segments}

    # ------------------------------------------------------------- loaders

    @classmethod
    def from_descript_json(
        cls, data: dict | list, session: LogSession, *, offset_seconds: float = 0.0
    ) -> "Transcript":
        """Build a transcript from Descript-style JSON.

        ``offset_seconds`` shifts transcript time to logging-relative time when
        recording and logging did not start at the same instant.
        """
        rate = session.rate

        def to_frame(seconds: float) -> int:
            return round((seconds - offset_seconds) * rate.num / rate.den)

        raw = data.get("segments", data) if isinstance(data, dict) else data
        if not isinstance(raw, list):
            raise ValueError("Descript transcript must be a list of segments.")

        segments: list[SpeakerSegment] = []
        for item in raw:
            speaker = str(
                item.get("speaker")
                or item.get("speaker_label")
                or item.get("name")
                or "Unknown"
            )
            start = _read_time(item, ("start", "start_time", "startTime", "start_sec"))
            end = _read_time(item, ("end", "end_time", "endTime", "end_sec"))
            if start is None or end is None or end <= start:
                continue
            segments.append(
                SpeakerSegment(
                    speaker=speaker,
                    start_frame=max(0, to_frame(start)),
                    end_frame=to_frame(end),
                )
            )
        segments.sort(key=lambda s: s.start_frame)
        return cls(segments=segments)


def _read_time(item: dict, keys: tuple[str, ...]) -> float | None:
    for key in keys:
        if key in item and item[key] is not None:
            return float(item[key])
    return None


def speaker_camera_mismatch(ctx) -> list:
    """FUTURE PHASE — not implemented yet.

    When a transcript and a speaker->expected-camera mapping are available, this
    rule will flag spans where the active speaker does not match the camera on
    Program (e.g. Speaker A is talking but the switcher is on Speaker B's
    close-up). It will register into :data:`atem_cut_logger.analysis.rules.RULES`
    exactly like every other rule.

    It is intentionally a no-op today: the transcript import above provides the
    data groundwork, but the comparison logic — and any speaker/camera pairing
    UI — is deferred. This must never involve face recognition or automatic
    reframing.
    """
    return []
