"""Configuration for the Smart Cleanup analysis stage.

Every threshold is a plain field on :class:`CleanupConfig`, and every rule has
an ``enable_*`` flag so an operator can turn individual checks on or off. The
config round-trips through JSON so a house style ("our shows never hold under
1.5 s") can be saved and reused.

Nothing here touches the switch log — analysis is read-only.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, fields


@dataclass
class CleanupConfig:
    # --- shot-length rules -------------------------------------------------
    enable_min_shot: bool = True
    min_shot_seconds: float = 1.0          # shots shorter than this are flagged
    enable_max_shot: bool = True
    max_shot_seconds: float = 120.0        # shots longer than this are flagged

    # --- accidental cuts (also what the cleaned timeline removes) ----------
    enable_accidental: bool = True
    accidental_cut_seconds: float = 0.5    # shots shorter than this look accidental

    # --- rapid back-and-forth (A -> B -> A) --------------------------------
    enable_back_forth: bool = True
    back_forth_seconds: float = 2.0        # middle shot shorter than this = bounce

    # --- repeated selection of the same camera in a short window -----------
    enable_repeat_same: bool = True
    repeat_window_seconds: float = 10.0
    repeat_count: int = 4                  # Nth selection of one camera in window

    # --- one camera dominating a stretch of the show ----------------------
    # Different from max_shot: this catches a *run* of shots where coverage
    # effectively collapsed to a single angle, even though cuts kept happening.
    enable_solo_stretch: bool = True
    solo_window_seconds: float = 180.0     # length of the window examined
    solo_fraction: float = 0.9             # one camera holding this much of it

    # --- designated wide-camera usage -------------------------------------
    # Set wide_camera_input to the ATEM input number of the wide shot to enable
    # the over/under-use checks.
    wide_camera_input: int | None = None
    wide_min_fraction: float = 0.10        # flag if wide is on-air < 10% of show
    wide_max_fraction: float = 0.60        # flag if wide is on-air > 60% of show

    def __post_init__(self) -> None:
        self.validate()

    def validate(self) -> None:
        if self.min_shot_seconds < 0 or self.max_shot_seconds < 0:
            raise ValueError("Shot-duration thresholds cannot be negative.")
        if self.accidental_cut_seconds < 0:
            raise ValueError("Accidental-cut threshold cannot be negative.")
        if self.enable_max_shot and self.max_shot_seconds <= self.min_shot_seconds:
            raise ValueError(
                "max_shot_seconds must be greater than min_shot_seconds."
            )
        if self.solo_window_seconds <= 0:
            raise ValueError("solo_window_seconds must be positive.")
        if not (0.0 < self.solo_fraction <= 1.0):
            raise ValueError("solo_fraction must be between 0 and 1.")
        if self.repeat_count < 2:
            raise ValueError("repeat_count must be at least 2.")
        if not (0.0 <= self.wide_min_fraction <= self.wide_max_fraction <= 1.0):
            raise ValueError(
                "wide fractions must satisfy 0 <= min <= max <= 1."
            )

    @property
    def wide_enabled(self) -> bool:
        return self.wide_camera_input is not None

    # ------------------------------------------------------------ JSON I/O

    def to_dict(self) -> dict:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)

    @classmethod
    def from_dict(cls, data: dict) -> "CleanupConfig":
        known = {f.name for f in fields(cls)}
        kwargs = {k: v for k, v in data.items() if k in known}
        if "wide_camera_input" in kwargs and kwargs["wide_camera_input"] is not None:
            kwargs["wide_camera_input"] = int(kwargs["wide_camera_input"])
        return cls(**kwargs)

    @classmethod
    def from_json(cls, text: str) -> "CleanupConfig":
        return cls.from_dict(json.loads(text))
