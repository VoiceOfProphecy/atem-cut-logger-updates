"""Run every registered rule over a session and assemble the result.

This is the one place that knows about rule *interaction*: a shot flagged as an
accidental cut should not also be reported as a generic "short shot", so the
lower-severity duplicate is suppressed here rather than in the rules.
"""

from __future__ import annotations

from ..session import LogSession
from .config import CleanupConfig
from .model import AnalysisContext, AnalysisResult, build_shots, severity_rank
from .rules import RULES


def analyze(
    session: LogSession,
    config: CleanupConfig | None = None,
    transcript: object | None = None,
) -> AnalysisResult:
    """Analyse a switch log read-only and return the detected issues.

    ``transcript`` is accepted (and passed to rules via the context) so a
    future speaker-vs-camera rule can use it; no current rule reads it.
    """
    session.validate()
    config = config or CleanupConfig()
    shots = build_shots(session)
    ctx = AnalysisContext(
        session=session, config=config, shots=shots, transcript=transcript
    )

    issues = []
    for _name, rule in RULES:
        issues.extend(rule(ctx))

    issues = _suppress_overlaps(issues)
    # Stable sort: by timeline frame, then most-severe first within a frame.
    issues.sort(key=lambda i: (i.frame, -severity_rank(i.severity)))

    return AnalysisResult(
        session=session, config=config, shots=shots, issues=issues
    )


def _suppress_overlaps(issues: list) -> list:
    """Drop 'short_shot' issues at events already flagged 'accidental_cut'."""
    accidental_events = {
        i.event_index for i in issues if i.issue_type == "accidental_cut"
    }
    return [
        i
        for i in issues
        if not (i.issue_type == "short_shot" and i.event_index in accidental_events)
    ]
