"""The Smart Cleanup rules.

Each rule is a function ``(AnalysisContext) -> list[Issue]`` registered in
:data:`RULES`. Adding a new check — for example the future speaker-vs-camera
comparison once a Descript transcript is available — is just a matter of
writing a function and registering it; nothing else in the pipeline changes.

Rules are intentionally independent. Overlap between "accidental cut" and
"short shot" is resolved once, centrally, in :mod:`analyzer`, so each rule can
stay simple and self-contained.
"""

from __future__ import annotations

from typing import Callable

from .config import CleanupConfig
from .model import (
    ERROR,
    INFO,
    WARNING,
    AnalysisContext,
    Issue,
    camera_screen_time,
)

Rule = Callable[[AnalysisContext], list[Issue]]


def _fmt_seconds(seconds: float) -> str:
    return f"{seconds:.2f} s"


def rule_min_shot(ctx: AnalysisContext) -> list[Issue]:
    cfg: CleanupConfig = ctx.config
    if not cfg.enable_min_shot:
        return []
    issues: list[Issue] = []
    for shot in ctx.shots:
        dur = shot.duration_seconds(ctx.session)
        if dur < cfg.min_shot_seconds:
            issues.append(
                Issue(
                    frame=shot.start_frame,
                    timecode=shot.timecode,
                    issue_type="short_shot",
                    title="Short shot",
                    severity=WARNING,
                    camera=shot.camera,
                    input_id=shot.input_id,
                    detail=f"{_fmt_seconds(dur)} (min {_fmt_seconds(cfg.min_shot_seconds)})",
                    suggestion="Shot is briefer than the minimum; hold longer or remove it.",
                    event_index=shot.event_index,
                )
            )
    return issues


def rule_max_shot(ctx: AnalysisContext) -> list[Issue]:
    cfg: CleanupConfig = ctx.config
    if not cfg.enable_max_shot:
        return []
    issues: list[Issue] = []
    for shot in ctx.shots:
        dur = shot.duration_seconds(ctx.session)
        if dur > cfg.max_shot_seconds:
            issues.append(
                Issue(
                    frame=shot.start_frame,
                    timecode=shot.timecode,
                    issue_type="long_shot",
                    title="Long shot",
                    severity=INFO,
                    camera=shot.camera,
                    input_id=shot.input_id,
                    detail=f"{_fmt_seconds(dur)} (max {_fmt_seconds(cfg.max_shot_seconds)})",
                    suggestion="Long unbroken take; check for a missed cut or add coverage.",
                    event_index=shot.event_index,
                )
            )
    return issues


def rule_accidental(ctx: AnalysisContext) -> list[Issue]:
    cfg: CleanupConfig = ctx.config
    if not cfg.enable_accidental:
        return []
    issues: list[Issue] = []
    for shot in ctx.shots:
        # Only a real cut (not the initial program) can be an accidental cut,
        # and only cuts are removed by the cleaned timeline.
        if not shot.is_cut:
            continue
        dur = shot.duration_seconds(ctx.session)
        if dur < cfg.accidental_cut_seconds:
            issues.append(
                Issue(
                    frame=shot.start_frame,
                    timecode=shot.timecode,
                    issue_type="accidental_cut",
                    title="Accidental cut",
                    severity=ERROR,
                    camera=shot.camera,
                    input_id=shot.input_id,
                    detail=f"{_fmt_seconds(dur)} (under {_fmt_seconds(cfg.accidental_cut_seconds)})",
                    suggestion="Likely accidental; the Cleaned timeline removes this cut.",
                    event_index=shot.event_index,
                )
            )
    return issues


def rule_back_forth(ctx: AnalysisContext) -> list[Issue]:
    cfg: CleanupConfig = ctx.config
    if not cfg.enable_back_forth:
        return []
    shots = ctx.shots
    issues: list[Issue] = []
    for i in range(1, len(shots) - 1):
        prev_shot, mid, next_shot = shots[i - 1], shots[i], shots[i + 1]
        if prev_shot.input_id != next_shot.input_id:
            continue
        if mid.input_id == prev_shot.input_id:
            continue  # not a real A-B-A (dedup should prevent, but be safe)
        if mid.duration_seconds(ctx.session) >= cfg.back_forth_seconds:
            continue
        issues.append(
            Issue(
                frame=mid.start_frame,
                timecode=mid.timecode,
                issue_type="rapid_back_forth",
                title="Rapid back-and-forth",
                severity=WARNING,
                camera=mid.camera,
                input_id=mid.input_id,
                detail=(
                    f"{prev_shot.camera} -> {mid.camera} -> {next_shot.camera}, "
                    f"middle {_fmt_seconds(mid.duration_seconds(ctx.session))}"
                ),
                suggestion="Quick bounce back to the previous camera; consider holding the original.",
                event_index=mid.event_index,
            )
        )
    return issues


def rule_repeat_same(ctx: AnalysisContext) -> list[Issue]:
    cfg: CleanupConfig = ctx.config
    if not cfg.enable_repeat_same:
        return []
    window_frames = round(cfg.repeat_window_seconds * ctx.session.rate.num
                          / ctx.session.rate.den)
    shots = ctx.shots
    issues: list[Issue] = []
    for i, shot in enumerate(shots):
        # Count selections of this camera within the trailing window,
        # including this one.
        count = 1
        j = i - 1
        while j >= 0 and shot.start_frame - shots[j].start_frame <= window_frames:
            if shots[j].input_id == shot.input_id:
                count += 1
            j -= 1
        if count == cfg.repeat_count:  # flag the moment the threshold is reached
            issues.append(
                Issue(
                    frame=shot.start_frame,
                    timecode=shot.timecode,
                    issue_type="repeated_camera",
                    title="Repeated camera",
                    severity=INFO,
                    camera=shot.camera,
                    input_id=shot.input_id,
                    detail=(
                        f"{shot.camera} selected {count}x within "
                        f"{_fmt_seconds(cfg.repeat_window_seconds)}"
                    ),
                    suggestion="This camera is being returned to repeatedly; consider a steadier pattern.",
                    event_index=shot.event_index,
                )
            )
    return issues


def rule_solo_stretch(ctx: AnalysisContext) -> list[Issue]:
    """Flag stretches where coverage collapsed onto one camera.

    Walks a window across the show and reports the first shot of each run in
    which a single input holds at least ``solo_fraction`` of the window. Only
    one issue is raised per run: a 20-minute single-camera stretch is one
    editorial fact, not forty repeats of it.
    """
    cfg: CleanupConfig = ctx.config
    if not cfg.enable_solo_stretch:
        return []
    rate = ctx.session.rate
    window = round(cfg.solo_window_seconds * rate.num / rate.den)
    shots = ctx.shots
    if window <= 0 or not shots:
        return []

    issues: list[Issue] = []
    reported_until = -1   # frame through which a run has already been reported
    for i, shot in enumerate(shots):
        window_end = shot.start_frame + window
        if window_end > ctx.session.duration_frames:
            break  # a partial window at the end would exaggerate any camera
        held: dict[int, int] = {}
        for other in shots[i:]:
            if other.start_frame >= window_end:
                break
            overlap = min(other.end_frame, window_end) - max(other.start_frame,
                                                             shot.start_frame)
            if overlap > 0:
                held[other.input_id] = held.get(other.input_id, 0) + overlap
        if not held:
            continue
        input_id, frames = max(held.items(), key=lambda kv: kv[1])
        if frames / window < cfg.solo_fraction:
            continue
        if shot.start_frame <= reported_until:
            continue  # still inside a stretch already reported
        reported_until = window_end
        label = ctx.session.camera_label(input_id)
        issues.append(
            Issue(
                frame=shot.start_frame,
                timecode=shot.timecode,
                issue_type="solo_stretch",
                title="Single-camera stretch",
                severity=WARNING,
                camera=label,
                input_id=input_id,
                detail=(
                    f"{label} holds {frames / window * 100:.0f}% of the "
                    f"{_fmt_seconds(cfg.solo_window_seconds)} from here"
                ),
                suggestion="Coverage collapsed to one angle; check the other ISOs for cutaways.",
                event_index=shot.event_index,
            )
        )
    return issues


def rule_wide_usage(ctx: AnalysisContext) -> list[Issue]:
    cfg: CleanupConfig = ctx.config
    if not cfg.wide_enabled:
        return []
    wide = cfg.wide_camera_input
    screen = camera_screen_time(ctx.shots, ctx.session.duration_frames)
    frames, fraction, _count = screen.get(wide, (0, 0.0, 0))
    label = ctx.session.camera_label(wide)
    pct = f"{fraction * 100:.0f}%"
    if fraction > cfg.wide_max_fraction:
        return [
            Issue(
                frame=0,
                timecode=ctx.timecode_at(0),
                issue_type="wide_overuse",
                title="Wide camera overused",
                severity=INFO,
                camera=label,
                input_id=wide,
                detail=f"{label} on Program {pct} (max {cfg.wide_max_fraction * 100:.0f}%)",
                suggestion="The wide is on air a lot; cut to tighter angles more often.",
                event_index=None,
            )
        ]
    if fraction < cfg.wide_min_fraction:
        return [
            Issue(
                frame=0,
                timecode=ctx.timecode_at(0),
                issue_type="wide_underuse",
                title="Wide camera underused",
                severity=INFO,
                camera=label,
                input_id=wide,
                detail=f"{label} on Program {pct} (min {cfg.wide_min_fraction * 100:.0f}%)",
                suggestion="The wide is rarely used; add establishing/safety wides.",
                event_index=None,
            )
        ]
    return []


# The rule registry. Order here is the order rules run; the analyzer re-sorts
# issues by timeline position afterwards. Append future rules (e.g. a
# speaker-vs-camera check) to extend the pipeline.
RULES: list[tuple[str, Rule]] = [
    ("min_shot", rule_min_shot),
    ("max_shot", rule_max_shot),
    ("accidental", rule_accidental),
    ("back_forth", rule_back_forth),
    ("repeat_same", rule_repeat_same),
    ("solo_stretch", rule_solo_stretch),
    ("wide_usage", rule_wide_usage),
]
