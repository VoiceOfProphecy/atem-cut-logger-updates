"""Local web app for ATEM Cut Logger.

A small zero-dependency service (stdlib only) that runs on a machine on the
production network and serves a browser UI. The service holds all the hardware
and analysis logic — the browser is only the interface — so nothing is lost
versus the desktop app.

Run it with::

    python -m atem_cut_logger.web
"""
