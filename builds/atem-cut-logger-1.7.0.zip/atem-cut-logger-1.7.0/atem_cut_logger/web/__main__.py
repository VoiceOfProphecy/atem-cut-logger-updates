"""Entry point: ``python -m atem_cut_logger.web``.

Starts the local service and (unless told not to) opens the browser at it.
Binds to localhost by default; pass ``--host 0.0.0.0`` to reach it from a tablet
or laptop elsewhere on the production network.
"""

from __future__ import annotations

import argparse
import socket
import sys
import threading
import webbrowser

from .. import APP_NAME, __version__
from .controller import Controller, default_autosave_path
from .server import make_server


def _lan_ip() -> str | None:
    """Best-effort local network IP of this machine (no packets are sent)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))  # doesn't actually send; just picks the iface
        return s.getsockname()[0]
    except OSError:
        try:
            return socket.gethostbyname(socket.gethostname())
        except OSError:
            return None
    finally:
        s.close()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="atem_cut_logger.web", description=f"{APP_NAME} — local web app"
    )
    parser.add_argument("--host", default="127.0.0.1",
                        help="Bind address (use 0.0.0.0 to allow other devices)")
    parser.add_argument("--port", type=int, default=8760)
    parser.add_argument("--no-browser", action="store_true",
                        help="Do not open a browser automatically")
    parser.add_argument("--update-check-hours", type=float, default=None,
                        help="How often to check for updates (0 disables it)")
    args = parser.parse_args(argv)

    try:
        controller = Controller(autosave_path=default_autosave_path())
        if args.update_check_hours is not None:
            controller.updates.interval_hours = args.update_check_hours
        # Restarting after an update must relaunch with the same options
        # (--host 0.0.0.0 above all, or the app would come back localhost-only).
        controller.updates.restart_argv = [
            sys.executable, "-m", "atem_cut_logger.web", *sys.argv[1:]
        ]
        if controller.updates.interval_hours > 0:
            controller.updates.start_background()
        httpd = make_server(args.host, args.port, controller)
    except OSError as exc:
        print(f"\n  Could not start on port {args.port}: {exc}")
        print(f"  Another program may be using it. Try a different port:")
        print(f"      python -m atem_cut_logger.web --port {args.port + 1}\n")
        return 1
    local_url = f"http://localhost:{args.port}/"
    print(f"\n  {APP_NAME} {__version__} — web app running")
    print("  " + "-" * 48)
    print(f"  On this computer :  {local_url}")
    if args.host == "0.0.0.0":
        ip = _lan_ip()
        network = f"http://{ip}:{args.port}/" if ip else \
            f"http://<this-computer's-IP>:{args.port}/"
        print(f"  On the network   :  {network}")
        print("     (open that address in any browser on the same network —")
        print("      phones, tablets, other control-room machines)")
    else:
        print("  (localhost only — pass --host 0.0.0.0 to allow other devices)")
    print("  " + "-" * 48)
    print("  Press Ctrl+C to stop.\n")
    url = local_url

    if not args.no_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down…")
    finally:
        httpd.controller.shutdown()  # type: ignore[attr-defined]
        httpd.shutdown()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
