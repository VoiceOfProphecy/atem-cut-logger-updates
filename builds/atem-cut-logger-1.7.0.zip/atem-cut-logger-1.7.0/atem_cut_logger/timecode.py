"""SMPTE timecode math for the frame rates ATEM Cut Logger supports.

All timecode arithmetic is done on integer frame counts since midnight.
Drop-frame is supported (and only meaningful) for 29.97 fps; it never drops
frames of media, it drops timecode *labels* (two per minute, except every
tenth minute) so wall-clock time and timecode stay aligned.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from fractions import Fraction


@dataclass(frozen=True)
class FrameRate:
    key: str            # user-facing name, e.g. "29.97"
    num: int            # frames per second as a rational: num/den
    den: int
    nominal: int        # timecode counting base (frames per TC second label)
    drop_capable: bool  # True only for 29.97

    @property
    def fps(self) -> Fraction:
        return Fraction(self.num, self.den)

    @property
    def frame_duration(self) -> Fraction:
        """Duration of one frame in seconds, exact."""
        return Fraction(self.den, self.num)


FRAME_RATES: dict[str, FrameRate] = {
    "23.976": FrameRate("23.976", 24000, 1001, 24, False),
    "24":     FrameRate("24",     24,    1,    24, False),
    "25":     FrameRate("25",     25,    1,    25, False),
    "29.97":  FrameRate("29.97",  30000, 1001, 30, True),
    "30":     FrameRate("30",     30,    1,    30, False),
}

_TC_RE = re.compile(r"^(\d{1,2})[:;.](\d{1,2})[:;.](\d{1,2})[:;.](\d{1,2})$")

# 29.97 drop-frame constants (2 labels dropped per minute, none every 10th)
_DF_PER_MIN = 2
_DF_FRAMES_PER_MIN = 60 * 30 - _DF_PER_MIN          # 1798
_DF_FRAMES_PER_10MIN = 10 * 60 * 30 - 9 * _DF_PER_MIN  # 17982


class TimecodeError(ValueError):
    pass


def validate_drop_frame(rate: FrameRate, drop_frame: bool) -> None:
    if drop_frame and not rate.drop_capable:
        raise TimecodeError(
            f"Drop-frame timecode is only defined for 29.97 fps, not {rate.key} fps."
        )


def parse_timecode(text: str, rate: FrameRate, drop_frame: bool) -> int:
    """Parse ``HH:MM:SS:FF`` (or ``HH:MM:SS;FF``) into frames since midnight."""
    validate_drop_frame(rate, drop_frame)
    m = _TC_RE.match(text.strip())
    if not m:
        raise TimecodeError(
            f"'{text}' is not a valid timecode (expected HH:MM:SS:FF)."
        )
    hh, mm, ss, ff = (int(g) for g in m.groups())
    if hh > 23 or mm > 59 or ss > 59:
        raise TimecodeError(f"'{text}' is out of range (max 23:59:59).")
    if ff >= rate.nominal:
        raise TimecodeError(
            f"Frame value {ff:02d} is invalid at {rate.key} fps (max {rate.nominal - 1:02d})."
        )
    if drop_frame and ss == 0 and mm % 10 != 0 and ff < _DF_PER_MIN:
        raise TimecodeError(
            f"'{text}' does not exist in drop-frame timecode "
            f"(frames 00 and 01 are dropped at the start of this minute)."
        )

    total_seconds = hh * 3600 + mm * 60 + ss
    frames = total_seconds * rate.nominal + ff
    if drop_frame:
        total_minutes = hh * 60 + mm
        frames -= _DF_PER_MIN * (total_minutes - total_minutes // 10)
    return frames


def frames_to_timecode(frames: int, rate: FrameRate, drop_frame: bool) -> str:
    """Format a frame count since midnight as SMPTE timecode.

    Drop-frame uses the conventional ``;`` separator before the frame field.
    """
    validate_drop_frame(rate, drop_frame)
    if frames < 0:
        raise TimecodeError("Negative frame counts cannot be formatted.")

    if drop_frame:
        # Re-insert dropped labels, then format as if NDF 30.
        d, m = divmod(frames, _DF_FRAMES_PER_10MIN)
        frames += 9 * _DF_PER_MIN * d
        if m >= _DF_PER_MIN:
            frames += _DF_PER_MIN * ((m - _DF_PER_MIN) // _DF_FRAMES_PER_MIN)

    base = rate.nominal
    ff = frames % base
    total_seconds = frames // base
    ss = total_seconds % 60
    mm = (total_seconds // 60) % 60
    hh = (total_seconds // 3600) % 24
    sep = ";" if drop_frame else ":"
    return f"{hh:02d}:{mm:02d}:{ss:02d}{sep}{ff:02d}"


def seconds_to_frames(elapsed_seconds: float, rate: FrameRate) -> int:
    """Convert elapsed real time to a whole number of frames (nearest)."""
    if elapsed_seconds < 0:
        raise TimecodeError("Elapsed time cannot be negative.")
    return round(elapsed_seconds * rate.num / rate.den)


def event_timecode(
    start_frames: int, elapsed_seconds: float, rate: FrameRate, drop_frame: bool
) -> tuple[int, str]:
    """Return (frames-since-logging-start, absolute SMPTE timecode string)."""
    offset = seconds_to_frames(elapsed_seconds, rate)
    return offset, frames_to_timecode(start_frames + offset, rate, drop_frame)
