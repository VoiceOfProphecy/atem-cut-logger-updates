"""ATEM Cut Logger desktop GUI (tkinter — ships with Python on macOS/Windows).

Layout follows the production workflow top to bottom:

    1. Connect (IP + Connect, or Test Mode)     <- always visible
    2. Big Program display                      <- confidence monitor
    3. Session settings (rate / TC / audio)     <- locked while logging
    4. Camera mapping table                     <- double-click to edit
    5. Start/Stop logging + live event log
    6. Export (JSON / CSV / FCPXML)

All device events arrive on backend threads and are drained from a queue on
the Tk main loop; timestamps are captured in the backend callbacks so GUI
latency never skews cut times.
"""

from __future__ import annotations

import queue
import time
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from .. import APP_NAME, __version__
from ..backends import create_backend
from ..fcpxml import ExportError, export_fcpxml
from ..session import CameraMapping, LogSession
from ..timecode import (
    FRAME_RATES,
    TimecodeError,
    frames_to_timecode,
    seconds_to_frames,
)

RESOLUTIONS = {
    "1920 x 1080": (1920, 1080),
    "1280 x 720": (1280, 720),
    "3840 x 2160 (UHD)": (3840, 2160),
}

PROGRAM_LIVE_BG = "#b71c1c"
PROGRAM_IDLE_BG = "#37474f"


class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        root.title(f"{APP_NAME} {__version__}")
        root.minsize(760, 640)

        self.session = LogSession()
        self.backend = None
        self.backend_kind = ""
        self.connected = False
        self.logging = False
        self.start_mono: float | None = None
        self.program_input: int | None = None
        self.dirty = False               # unsaved events in memory
        self.log_path: Path | None = None
        self.events_q: queue.Queue = queue.Queue()

        self._build_menu()
        self._build_ui()
        self._set_state()
        root.protocol("WM_DELETE_WINDOW", self._on_quit)
        root.after(100, self._poll)

    # ------------------------------------------------------------------- UI

    def _build_menu(self) -> None:
        menu = tk.Menu(self.root)
        filemenu = tk.Menu(menu, tearoff=False)
        filemenu.add_command(label="Open Log for Export…", command=self._open_log)
        filemenu.add_command(label="Save Log (JSON)…", command=self._save_json)
        filemenu.add_separator()
        filemenu.add_command(label="Export CSV…", command=self._save_csv)
        filemenu.add_command(label="Export Resolve Timeline (FCPXML)…",
                             command=self._export_fcpxml)
        filemenu.add_separator()
        filemenu.add_command(label="Quit", command=self._on_quit)
        menu.add_cascade(label="File", menu=filemenu)
        self.root.config(menu=menu)

    def _build_ui(self) -> None:
        outer = ttk.Frame(self.root, padding=10)
        outer.pack(fill="both", expand=True)

        # -- 1. Connection -------------------------------------------------
        conn = ttk.LabelFrame(outer, text="1 · Switcher", padding=8)
        conn.pack(fill="x")
        ttk.Label(conn, text="ATEM IP address:").grid(row=0, column=0, sticky="w")
        self.ip_var = tk.StringVar(value="192.168.10.240")
        self.ip_entry = ttk.Entry(conn, textvariable=self.ip_var, width=18)
        self.ip_entry.grid(row=0, column=1, padx=(6, 10))
        self.connect_btn = ttk.Button(conn, text="Connect", command=self._connect_atem)
        self.connect_btn.grid(row=0, column=2, padx=2)
        self.test_btn = ttk.Button(conn, text="Test Mode (no ATEM)",
                                   command=self._connect_simulator)
        self.test_btn.grid(row=0, column=3, padx=2)
        self.disconnect_btn = ttk.Button(conn, text="Disconnect",
                                         command=self._disconnect)
        self.disconnect_btn.grid(row=0, column=4, padx=2)
        self.status_var = tk.StringVar(value="Not connected.")
        ttk.Label(conn, textvariable=self.status_var).grid(
            row=1, column=0, columnspan=5, sticky="w", pady=(6, 0)
        )
        self.ip_entry.bind("<Return>", lambda _e: self._connect_atem())

        # -- 2. Program display --------------------------------------------
        self.program_label = tk.Label(
            outer, text="PROGRAM — not connected", font=("TkDefaultFont", 22, "bold"),
            fg="white", bg=PROGRAM_IDLE_BG, pady=14,
        )
        self.program_label.pack(fill="x", pady=8)

        # Simulator manual cut buttons (only shown in test mode)
        self.sim_frame = ttk.Frame(outer)
        self.sim_buttons: list[ttk.Button] = []

        # -- 3. Session settings -------------------------------------------
        settings = ttk.LabelFrame(outer, text="2 · Session settings", padding=8)
        settings.pack(fill="x", pady=(0, 8))
        self.settings_frame = settings

        ttk.Label(settings, text="Frame rate:").grid(row=0, column=0, sticky="w")
        self.rate_var = tk.StringVar(value="25")
        self.rate_combo = ttk.Combobox(
            settings, textvariable=self.rate_var, state="readonly", width=8,
            values=["23.976", "24", "25", "29.97", "30"],
        )
        self.rate_combo.grid(row=0, column=1, padx=(6, 14))
        self.rate_combo.bind("<<ComboboxSelected>>", lambda _e: self._rate_changed())

        self.drop_var = tk.BooleanVar(value=False)
        self.drop_check = ttk.Checkbutton(
            settings, text="Drop-frame timecode", variable=self.drop_var,
            command=self._sync_tc_separator,
        )
        self.drop_check.grid(row=0, column=2, padx=(0, 14))

        ttk.Label(settings, text="Start timecode:").grid(row=0, column=3, sticky="w")
        self.tc_var = tk.StringVar(value="00:00:00:00")
        self.tc_entry = ttk.Entry(settings, textvariable=self.tc_var, width=13)
        self.tc_entry.grid(row=0, column=4, padx=6)
        self.now_btn = ttk.Button(settings, text="Now", width=5,
                                  command=self._set_tc_now)
        self.now_btn.grid(row=0, column=5)

        ttk.Label(settings, text="Resolution:").grid(
            row=1, column=0, sticky="w", pady=(8, 0)
        )
        self.res_var = tk.StringVar(value="1920 x 1080")
        self.res_combo = ttk.Combobox(
            settings, textvariable=self.res_var, state="readonly", width=18,
            values=list(RESOLUTIONS),
        )
        self.res_combo.grid(row=1, column=1, columnspan=2, sticky="w",
                            padx=6, pady=(8, 0))

        ttk.Label(settings, text="ISO files:").grid(
            row=1, column=3, sticky="w", pady=(8, 0)
        )
        self.sync_var = tk.StringVar(value="start")
        sync_frame = ttk.Frame(settings)
        sync_frame.grid(row=1, column=4, columnspan=2, sticky="w", pady=(8, 0))
        ttk.Radiobutton(sync_frame, text="started with logging",
                        variable=self.sync_var, value="start").pack(side="left")
        ttk.Radiobutton(sync_frame, text="timecode-synced",
                        variable=self.sync_var, value="tc").pack(side="left")

        ttk.Label(settings, text="Program audio file:").grid(
            row=2, column=0, sticky="w", pady=(8, 0)
        )
        self.audio_var = tk.StringVar(value="")
        self.audio_entry = ttk.Entry(settings, textvariable=self.audio_var, width=48)
        self.audio_entry.grid(row=2, column=1, columnspan=4, sticky="we",
                              padx=6, pady=(8, 0))
        self.audio_btn = ttk.Button(settings, text="Browse…",
                                    command=self._browse_audio)
        self.audio_btn.grid(row=2, column=5, pady=(8, 0))

        # -- 4. Camera mapping ----------------------------------------------
        mapping = ttk.LabelFrame(
            outer, text="3 · Camera mapping (double-click a row to edit)", padding=8
        )
        mapping.pack(fill="both", expand=True, pady=(0, 8))
        self.map_tree = ttk.Treeview(
            mapping, columns=("input", "name", "file"), show="headings", height=5
        )
        self.map_tree.heading("input", text="ATEM input")
        self.map_tree.heading("name", text="Camera / angle name")
        self.map_tree.heading("file", text="ISO media file")
        self.map_tree.column("input", width=90, anchor="center", stretch=False)
        self.map_tree.column("name", width=220)
        self.map_tree.column("file", width=340)
        self.map_tree.pack(side="left", fill="both", expand=True)
        map_scroll = ttk.Scrollbar(mapping, orient="vertical",
                                   command=self.map_tree.yview)
        map_scroll.pack(side="left", fill="y")
        self.map_tree.configure(yscrollcommand=map_scroll.set)
        self.map_tree.bind("<Double-1>", self._edit_mapping)
        map_btns = ttk.Frame(mapping)
        map_btns.pack(side="left", fill="y", padx=(8, 0))
        self.add_input_btn = ttk.Button(map_btns, text="Add input…",
                                        command=self._add_input)
        self.add_input_btn.pack(fill="x")

        # -- 5. Logging -----------------------------------------------------
        logf = ttk.LabelFrame(outer, text="4 · Log", padding=8)
        logf.pack(fill="both", expand=True)
        top = ttk.Frame(logf)
        top.pack(fill="x")
        self.log_btn = tk.Button(
            top, text="●  Start Logging", font=("TkDefaultFont", 13, "bold"),
            command=self._toggle_logging, height=2, width=18,
        )
        self.log_btn.pack(side="left")
        self.clock_var = tk.StringVar(value="—")
        ttk.Label(top, textvariable=self.clock_var,
                  font=("TkFixedFont", 14)).pack(side="left", padx=14)

        self.event_tree = ttk.Treeview(
            logf, columns=("n", "tc", "input", "camera"), show="headings", height=7
        )
        for col, text, width, anchor in (
            ("n", "#", 50, "center"),
            ("tc", "Timecode", 130, "center"),
            ("input", "Input", 60, "center"),
            ("camera", "Camera", 260, "w"),
        ):
            self.event_tree.heading(col, text=text)
            self.event_tree.column(col, width=width, anchor=anchor,
                                   stretch=(col == "camera"))
        self.event_tree.pack(fill="both", expand=True, pady=(8, 0))

        # -- 6. Export -------------------------------------------------------
        export = ttk.Frame(outer)
        export.pack(fill="x", pady=(8, 0))
        self.save_json_btn = ttk.Button(export, text="Save Log (JSON)",
                                        command=self._save_json)
        self.save_json_btn.pack(side="left")
        self.save_csv_btn = ttk.Button(export, text="Export CSV",
                                       command=self._save_csv)
        self.save_csv_btn.pack(side="left", padx=6)
        self.export_xml_btn = ttk.Button(
            export, text="Export Resolve Timeline (FCPXML)",
            command=self._export_fcpxml,
        )
        self.export_xml_btn.pack(side="left")
        self.cleanup_btn = ttk.Button(
            export, text="Smart Cleanup…", command=self._open_cleanup,
        )
        self.cleanup_btn.pack(side="left", padx=(6, 0))

    # ------------------------------------------------------------ UI state

    def _set_state(self) -> None:
        connected, logging = self.connected, self.logging
        self.connect_btn.state(["disabled"] if connected else ["!disabled"])
        self.test_btn.state(["disabled"] if connected else ["!disabled"])
        self.ip_entry.state(["disabled"] if connected else ["!disabled"])
        self.disconnect_btn.state(["!disabled"] if connected else ["disabled"])

        settings_state = ["disabled"] if logging else ["!disabled"]
        for widget in (self.rate_combo, self.drop_check, self.tc_entry,
                       self.now_btn, self.res_combo, self.audio_entry,
                       self.audio_btn, self.add_input_btn):
            widget.state(settings_state)
        self.rate_combo.configure(state="disabled" if logging else "readonly")
        self.res_combo.configure(state="disabled" if logging else "readonly")

        self.log_btn.configure(
            state="normal" if connected else "disabled",
            text="■  Stop Logging" if logging else "●  Start Logging",
            fg="#b71c1c" if logging else "black",
        )
        has_events = bool(self.session.events) and not logging
        for btn in (self.save_json_btn, self.save_csv_btn, self.export_xml_btn,
                    self.cleanup_btn):
            btn.state(["!disabled"] if has_events else ["disabled"])
        self._rate_changed(init=True)

    def _rate_changed(self, init: bool = False) -> None:
        rate = FRAME_RATES[self.rate_var.get()]
        if rate.drop_capable:
            self.drop_check.state(["!disabled"] if not self.logging else ["disabled"])
            if not init:
                self.drop_var.set(True)   # 29.97 productions are DF by default
        else:
            self.drop_var.set(False)
            self.drop_check.state(["disabled"])
        self._sync_tc_separator()

    def _sync_tc_separator(self) -> None:
        tc = self.tc_var.get()
        if len(tc) == 11:
            sep = ";" if self.drop_var.get() else ":"
            self.tc_var.set(tc[:8] + sep + tc[9:])

    def _set_tc_now(self) -> None:
        rate = FRAME_RATES[self.rate_var.get()]
        now = datetime.now()
        seconds = (now.hour * 3600 + now.minute * 60 + now.second
                   + now.microsecond / 1e6)
        frames = seconds_to_frames(seconds, rate)
        self.tc_var.set(frames_to_timecode(frames, rate, self.drop_var.get()))

    # ---------------------------------------------------------- connection

    def _connect_atem(self) -> None:
        ip = self.ip_var.get().strip()
        if not ip:
            messagebox.showerror(APP_NAME, "Enter the ATEM's IP address first.")
            return
        self._connect("atem", ip)

    def _connect_simulator(self) -> None:
        self._connect("simulator", "")

    def _connect(self, kind: str, address: str) -> None:
        try:
            self.backend = create_backend(kind, _QueueListener(self.events_q))
        except (RuntimeError, ImportError) as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return
        self.backend_kind = kind
        self.status_var.set(
            "Connecting…" if kind == "atem" else "Starting simulator…"
        )
        try:
            self.backend.connect(address)
        except Exception as exc:  # backend-specific failures surface here
            self.backend = None
            self.status_var.set("Not connected.")
            messagebox.showerror(APP_NAME, f"Could not connect: {exc}")

    def _disconnect(self) -> None:
        if self.logging and not messagebox.askyesno(
            APP_NAME, "Logging is running. Stop logging and disconnect?"
        ):
            return
        if self.logging:
            self._stop_logging()
        if self.backend:
            self.backend.disconnect()
            self.backend = None

    # -------------------------------------------------------- event queue

    def _poll(self) -> None:
        try:
            while True:
                self._handle(self.events_q.get_nowait())
        except queue.Empty:
            pass
        if self.logging and self.start_mono is not None:
            elapsed = time.monotonic() - self.start_mono
            frame = seconds_to_frames(elapsed, self.session.rate)
            tc = frames_to_timecode(
                self.session.start_frames + frame,
                self.session.rate, self.session.drop_frame,
            )
            self.clock_var.set(f"REC {tc}   ({len(self.session.events)} events)")
        self.root.after(50 if self.logging else 100, self._poll)

    def _handle(self, msg: tuple) -> None:
        kind = msg[0]
        if kind == "connected":
            _, product, inputs, program = msg
            self.connected = True
            self.program_input = program
            self.status_var.set(f"Connected: {product}")
            self.session.switcher_product = product
            for input_id, name in sorted(inputs.items()):
                existing = self.session.mappings.get(input_id)
                if existing is None:
                    self.session.mappings[input_id] = CameraMapping(input_id, name)
                elif not existing.name:
                    existing.name = name
            self._refresh_mapping_table()
            self._show_program()
            self._show_sim_buttons(self.backend_kind == "simulator", inputs)
            self._set_state()
        elif kind == "program":
            _, input_id, t = msg
            self.program_input = input_id
            if self.logging and self.start_mono is not None:
                event = self.session.add_program_change(
                    input_id, max(0.0, t - self.start_mono)
                )
                if event:
                    self.dirty = True
                    self.event_tree.insert(
                        "", "end",
                        values=(len(self.session.events), event.timecode,
                                event.input_id, event.camera),
                    )
                    self.event_tree.yview_moveto(1.0)
            self._show_program()
        elif kind == "disconnected":
            was_logging = self.logging
            if was_logging:
                self._stop_logging()
            self.connected = False
            self.program_input = None
            self.status_var.set(f"Disconnected: {msg[1]}")
            self._show_program()
            self._show_sim_buttons(False, {})
            self._set_state()
            if was_logging:
                messagebox.showwarning(
                    APP_NAME,
                    "Connection to the switcher was lost.\n\n"
                    "Logging stopped — every event captured so far is intact. "
                    "Save the log now.",
                )
        elif kind == "error":
            self.status_var.set(f"Error: {msg[1]}")
            messagebox.showerror(APP_NAME, msg[1])

    def _show_program(self) -> None:
        if not self.connected or self.program_input is None:
            self.program_label.configure(
                text="PROGRAM — not connected", bg=PROGRAM_IDLE_BG
            )
            return
        label = self.session.camera_label(self.program_input)
        self.program_label.configure(
            text=f"PROGRAM  ·  {self.program_input}  ·  {label}",
            bg=PROGRAM_LIVE_BG if self.logging else PROGRAM_IDLE_BG,
        )

    def _show_sim_buttons(self, show: bool, inputs: dict) -> None:
        for btn in self.sim_buttons:
            btn.destroy()
        self.sim_buttons.clear()
        if show:
            ttk.Label(self.sim_frame, text="Simulate cut to:").pack(side="left")
            for input_id in sorted(inputs):
                btn = ttk.Button(
                    self.sim_frame, text=str(input_id), width=3,
                    command=lambda i=input_id: self.backend.cut_to(i),
                )
                btn.pack(side="left", padx=2)
                self.sim_buttons.append(btn)
            self.sim_frame.pack(fill="x", pady=(0, 8),
                                after=self.program_label)
        else:
            for child in self.sim_frame.winfo_children():
                child.destroy()
            self.sim_frame.pack_forget()

    # -------------------------------------------------------------- mapping

    def _refresh_mapping_table(self) -> None:
        self.map_tree.delete(*self.map_tree.get_children())
        for m in sorted(self.session.mappings.values(), key=lambda m: m.input_id):
            self.map_tree.insert(
                "", "end", iid=str(m.input_id),
                values=(m.input_id, m.name, m.file),
            )

    def _add_input(self) -> None:
        existing = self.session.mappings
        next_id = max(existing, default=0) + 1
        self.session.mappings[next_id] = CameraMapping(next_id, f"Camera {next_id}")
        self._refresh_mapping_table()
        self._edit_mapping_row(next_id)

    def _edit_mapping(self, _event) -> None:
        item = self.map_tree.focus()
        if item:
            self._edit_mapping_row(int(item))

    def _edit_mapping_row(self, input_id: int) -> None:
        mapping = self.session.mappings[input_id]
        dialog = tk.Toplevel(self.root)
        dialog.title(f"ATEM input {input_id}")
        dialog.transient(self.root)
        dialog.grab_set()
        frame = ttk.Frame(dialog, padding=12)
        frame.pack(fill="both", expand=True)

        ttk.Label(frame, text="Camera / angle name:").grid(row=0, column=0, sticky="w")
        name_var = tk.StringVar(value=mapping.name)
        ttk.Entry(frame, textvariable=name_var, width=32).grid(
            row=0, column=1, padx=6, pady=2
        )
        ttk.Label(frame, text="ISO media file:").grid(row=1, column=0, sticky="w")
        file_var = tk.StringVar(value=mapping.file)
        ttk.Entry(frame, textvariable=file_var, width=32).grid(
            row=1, column=1, padx=6, pady=2
        )

        def browse():
            path = filedialog.askopenfilename(
                parent=dialog, title=f"ISO file for input {input_id}",
                filetypes=[("Media files", "*.mov *.mp4 *.mxf *.avi *.braw"),
                           ("All files", "*")],
            )
            if path:
                file_var.set(path)

        ttk.Button(frame, text="Browse…", command=browse).grid(row=1, column=2)

        def save():
            mapping.name = name_var.get().strip()
            mapping.file = file_var.get().strip()
            # Camera labels on already-logged events follow the mapping.
            for e in self.session.events:
                if e.input_id == input_id:
                    e.camera = mapping.label()
            self._refresh_mapping_table()
            self._refresh_event_table()
            self._show_program()
            dialog.destroy()

        btns = ttk.Frame(frame)
        btns.grid(row=2, column=0, columnspan=3, pady=(10, 0))
        ttk.Button(btns, text="Save", command=save).pack(side="left", padx=4)
        ttk.Button(btns, text="Cancel", command=dialog.destroy).pack(side="left")
        dialog.bind("<Return>", lambda _e: save())
        dialog.wait_window()

    def _refresh_event_table(self) -> None:
        self.event_tree.delete(*self.event_tree.get_children())
        for i, e in enumerate(self.session.events, start=1):
            self.event_tree.insert(
                "", "end", values=(i, e.timecode, e.input_id, e.camera)
            )

    def _browse_audio(self) -> None:
        path = filedialog.askopenfilename(
            title="Continuous program-audio recording",
            filetypes=[("Audio/media files", "*.wav *.aif *.aiff *.mp3 *.mov *.mp4 *.mxf"),
                       ("All files", "*")],
        )
        if path:
            self.audio_var.set(path)

    # -------------------------------------------------------------- logging

    def _toggle_logging(self) -> None:
        if self.logging:
            self._stop_logging()
        else:
            self._start_logging()

    def _start_logging(self) -> None:
        if self.dirty and self.session.events:
            if not messagebox.askyesno(
                APP_NAME, "The current log has not been saved. Discard it and start a new one?"
            ):
                return
        self.session.rate_key = self.rate_var.get()
        self.session.drop_frame = self.drop_var.get()
        self.session.start_timecode = self.tc_var.get().strip()
        self.session.audio_file = self.audio_var.get().strip()
        try:
            self.session.validate()
        except TimecodeError as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return
        if self.program_input is None:
            messagebox.showerror(APP_NAME, "No Program input known yet — not connected?")
            return
        self.session.begin()
        self.event_tree.delete(*self.event_tree.get_children())
        self.start_mono = time.monotonic()
        self.logging = True
        self.dirty = True
        self.log_path = None
        # Event #1: whatever is on Program when the show starts.
        first = self.session.add_program_change(self.program_input, 0.0)
        if first:
            self.event_tree.insert(
                "", "end", values=(1, first.timecode, first.input_id, first.camera)
            )
        self._show_program()
        self._set_state()

    def _stop_logging(self) -> None:
        if self.start_mono is not None:
            self.session.end(time.monotonic() - self.start_mono)
        self.logging = False
        self.start_mono = None
        self.clock_var.set(
            f"Stopped at {self.session.end_timecode} "
            f"({len(self.session.events)} events)"
        )
        self._show_program()
        self._set_state()

    # -------------------------------------------------------------- exports

    def _require_events(self) -> bool:
        if not self.session.events:
            messagebox.showinfo(APP_NAME, "No events logged yet.")
            return False
        return True

    def _save_json(self) -> None:
        if not self._require_events():
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".atemlog.json",
            initialfile=self._default_stem() + ".atemlog.json",
            filetypes=[("ATEM Cut Logger session", "*.atemlog.json *.json")],
        )
        if not path:
            return
        Path(path).write_text(self.session.to_json(), encoding="utf-8")
        self.dirty = False
        self.log_path = Path(path)
        self.status_var.set(f"Log saved: {path}")

    def _save_csv(self) -> None:
        if not self._require_events():
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            initialfile=self._default_stem() + ".csv",
            filetypes=[("CSV", "*.csv")],
        )
        if not path:
            return
        Path(path).write_text(self.session.to_csv(), encoding="utf-8")
        self.status_var.set(f"CSV saved: {path}")

    def _open_cleanup(self) -> None:
        if not self._require_events():
            return
        # Keep the audio-file field in sync so the cleaned timeline carries it.
        self.session.audio_file = self.audio_var.get().strip()
        from .cleanup_dialog import CleanupDialog

        CleanupDialog(self.root, self.session, self._default_stem())

    def _export_fcpxml(self) -> None:
        if not self._require_events():
            return
        missing = [
            m.label() for m in self.session.mappings.values()
            if not m.file and any(e.input_id == m.input_id for e in self.session.events)
        ]
        if missing and not messagebox.askyesno(
            APP_NAME,
            "No ISO file selected for: " + ", ".join(missing) + ".\n\n"
            "The timeline will contain offline placeholders you can relink in "
            "Resolve. Export anyway?",
        ):
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".fcpxml",
            initialfile=self._default_stem() + ".fcpxml",
            filetypes=[("Final Cut Pro XML", "*.fcpxml")],
        )
        if not path:
            return
        self.session.audio_file = self.audio_var.get().strip()
        width, height = RESOLUTIONS[self.res_var.get()]
        try:
            xml = export_fcpxml(
                self.session,
                width=width, height=height,
                tc_synced_isos=self.sync_var.get() == "tc",
                project_name=Path(path).stem,
            )
        except (ExportError, TimecodeError) as exc:
            messagebox.showerror(APP_NAME, str(exc))
            return
        Path(path).write_text(xml, encoding="utf-8")
        self.status_var.set(f"Resolve timeline saved: {path}")
        messagebox.showinfo(
            APP_NAME,
            f"Timeline exported.\n\nIn DaVinci Resolve use:\n"
            f"File ▸ Import ▸ Timeline… and pick\n{path}",
        )

    def _open_log(self) -> None:
        if self.logging:
            messagebox.showerror(APP_NAME, "Stop logging first.")
            return
        path = filedialog.askopenfilename(
            filetypes=[("ATEM Cut Logger session", "*.atemlog.json *.json")]
        )
        if not path:
            return
        try:
            self.session = LogSession.from_json(Path(path).read_text(encoding="utf-8"))
        except (ValueError, KeyError, OSError) as exc:
            messagebox.showerror(APP_NAME, f"Could not open log: {exc}")
            return
        self.dirty = False
        self.log_path = Path(path)
        self.rate_var.set(self.session.rate_key)
        self.drop_var.set(self.session.drop_frame)
        self.tc_var.set(self.session.start_timecode)
        self.audio_var.set(self.session.audio_file)
        self._refresh_mapping_table()
        self._refresh_event_table()
        self.clock_var.set(
            f"Loaded {Path(path).name} ({len(self.session.events)} events)"
        )
        self.status_var.set("Log loaded — exports will regenerate from it.")
        self._set_state()

    def _default_stem(self) -> str:
        if self.log_path:
            return self.log_path.name.replace(".atemlog.json", "")
        stamp = (self.session.started_wall_clock or
                 datetime.now().isoformat(timespec="seconds"))
        return "atem-cuts-" + stamp.replace(":", "-")[:19]

    # ----------------------------------------------------------------- quit

    def _on_quit(self) -> None:
        if self.logging and not messagebox.askyesno(
            APP_NAME, "Logging is running. Quit anyway?"
        ):
            return
        if (not self.logging and self.dirty and self.session.events
                and messagebox.askyesno(APP_NAME, "Save the log before quitting?")):
            self._save_json()
        if self.backend:
            try:
                self.backend.disconnect()
            except Exception:
                pass
        self.root.destroy()


class _QueueListener:
    """Backend listener that forwards everything into the GUI queue."""

    def __init__(self, q: queue.Queue):
        self.q = q

    def on_connected(self, product_name, inputs, program):
        self.q.put(("connected", product_name, inputs, program))

    def on_program_changed(self, input_id, monotonic_time):
        self.q.put(("program", input_id, monotonic_time))

    def on_disconnected(self, reason):
        self.q.put(("disconnected", reason))

    def on_error(self, message):
        self.q.put(("error", message))


def run_gui() -> int:
    root = tk.Tk()
    try:
        ttk.Style().theme_use("clam")
    except tk.TclError:
        pass
    App(root)
    root.mainloop()
    return 0
