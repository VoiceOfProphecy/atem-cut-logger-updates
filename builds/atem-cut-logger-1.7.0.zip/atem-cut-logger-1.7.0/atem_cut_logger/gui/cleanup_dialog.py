"""Smart Cleanup dialog — configure rules, review issues, export results.

Everything here is non-destructive: analysis is read-only and the cleaned
timeline is built from a deep copy, so the loaded session, its JSON log and any
previously exported XML are never touched.
"""

from __future__ import annotations

import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from .. import APP_NAME
from ..analysis import CleanupConfig, analyze
from ..analysis.cleaned import export_cleaned_fcpxml
from ..analysis.markers import export_markers_fcpxml
from ..analysis.report import render_csv, render_text
from ..session import LogSession

_SEVERITY_COLOR = {"error": "#b71c1c", "warning": "#e65100", "info": "#1b5e20"}


class CleanupDialog(tk.Toplevel):
    def __init__(self, parent: tk.Misc, session: LogSession, default_stem: str):
        super().__init__(parent)
        self.session = session
        self.default_stem = default_stem
        self.result = None
        self.title("Smart Cleanup")
        self.transient(parent)
        self.minsize(720, 560)

        self._build_config()
        self._build_results()
        self._build_exports()
        self.grab_set()
        self._analyze()  # run once on open with defaults

    # ---------------------------------------------------------------- config

    def _build_config(self) -> None:
        frame = ttk.LabelFrame(self, text="Rules", padding=8)
        frame.pack(fill="x", padx=10, pady=(10, 6))

        self.vars: dict[str, tk.Variable] = {}

        def spin(row, col, label, key, default, from_, to, inc):
            ttk.Label(frame, text=label).grid(row=row, column=col * 2,
                                              sticky="w", padx=(0, 4), pady=2)
            var = tk.DoubleVar(value=default)
            ttk.Spinbox(frame, from_=from_, to=to, increment=inc, width=7,
                        textvariable=var).grid(row=row, column=col * 2 + 1,
                                               sticky="w", padx=(0, 14))
            self.vars[key] = var

        d = CleanupConfig()
        spin(0, 0, "Min shot (s):", "min_shot_seconds", d.min_shot_seconds, 0, 60, 0.1)
        spin(0, 1, "Max shot (s):", "max_shot_seconds", d.max_shot_seconds, 1, 3600, 1)
        spin(0, 2, "Accidental <(s):", "accidental_cut_seconds",
             d.accidental_cut_seconds, 0, 10, 0.05)
        spin(1, 0, "Back-forth (s):", "back_forth_seconds", d.back_forth_seconds, 0, 30, 0.1)
        spin(1, 1, "Repeat window (s):", "repeat_window_seconds",
             d.repeat_window_seconds, 1, 120, 1)

        ttk.Label(frame, text="Repeat count:").grid(row=1, column=4, sticky="w", padx=(0, 4))
        self.vars["repeat_count"] = tk.IntVar(value=d.repeat_count)
        ttk.Spinbox(frame, from_=2, to=20, width=7,
                    textvariable=self.vars["repeat_count"]).grid(row=1, column=5, sticky="w")

        # Wide camera selector, populated from the session's mappings.
        ttk.Label(frame, text="Wide camera:").grid(row=2, column=0, sticky="w", pady=(6, 0))
        self.wide_var = tk.StringVar(value="(none)")
        choices = ["(none)"] + [
            f"{m.input_id}: {m.label()}"
            for m in sorted(self.session.mappings.values(), key=lambda m: m.input_id)
        ]
        ttk.Combobox(frame, textvariable=self.wide_var, values=choices,
                     state="readonly", width=22).grid(
            row=2, column=1, columnspan=2, sticky="w", pady=(6, 0))

        ttk.Button(frame, text="Analyze", command=self._analyze).grid(
            row=2, column=5, sticky="e", pady=(6, 0))

    def _wide_input(self) -> int | None:
        text = self.wide_var.get()
        if text and text != "(none)" and ":" in text:
            return int(text.split(":", 1)[0])
        return None

    def _config(self) -> CleanupConfig:
        return CleanupConfig(
            min_shot_seconds=float(self.vars["min_shot_seconds"].get()),
            max_shot_seconds=float(self.vars["max_shot_seconds"].get()),
            accidental_cut_seconds=float(self.vars["accidental_cut_seconds"].get()),
            back_forth_seconds=float(self.vars["back_forth_seconds"].get()),
            repeat_window_seconds=float(self.vars["repeat_window_seconds"].get()),
            repeat_count=int(self.vars["repeat_count"].get()),
            wide_camera_input=self._wide_input(),
        )

    # --------------------------------------------------------------- results

    def _build_results(self) -> None:
        frame = ttk.LabelFrame(self, text="Detected issues", padding=8)
        frame.pack(fill="both", expand=True, padx=10, pady=6)
        self.summary_var = tk.StringVar(value="")
        ttk.Label(frame, textvariable=self.summary_var).pack(anchor="w")

        self.tree = ttk.Treeview(
            frame, columns=("tc", "issue", "camera", "suggestion"),
            show="headings", height=12,
        )
        for col, text, width, stretch in (
            ("tc", "Timecode", 110, False),
            ("issue", "Issue", 150, False),
            ("camera", "Camera", 130, False),
            ("suggestion", "Suggested action", 320, True),
        ):
            self.tree.heading(col, text=text)
            self.tree.column(col, width=width, stretch=stretch)
        self.tree.pack(side="left", fill="both", expand=True, pady=(6, 0))
        scroll = ttk.Scrollbar(frame, orient="vertical", command=self.tree.yview)
        scroll.pack(side="left", fill="y", pady=(6, 0))
        self.tree.configure(yscrollcommand=scroll.set)
        for severity, color in _SEVERITY_COLOR.items():
            self.tree.tag_configure(severity, foreground=color)

    def _analyze(self) -> None:
        try:
            config = self._config()
        except ValueError as exc:
            messagebox.showerror(APP_NAME, str(exc), parent=self)
            return
        self.result = analyze(self.session, config)
        self.tree.delete(*self.tree.get_children())
        for issue in self.result.issues:
            self.tree.insert(
                "", "end",
                values=(issue.timecode, issue.title, issue.camera, issue.suggestion),
                tags=(issue.severity,),
            )
        counts = self.result.issues_by_type()
        summary = f"{len(self.result.issues)} issue(s)"
        if counts:
            summary += "  —  " + ", ".join(f"{k}: {v}" for k, v in sorted(counts.items()))
        self.summary_var.set(summary)

    # --------------------------------------------------------------- exports

    def _build_exports(self) -> None:
        frame = ttk.Frame(self, padding=(10, 0, 10, 10))
        frame.pack(fill="x")
        ttk.Button(frame, text="Save Report…",
                   command=self._save_report).pack(side="left")
        ttk.Button(frame, text="Export Markers (FCPXML)…",
                   command=self._save_markers).pack(side="left", padx=6)
        ttk.Button(frame, text="Export Cleaned Timeline (FCPXML)…",
                   command=self._save_cleaned).pack(side="left")
        ttk.Button(frame, text="Close", command=self.destroy).pack(side="right")
        ttk.Label(
            frame,
            text="Originals are never modified.",
            foreground="#555",
        ).pack(side="right", padx=10)

    def _ensure_result(self) -> bool:
        if self.result is None:
            self._analyze()
        return self.result is not None

    def _save_report(self) -> None:
        if not self._ensure_result():
            return
        path = filedialog.asksaveasfilename(
            parent=self, defaultextension=".txt",
            initialfile=self.default_stem + "-cleanup.txt",
            filetypes=[("Text report", "*.txt"), ("CSV", "*.csv")],
        )
        if not path:
            return
        text = render_csv(self.result) if path.lower().endswith(".csv") \
            else render_text(self.result)
        Path(path).write_text(text, encoding="utf-8")
        messagebox.showinfo(APP_NAME, f"Report saved:\n{path}", parent=self)

    def _save_markers(self) -> None:
        if not self._ensure_result():
            return
        if not self.result.issues:
            messagebox.showinfo(APP_NAME, "No issues to mark.", parent=self)
            return
        path = filedialog.asksaveasfilename(
            parent=self, defaultextension=".fcpxml",
            initialfile=self.default_stem + "-markers.fcpxml",
            filetypes=[("Final Cut Pro XML", "*.fcpxml")],
        )
        if not path:
            return
        Path(path).write_text(export_markers_fcpxml(self.result), encoding="utf-8")
        messagebox.showinfo(APP_NAME, f"Markers timeline saved:\n{path}", parent=self)

    def _save_cleaned(self) -> None:
        if not self._ensure_result():
            return
        path = filedialog.asksaveasfilename(
            parent=self, defaultextension=".fcpxml",
            initialfile=self.default_stem + "-cleaned.fcpxml",
            filetypes=[("Final Cut Pro XML", "*.fcpxml")],
        )
        if not path:
            return
        xml, clean = export_cleaned_fcpxml(self.result)
        Path(path).write_text(xml, encoding="utf-8")
        messagebox.showinfo(
            APP_NAME,
            f"Cleaned timeline saved:\n{path}\n\n"
            f"{clean.removed_count} accidental cut(s) removed, "
            f"{clean.merged_count} redundant cut(s) collapsed.\n"
            "The original log and XML are unchanged.",
            parent=self,
        )
