"""Switcher backends.

Every backend speaks the same tiny event vocabulary so the app, the CLI and
the tests are identical whether they talk to a real ATEM (via the official
Blackmagic SDK) or to the built-in simulator (test mode).

Events delivered to the listener (all called from a background thread):

* ``on_connected(product_name, inputs)`` — ``inputs`` maps input id -> label.
* ``on_program_changed(input_id, monotonic_time, transition, transition_frames)``
  — Program bus changed on M/E 1. ``monotonic_time`` is ``time.monotonic()``
  captured *inside* the device callback, so UI latency never skews logged cut
  times. Fired for CUT and at AUTO-transition completion; never for Preview
  changes. ``transition`` names the style ("cut" for a hard cut, otherwise
  "mix"/"dip"/"wipe"/"dve"/"sting") and ``transition_frames`` its length, so
  exports can place the blend rather than pretending it was a cut.
* ``on_macros(macros)`` — the switcher's macro list, once, after connecting.
* ``on_disconnected(reason)``
* ``on_error(message)``
"""

from __future__ import annotations

from typing import Callable, Mapping, Protocol


class SwitcherListener(Protocol):
    def on_connected(self, product_name: str, inputs: Mapping[int, str], program: int) -> None: ...
    def on_program_changed(self, input_id: int, monotonic_time: float,
                           transition: str = "cut",
                           transition_frames: int = 0) -> None: ...
    def on_macros(self, macros: list) -> None: ...
    def on_disconnected(self, reason: str) -> None: ...
    def on_error(self, message: str) -> None: ...


class SwitcherBackend:
    """Base class; concrete backends override connect/disconnect."""

    def __init__(self, listener: SwitcherListener):
        self.listener = listener

    def connect(self, address: str) -> None:
        raise NotImplementedError

    def disconnect(self) -> None:
        raise NotImplementedError

    def run_macro(self, index: int) -> None:
        """Run a switcher macro. Backends without macro support say so."""
        raise RuntimeError("This connection can't run macros.")

    def get_current_timecode(self, timeout: float = 1.0):
        """Read the switcher's own timecode generator right now.

        Returns ``(timecode_str, drop_frame)`` or ``None`` if unsupported (the
        default) or unavailable within ``timeout`` seconds. Used to auto-fill
        Start Timecode from the switcher's free-run/time-of-day generator
        instead of the operator typing it — never required, never blocking
        more than ``timeout``.
        """
        return None


def create_backend(kind: str, listener: SwitcherListener) -> SwitcherBackend:
    """Factory: ``simulator`` always works; ``atem`` picks the platform backend."""
    if kind == "simulator":
        from .simulator import SimulatorBackend

        return SimulatorBackend(listener)
    if kind == "atem":
        import sys

        if sys.platform == "win32":
            from .windows_com import WindowsComBackend

            return WindowsComBackend(listener)
        if sys.platform == "darwin":
            from .mac_bridge import MacBridgeBackend

            return MacBridgeBackend(listener)
        raise RuntimeError(
            "The Blackmagic ATEM SDK is only available on Windows and macOS. "
            "Use Test Mode (simulator) on this platform."
        )
    raise ValueError(f"Unknown backend '{kind}'.")
