"""macOS backend — talks to the official Blackmagic SDK via ``atem-bridge``.

The bridge (see ``bridge/mac``) is a small C++ helper compiled against
Blackmagic's ``BMDSwitcherAPI.h``. It emits newline-delimited JSON events;
this backend spawns it, timestamps each event on receipt with
``time.monotonic()`` and forwards them to the listener.

The helper is found via (in order): the ``ATEM_BRIDGE`` environment variable,
``bridge/mac/atem-bridge`` in the repo, or ``atem-bridge`` on ``PATH``.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import threading
import time
from pathlib import Path

from . import SwitcherBackend

_CONNECT_TIMEOUT = 15.0


def _find_bridge() -> str:
    env = os.environ.get("ATEM_BRIDGE")
    if env and Path(env).is_file():
        return env
    repo_binary = Path(__file__).resolve().parents[2] / "bridge" / "mac" / "atem-bridge"
    if repo_binary.is_file():
        return str(repo_binary)
    on_path = shutil.which("atem-bridge")
    if on_path:
        return on_path
    raise RuntimeError(
        "The atem-bridge helper was not found. Build it first:\n"
        "    cd bridge/mac && make\n"
        "(requires the Blackmagic ATEM Switchers SDK — see bridge/mac/README.md)"
    )


class MacBridgeBackend(SwitcherBackend):
    def __init__(self, listener):
        super().__init__(listener)
        self._process: subprocess.Popen | None = None
        self._thread: threading.Thread | None = None
        self._stopping = False
        self._tc_event = threading.Event()
        self._tc_result: tuple[str, bool] | None = None
        # The bridge reports a transition's style and length when it starts;
        # the Program change that ends it arrives separately, so the pending
        # description is held here until that change lands.
        self._pending_transition: tuple[str, int] | None = None

    def connect(self, address: str) -> None:
        if not address:
            raise RuntimeError("An ATEM IP address is required.")
        bridge = _find_bridge()
        self._stopping = False
        self._process = subprocess.Popen(
            [bridge, address],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            bufsize=1,
        )
        self._thread = threading.Thread(
            target=self._read_events, name="atem-bridge-reader", daemon=True
        )
        self._thread.start()

    def disconnect(self) -> None:
        self._stopping = True
        process, self._process = self._process, None
        if process:
            try:
                if process.stdin:
                    process.stdin.write("quit\n")
                    process.stdin.flush()
                process.wait(timeout=3)
            except (OSError, subprocess.TimeoutExpired):
                process.kill()
        if self._thread:
            self._thread.join(timeout=3)
            self._thread = None

    def run_macro(self, index: int) -> None:
        process = self._process
        if process is None or process.stdin is None:
            raise RuntimeError("Not connected to a switcher.")
        try:
            process.stdin.write(f"macro {int(index)}\n")
            process.stdin.flush()
        except (OSError, ValueError) as exc:
            raise RuntimeError(f"Could not run macro {index}: {exc}") from exc

    def get_current_timecode(self, timeout: float = 1.0):
        process = self._process
        if process is None or process.stdin is None:
            return None
        self._tc_event.clear()
        self._tc_result = None
        try:
            process.stdin.write("tc\n")
            process.stdin.flush()
        except (OSError, ValueError):
            return None
        if self._tc_event.wait(timeout):
            return self._tc_result
        return None

    # ------------------------------------------------------------- internals

    def _read_events(self) -> None:
        process = self._process
        if process is None or process.stdout is None:
            return
        pending: dict[str, object] | None = None  # buffered "connected" event
        inputs: dict[int, str] = {}
        connected = False
        deadline = time.monotonic() + _CONNECT_TIMEOUT

        for line in process.stdout:
            now = time.monotonic()  # timestamp first, parse after
            line = line.strip()
            if not line:
                continue
            try:
                msg = json.loads(line)
            except json.JSONDecodeError:
                continue

            kind = msg.get("type")
            if kind == "connected":
                pending = msg
            elif kind == "input":
                inputs[int(msg["id"])] = str(msg.get("name", ""))
            elif kind == "inputs_done":
                if pending is not None:
                    self.listener.on_connected(
                        str(pending.get("product", "ATEM")),
                        dict(inputs),
                        int(pending.get("program", 0)),
                    )
                    connected = True
                    pending = None
            elif kind == "program":
                if pending is not None:
                    # Input enumeration got interrupted; connect anyway.
                    self.listener.on_connected(
                        str(pending.get("product", "ATEM")),
                        dict(inputs),
                        int(pending.get("program", 0)),
                    )
                    connected = True
                    pending = None
                transition, frames = self._pending_transition or ("cut", 0)
                self._pending_transition = None
                self.listener.on_program_changed(
                    int(msg["input"]), now, transition, frames
                )
            elif kind == "transition":
                # Start of an AUTO transition. Its completion arrives as the
                # next "program" event, which is what actually gets logged.
                if msg.get("in_transition"):
                    self._pending_transition = (
                        str(msg.get("style", "mix")), int(msg.get("frames", 0))
                    )
            elif kind == "macros":
                macros = [
                    {"index": int(m.get("index", i)), "name": str(m.get("name", ""))}
                    for i, m in enumerate(msg.get("macros") or [])
                ]
                on_macros = getattr(self.listener, "on_macros", None)
                if on_macros:
                    on_macros(macros)
            elif kind == "timecode":
                tc = msg.get("timecode")
                self._tc_result = (tc, bool(msg.get("drop_frame"))) if tc else None
                self._tc_event.set()
            elif kind == "disconnected":
                if not self._stopping:
                    self.listener.on_disconnected("Switcher connection lost")
                connected = True  # suppress the exit-code error below
                break
            elif kind == "error":
                self.listener.on_error(str(msg.get("message", "Unknown bridge error")))
                connected = True  # error already surfaced
                break
            if not connected and pending is None and now > deadline:
                break

        process.stdout.close()
        code = process.wait()
        if self._stopping:
            self.listener.on_disconnected("Disconnected by user")
        elif not connected:
            self.listener.on_error(
                f"atem-bridge exited (code {code}) before connecting. "
                "Is ATEM Software Control installed and the IP correct?"
            )
