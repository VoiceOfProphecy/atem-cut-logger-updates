"""Test mode: simulates an ATEM's Program bus without any hardware.

Behaviour mirrors the real SDK backends closely enough to exercise every code
path the app has:

* random CUTs and AUTO transitions (the AUTO notification is delayed by the
  transition duration, matching the real switcher, which changes Program only
  at transition *completion*);
* occasional redundant notifications for the already-live source, to prove
  duplicate suppression works;
* Preview-bus churn happens internally and is (correctly) never reported.

Manual switching is available too — the GUI shows a row of cut buttons wired
to :meth:`SimulatorBackend.cut_to`.
"""

from __future__ import annotations

import random
import threading
import time

from . import SwitcherBackend

INPUTS = {i: f"Camera {i}" for i in range(1, 9)}
PRODUCT = "ATEM Simulator (Test Mode)"


class SimulatorBackend(SwitcherBackend):
    def __init__(self, listener, auto_switch: bool = True, seed: int | None = None):
        super().__init__(listener)
        self.auto_switch = auto_switch
        self._rng = random.Random(seed)
        self._program = 1
        self._preview = 2
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    # ------------------------------------------------------------- lifecycle

    def connect(self, address: str) -> None:
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._run, name="atem-simulator", daemon=True
        )
        self._thread.start()

    def disconnect(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2)
            self._thread = None
        self.listener.on_disconnected("Test mode stopped")

    # ------------------------------------------------------- manual control

    def cut_to(self, input_id: int) -> None:
        """Immediate CUT — safe to call from any thread (e.g. GUI buttons)."""
        self._set_program(input_id)

    def _set_program(self, input_id: int) -> None:
        with self._lock:
            self._program = input_id
        # Real backends notify even when the source did not change (state
        # sync); we do the same so dedup logic is genuinely exercised.
        self.listener.on_program_changed(input_id, time.monotonic())

    # ------------------------------------------------------------- internals

    def _run(self) -> None:
        self.listener.on_connected(PRODUCT, dict(INPUTS), self._program)
        while not self._stop.wait(timeout=self._rng.uniform(2.0, 7.0)):
            if not self.auto_switch:
                continue
            roll = self._rng.random()
            with self._lock:
                program = self._program
            if roll < 0.10:
                # Redundant notification: same source again.
                self._set_program(program)
            else:
                choices = [i for i in INPUTS if i != program]
                target = self._rng.choice(choices)
                self._preview = target
                if roll < 0.40:
                    # AUTO transition: Program changes at completion.
                    duration = self._rng.uniform(0.5, 1.5)
                    if self._stop.wait(timeout=duration):
                        break
                self._set_program(target)
