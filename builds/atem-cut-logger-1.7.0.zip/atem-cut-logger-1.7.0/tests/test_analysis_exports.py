import copy
import unittest
import xml.etree.ElementTree as ET

from atem_cut_logger.analysis import CleanupConfig, analyze
from atem_cut_logger.analysis.cleaned import build_cleaned_session, export_cleaned_fcpxml
from atem_cut_logger.analysis.markers import export_markers_fcpxml
from atem_cut_logger.analysis.report import render_csv, render_text
from tests.test_analysis_rules import make_session


def parse(xml):
    return ET.fromstring(xml.split("<!DOCTYPE fcpxml>")[1])


class Report(unittest.TestCase):
    def setUp(self):
        self.session = make_session(
            [(0, 1), (100, 2), (110, 1), (400, 2)], end_frame=600,
            names={1: "CAM 1 Wide", 2: "CAM 2 Tight"},
        )
        self.result = analyze(self.session, CleanupConfig(wide_camera_input=1))

    def test_text_report_has_key_sections(self):
        text = render_text(self.result)
        self.assertIn("Smart Cleanup Report", text)
        self.assertIn("Camera screen time:", text)
        self.assertIn("CAM 1 Wide", text)
        self.assertIn("Accidental cut", text)
        # every issue's timecode appears
        for issue in self.result.issues:
            self.assertIn(issue.timecode, text)

    def test_csv_columns_and_rows(self):
        rows = render_csv(self.result).strip().splitlines()
        self.assertEqual(
            rows[0],
            "timecode,issue_type,issue,severity,camera,atem_input,detail,suggested_action",
        )
        self.assertEqual(len(rows) - 1, len(self.result.issues))

    def test_clean_report_when_no_issues(self):
        session = make_session([(0, 1), (200, 2)], end_frame=400)
        result = analyze(session, CleanupConfig())
        self.assertIn("No issues detected", render_text(result))


class Markers(unittest.TestCase):
    def test_marker_per_issue_at_correct_timeline_position(self):
        session = make_session([(0, 1), (100, 2), (110, 1)], end_frame=200)
        result = analyze(session, CleanupConfig())
        xml = export_markers_fcpxml(result)
        root = parse(xml)
        markers = root.findall(".//spine/asset-clip/marker")
        self.assertEqual(len(markers), len(result.issues))
        self.assertTrue(result.issues)

        # The accidental cut at frame 100 (source-in == 100 in default ISO mode)
        # must produce a marker whose start rational equals 100 frames.
        num, den = 100, 2500  # 25 fps frame duration
        starts = {m.get("start") for m in markers}
        self.assertIn(f"{100 * num}/{den}s", starts)

    def test_markers_export_still_valid_timeline(self):
        session = make_session([(0, 1), (100, 2), (110, 1)], end_frame=200)
        result = analyze(session, CleanupConfig())
        root = parse(export_markers_fcpxml(result))
        # timeline clips are unchanged in count vs a plain export
        self.assertEqual(len(root.findall(".//spine/asset-clip")), 3)


class Cleaned(unittest.TestCase):
    def test_removes_only_accidental_cuts(self):
        # cam2 at 100 lasts 10 frames (0.4s) -> accidental; cam1 resumes at 110
        session = make_session([(0, 1), (100, 2), (110, 1), (400, 2)], end_frame=600)
        result = analyze(session, CleanupConfig())
        xml, clean = export_cleaned_fcpxml(result)
        self.assertEqual(clean.removed_count, 1)
        self.assertEqual(clean.removed_frames, [100])
        # The blip and its redundant return-cut both vanish: cam1 now runs 0..400
        inputs = [e.input_id for e in clean.session.events]
        self.assertEqual(inputs, [1, 2])
        self.assertEqual(clean.session.events[1].frame, 400)

    def test_original_session_not_mutated(self):
        session = make_session([(0, 1), (100, 2), (110, 1), (400, 2)], end_frame=600)
        before = copy.deepcopy(session)
        result = analyze(session, CleanupConfig())
        build_cleaned_session(session, result.config)
        self.assertEqual([e.frame for e in session.events],
                         [e.frame for e in before.events])
        self.assertEqual([e.input_id for e in session.events],
                         [e.input_id for e in before.events])

    def test_nothing_removed_when_no_accidental(self):
        session = make_session([(0, 1), (200, 2), (400, 1)], end_frame=600)
        result = analyze(session, CleanupConfig())
        _xml, clean = export_cleaned_fcpxml(result)
        self.assertEqual(clean.removed_count, 0)
        self.assertEqual(len(clean.session.events), 3)

    def test_consecutive_accidental_blips_collapse(self):
        # two back-to-back sub-0.5s blips between cam1 spans
        session = make_session([(0, 1), (100, 2), (105, 3), (110, 1)], end_frame=400)
        result = analyze(session, CleanupConfig())
        _xml, clean = export_cleaned_fcpxml(result)
        self.assertEqual([e.input_id for e in clean.session.events], [1])
        self.assertEqual(clean.removed_count, 2)


if __name__ == "__main__":
    unittest.main()
