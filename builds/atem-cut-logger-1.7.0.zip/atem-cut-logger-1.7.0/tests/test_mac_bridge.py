"""Exercises MacBridgeBackend against a fake atem-bridge executable.

The real bridge needs macOS + the Blackmagic SDK; the JSON-line protocol is
platform-independent, so we validate the Python side with a stand-in script.
"""

import os
import queue
import stat
import sys
import tempfile
import time
import unittest
from pathlib import Path

from atem_cut_logger.backends.mac_bridge import MacBridgeBackend

FAKE_BRIDGE = """#!{python}
import sys, time
def emit(line):
    print(line, flush=True)
mode = sys.argv[1]
if mode == "10.0.0.99":
    emit('{{"type":"error","message":"Could not connect: no response"}}')
    sys.exit(1)
emit('{{"type":"connected","product":"Fake ATEM","program":1}}')
emit('{{"type":"input","id":1,"name":"Camera 1"}}')
emit('{{"type":"input","id":2,"name":"Camera 2"}}')
emit('{{"type":"inputs_done"}}')
time.sleep(0.15)
emit('{{"type":"program","input":2}}')
emit('{{"type":"program","input":2}}')
time.sleep(0.1)
emit('{{"type":"program","input":1}}')
for line in sys.stdin:
    cmd = line.strip()
    if cmd == "quit":
        break
    if cmd == "tc":
        emit('{{"type":"timecode","timecode":"12:34:56:07","drop_frame":false}}')
"""


class Listener:
    def __init__(self):
        self.q = queue.Queue()

    def on_connected(self, product, inputs, program):
        self.q.put(("connected", product, inputs, program))

    def on_program_changed(self, input_id, t, transition="cut", transition_frames=0):
        self.q.put(("program", input_id, t, transition, transition_frames))

    def on_disconnected(self, reason):
        self.q.put(("disconnected", reason))

    def on_error(self, message):
        self.q.put(("error", message))

    def on_macros(self, macros):
        self.q.put(("macros", macros))


class MacBridgeProtocol(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        bridge = Path(self.tmp.name) / "fake-bridge"
        bridge.write_text(FAKE_BRIDGE.format(python=sys.executable))
        bridge.chmod(bridge.stat().st_mode | stat.S_IEXEC)
        os.environ["ATEM_BRIDGE"] = str(bridge)

    def tearDown(self):
        os.environ.pop("ATEM_BRIDGE", None)
        self.tmp.cleanup()

    def drain(self, listener, n, timeout=5.0):
        out = []
        deadline = time.monotonic() + timeout
        while len(out) < n and time.monotonic() < deadline:
            try:
                out.append(listener.q.get(timeout=0.2))
            except queue.Empty:
                pass
        return out

    def test_full_session(self):
        listener = Listener()
        backend = MacBridgeBackend(listener)
        backend.connect("192.168.1.50")
        events = self.drain(listener, 4)
        self.assertEqual(events[0][0], "connected")
        self.assertEqual(events[0][1], "Fake ATEM")
        self.assertEqual(events[0][2], {1: "Camera 1", 2: "Camera 2"})
        self.assertEqual(events[0][3], 1)
        # program events preserved in order (duplicates forwarded; the
        # session layer is responsible for suppression)
        self.assertEqual([e[1] for e in events[1:4]], [2, 2, 1])
        self.assertLess(events[1][2], events[3][2])  # monotonic timestamps
        backend.disconnect()
        final = self.drain(listener, 1)
        self.assertEqual(final[0], ("disconnected", "Disconnected by user"))

    def test_get_current_timecode_round_trip(self):
        listener = Listener()
        backend = MacBridgeBackend(listener)
        backend.connect("192.168.1.50")
        self.drain(listener, 4)  # let it finish connecting first
        result = backend.get_current_timecode(timeout=3.0)
        self.assertEqual(result, ("12:34:56:07", False))
        backend.disconnect()

    def test_get_current_timecode_none_when_not_connected(self):
        backend = MacBridgeBackend(Listener())
        self.assertIsNone(backend.get_current_timecode(timeout=0.2))

    def test_connect_error_surfaces(self):
        listener = Listener()
        backend = MacBridgeBackend(listener)
        backend.connect("10.0.0.99")
        events = self.drain(listener, 1)
        self.assertEqual(events[0][0], "error")
        self.assertIn("no response", events[0][1])
        backend.disconnect()


if __name__ == "__main__":
    unittest.main()


class TransitionAndMacroProtocol(unittest.TestCase):
    """The bridge reports a transition's style before the Program change that
    completes it, and a macro list after connecting."""

    BRIDGE = """#!{python}
import sys, time
def emit(line):
    print(line, flush=True)
emit('{{"type":"connected","product":"Fake ATEM","program":1}}')
emit('{{"type":"input","id":1,"name":"Camera 1"}}')
emit('{{"type":"inputs_done"}}')
emit('{{"type":"macros","macros":[{{"index":0,"name":"Lower third"}}]}}')
emit('{{"type":"transition","in_transition":true,"style":"mix","frames":50}}')
time.sleep(0.05)
emit('{{"type":"program","input":2}}')
time.sleep(0.05)
emit('{{"type":"program","input":1}}')
for line in sys.stdin:
    cmd = line.strip()
    if cmd == "quit":
        break
    if cmd.startswith("macro "):
        emit('{{"type":"macro_run","index":%s}}' % cmd.split()[1])
"""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        path = Path(self.tmp.name) / "atem-bridge"
        path.write_text(self.BRIDGE.format(python=sys.executable))
        path.chmod(path.stat().st_mode | stat.S_IEXEC)
        os.environ["ATEM_BRIDGE"] = str(path)
        self.addCleanup(os.environ.pop, "ATEM_BRIDGE", None)
        self.addCleanup(self.tmp.cleanup)
        self.listener = Listener()
        self.backend = MacBridgeBackend(self.listener)
        self.addCleanup(self.backend.disconnect)

    def _drain(self, count, timeout=5.0):
        out = []
        deadline = time.monotonic() + timeout
        while len(out) < count and time.monotonic() < deadline:
            try:
                out.append(self.listener.q.get(timeout=0.2))
            except queue.Empty:
                pass
        return out

    def test_transition_is_attached_to_the_program_change_it_completes(self):
        self.backend.connect("10.0.0.1")
        events = self._drain(4)
        programs = [e for e in events if e[0] == "program"]
        self.assertEqual(programs[0][1], 2)
        self.assertEqual(programs[0][3], "mix")
        self.assertEqual(programs[0][4], 50)
        # The transition applies once: the next change is a plain cut.
        self.assertEqual(programs[1][3], "cut")
        self.assertEqual(programs[1][4], 0)

    def test_macro_list_reaches_the_listener(self):
        self.backend.connect("10.0.0.1")
        events = self._drain(4)
        macros = [e for e in events if e[0] == "macros"]
        self.assertEqual(macros[0][1], [{"index": 0, "name": "Lower third"}])

    def test_run_macro_needs_a_connection(self):
        with self.assertRaises(RuntimeError):
            self.backend.run_macro(0)
