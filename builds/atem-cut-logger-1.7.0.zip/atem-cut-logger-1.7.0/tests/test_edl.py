"""CMX3600 EDL export.

An EDL is read by machines that are fussy about column layout, so these tests
pin the shape as much as the content: the header, the event line, and that a
shot's record timecodes match the FCPXML timeline the same log produces.
"""

import unittest

from atem_cut_logger.edl import export_edl, reel_name
from atem_cut_logger.session import CameraMapping, LogSession


def session_with_cuts(rate_key="25", drop_frame=False, start="01:00:00:00"):
    s = LogSession(rate_key=rate_key, drop_frame=drop_frame, start_timecode=start)
    s.name = "TVTL 01-08"
    s.mappings = {
        1: CameraMapping(1, "CAM 1 Wide", "/media/cam1.mov"),
        2: CameraMapping(2, "CAM 2 Close"),
    }
    s.begin()
    s.add_program_change(1, 0.0)
    s.add_program_change(2, 4.0)
    s.add_program_change(1, 10.0)
    s.end(20.0)
    return s


class EdlTest(unittest.TestCase):
    def test_header_names_the_session_and_frame_mode(self):
        text = export_edl(session_with_cuts())
        lines = text.splitlines()
        self.assertEqual(lines[0], "TITLE:   TVTL 01-08")
        self.assertEqual(lines[1], "FCM: NON-DROP FRAME")

    def test_drop_frame_sessions_say_so(self):
        s = session_with_cuts(rate_key="29.97", drop_frame=True)
        self.assertIn("FCM: DROP FRAME", export_edl(s))

    def test_one_event_per_shot_numbered_from_one(self):
        text = export_edl(session_with_cuts())
        events = [ln for ln in text.splitlines() if ln[:3].isdigit()]
        self.assertEqual(len(events), 3)
        self.assertTrue(events[0].startswith("001  "))
        self.assertTrue(events[2].startswith("003  "))

    def test_event_line_carries_reel_track_transition_and_four_timecodes(self):
        text = export_edl(session_with_cuts())
        first = [ln for ln in text.splitlines() if ln.startswith("001")][0]
        parts = first.split()
        self.assertEqual(parts[1], "CAM1WIDE")     # 8-char reel
        self.assertEqual(parts[2], "V")            # video only
        self.assertEqual(parts[3], "C")            # cut
        self.assertEqual(parts[4:], ["01:00:00:00", "01:00:04:00",
                                     "01:00:00:00", "01:00:04:00"])

    def test_clip_name_and_iso_path_ride_along_as_comments(self):
        text = export_edl(session_with_cuts())
        self.assertIn("* FROM CLIP NAME: CAM 1 Wide", text)
        self.assertIn("* SOURCE FILE: /media/cam1.mov", text)
        # CAM 2 has no ISO file, so no source line is invented for it.
        self.assertNotIn("* SOURCE FILE: CAM 2", text)

    def test_reel_names_are_eight_chars_and_never_empty(self):
        s = LogSession()
        s.mappings = {1: CameraMapping(1, "A really long camera name"),
                      2: CameraMapping(2, "!!!")}
        self.assertEqual(reel_name(s, 1), "AREALLYL")
        self.assertEqual(reel_name(s, 2), "INPUT2"[:8])
        self.assertEqual(reel_name(s, 9), "INPUT9")  # unmapped input

    def test_flags_and_notes_are_preserved_as_comments(self):
        s = session_with_cuts()
        s.add_error_flag(5.0, "audio dropout")
        s.add_note(7.0, "lower third")
        text = export_edl(s)
        self.assertIn("* ERROR FLAG AT 01:00:05:00: audio dropout", text)
        self.assertIn("* NOTE AT 01:00:07:00: lower third", text)

    def test_empty_log_is_refused(self):
        with self.assertRaises(ValueError):
            export_edl(LogSession())

    def test_last_shot_runs_to_the_session_duration(self):
        text = export_edl(session_with_cuts())
        last = [ln for ln in text.splitlines() if ln.startswith("003")][0]
        self.assertTrue(last.endswith("01:00:20:00"))


if __name__ == "__main__":
    unittest.main()


class EdlTransitionTest(unittest.TestCase):
    """A logged dissolve must export as a real dissolve, positioned where the
    blend actually began — the switcher reports the frame it *finished*."""

    def _session(self):
        s = LogSession(rate_key="25", start_timecode="01:00:00:00")
        s.mappings = {1: CameraMapping(1, "CAM 1"), 2: CameraMapping(2, "CAM 2")}
        s.begin()
        s.add_program_change(1, 0.0)
        s.add_program_change(2, 10.0, "mix", 50)   # 2 s dissolve at 25 fps
        s.end(20.0)
        return s

    def test_dissolve_emits_a_D_event_with_its_length(self):
        text = export_edl(self._session())
        dissolves = [ln for ln in text.splitlines() if " D " in ln]
        self.assertEqual(len(dissolves), 1)
        self.assertIn("D    050", dissolves[0])
        self.assertIn("CAM2", dissolves[0])

    def test_dissolve_starts_where_the_blend_began(self):
        text = export_edl(self._session())
        dissolve = [ln for ln in text.splitlines() if " D " in ln][0]
        # Program change logged at 10 s; a 2 s blend began at 8 s.
        self.assertIn("01:00:08:00", dissolve)

    def test_outgoing_reel_gets_the_zero_length_cut_event(self):
        lines = export_edl(self._session()).splitlines()
        idx = next(i for i, ln in enumerate(lines) if " D " in ln)
        outgoing = lines[idx - 1]
        self.assertIn("CAM1", outgoing)
        self.assertIn(" C ", outgoing)
        self.assertEqual(outgoing.split()[4:], ["01:00:08:00"] * 4)

    def test_the_style_is_named_in_a_comment(self):
        self.assertIn("* EFFECT NAME: CROSS DISSOLVE (mix)", export_edl(self._session()))

    def test_hard_cuts_are_unaffected(self):
        s = self._session()
        s.events[1].transition = "cut"
        s.events[1].transition_frames = 0
        text = export_edl(s)
        self.assertNotIn(" D ", text)
        self.assertIn("01:00:10:00", text)
