import json
import unittest

from atem_cut_logger.session import CameraMapping, LogSession


def make_session(**kwargs):
    session = LogSession(
        rate_key=kwargs.pop("rate_key", "29.97"),
        drop_frame=kwargs.pop("drop_frame", True),
        start_timecode=kwargs.pop("start_timecode", "01:00:00;00"),
        **kwargs,
    )
    session.mappings = {
        1: CameraMapping(1, "CAM 1 Wide", "/iso/cam1.mov"),
        2: CameraMapping(2, "CAM 2 Tight", "/iso/cam2.mov"),
        3: CameraMapping(3, "", "/iso/cam3.mov"),
    }
    session.begin()
    return session


class Logging(unittest.TestCase):
    def test_initial_program_and_changes(self):
        s = make_session()
        first = s.add_program_change(1, 0.0)
        self.assertIsNotNone(first)
        self.assertEqual(first.timecode, "01:00:00;00")
        self.assertEqual(first.camera, "CAM 1 Wide")

        e = s.add_program_change(2, 5.0)
        self.assertEqual(e.input_id, 2)
        self.assertEqual(e.frame, 150)  # 5s * 29.97 = 149.85 -> 150

        unmapped = s.add_program_change(3, 6.0)
        self.assertEqual(unmapped.camera, "Input 3")

    def test_duplicate_program_suppressed(self):
        s = make_session()
        s.add_program_change(1, 0.0)
        self.assertIsNone(s.add_program_change(1, 2.0))
        s.add_program_change(2, 3.0)
        self.assertIsNone(s.add_program_change(2, 3.5))
        self.assertEqual(len(s.events), 2)

    def test_two_cuts_in_same_frame_keep_later_source(self):
        s = make_session(rate_key="25", drop_frame=False, start_timecode="00:00:00:00")
        s.add_program_change(1, 0.0)
        s.add_program_change(2, 10.000)
        s.add_program_change(3, 10.010)  # same 25fps frame (frame 250)
        self.assertEqual([e.input_id for e in s.events], [1, 3])
        self.assertEqual(s.events[-1].frame, 250)

    def test_same_frame_bounce_back_collapses_to_nothing(self):
        s = make_session(rate_key="25", drop_frame=False, start_timecode="00:00:00:00")
        s.add_program_change(1, 0.0)
        s.add_program_change(2, 10.000)
        s.add_program_change(1, 10.010)  # back to 1 within the same frame
        self.assertEqual([e.input_id for e in s.events], [1])

    def test_end_never_before_last_event(self):
        s = make_session()
        s.add_program_change(1, 0.0)
        s.add_program_change(2, 12.0)
        s.end(11.0)  # clock skew: stop reported before last event
        self.assertGreaterEqual(s.duration_frames, s.events[-1].frame + 1)


class ResyncTimecodes(unittest.TestCase):
    def test_corrects_stale_timecodes_after_start_timecode_fix(self):
        # e.g. a typo'd Start Timecode discovered after logging: the operator
        # fixes session.start_timecode post-hoc and expects the log to catch
        # up, not keep showing timecodes computed from the wrong value.
        s = make_session(rate_key="24", drop_frame=False, start_timecode="05:19:30:00")
        s.add_program_change(1, 0.0)
        s.add_program_change(2, 5.0)
        self.assertEqual(s.events[0].timecode, "05:19:30:00")
        self.assertEqual(s.events[1].timecode, "05:19:35:00")

        s.start_timecode = "05:24:54:10"
        s.resync_event_timecodes()

        self.assertEqual(s.events[0].timecode, "05:24:54:10")
        self.assertEqual(s.events[1].timecode, "05:24:59:10")
        # Relative positions are untouched — only the absolute label moves.
        self.assertEqual(s.events[1].frame - s.events[0].frame, 5 * 24)

    def test_resync_reflects_rate_and_drop_frame_changes_too(self):
        s = make_session(rate_key="24", drop_frame=False, start_timecode="01:00:00:00")
        s.add_program_change(1, 0.0)
        s.rate_key = "29.97"
        s.drop_frame = True
        s.resync_event_timecodes()
        self.assertEqual(s.events[0].timecode, "01:00:00;00")

    def test_noop_with_no_events(self):
        s = make_session()
        s.resync_event_timecodes()  # must not raise on an empty log


class ErrorFlags(unittest.TestCase):
    def test_add_flag_records_timecode_and_note(self):
        s = make_session(rate_key="24", drop_frame=False, start_timecode="01:00:00:00")
        s.add_program_change(1, 0.0)
        flag = s.add_error_flag(3.5, note="  feed died  ")
        self.assertEqual(flag.timecode, "01:00:03:12")
        self.assertEqual(flag.note, "feed died")  # trimmed
        self.assertEqual(s.flags, [flag])

    def test_remove_flag(self):
        s = make_session()
        s.add_program_change(1, 0.0)
        s.add_error_flag(1.0, "a")
        s.add_error_flag(2.0, "b")
        s.remove_flag(0)
        self.assertEqual([f.note for f in s.flags], ["b"])

    def test_remove_flag_bad_index_raises(self):
        s = make_session()
        with self.assertRaises(IndexError):
            s.remove_flag(0)

    def test_set_flag_note(self):
        s = make_session()
        s.add_program_change(1, 0.0)
        s.add_error_flag(1.0)
        s.set_flag_note(0, "  wrong camera  ")
        self.assertEqual(s.flags[0].note, "wrong camera")

    def test_begin_clears_flags(self):
        s = make_session()
        s.add_program_change(1, 0.0)
        s.add_error_flag(1.0, "leftover")
        s.begin()
        self.assertEqual(s.flags, [])

    def test_resync_event_timecodes_also_resyncs_flags(self):
        s = make_session(rate_key="24", drop_frame=False, start_timecode="05:19:30:00")
        s.add_program_change(1, 0.0)
        s.add_error_flag(5.0)
        self.assertEqual(s.flags[0].timecode, "05:19:35:00")
        s.start_timecode = "05:24:54:10"
        s.resync_event_timecodes()
        self.assertEqual(s.flags[0].timecode, "05:24:59:10")


class Persistence(unittest.TestCase):
    def test_json_round_trip(self):
        s = make_session()
        s.audio_file = "/iso/program_audio.wav"
        s.switcher_product = "ATEM Simulator (Test Mode)"
        s.add_program_change(1, 0.0)
        s.add_program_change(2, 5.5)
        s.end(20.0)

        restored = LogSession.from_json(s.to_json())
        self.assertEqual(restored.rate_key, "29.97")
        self.assertTrue(restored.drop_frame)
        self.assertEqual(restored.start_timecode, "01:00:00;00")
        self.assertEqual(restored.audio_file, "/iso/program_audio.wav")
        self.assertEqual(len(restored.events), 2)
        self.assertEqual(restored.events[1].timecode, s.events[1].timecode)
        self.assertEqual(restored.mappings[2].file, "/iso/cam2.mov")
        self.assertEqual(restored.duration, 20.0)

    def test_json_round_trip_includes_flags(self):
        s = make_session()
        s.add_program_change(1, 0.0)
        s.add_error_flag(2.0, "dead feed")

        restored = LogSession.from_json(s.to_json())
        self.assertEqual(len(restored.flags), 1)
        self.assertEqual(restored.flags[0].note, "dead feed")
        self.assertEqual(restored.flags[0].timecode, s.flags[0].timecode)

    def test_loads_older_log_with_no_flags_key(self):
        # A log saved before this feature existed has no "flags" key at all —
        # must still load cleanly with an empty flags list.
        s = make_session()
        s.add_program_change(1, 0.0)
        data = json.loads(s.to_json())
        del data["flags"]
        restored = LogSession.from_json(json.dumps(data))
        self.assertEqual(restored.flags, [])

    def test_csv_output(self):
        s = make_session(rate_key="24", drop_frame=False, start_timecode="00:59:50:00")
        s.add_program_change(1, 0.0)
        s.add_program_change(2, 10.0)
        s.end(15.0)
        lines = s.to_csv().strip().splitlines()
        self.assertEqual(
            lines[0], "event,elapsed_seconds,timecode,atem_input,camera,iso_file,"
            "transition,transition_frames"
        )
        self.assertEqual(lines[1],
                         "1,0.000,00:59:50:00,1,CAM 1 Wide,/iso/cam1.mov,cut,0")
        self.assertEqual(lines[2],
                         "2,10.000,01:00:00:00,2,CAM 2 Tight,/iso/cam2.mov,cut,0")


if __name__ == "__main__":
    unittest.main()


class TransitionEvents(unittest.TestCase):
    """Transitions are recorded alongside the cut they completed."""

    def _session(self):
        s = LogSession(rate_key="25", start_timecode="00:00:00:00")
        s.begin()
        return s

    def test_a_cut_is_the_default_and_carries_no_length(self):
        s = self._session()
        e = s.add_program_change(1, 0.0)
        self.assertEqual(e.transition, "cut")
        self.assertEqual(e.transition_frames, 0)
        self.assertFalse(e.is_transition)

    def test_a_transition_records_its_style_and_length(self):
        s = self._session()
        s.add_program_change(1, 0.0)
        e = s.add_program_change(2, 4.0, "mix", 50)
        self.assertTrue(e.is_transition)
        self.assertEqual(e.transition, "mix")
        self.assertEqual(e.transition_frames, 50)

    def test_the_blend_starts_before_the_logged_frame(self):
        s = self._session()
        s.add_program_change(1, 0.0)
        e = s.add_program_change(2, 4.0, "mix", 50)   # logged at frame 100
        self.assertEqual(e.frame, 100)
        self.assertEqual(e.transition_start_frame, 50)

    def test_a_blend_longer_than_the_show_clamps_to_the_start(self):
        s = self._session()
        e = s.add_program_change(1, 0.0, "mix", 999)
        self.assertEqual(e.transition_start_frame, 0)

    def test_transitions_survive_a_json_round_trip(self):
        s = self._session()
        s.add_program_change(1, 0.0)
        s.add_program_change(2, 4.0, "wipe", 25)
        s.end(10.0)
        loaded = LogSession.from_json(s.to_json())
        self.assertEqual(loaded.events[1].transition, "wipe")
        self.assertEqual(loaded.events[1].transition_frames, 25)

    def test_schema_1_logs_still_load_as_plain_cuts(self):
        s = self._session()
        s.add_program_change(1, 0.0)
        s.end(5.0)
        old = json.loads(s.to_json())
        old["schema"] = 1
        for event in old["events"]:
            event.pop("transition", None)
            event.pop("transition_frames", None)
        loaded = LogSession.from_json(json.dumps(old))
        self.assertEqual(loaded.events[0].transition, "cut")
        self.assertEqual(loaded.events[0].transition_frames, 0)
