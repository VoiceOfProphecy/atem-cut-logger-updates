import unittest

from atem_cut_logger.analysis.transcript import (
    Transcript,
    speaker_camera_mismatch,
)
from tests.test_analysis_rules import make_session


class TranscriptLoader(unittest.TestCase):
    def setUp(self):
        # 25 fps: 1 s = 25 frames
        self.session = make_session([(0, 1), (250, 2)], end_frame=500)

    def test_from_descript_segments_wrapper(self):
        data = {
            "segments": [
                {"speaker": "Alice", "start": 0.0, "end": 4.0},
                {"speaker": "Bob", "start": 4.0, "end": 10.0},
            ]
        }
        tr = Transcript.from_descript_json(data, self.session)
        self.assertEqual(tr.speakers(), {"Alice", "Bob"})
        self.assertEqual(tr.active_speaker_at(0), "Alice")
        self.assertEqual(tr.active_speaker_at(50), "Alice")     # 2 s
        self.assertEqual(tr.active_speaker_at(150), "Bob")      # 6 s
        self.assertIsNone(tr.active_speaker_at(400))            # past end

    def test_from_descript_bare_list_and_alt_keys(self):
        data = [
            {"speaker_label": "S1", "start_time": 0.0, "end_time": 2.0},
            {"name": "S2", "startTime": 2.0, "endTime": 4.0},
        ]
        tr = Transcript.from_descript_json(data, self.session)
        self.assertEqual(tr.active_speaker_at(25), "S1")   # 1 s
        self.assertEqual(tr.active_speaker_at(75), "S2")   # 3 s

    def test_offset_shifts_to_logging_relative(self):
        data = [{"speaker": "A", "start": 10.0, "end": 14.0}]
        tr = Transcript.from_descript_json(data, self.session, offset_seconds=10.0)
        self.assertEqual(tr.active_speaker_at(0), "A")     # 10 s transcript -> 0 s log

    def test_bad_segments_skipped(self):
        data = [
            {"speaker": "A", "start": 5.0, "end": 5.0},   # zero-length
            {"speaker": "B", "start": 2.0},               # missing end
            {"speaker": "C", "start": 0.0, "end": 1.0},   # good
        ]
        tr = Transcript.from_descript_json(data, self.session)
        self.assertEqual(len(tr.segments), 1)
        self.assertEqual(tr.segments[0].speaker, "C")


class FuturePhaseSeam(unittest.TestCase):
    def test_speaker_camera_rule_is_noop_placeholder(self):
        # The comparison rule is deferred; it must exist but do nothing yet.
        self.assertEqual(speaker_camera_mismatch(object()), [])


if __name__ == "__main__":
    unittest.main()
