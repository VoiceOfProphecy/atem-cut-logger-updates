import unittest
import xml.etree.ElementTree as ET
from fractions import Fraction

from atem_cut_logger.fcpxml import (
    ExportError,
    export_fcpxml,
    export_flags_fcpxml,
    flags_to_markers,
)
from atem_cut_logger.session import CameraMapping, LogSession


def rational(value: str) -> Fraction:
    assert value.endswith("s")
    body = value[:-1]
    if "/" in body:
        a, b = body.split("/")
        return Fraction(int(a), int(b))
    return Fraction(int(body))


def make_session():
    s = LogSession(rate_key="29.97", drop_frame=True, start_timecode="01:00:00;00")
    s.mappings = {
        1: CameraMapping(1, "CAM 1 Wide", "/iso/cam 1.mov"),
        2: CameraMapping(2, "CAM 2 Tight", "/iso/cam2.mov"),
        5: CameraMapping(5, "", ""),  # unmapped file -> relink stub
    }
    s.audio_file = "/iso/program_audio.wav"
    s.begin()
    s.add_program_change(1, 0.0)
    s.add_program_change(2, 5.0)
    s.add_program_change(5, 12.5)
    s.add_program_change(1, 20.0)
    s.end(30.0)
    return s


class FcpxmlExport(unittest.TestCase):
    def setUp(self):
        self.session = make_session()
        self.xml = export_fcpxml(self.session, project_name="Show")
        self.root = ET.fromstring(self.xml.split("<!DOCTYPE fcpxml>")[1])

    def frame_duration(self):
        fmt = self.root.find("./resources/format")
        return rational(fmt.get("frameDuration"))

    def test_document_shape(self):
        self.assertEqual(self.root.tag, "fcpxml")
        self.assertIn('<!DOCTYPE fcpxml>', self.xml)
        seq = self.root.find(".//sequence")
        self.assertEqual(seq.get("tcFormat"), "DF")
        self.assertEqual(rational(seq.get("tcStart")),
                         107892 * Fraction(1001, 30000))

    def test_clips_are_contiguous_and_video_only(self):
        fd = self.frame_duration()
        clips = self.root.findall(".//spine/asset-clip")
        self.assertEqual(len(clips), 4)
        seq = self.root.find(".//sequence")
        position = rational(seq.get("tcStart"))
        for clip in clips:
            self.assertEqual(rational(clip.get("offset")), position)
            position += rational(clip.get("duration"))
            # every boundary lands exactly on a frame
            self.assertEqual((rational(clip.get("offset")) / fd).denominator, 1)
        self.assertEqual(position, rational(seq.get("tcStart"))
                         + rational(seq.get("duration")))
        # camera assets must not contribute audio
        for asset in self.root.findall("./resources/asset"):
            if asset.get("id").startswith("cam"):
                self.assertEqual(asset.get("hasAudio"), "0")

    def test_source_positions_default_iso_model(self):
        # ISOs started with logging: clip start == elapsed frames into the file
        clips = self.root.findall(".//spine/asset-clip")
        fd = self.frame_duration()
        self.assertEqual(rational(clips[0].get("start")), 0)
        self.assertEqual(rational(clips[1].get("start")) / fd,
                         self.session.events[1].frame)

    def test_continuous_audio_track(self):
        audios = self.root.findall(".//spine/asset-clip/audio")
        self.assertEqual(len(audios), 1)
        audio = audios[0]
        self.assertEqual(audio.get("lane"), "-1")
        seq = self.root.find(".//sequence")
        self.assertEqual(rational(audio.get("duration")),
                         rational(seq.get("duration")))
        asset = self.root.find("./resources/asset[@id='progaudio']")
        self.assertEqual(asset.get("hasVideo"), "0")
        self.assertEqual(asset.get("hasAudio"), "1")

    def test_media_references(self):
        srcs = {a.get("id"): a.get("src")
                for a in self.root.findall("./resources/asset")}
        self.assertEqual(srcs["cam1"], "file:///iso/cam%201.mov")
        self.assertIn("ATEM-Cut-Logger-Relink", srcs["cam5"])
        self.assertEqual(srcs["progaudio"], "file:///iso/program_audio.wav")

    def test_tc_synced_mode_uses_absolute_timecode(self):
        xml = export_fcpxml(self.session, tc_synced_isos=True)
        root = ET.fromstring(xml.split("<!DOCTYPE fcpxml>")[1])
        clips = root.findall(".//spine/asset-clip")
        # source start == timeline offset when ISOs share production TC
        for clip in clips:
            self.assertEqual(clip.get("start"), clip.get("offset"))
        for asset in root.findall("./resources/asset"):
            self.assertEqual(rational(asset.get("start")),
                             107892 * Fraction(1001, 30000))

    def test_windows_paths_and_no_audio(self):
        s = make_session()
        s.audio_file = ""
        s.mappings[1].file = r"D:\ISO\cam1.mov"
        xml = export_fcpxml(s)
        root = ET.fromstring(xml.split("<!DOCTYPE fcpxml>")[1])
        self.assertEqual(
            root.find("./resources/asset[@id='cam1']").get("src"),
            "file:///D:/ISO/cam1.mov",
        )
        self.assertFalse(root.findall(".//audio"))

    def test_empty_session_rejected(self):
        s = LogSession()
        s.begin()
        with self.assertRaises(ExportError):
            export_fcpxml(s)

    def test_regeneration_from_json_is_identical(self):
        restored = LogSession.from_json(self.session.to_json())
        self.assertEqual(export_fcpxml(restored, project_name="Show"), self.xml)


class FlagsExport(unittest.TestCase):
    def test_flags_to_markers(self):
        s = make_session()
        s.add_error_flag(6.0, "audio dropout")
        s.add_error_flag(13.0)  # no note -> generic label

        markers = flags_to_markers(s)
        self.assertEqual(len(markers), 2)
        self.assertIn("audio dropout", markers[0].name)
        self.assertEqual(markers[1].name, "⚠ Flagged")

    def test_export_flags_fcpxml_places_markers(self):
        s = make_session()
        s.add_error_flag(6.0, "audio dropout")

        xml = export_flags_fcpxml(s)
        root = ET.fromstring(xml.split("<!DOCTYPE fcpxml>")[1])
        markers = root.findall(".//spine/asset-clip/marker")
        self.assertEqual(len(markers), 1)
        self.assertIn("audio dropout", markers[0].get("value"))

    def test_export_flags_fcpxml_empty_session_rejected(self):
        s = LogSession()
        s.begin()
        with self.assertRaises(ExportError):
            export_flags_fcpxml(s)

    def test_export_flags_fcpxml_with_no_flags_has_no_markers(self):
        s = make_session()  # no flags added
        xml = export_flags_fcpxml(s)
        root = ET.fromstring(xml.split("<!DOCTYPE fcpxml>")[1])
        self.assertEqual(root.findall(".//spine/asset-clip/marker"), [])


if __name__ == "__main__":
    unittest.main()


class TransitionPlacement(unittest.TestCase):
    """A dissolve flattens to a cut at the middle of the blend, not at its end."""

    def _session(self, transition_frames=50):
        s = LogSession(rate_key="25", start_timecode="01:00:00:00")
        s.mappings = {1: CameraMapping(1, "CAM 1"), 2: CameraMapping(2, "CAM 2")}
        s.begin()
        s.add_program_change(1, 0.0)
        s.add_program_change(2, 10.0, "mix", transition_frames)
        s.end(20.0)
        return s

    def _clips(self, session):
        root = ET.fromstring(export_fcpxml(session))
        return root.findall(".//spine/asset-clip")

    def test_cut_lands_at_the_midpoint_of_the_blend(self):
        clips = self._clips(self._session())
        # 25 fps: logged at frame 250, 50-frame blend -> boundary at frame 225.
        self.assertEqual(clips[0].get("duration"), "22500/2500s")    # 225 frames
        self.assertEqual(clips[1].get("offset"), "9022500/2500s")    # start + 225

    def test_clips_still_abut_with_no_gap(self):
        clips = self._clips(self._session())
        def frames(value):
            num, _den = value.rstrip("s").split("/")
            return int(num) // 100      # 25 fps frame duration is 100/2500s
        end_of_first = frames(clips[0].get("offset")) + frames(clips[0].get("duration"))
        self.assertEqual(end_of_first, frames(clips[1].get("offset")))

    def test_a_hard_cut_is_placed_exactly_where_it_was_logged(self):
        session = self._session(transition_frames=0)
        session.events[1].transition = "cut"
        clips = self._clips(session)
        self.assertEqual(clips[0].get("duration"), "25000/2500s")   # 250 frames

    def test_a_blend_longer_than_the_previous_shot_cannot_reorder_clips(self):
        session = self._session(transition_frames=999)
        clips = self._clips(session)
        self.assertEqual(clips[0].get("duration"), "100/2500s")     # 1 frame minimum
