import time
import unittest

from atem_cut_logger.web.controller import Controller, ControllerError


def drain(q):
    out = []
    while not q.empty():
        out.append(q.get_nowait())
    return out


class ControllerCore(unittest.TestCase):
    def setUp(self):
        self.c = Controller()
        self.c.on_connected("Test Switcher", {1: "Cam 1", 2: "Cam 2", 3: "Cam 3"}, 1)
        self.c.update_settings({"rate_key": "25", "drop_frame": False,
                                "start_timecode": "01:00:00:00"})

    def test_snapshot_after_connect(self):
        snap = self.c.snapshot()
        self.assertTrue(snap["connected"])
        self.assertEqual(snap["program_input"], 1)
        self.assertEqual(snap["program_camera"], "Cam 1")
        self.assertEqual(len(snap["mappings"]), 3)
        self.assertFalse(snap["logging"])

    def test_snapshot_reports_app_version(self):
        from atem_cut_logger import __version__

        self.assertEqual(self.c.snapshot()["version"], __version__)

    def test_logging_records_and_dedupes(self):
        self.c.start_logging()
        base = self.c.start_mono
        self.c.on_program_changed(2, base + 5.0)     # new
        self.c.on_program_changed(2, base + 6.0)     # duplicate -> ignored
        self.c.on_program_changed(3, base + 8.0)     # new
        self.c.stop_logging()
        events = self.c.snapshot()["events"]
        self.assertEqual([e["input"] for e in events], [1, 2, 3])
        self.assertEqual(events[1]["timecode"], "01:00:05:00")
        self.assertTrue(self.c.snapshot()["can_export"])

    def test_settings_locked_while_logging(self):
        self.c.start_logging()
        with self.assertRaises(ControllerError):
            self.c.update_settings({"rate_key": "30"})
        self.c.stop_logging()

    def test_start_requires_connection(self):
        c = Controller()
        with self.assertRaises(ControllerError):
            c.start_logging()

    def test_broadcast_on_event(self):
        q = self.c.subscribe()
        self.c.start_logging()
        drain(q)
        self.c.on_program_changed(2, self.c.start_mono + 3.0)
        kinds = [m["type"] for m in drain(q)]
        self.assertIn("event", kinds)
        self.assertIn("program", kinds)

    def test_mapping_update_relabels_events(self):
        self.c.start_logging()
        self.c.on_program_changed(2, self.c.start_mono + 2.0)
        self.c.stop_logging()
        self.c.upsert_mapping(2, name="CAM 2 Tight", file="/iso/cam2.mov")
        events = self.c.snapshot()["events"]
        self.assertEqual(events[1]["camera"], "CAM 2 Tight")

    def test_simulate_cut_rejected_without_simulator(self):
        with self.assertRaises(ControllerError):
            self.c.simulate_cut(2)

    def test_correcting_start_timecode_after_logging_updates_log_display(self):
        # Regression: fixing a wrong Start Timecode post-hoc must update the
        # already-logged events' displayed timecode, not just the setting.
        self.c.start_logging()
        self.c.on_program_changed(2, self.c.start_mono + 5.0)
        self.c.stop_logging()
        before = self.c.snapshot()["events"][1]["timecode"]

        self.c.update_settings({"start_timecode": "05:24:54:10"})

        after = self.c.snapshot()["events"][1]["timecode"]
        self.assertNotEqual(before, after)
        self.assertEqual(after, "05:24:59:10")

    def test_load_session_json_round_trip(self):
        self.c.start_logging()
        self.c.on_program_changed(2, self.c.start_mono + 4.0)
        self.c.stop_logging()
        text = self.c.session.to_json()
        c2 = Controller()
        c2.load_session_json(text, name="show.atemlog.json")
        snap = c2.snapshot()
        self.assertEqual(snap["loaded_name"], "show.atemlog.json")
        self.assertEqual(len(snap["events"]), 2)


class FakeTimecodeBackend:
    """Minimal stand-in for a real backend's get_current_timecode()."""

    def __init__(self, result=None):
        self.result = result
        self.calls = 0

    def get_current_timecode(self, timeout: float = 1.0):
        self.calls += 1
        return self.result


class AutoTimecode(unittest.TestCase):
    def setUp(self):
        self.c = Controller()
        self.c.on_connected("Test Switcher", {1: "Cam 1", 2: "Cam 2"}, 1)
        self.c.update_settings({"rate_key": "25", "drop_frame": False,
                                "start_timecode": "01:00:00:00"})

    def test_picks_up_switcher_timecode_by_default(self):
        backend = FakeTimecodeBackend(("14:30:00:12", False))
        self.c.backend = backend
        self.c.start_logging()
        self.assertEqual(backend.calls, 1)
        self.assertEqual(self.c.session.start_timecode, "14:30:00:12")
        self.assertFalse(self.c.session.drop_frame)

    def test_disabled_keeps_typed_value(self):
        backend = FakeTimecodeBackend(("14:30:00:12", False))
        self.c.backend = backend
        self.c.auto_timecode = False
        self.c.start_logging()
        self.assertEqual(backend.calls, 0)
        self.assertEqual(self.c.session.start_timecode, "01:00:00:00")

    def test_unsupported_backend_falls_back_to_typed_value(self):
        self.c.backend = FakeTimecodeBackend(None)  # e.g. Test Mode
        self.c.start_logging()
        self.assertEqual(self.c.session.start_timecode, "01:00:00:00")

    def test_no_backend_object_falls_back_to_typed_value(self):
        # Matches how earlier tests exercise the controller: on_connected()
        # called directly, backend never assigned.
        self.c.start_logging()
        self.assertEqual(self.c.session.start_timecode, "01:00:00:00")

    def test_invalid_switcher_timecode_raises_clean_error(self):
        # Switcher reports drop-frame at 25 fps, which is not a valid
        # combination — must fail with a clear ControllerError, not corrupt
        # the session silently.
        self.c.backend = FakeTimecodeBackend(("14:30:00:12", True))
        with self.assertRaises(ControllerError):
            self.c.start_logging()


class Flags(unittest.TestCase):
    def setUp(self):
        self.c = Controller()
        self.c.on_connected("Test Switcher", {1: "Cam 1", 2: "Cam 2"}, 1)
        self.c.update_settings({"rate_key": "25", "start_timecode": "01:00:00:00"})

    def test_requires_logging(self):
        with self.assertRaises(ControllerError):
            self.c.add_flag("too early")

    def test_add_flag_while_logging(self):
        self.c.start_logging()
        self.c.add_flag("dead feed")
        flags = self.c.snapshot()["flags"]
        self.assertEqual(len(flags), 1)
        self.assertEqual(flags[0]["note"], "dead feed")
        self.assertEqual(flags[0]["index"], 0)

    def test_add_flag_needs_no_note(self):
        self.c.start_logging()
        self.c.add_flag()
        self.assertEqual(self.c.snapshot()["flags"][0]["note"], "")

    def test_broadcasts_flag_event(self):
        q = self.c.subscribe()
        self.c.start_logging()
        drain(q)
        self.c.add_flag("audio dropout")
        kinds = [m["type"] for m in drain(q)]
        self.assertIn("flag", kinds)

    def test_remove_flag(self):
        self.c.start_logging()
        self.c.add_flag("a")
        self.c.add_flag("b")
        self.c.remove_flag(0)
        notes = [f["note"] for f in self.c.snapshot()["flags"]]
        self.assertEqual(notes, ["b"])

    def test_remove_flag_bad_index_raises_controller_error(self):
        self.c.start_logging()
        with self.assertRaises(ControllerError):
            self.c.remove_flag(5)

    def test_set_flag_note_after_the_fact(self):
        self.c.start_logging()
        self.c.add_flag()
        self.c.set_flag_note(0, "  wrong camera  ")
        self.assertEqual(self.c.snapshot()["flags"][0]["note"], "wrong camera")

    def test_flags_survive_json_round_trip(self):
        self.c.start_logging()
        self.c.add_flag("dead feed")
        self.c.stop_logging()
        text = self.c.session.to_json()
        c2 = Controller()
        c2.load_session_json(text)
        self.assertEqual(c2.snapshot()["flags"][0]["note"], "dead feed")

    def test_begin_clears_flags_on_restart(self):
        self.c.start_logging()
        self.c.add_flag("leftover")
        self.c.stop_logging()
        self.c.start_logging()
        self.assertEqual(self.c.snapshot()["flags"], [])


class SimulatorIntegration(unittest.TestCase):
    def test_connect_simulator_and_manual_cut(self):
        c = Controller()
        q = c.subscribe()
        c.connect("simulator", "")
        # wait for the simulator's connected broadcast
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline and not c.connected:
            time.sleep(0.02)
        self.assertTrue(c.connected)
        c.update_settings({"rate_key": "25", "start_timecode": "00:00:00:00"})
        c.start_logging()
        c.simulate_cut(3)
        time.sleep(0.1)
        c.stop_logging()
        inputs = [e["input"] for e in c.snapshot()["events"]]
        self.assertIn(3, inputs)
        c.disconnect()


if __name__ == "__main__":
    unittest.main()
