"""Public-feed updates, served by a throwaway HTTP server on localhost.

The interesting cases are the refusals: a build whose checksum doesn't match,
a build whose version doesn't match what the feed promised, and an archive with
a path that would escape the install directory. Each must leave the existing
install untouched.
"""

import hashlib
import http.server
import json
import tempfile
import threading
import unittest
import zipfile
from pathlib import Path

from atem_cut_logger.release_channel import (
    ReleaseChannel,
    ReleaseError,
    is_newer,
    parse_version,
)
from atem_cut_logger.updates import UpdateManager


def build_zip(path: Path, version: str, extra: dict[str, str] | None = None) -> bytes:
    """A published build: one top-level directory holding the app tree."""
    with zipfile.ZipFile(path, "w") as zf:
        zf.writestr(f"atem-cut-logger-{version}/atem_cut_logger/__init__.py",
                    f'__version__ = "{version}"\n')
        zf.writestr(f"atem-cut-logger-{version}/README.md", f"# {version}\n")
        for name, content in (extra or {}).items():
            zf.writestr(name, content)
    return path.read_bytes()


class FeedServer:
    """Serves a directory over HTTP for the duration of one test."""

    def __init__(self, directory: Path):
        handler = http.server.SimpleHTTPRequestHandler

        class Quiet(handler):  # type: ignore[valid-type,misc]
            def __init__(self, *a, **kw):
                super().__init__(*a, directory=str(directory), **kw)

            def log_message(self, *a):
                pass

        self.httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Quiet)
        self.port = self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    @property
    def manifest_url(self) -> str:
        return f"http://127.0.0.1:{self.port}/manifest.json"

    def stop(self):
        self.httpd.shutdown()
        self.httpd.server_close()


class VersionCompareTest(unittest.TestCase):
    def test_numeric_ordering_not_string_ordering(self):
        self.assertEqual(parse_version("1.10.2"), (1, 10, 2))
        self.assertTrue(is_newer("1.10.0", "1.9.9"))
        self.assertFalse(is_newer("1.2.0", "1.2.0"))
        self.assertFalse(is_newer("1.1.9", "1.2.0"))

    def test_odd_versions_do_not_crash(self):
        self.assertEqual(parse_version("v2.0-beta"), (2, 0))
        self.assertFalse(is_newer("", "1.0.0"))


class ReleaseChannelTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.feed_dir = self.root / "feed"
        (self.feed_dir / "builds").mkdir(parents=True)
        self.install = self.root / "install"
        (self.install / "atem_cut_logger").mkdir(parents=True)
        (self.install / "atem_cut_logger" / "__init__.py").write_text(
            '__version__ = "1.0.0"\n')
        self.server = FeedServer(self.feed_dir)
        self.addCleanup(self.server.stop)
        self.addCleanup(self.tmp.cleanup)
        self.channel = ReleaseChannel(self.server.manifest_url)

    def publish(self, version="1.4.0", *, sha=None, zip_version=None, extra=None,
                notes=("Session templates",)):
        blob = build_zip(self.feed_dir / "builds" / f"b-{version}.zip",
                         zip_version or version, extra)
        manifest = {
            "version": version,
            "notes": list(notes),
            "zip": f"builds/b-{version}.zip",
            "sha256": sha or hashlib.sha256(blob).hexdigest(),
        }
        (self.feed_dir / "manifest.json").write_text(json.dumps(manifest))
        return manifest

    # ------------------------------------------------------------------

    def test_manifest_is_read_and_the_zip_url_resolved(self):
        self.publish()
        manifest = self.channel.fetch_manifest()
        self.assertEqual(manifest["version"], "1.4.0")
        self.assertTrue(self.channel.zip_url(manifest).endswith("/builds/b-1.4.0.zip"))

    def test_missing_feed_is_a_readable_error(self):
        with self.assertRaises(ReleaseError) as ctx:
            self.channel.fetch_manifest()
        self.assertIn("404", str(ctx.exception))

    def test_malformed_feed_is_rejected(self):
        (self.feed_dir / "manifest.json").write_text("not json at all")
        with self.assertRaises(ReleaseError):
            self.channel.fetch_manifest()

    def test_install_replaces_the_tree_and_returns_the_version(self):
        manifest = self.publish()
        version = self.channel.install(manifest, self.install)
        self.assertEqual(version, "1.4.0")
        self.assertIn('"1.4.0"',
                      (self.install / "atem_cut_logger" / "__init__.py").read_text())
        self.assertTrue((self.install / "README.md").is_file())

    def test_install_keeps_the_sdk_files_and_the_compiled_bridge(self):
        bridge = self.install / "bridge" / "mac"
        bridge.mkdir(parents=True)
        (bridge / "BMDSwitcherAPI.h").write_text("licensed header")
        (bridge / "atem-bridge").write_bytes(b"compiled binary")
        manifest = self.publish()
        self.channel.install(manifest, self.install)
        self.assertEqual((bridge / "BMDSwitcherAPI.h").read_text(), "licensed header")
        self.assertEqual((bridge / "atem-bridge").read_bytes(), b"compiled binary")

    def test_checksum_mismatch_refuses_and_leaves_the_install_alone(self):
        manifest = self.publish(sha="0" * 64)
        with self.assertRaises(ReleaseError) as ctx:
            self.channel.install(manifest, self.install)
        self.assertIn("checksum", str(ctx.exception))
        self.assertIn('"1.0.0"',
                      (self.install / "atem_cut_logger" / "__init__.py").read_text())

    def test_version_mismatch_between_feed_and_build_is_refused(self):
        manifest = self.publish(version="1.4.0", zip_version="1.3.0")
        with self.assertRaises(ReleaseError) as ctx:
            self.channel.install(manifest, self.install)
        self.assertIn("refusing", str(ctx.exception))
        self.assertIn('"1.0.0"',
                      (self.install / "atem_cut_logger" / "__init__.py").read_text())

    def test_archive_escaping_the_install_directory_is_refused(self):
        manifest = self.publish(extra={"../escaped.txt": "nope"})
        with self.assertRaises(ReleaseError) as ctx:
            self.channel.install(manifest, self.install)
        self.assertIn("bad path", str(ctx.exception))
        self.assertFalse((self.root / "escaped.txt").exists())


class ManagerOnReleaseChannelTest(unittest.TestCase):
    """The manager end of it: a ZIP install checking and applying from a feed."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.feed_dir = self.root / "feed"
        (self.feed_dir / "builds").mkdir(parents=True)
        self.install = self.root / "install"
        (self.install / "atem_cut_logger").mkdir(parents=True)
        (self.install / "atem_cut_logger" / "__init__.py").write_text(
            '__version__ = "1.0.0"\n')
        self.server = FeedServer(self.feed_dir)
        self.addCleanup(self.server.stop)
        self.addCleanup(self.tmp.cleanup)

    def _manager(self):
        return UpdateManager(
            root=self.install,
            release_channel=ReleaseChannel(self.server.manifest_url),
        )

    def _publish(self, version):
        blob = build_zip(self.feed_dir / "builds" / f"b-{version}.zip", version)
        (self.feed_dir / "manifest.json").write_text(json.dumps({
            "version": version, "notes": [f"Release {version}"],
            "zip": f"builds/b-{version}.zip",
            "sha256": hashlib.sha256(blob).hexdigest(),
        }))

    def test_newer_release_shows_up_as_available_with_its_notes(self):
        self._publish("99.0.0")   # certainly newer than the running version
        status = self._manager().check()
        self.assertEqual(status["channel"], "release")
        self.assertTrue(status["update_available"])
        self.assertEqual(status["available_version"], "99.0.0")
        self.assertEqual(status["summary"], ["Release 99.0.0"])

    def test_older_release_is_not_offered(self):
        self._publish("0.0.1")
        status = self._manager().check()
        self.assertFalse(status["update_available"])
        self.assertEqual(status["available_version"], "")

    def test_apply_installs_the_published_build(self):
        self._publish("99.0.0")
        mgr = self._manager()
        mgr.check()
        result = mgr.apply()
        self.assertTrue(result["updated"])
        self.assertEqual(result["channel"], "release")
        self.assertEqual(result["version"], "99.0.0")
        self.assertFalse(mgr.status()["update_available"])

    def test_apply_refuses_while_logging(self):
        self._publish("99.0.0")
        mgr = UpdateManager(
            root=self.install,
            release_channel=ReleaseChannel(self.server.manifest_url),
            is_busy=lambda: True,
        )
        with self.assertRaises(Exception) as ctx:
            mgr.apply()
        self.assertIn("Not while logging", str(ctx.exception))
        self.assertIn('"1.0.0"',
                      (self.install / "atem_cut_logger" / "__init__.py").read_text())


if __name__ == "__main__":
    unittest.main()
