import unittest

from atem_cut_logger.timecode import (
    FRAME_RATES,
    TimecodeError,
    event_timecode,
    frames_to_timecode,
    parse_timecode,
    seconds_to_frames,
)


class ParseFormatRoundTrip(unittest.TestCase):
    def test_round_trip_all_rates_ndf(self):
        samples = ["00:00:00:00", "01:02:03:04", "10:59:59:20", "23:00:30:00"]
        for key, rate in FRAME_RATES.items():
            for tc in samples:
                frames = parse_timecode(tc, rate, False)
                self.assertEqual(frames_to_timecode(frames, rate, False), tc,
                                 f"rate {key}")

    def test_round_trip_drop_frame_exhaustive_hour(self):
        rate = FRAME_RATES["29.97"]
        # Every frame in the first hour survives a format->parse round trip
        # and frame numbers are contiguous (no gaps, no repeats).
        for frames in range(0, 60 * 60 * 30 - 108, 7):
            tc = frames_to_timecode(frames, rate, True)
            self.assertEqual(parse_timecode(tc, rate, True), frames, tc)

    def test_known_drop_frame_values(self):
        rate = FRAME_RATES["29.97"]
        # Minute 0 drops nothing: frames 0..1799 are 00:00:00;00..00:00:59;29.
        self.assertEqual(frames_to_timecode(1799, rate, True), "00:00:59;29")
        # 00:01:00;00 and ;01 do not exist: frame 1800 is labelled 00:01:00;02.
        self.assertEqual(frames_to_timecode(1800, rate, True), "00:01:00;02")
        self.assertEqual(parse_timecode("00:01:00;02", rate, True), 1800)
        # Tenth minute keeps its labels.
        self.assertEqual(frames_to_timecode(17982, rate, True), "00:10:00;00")
        # One hour of DF timecode = 107892 frames.
        self.assertEqual(frames_to_timecode(107892, rate, True), "01:00:00;00")
        self.assertEqual(parse_timecode("01:00:00;00", rate, True), 107892)

    def test_drop_frame_alignment_with_real_time(self):
        # After exactly 1 hour of real time at 29.97, DF timecode reads ~1 hour
        # (that is the whole point of drop frame).
        rate = FRAME_RATES["29.97"]
        frames = seconds_to_frames(3600.0, rate)  # 107892.1 -> 107892
        self.assertEqual(frames_to_timecode(frames, rate, True), "01:00:00;00")
        # NDF drifts by ~3.6 seconds per hour.
        self.assertEqual(frames_to_timecode(frames, rate, False), "00:59:56:12")

    def test_invalid_drop_frame_label_rejected(self):
        rate = FRAME_RATES["29.97"]
        for bad in ("00:01:00;00", "00:01:00;01", "00:59:00;01"):
            with self.assertRaises(TimecodeError):
                parse_timecode(bad, rate, True)
        # ...but valid at the tenth minute.
        parse_timecode("00:10:00;00", rate, True)

    def test_drop_frame_only_on_2997(self):
        for key in ("23.976", "24", "25", "30"):
            with self.assertRaises(TimecodeError):
                parse_timecode("00:00:00:00", FRAME_RATES[key], True)

    def test_frame_field_range(self):
        with self.assertRaises(TimecodeError):
            parse_timecode("00:00:00:25", FRAME_RATES["25"], False)
        with self.assertRaises(TimecodeError):
            parse_timecode("00:00:00:24", FRAME_RATES["23.976"], False)
        parse_timecode("00:00:00:29", FRAME_RATES["29.97"], False)

    def test_garbage_rejected(self):
        for bad in ("", "1:2:3", "aa:bb:cc:dd", "25:00:00:00", "00:61:00:00"):
            with self.assertRaises(TimecodeError):
                parse_timecode(bad, FRAME_RATES["25"], False)


class ElapsedTime(unittest.TestCase):
    def test_seconds_to_frames_fractional_rates(self):
        rate = FRAME_RATES["23.976"]
        self.assertEqual(seconds_to_frames(0.0, rate), 0)
        self.assertEqual(seconds_to_frames(1001 / 24000, rate), 1)
        self.assertEqual(seconds_to_frames(10.0, rate), 240)  # 239.76 -> 240

    def test_event_timecode_offsets_start(self):
        rate = FRAME_RATES["25"]
        start = parse_timecode("10:00:00:00", rate, False)
        frame, tc = event_timecode(start, 90.04, rate, False)
        self.assertEqual(frame, 2251)
        self.assertEqual(tc, "10:01:30:01")

    def test_event_timecode_df(self):
        rate = FRAME_RATES["29.97"]
        start = parse_timecode("01:00:00;00", rate, True)
        frame, tc = event_timecode(start, 60.0, rate, True)
        self.assertEqual(frame, 1798)  # 60s * 29.97 = 1798.2
        self.assertEqual(tc, "01:00:59;28")
        # 60 timecode-labels later lands just past the dropped labels.
        frame, tc = event_timecode(start, 1800 * 1001 / 30000, rate, True)
        self.assertEqual(frame, 1800)
        self.assertEqual(tc, "01:01:00;02")


if __name__ == "__main__":
    unittest.main()
