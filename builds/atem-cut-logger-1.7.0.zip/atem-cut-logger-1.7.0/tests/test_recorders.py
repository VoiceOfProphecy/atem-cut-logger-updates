"""Recorder control, driven against a stand-in HyperDeck on localhost.

The fake speaks the real line protocol (banner, ``200 ok``, ``208 transport
info:`` blocks), so the client code under test is the same code that talks to a
deck in the rack. The cases that matter for a live show are the unhappy ones:
a deck that refuses a command, one that isn't there at all, and one that starts
rolling on its own while the app is idle.
"""

import socket
import threading
import unittest

from atem_cut_logger.recorders import (
    HyperDeck,
    RecorderConfig,
    RecorderError,
    RecorderPool,
    RecorderWatcher,
)


class FakeDeck:
    """A minimal HyperDeck: record / stop / transport info, one client at a time."""

    def __init__(self, refuse: set[str] | None = None):
        self.refuse = refuse or set()
        self.recording = False
        self.clip = ""
        self.commands: list[str] = []
        self._sock = socket.socket()
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind(("127.0.0.1", 0))
        self._sock.listen(8)
        self.port = self._sock.getsockname()[1]
        self._stop = threading.Event()
        threading.Thread(target=self._serve, daemon=True).start()

    def config(self, name="Deck") -> RecorderConfig:
        return RecorderConfig(name=name, host="127.0.0.1", port=self.port)

    def _serve(self):
        while not self._stop.is_set():
            try:
                conn, _ = self._sock.accept()
            except OSError:
                return
            threading.Thread(target=self._session, args=(conn,), daemon=True).start()

    def _session(self, conn):
        with conn:
            conn.sendall(b"500 connection info:\r\nprotocol version: 1.11\r\n\r\n")
            buffer = b""
            while not self._stop.is_set():
                try:
                    chunk = conn.recv(4096)
                except OSError:
                    return
                if not chunk:
                    return
                buffer += chunk
                while b"\r\n" in buffer:
                    line, _, buffer = buffer.partition(b"\r\n")
                    conn.sendall(self._respond(line.decode().strip()))

    def _respond(self, command: str) -> bytes:
        self.commands.append(command)
        head = command.split(":")[0].strip()
        if head in self.refuse:
            return b"120 unsupported\r\n"
        if head == "record":
            self.recording = True
            if ":" in command:
                self.clip = command.split("name:")[-1].strip()
            return b"200 ok\r\n"
        if head == "stop":
            self.recording = False
            return b"200 ok\r\n"
        if head == "transport info":
            status = "record" if self.recording else "preview"
            return (
                "208 transport info:\r\n"
                f"status: {status}\r\n"
                "timecode: 01:00:12:10\r\n"
                f"clip id: {self.clip or 'none'}\r\n\r\n"
            ).encode()
        return b"200 ok\r\n"

    def close(self):
        self._stop.set()
        self._sock.close()


class HyperDeckTest(unittest.TestCase):
    def setUp(self):
        self.deck = FakeDeck()
        self.addCleanup(self.deck.close)
        self.client = HyperDeck(self.deck.config())

    def test_status_reads_the_transport_block(self):
        status = self.client.status()
        self.assertTrue(status.reachable)
        self.assertFalse(status.recording)
        self.assertEqual(status.status, "preview")
        self.assertEqual(status.timecode, "01:00:12:10")

    def test_record_and_stop_move_the_deck(self):
        self.client.start_recording()
        self.assertTrue(self.client.status().recording)
        self.client.stop_recording()
        self.assertFalse(self.client.status().recording)

    def test_record_can_name_the_clip(self):
        self.client.start_recording("tvtl-01-08")
        self.assertEqual(self.deck.clip, "tvtl-01-08")
        self.assertIn("record: name: tvtl-01-08", self.deck.commands)

    def test_a_refused_command_names_the_deck_and_the_command(self):
        deck = FakeDeck(refuse={"record"})
        self.addCleanup(deck.close)
        client = HyperDeck(deck.config("Rack A"))
        with self.assertRaises(RecorderError) as ctx:
            client.start_recording()
        self.assertIn("Rack A", str(ctx.exception))
        self.assertIn("record", str(ctx.exception))

    def test_an_unreachable_deck_is_an_error_not_a_hang(self):
        client = HyperDeck(RecorderConfig("Ghost", "127.0.0.1", 9))
        with self.assertRaises(RecorderError):
            client.transport()
        # status() converts it into something the UI can render.
        status = client.status()
        self.assertFalse(status.reachable)
        self.assertTrue(status.error)


class RecorderPoolTest(unittest.TestCase):
    def setUp(self):
        self.a = FakeDeck()
        self.b = FakeDeck()
        self.addCleanup(self.a.close)
        self.addCleanup(self.b.close)
        self.pool = RecorderPool([self.a.config("A"), self.b.config("B")])

    def test_record_all_rolls_every_deck(self):
        statuses = self.pool.record_all()
        self.assertEqual([s.recording for s in statuses], [True, True])
        self.assertTrue(self.a.recording and self.b.recording)

    def test_stop_all_stops_every_deck(self):
        self.pool.record_all()
        statuses = self.pool.stop_all()
        self.assertEqual([s.recording for s in statuses], [False, False])

    def test_one_dead_deck_does_not_stop_the_others(self):
        pool = RecorderPool([self.a.config("A"),
                             RecorderConfig("Ghost", "127.0.0.1", 9)])
        statuses = pool.record_all()
        self.assertTrue(statuses[0].recording)
        self.assertTrue(self.a.recording)
        self.assertFalse(statuses[1].reachable)
        self.assertTrue(statuses[1].error)

    def test_configs_are_validated(self):
        pool = RecorderPool()
        with self.assertRaises(RecorderError):
            pool.set_configs([{"name": "no host"}])
        with self.assertRaises(RecorderError):
            pool.set_configs([{"host": "10.0.0.1", "port": "not a number"}])
        with self.assertRaises(RecorderError):
            pool.set_configs([{"host": "10.0.0.1"}, {"host": "10.0.0.1"}])

    def test_a_deck_with_no_name_falls_back_to_its_address(self):
        pool = RecorderPool()
        configs = pool.set_configs([{"host": "10.0.0.7"}])
        self.assertEqual(configs[0].name, "10.0.0.7")
        self.assertEqual(configs[0].port, 9993)


class RecorderWatcherTest(unittest.TestCase):
    def setUp(self):
        self.deck = FakeDeck()
        self.addCleanup(self.deck.close)
        self.pool = RecorderPool([self.deck.config("A")])
        self.fired = []
        self.watcher = RecorderWatcher(self.pool, lambda: self.fired.append(1))

    def test_recording_start_fires_once_per_run(self):
        self.watcher.enabled = True
        self.watcher.poll_once()
        self.assertEqual(self.fired, [])

        self.deck.recording = True          # someone hit record on the deck
        self.watcher.poll_once()
        self.assertEqual(len(self.fired), 1)

        self.watcher.poll_once()            # still rolling: not a new start
        self.assertEqual(len(self.fired), 1)

        self.deck.recording = False
        self.watcher.poll_once()
        self.deck.recording = True
        self.watcher.poll_once()            # a new run does fire again
        self.assertEqual(len(self.fired), 2)

    def test_nothing_fires_while_the_option_is_off(self):
        self.watcher.enabled = False
        self.deck.recording = True
        self.watcher.poll_once()
        self.assertEqual(self.fired, [])

    def test_last_status_is_kept_for_the_ui(self):
        self.watcher.poll_once()
        self.assertEqual(len(self.watcher.last), 1)
        self.assertTrue(self.watcher.last[0].reachable)


class ControllerAutoStartTest(unittest.TestCase):
    """The point of the whole feature: recording starts, logging follows."""

    def setUp(self):
        import tempfile
        from pathlib import Path

        from atem_cut_logger.templates import TemplateStore
        from atem_cut_logger.updates import UpdateManager
        from atem_cut_logger.web.controller import Controller

        self.tmp = tempfile.TemporaryDirectory()
        tmp = Path(self.tmp.name)
        self.deck = FakeDeck()
        self.c = Controller(updates=UpdateManager(root=tmp / "not-a-clone"),
                            templates=TemplateStore(tmp / "templates"))
        self.addCleanup(self.tmp.cleanup)
        self.addCleanup(self.c.shutdown)
        self.addCleanup(self.deck.close)
        self.c.set_recorders([{"name": "A", "host": "127.0.0.1",
                               "port": self.deck.port}])

    def test_deck_rolling_starts_logging_when_the_option_is_on(self):
        self.c.update_settings({"auto_start_on_record": True})
        self.c.connect("simulator")
        self.deck.recording = True
        self.c.recorder_status()          # the poll the UI/timer performs
        self.assertTrue(self.c.logging)

    def test_nothing_starts_when_the_option_is_off(self):
        self.c.connect("simulator")
        self.deck.recording = True
        self.c.recorder_status()
        self.assertFalse(self.c.logging)

    def test_record_all_rolls_the_deck_and_starts_logging(self):
        self.c.update_settings({"auto_start_on_record": True})
        self.c.connect("simulator")
        statuses = self.c.record_all()
        self.assertTrue(statuses[0]["recording"])
        self.assertTrue(self.c.logging)

    def test_recording_without_a_switcher_does_not_start_logging(self):
        self.c.update_settings({"auto_start_on_record": True})
        self.deck.recording = True
        self.c.recorder_status()          # not connected: nothing to log
        self.assertFalse(self.c.logging)

    def test_clip_is_named_after_the_session(self):
        self.c.update_settings({"session_name": "TVTL 01-08"})
        self.c.connect("simulator")
        self.c.record_all()
        self.assertEqual(self.deck.clip, "tvtl-01-08")

    def test_recorders_ride_along_in_a_template(self):
        self.c.save_template("Rack")
        self.c.set_recorders([])
        self.c.apply_template("Rack")
        self.assertEqual(len(self.c.snapshot()["recorders"]), 1)

    def test_commands_need_recorders_configured(self):
        from atem_cut_logger.web.controller import ControllerError
        self.c.set_recorders([])
        for call in (self.c.record_all, self.c.stop_recorders):
            with self.assertRaises(ControllerError):
                call()


if __name__ == "__main__":
    unittest.main()
