"""Update manager tests, driven against real local git repositories.

Nothing here touches the network: a bare repo plays the part of "origin", so
fetch/compare/fast-forward exercise the same code paths the operator's machine
runs against GitHub.
"""

import os
import subprocess
import tempfile
import unittest
from pathlib import Path

from atem_cut_logger.updates import UpdateError, UpdateManager


def git(cwd, *args):
    subprocess.run(
        ["git", *args], cwd=cwd, check=True,
        capture_output=True, text=True,
        env={"PATH": "/usr/bin:/bin:/usr/local/bin", "HOME": str(cwd),
             "GIT_AUTHOR_NAME": "T", "GIT_AUTHOR_EMAIL": "t@example.com",
             "GIT_COMMITTER_NAME": "T", "GIT_COMMITTER_EMAIL": "t@example.com"},
    )


class UpdateManagerTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.upstream = root / "upstream"
        self.upstream.mkdir()
        git(self.upstream, "init", "-b", "main")
        self._write_version(self.upstream, "1.0.0")
        git(self.upstream, "add", "-A")
        git(self.upstream, "commit", "-m", "initial")

        self.clone = root / "clone"
        git(root, "clone", str(self.upstream), str(self.clone))
        self.mgr = UpdateManager(root=self.clone)
        self.addCleanup(self.tmp.cleanup)

    def _write_version(self, repo: Path, version: str):
        pkg = repo / "atem_cut_logger"
        pkg.mkdir(exist_ok=True)
        (pkg / "__init__.py").write_text(f'__version__ = "{version}"\n')

    def _push_upstream_commit(self, version="1.1.0", subject="add a feature"):
        self._write_version(self.upstream, version)
        git(self.upstream, "add", "-A")
        git(self.upstream, "commit", "-m", subject)

    # ------------------------------------------------------------------

    def test_clone_reports_no_update_when_current(self):
        status = self.mgr.check()
        self.assertTrue(status["supported"])
        self.assertFalse(status["update_available"])
        self.assertEqual(status["commits_behind"], 0)
        self.assertEqual(status["error"], "")

    def test_check_finds_upstream_commits_and_summarises_them(self):
        self._push_upstream_commit(subject="add EDL export")
        status = self.mgr.check()
        self.assertTrue(status["update_available"])
        self.assertEqual(status["commits_behind"], 1)
        self.assertEqual(status["summary"], ["add EDL export"])
        self.assertIsNotNone(status["last_checked"])

    def test_apply_fast_forwards_and_reports_the_new_version(self):
        self._push_upstream_commit(version="1.2.0")
        self.mgr.check()
        result = self.mgr.apply()
        self.assertTrue(result["updated"])
        self.assertEqual(result["version"], "1.2.0")
        # No SDK headers in the fixture, so there is no bridge to rebuild.
        self.assertEqual(result["bridge"], "skipped")
        self.assertFalse(self.mgr.status()["update_available"])

    def test_apply_is_a_no_op_when_already_current(self):
        result = self.mgr.apply()
        self.assertFalse(result["updated"])

    def test_apply_refuses_while_logging(self):
        mgr = UpdateManager(root=self.clone, is_busy=lambda: True)
        self._push_upstream_commit()
        with self.assertRaises(UpdateError) as ctx:
            mgr.apply()
        self.assertIn("Not while logging", str(ctx.exception))

    def test_apply_refuses_with_local_changes_rather_than_discarding_them(self):
        self._push_upstream_commit()
        (self.clone / "atem_cut_logger" / "__init__.py").write_text(
            '__version__ = "9.9.9"  # operator edit\n'
        )
        with self.assertRaises(UpdateError) as ctx:
            self.mgr.apply()
        self.assertIn("local changes", str(ctx.exception))
        # The edit survives.
        self.assertIn("9.9.9",
                      (self.clone / "atem_cut_logger" / "__init__.py").read_text())

    def test_zip_install_follows_the_release_channel_instead_of_git(self):
        plain = Path(self.tmp.name) / "zip-install"
        plain.mkdir()
        mgr = UpdateManager(root=plain)
        self.assertFalse(mgr.is_clone())
        status = mgr.status()
        self.assertEqual(status["channel"], "release")
        self.assertTrue(status["supported"])   # the feed needs no login
        self.assertEqual(status["commit"], "")

    def test_clone_uses_the_git_channel(self):
        self.assertEqual(self.mgr.status()["channel"], "git")

    @unittest.skipIf(os.geteuid() == 0, "root bypasses file permissions")
    def test_unwritable_install_is_reported_rather_than_failing_late(self):
        locked = Path(self.tmp.name) / "read-only"
        locked.mkdir(mode=0o500)
        self.addCleanup(locked.chmod, 0o700)
        mgr = UpdateManager(root=locked)
        self.assertFalse(mgr.status()["supported"])
        self.assertIn("isn't writable", mgr.status()["reason"])
        with self.assertRaises(UpdateError):
            mgr.check()

    def test_status_is_cheap_to_call_repeatedly(self):
        first = self.mgr.status()
        self.assertEqual(first["commit"], self.mgr.status()["commit"])
        self.assertTrue(first["commit"])

    def test_change_callback_fires_on_check(self):
        seen = []
        mgr = UpdateManager(root=self.clone, on_change=lambda: seen.append(1))
        mgr.check()
        self.assertTrue(seen)


if __name__ == "__main__":
    unittest.main()
