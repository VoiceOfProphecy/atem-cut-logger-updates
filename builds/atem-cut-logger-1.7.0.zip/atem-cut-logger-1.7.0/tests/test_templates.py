"""Session templates and the New session button.

The rules worth protecting: a template carries the show *setup* and never the
per-show values (start timecode, session name), and New session refuses to bin
unexported cuts unless it is told to.
"""

import tempfile
import unittest
from pathlib import Path

from atem_cut_logger.templates import TemplateError, TemplateStore, slugify
from atem_cut_logger.updates import UpdateManager
from atem_cut_logger.web.controller import Controller, ControllerError


def make_controller(tmp: Path) -> Controller:
    # No autosave path and a non-clone update root: this test touches neither
    # the operator's home directory nor the network.
    return Controller(
        updates=UpdateManager(root=tmp / "not-a-clone"),
        templates=TemplateStore(tmp / "templates"),
    )


class TemplateStoreTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.store = TemplateStore(Path(self.tmp.name) / "templates")
        self.addCleanup(self.tmp.cleanup)

    def test_slugify_makes_a_filename_and_keeps_it_stable(self):
        self.assertEqual(slugify("TVTL 01-08"), "tvtl-01-08")
        self.assertEqual(slugify("  Morning News!!  "), "morning-news")
        self.assertEqual(slugify("///"), "")

    def test_missing_directory_lists_nothing_rather_than_failing(self):
        self.assertEqual(self.store.list(), [])

    def test_save_then_load_round_trips(self):
        self.store.save("Morning News", {"rate_key": "25", "mappings": []})
        data = self.store.load("Morning News")
        self.assertEqual(data["name"], "Morning News")
        self.assertEqual(data["rate_key"], "25")

    def test_names_differing_only_in_case_or_spacing_are_the_same_template(self):
        self.store.save("Morning News", {"rate_key": "25"})
        self.store.save("morning   news", {"rate_key": "30"})
        self.assertEqual(len(self.store.list()), 1)
        self.assertEqual(self.store.load("Morning News")["rate_key"], "30")

    def test_blank_name_is_rejected(self):
        with self.assertRaises(TemplateError):
            self.store.save("   ", {})

    def test_unknown_template_reports_itself(self):
        for call in (lambda: self.store.load("nope"), lambda: self.store.delete("nope")):
            with self.assertRaises(TemplateError):
                call()

    def test_corrupt_file_is_skipped_by_list(self):
        self.store.save("good", {"rate_key": "25"})
        (self.store.dir / "broken.template.json").write_text("{not json")
        self.assertEqual([t["name"] for t in self.store.list()], ["good"])


class ControllerTemplateTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.c = make_controller(Path(self.tmp.name))
        self.addCleanup(self.tmp.cleanup)
        self.addCleanup(self.c.shutdown)

    def _setup_a_show(self):
        self.c.update_settings({
            "rate_key": "30", "drop_frame": False, "resolution": "1280x720",
            "iso_sync": "tc", "audio_file": "/media/program.wav",
            "start_timecode": "10:00:00:00", "session_name": "TVTL 01-08",
        })
        self.c.upsert_mapping(1, "CAM 1 Wide", "/media/cam1.mov")
        self.c.upsert_mapping(2, "CAM 2 Close", "/media/cam2.mov")

    def test_saved_template_carries_the_setup(self):
        self._setup_a_show()
        saved = self.c.save_template("TVTL")
        self.assertEqual(saved["rate_key"], "30")
        self.assertEqual(saved["resolution"], "1280x720")
        self.assertEqual(saved["iso_sync"], "tc")
        self.assertEqual(saved["audio_file"], "/media/program.wav")
        self.assertEqual([m["name"] for m in saved["mappings"]],
                         ["CAM 1 Wide", "CAM 2 Close"])

    def test_template_does_not_carry_per_show_values(self):
        self._setup_a_show()
        saved = self.c.save_template("TVTL")
        self.assertNotIn("start_timecode", saved)
        self.assertNotIn("session_name", saved)

    def test_applying_a_template_restores_setup_but_leaves_the_show_alone(self):
        self._setup_a_show()
        self.c.save_template("TVTL")
        # A different show is set up by hand...
        self.c.update_settings({
            "rate_key": "25", "resolution": "1920x1080", "iso_sync": "start",
            "audio_file": "", "start_timecode": "18:30:00:00",
            "session_name": "Evening",
        })
        self.c.upsert_mapping(1, "Handheld")
        self.c.apply_template("TVTL")

        snap = self.c.snapshot()
        self.assertEqual(snap["settings"]["rate_key"], "30")
        self.assertEqual(snap["settings"]["resolution"], "1280x720")
        self.assertEqual(snap["settings"]["iso_sync"], "tc")
        self.assertEqual([m["name"] for m in snap["mappings"]],
                         ["CAM 1 Wide", "CAM 2 Close"])
        # The show's own values survive the template load.
        self.assertEqual(snap["settings"]["start_timecode"], "18:30:00:00")
        self.assertEqual(snap["settings"]["session_name"], "Evening")

    def test_templates_appear_in_the_snapshot(self):
        self._setup_a_show()
        self.c.save_template("TVTL")
        names = [t["name"] for t in self.c.snapshot()["templates"]]
        self.assertEqual(names, ["TVTL"])

    def test_applying_an_unknown_template_is_a_user_error(self):
        with self.assertRaises(ControllerError):
            self.c.apply_template("nothing here")

    def test_deleting_removes_it_from_the_snapshot(self):
        self.c.save_template("TVTL")
        self.c.delete_template("TVTL")
        self.assertEqual(self.c.snapshot()["templates"], [])

    def test_template_cannot_be_loaded_while_logging(self):
        self.c.save_template("TVTL")
        self.c.connect("simulator")
        self.c.start_logging()
        with self.assertRaises(ControllerError):
            self.c.apply_template("TVTL")


class NewSessionTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.c = make_controller(Path(self.tmp.name))
        self.addCleanup(self.tmp.cleanup)
        self.addCleanup(self.c.shutdown)

    def _log_a_couple_of_cuts(self):
        self.c.upsert_mapping(1, "CAM 1")
        self.c.upsert_mapping(2, "CAM 2")
        self.c.connect("simulator")
        self.c.start_logging()
        self.c.simulate_cut(2)
        self.c.stop_logging()

    def test_new_session_refuses_to_discard_unsaved_events(self):
        self._log_a_couple_of_cuts()
        self.assertTrue(self.c.snapshot()["unsaved"])
        with self.assertRaises(ControllerError) as ctx:
            self.c.new_session()
        self.assertIn("unsaved", str(ctx.exception))
        self.assertTrue(self.c.session.events)  # nothing was thrown away

    def test_forced_new_session_clears_the_log_but_keeps_the_setup(self):
        self._log_a_couple_of_cuts()
        self.c.update_settings({"rate_key": "30", "session_name": "Show A"})
        self.c.new_session(force=True)

        snap = self.c.snapshot()
        self.assertEqual(snap["events"], [])
        self.assertEqual(snap["flags"], [])
        self.assertEqual(snap["notes"], [])
        self.assertFalse(snap["unsaved"])
        self.assertEqual(snap["settings"]["rate_key"], "30")
        # The camera mapping (named by hand, plus the ones Test Mode reported)
        # is production setup, so it carries over to the next show.
        names = [m["name"] for m in snap["mappings"]]
        self.assertIn("CAM 1", names)
        self.assertIn("CAM 2", names)
        # The name belongs to the finished show, not the new one.
        self.assertEqual(snap["settings"]["session_name"], "")

    def test_exporting_the_log_clears_the_unsaved_warning(self):
        self._log_a_couple_of_cuts()
        self.c.mark_saved()
        self.assertFalse(self.c.snapshot()["unsaved"])
        self.c.new_session()  # no force needed once a copy exists
        self.assertEqual(self.c.snapshot()["events"], [])

    def test_new_session_refuses_while_logging(self):
        self.c.connect("simulator")
        self.c.start_logging()
        with self.assertRaises(ControllerError):
            self.c.new_session(force=True)


if __name__ == "__main__":
    unittest.main()
