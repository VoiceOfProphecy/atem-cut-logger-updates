import unittest

from atem_cut_logger.analysis import CleanupConfig, analyze
from atem_cut_logger.session import CameraMapping, LogSession, SwitchEvent
from atem_cut_logger.timecode import frames_to_timecode


def make_session(events, end_frame, rate_key="25", start="00:00:00:00", names=None):
    """events: list of (frame, input_id). 25 fps => 1 s = 25 frames."""
    session = LogSession(rate_key=rate_key, drop_frame=False, start_timecode=start)
    rate = session.rate
    names = names or {}
    used = {iid for _f, iid in events}
    for iid in used:
        session.mappings[iid] = CameraMapping(iid, names.get(iid, f"Camera {iid}"))
    for frame, iid in events:
        tc = frames_to_timecode(session.start_frames + frame, rate, False)
        session.events.append(
            SwitchEvent(
                elapsed=frame * rate.den / rate.num,
                frame=frame,
                timecode=tc,
                input_id=iid,
                camera=session.camera_label(iid),
            )
        )
    session.duration = end_frame * rate.den / rate.num
    return session


def only(name):
    """A config with every rule disabled except the named one(s)."""
    flags = dict(
        enable_min_shot=False,
        enable_max_shot=False,
        enable_accidental=False,
        enable_back_forth=False,
        enable_repeat_same=False,
    )
    for key in ([name] if isinstance(name, str) else name):
        flags[f"enable_{key}"] = True
    return flags


def types_at(result, frame):
    return {i.issue_type for i in result.issues if i.frame == frame}


class ShotDurationRules(unittest.TestCase):
    def test_min_shot_flags_short_but_not_accidental(self):
        # 20-frame cut shot = 0.8 s: below min (1.0 s) but above accidental (0.5 s)
        session = make_session([(0, 1), (100, 2), (120, 1)], end_frame=200)
        cfg = CleanupConfig(**only("min_shot"))
        result = analyze(session, cfg)
        short = [i for i in result.issues if i.issue_type == "short_shot"]
        self.assertEqual(len(short), 1)
        self.assertEqual(short[0].frame, 100)
        self.assertEqual(short[0].camera, "Camera 2")

    def test_max_shot_flags_long_take(self):
        session = make_session([(0, 1), (75, 2)], end_frame=100)  # cam1 = 3 s
        cfg = CleanupConfig(max_shot_seconds=2.0, **only("max_shot"))
        result = analyze(session, cfg)
        long = [i for i in result.issues if i.issue_type == "long_shot"]
        self.assertEqual(len(long), 1)
        self.assertEqual(long[0].frame, 0)

    def test_accidental_cut_flagged_and_is_a_cut_only(self):
        # cam2 shot is 10 frames = 0.4 s (< 0.5 s accidental threshold)
        session = make_session([(0, 1), (100, 2), (110, 1)], end_frame=200)
        cfg = CleanupConfig(**only("accidental"))
        result = analyze(session, cfg)
        acc = [i for i in result.issues if i.issue_type == "accidental_cut"]
        self.assertEqual(len(acc), 1)
        self.assertEqual(acc[0].frame, 100)
        self.assertEqual(acc[0].severity, "error")

    def test_initial_short_program_is_not_accidental(self):
        # first shot short, but it is the initial program (not a cut)
        session = make_session([(0, 1), (5, 2)], end_frame=100)
        cfg = CleanupConfig(**only("accidental"))
        result = analyze(session, cfg)
        self.assertEqual([i for i in result.issues if i.issue_type == "accidental_cut"], [])


class PatternRules(unittest.TestCase):
    def test_rapid_back_and_forth(self):
        # 1 -> 2 -> 1, middle shot 15 frames = 0.6 s (< 2 s)
        session = make_session([(0, 1), (30, 2), (45, 1)], end_frame=200)
        cfg = CleanupConfig(**only("back_forth"))
        result = analyze(session, cfg)
        bf = [i for i in result.issues if i.issue_type == "rapid_back_forth"]
        self.assertEqual(len(bf), 1)
        self.assertEqual(bf[0].frame, 30)

    def test_no_back_forth_when_flanks_differ(self):
        session = make_session([(0, 1), (30, 2), (45, 3)], end_frame=200)
        cfg = CleanupConfig(**only("back_forth"))
        self.assertEqual(analyze(session, cfg).issues, [])

    def test_repeated_camera_within_window(self):
        # cam1 selected at 0,10,20,30 -> 4th selection within 10 s window
        events = [(0, 1), (5, 2), (10, 1), (15, 2), (20, 1), (25, 2), (30, 1)]
        session = make_session(events, end_frame=100)
        cfg = CleanupConfig(repeat_count=4, **only("repeat_same"))
        result = analyze(session, cfg)
        rep = [i for i in result.issues if i.issue_type == "repeated_camera"]
        self.assertEqual(len(rep), 1)
        self.assertEqual(rep[0].frame, 30)


class WideUsageRule(unittest.TestCase):
    def test_wide_overuse(self):
        session = make_session([(0, 1), (80, 2)], end_frame=100)  # cam1 = 80%
        cfg = CleanupConfig(wide_camera_input=1, **only([]))
        result = analyze(session, cfg)
        over = [i for i in result.issues if i.issue_type == "wide_overuse"]
        self.assertEqual(len(over), 1)
        self.assertEqual(over[0].input_id, 1)

    def test_wide_underuse(self):
        session = make_session([(0, 2), (95, 1)], end_frame=100)  # cam1 = 5%
        cfg = CleanupConfig(wide_camera_input=1, **only([]))
        result = analyze(session, cfg)
        self.assertTrue(any(i.issue_type == "wide_underuse" for i in result.issues))

    def test_wide_disabled_without_input(self):
        session = make_session([(0, 1), (80, 2)], end_frame=100)
        cfg = CleanupConfig(**only([]))  # no wide_camera_input
        self.assertEqual(analyze(session, cfg).issues, [])


class Interaction(unittest.TestCase):
    def test_accidental_suppresses_short_shot_at_same_event(self):
        session = make_session([(0, 1), (100, 2), (110, 1)], end_frame=200)
        cfg = CleanupConfig(enable_min_shot=True, enable_accidental=True,
                            enable_max_shot=False, enable_back_forth=False,
                            enable_repeat_same=False)
        result = analyze(session, cfg)
        self.assertIn("accidental_cut", types_at(result, 100))
        self.assertNotIn("short_shot", types_at(result, 100))

    def test_issues_sorted_by_frame(self):
        session = make_session([(0, 1), (100, 2), (110, 1)], end_frame=200)
        result = analyze(session, CleanupConfig(wide_camera_input=1))
        frames = [i.frame for i in result.issues]
        self.assertEqual(frames, sorted(frames))


if __name__ == "__main__":
    unittest.main()


class SoloStretchRuleTest(unittest.TestCase):
    """One camera holding a long run, even though cuts keep happening."""

    def _session(self, pattern, rate_key="25", shot_seconds=10.0):
        s = LogSession(rate_key=rate_key, start_timecode="00:00:00:00")
        s.mappings = {i: CameraMapping(i, f"CAM {i}") for i in (1, 2, 3)}
        s.begin()
        for n, input_id in enumerate(pattern):
            s.add_program_change(input_id, n * shot_seconds)
        s.end(len(pattern) * shot_seconds)
        return s

    def test_a_single_camera_run_is_reported_once(self):
        # CAM 1 for 200 s with brief visits elsewhere, then a mixed section.
        pattern = [1, 2, 1, 2, 1, 2, 1, 2, 1, 2] + [1, 2, 3, 1, 2, 3]
        session = self._session(pattern, shot_seconds=5.0)
        config = CleanupConfig(solo_window_seconds=30.0, solo_fraction=0.5)
        issues = [i for i in analyze(session, config).issues
                  if i.issue_type == "solo_stretch"]
        self.assertTrue(issues, "expected a single-camera stretch to be flagged")
        # Reported per run, not per shot inside the run.
        self.assertLess(len(issues), len(pattern))

    def test_balanced_coverage_is_not_flagged(self):
        session = self._session([1, 2, 3] * 8, shot_seconds=5.0)
        config = CleanupConfig(solo_window_seconds=30.0, solo_fraction=0.9)
        issues = [i for i in analyze(session, config).issues
                  if i.issue_type == "solo_stretch"]
        self.assertEqual(issues, [])

    def test_rule_can_be_switched_off(self):
        session = self._session([1, 2, 1, 2, 1, 2, 1, 2], shot_seconds=5.0)
        config = CleanupConfig(enable_solo_stretch=False,
                               solo_window_seconds=30.0, solo_fraction=0.5)
        issues = [i for i in analyze(session, config).issues
                  if i.issue_type == "solo_stretch"]
        self.assertEqual(issues, [])

    def test_impossible_thresholds_are_rejected(self):
        for kwargs in ({"solo_window_seconds": 0}, {"solo_fraction": 0},
                       {"solo_fraction": 1.5}):
            with self.assertRaises(ValueError):
                CleanupConfig(**kwargs)
