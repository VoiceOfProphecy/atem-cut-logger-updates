"""The version and the changelog must not drift apart.

Every user-visible change bumps ``__version__`` and adds a changelog entry (see
CLAUDE.md); this test is what makes forgetting it loud instead of silent.
"""

import re
import unittest
from pathlib import Path

import atem_cut_logger

CHANGELOG = Path(__file__).resolve().parent.parent / "CHANGELOG.md"


class VersionTest(unittest.TestCase):
    def test_version_is_semver(self):
        self.assertRegex(atem_cut_logger.__version__, r"^\d+\.\d+\.\d+$")

    def test_changelog_leads_with_the_current_version(self):
        headings = re.findall(r"^## (\S+)", CHANGELOG.read_text(), re.MULTILINE)
        self.assertTrue(headings, "CHANGELOG.md has no version headings")
        self.assertEqual(
            headings[0],
            atem_cut_logger.__version__,
            "Top CHANGELOG.md entry must match __version__ — bump both together.",
        )

    def test_changelog_versions_are_in_descending_order(self):
        def key(v):
            return tuple(int(part) for part in v.split("."))

        headings = re.findall(r"^## (\S+)", CHANGELOG.read_text(), re.MULTILINE)
        self.assertEqual(headings, sorted(headings, key=key, reverse=True))


if __name__ == "__main__":
    unittest.main()
