import tempfile
import unittest
from pathlib import Path

from atem_cut_logger.web.controller import ControlDenied, Controller, ControllerError


def logged_controller(autosave=None):
    c = Controller(autosave_path=autosave)
    c.on_connected("Test", {1: "Cam 1", 2: "Cam 2"}, 1)
    c.update_settings({"rate_key": "25", "start_timecode": "00:00:00:00"})
    return c


class Autosave(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "autosave.atemlog.json"

    def tearDown(self):
        self.tmp.cleanup()

    def test_autosaves_while_logging(self):
        c = logged_controller(self.path)
        c.start_logging()
        c.on_program_changed(2, c.start_mono + 3.0)
        self.assertTrue(self.path.is_file())
        # the file contains the events logged so far
        text = self.path.read_text()
        self.assertIn('"input": 2', text)

    def test_recovers_on_restart(self):
        c = logged_controller(self.path)
        c.start_logging()
        c.on_program_changed(2, c.start_mono + 4.0)
        c.stop_logging()
        # simulate a crash: a brand-new controller pointed at the same file
        recovered = Controller(autosave_path=self.path)
        snap = recovered.snapshot()
        self.assertTrue(snap["recovered"])
        self.assertEqual(len(snap["events"]), 2)

    def test_mark_saved_clears_autosave(self):
        c = logged_controller(self.path)
        c.start_logging()
        c.on_program_changed(2, c.start_mono + 2.0)
        c.stop_logging()
        self.assertTrue(self.path.is_file())
        c.mark_saved()
        self.assertFalse(self.path.is_file())
        # a fresh controller now starts clean (no recovery)
        self.assertFalse(Controller(autosave_path=self.path).snapshot()["recovered"])

    def test_disabled_when_no_path(self):
        c = logged_controller(None)
        c.start_logging()
        c.on_program_changed(2, c.start_mono + 1.0)
        # nothing written anywhere; mark_saved is a harmless no-op
        c.mark_saved()


class ControlLock(unittest.TestCase):
    def test_first_claim_locks_others_out(self):
        c = logged_controller()
        c.claim_control("tokenA", "TD Mac")
        c.enforce_control("tokenA")  # holder passes
        with self.assertRaises(ControlDenied):
            c.enforce_control("tokenB")  # someone else blocked

    def test_unclaimed_is_open(self):
        c = logged_controller()
        c.enforce_control(None)  # no holder yet -> allowed
        c.enforce_control("anything")

    def test_force_take_over(self):
        c = logged_controller()
        c.claim_control("tokenA", "TD Mac")
        with self.assertRaises(ControlDenied):
            c.claim_control("tokenB", "Tablet")            # polite claim refused
        c.claim_control("tokenB", "Tablet", force=True)    # take over
        c.enforce_control("tokenB")
        with self.assertRaises(ControlDenied):
            c.enforce_control("tokenA")                    # old holder now locked
        self.assertEqual(c.snapshot()["control_label"], "Tablet")

    def test_release_reopens(self):
        c = logged_controller()
        c.claim_control("tokenA", "TD")
        c.release_control("tokenA")
        self.assertEqual(c.snapshot()["control_label"], "")
        c.enforce_control("tokenB")  # open again

    def test_claim_requires_token(self):
        c = logged_controller()
        with self.assertRaises(ControllerError):
            c.claim_control("", "nobody")


if __name__ == "__main__":
    unittest.main()
