#!/bin/bash
# Removes the background service installed by install.sh. The app will no
# longer start automatically or keep running after you close it.
set -euo pipefail

LABEL="com.atemcutlogger.web"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"

launchctl unload "$PLIST" >/dev/null 2>&1 || true
rm -f "$PLIST"

echo "Removed. ATEM Cut Logger will no longer start automatically or run in"
echo "the background. Use the double-click launcher or the terminal command"
echo "to run it manually from now on."
