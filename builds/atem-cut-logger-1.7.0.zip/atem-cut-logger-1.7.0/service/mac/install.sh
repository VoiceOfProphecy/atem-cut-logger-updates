#!/bin/bash
# Installs ATEM Cut Logger as a background service on this Mac using launchd
# (Apple's standard way to run always-on background processes).
#
# After this runs once:
#   - The web app starts automatically at login.
#   - It keeps running even if every Terminal window is closed.
#   - If it ever crashes, launchd restarts it automatically.
#   - It survives reboots (starts again next time you log in).
#
# Run it with:  bash service/mac/install.sh
set -euo pipefail

APP_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
PYTHON="$(command -v python3 || true)"
LABEL="com.atemcutlogger.web"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"
LOG_DIR="$HOME/Library/Logs/ATEMCutLogger"

if [ -z "$PYTHON" ]; then
    echo "python3 not found. Install Python from python.org first." >&2
    exit 1
fi
if [ ! -d "$APP_DIR/atem_cut_logger" ]; then
    echo "Could not find the atem_cut_logger app next to this script." >&2
    exit 1
fi

mkdir -p "$LOG_DIR" "$HOME/Library/LaunchAgents"

cat > "$PLIST" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key><string>$LABEL</string>
    <key>ProgramArguments</key>
    <array>
        <string>$PYTHON</string>
        <string>-m</string>
        <string>atem_cut_logger.web</string>
        <string>--host</string>
        <string>0.0.0.0</string>
        <string>--no-browser</string>
    </array>
    <key>WorkingDirectory</key><string>$APP_DIR</string>
    <key>RunAtLoad</key><true/>
    <key>KeepAlive</key><true/>
    <key>StandardOutPath</key><string>$LOG_DIR/out.log</string>
    <key>StandardErrorPath</key><string>$LOG_DIR/err.log</string>
</dict>
</plist>
EOF

launchctl unload "$PLIST" >/dev/null 2>&1 || true
launchctl load "$PLIST"

echo ""
echo "  Installed and started ATEM Cut Logger as a background service."
echo "  ------------------------------------------------------------"
echo "  It's now running at:  http://localhost:8760/"
echo "  (bookmark that address in your browser — no more launching by hand)"
echo ""
echo "  It will keep running even if you close every Terminal window, and"
echo "  will start again automatically next time this Mac logs in."
echo ""
echo "  Logs: $LOG_DIR"
echo "  To stop watching it run this way: bash service/mac/uninstall.sh"
echo ""
