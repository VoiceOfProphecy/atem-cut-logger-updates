# Running as a background service (macOS)

For the machine that's always on the production network, install it once as a
background service instead of a Terminal window you have to remember to open:

```sh
bash service/mac/install.sh
```

After that:

- Open **http://localhost:8760/** any time — no need to start anything. Bookmark
  it, or bookmark `http://<this-machine-ip>:8760/` on other devices.
- It starts automatically every time this Mac logs in.
- It keeps running even if you close every Terminal window.
- If it ever crashes, it restarts itself.

## Useful commands

```sh
# Restart it (e.g. after updating the code)
launchctl kickstart -k gui/$(id -u)/com.atemcutlogger.web

# Check whether it's running
launchctl list | grep atemcutlogger

# View recent logs
tail -f ~/Library/Logs/ATEMCutLogger/out.log
tail -f ~/Library/Logs/ATEMCutLogger/err.log

# Remove the service entirely
bash service/mac/uninstall.sh
```

## Updating the code later

The service always runs whatever's in this folder. After pulling/copying in
an update (and rebuilding `bridge/mac` if it changed), just restart:

```sh
launchctl kickstart -k gui/$(id -u)/com.atemcutlogger.web
```

## When to use this vs. the double-click launcher

- **This background service** — the always-on control-room machine. Set it up
  once; forget about it.
- **`Start ATEM Cut Logger (Mac).command`** — a laptop or a machine you only
  run it on occasionally. Double-click, use it, close the window when done.
