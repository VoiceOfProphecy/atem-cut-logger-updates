@echo off
REM Double-click this file to start ATEM Cut Logger's web app.
REM It serves to every browser on your network. The window shows the address
REM to open on other devices (tablets, laptops, other control-room machines).
REM Close the window to stop it.
cd /d "%~dp0"
py -m atem_cut_logger.web --host 0.0.0.0 || python -m atem_cut_logger.web --host 0.0.0.0
pause
