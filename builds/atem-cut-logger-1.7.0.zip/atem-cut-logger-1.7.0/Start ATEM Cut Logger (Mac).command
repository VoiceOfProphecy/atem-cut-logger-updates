#!/bin/bash
# Double-click this file (or the "Start ATEM Cut Logger" icon the installer
# put on your Desktop) to update and start ATEM Cut Logger in one step.
#
# It updates to the latest code, rebuilds the ATEM bridge if it changed,
# then starts the server and opens the app in your browser. Other devices on
# the same network can open the "On the network" address it prints.
#
# Close the window (or press Ctrl+C) to stop it.

cd "$(dirname "$0")" || exit 1

pause_on_error() {
    echo ""
    echo "  Something went wrong (see above)."
    echo "  Press Return to close this window."
    read -r _
    exit 1
}

# --- Python present? -------------------------------------------------------
if ! command -v python3 >/dev/null 2>&1; then
    echo ""
    echo "  Python 3 isn't installed. Opening python.org —"
    echo "  install it, then double-click this again."
    open "https://www.python.org/downloads/" 2>/dev/null
    pause_on_error
fi

# --- Update ----------------------------------------------------------------
if [ -d .git ]; then
    echo "Checking for updates..."
    # Never block on a credential prompt if the remote needs a login.
    if GIT_TERMINAL_PROMPT=0 git pull --ff-only 2>&1; then
        echo "Up to date."
    else
        echo "Could not auto-update (offline, or local changes present)."
        echo "Continuing with the code already on disk."
    fi
    if [ -f bridge/mac/BMDSwitcherAPI.h ]; then
        make -C bridge/mac || echo "Bridge rebuild had an issue — Connect may fail; Test Mode still works."
    fi
else
    echo "This copy can't auto-update (it isn't a git clone)."
    echo "To get auto-updates, re-run the installer — see HOW-TO-RUN.txt."
fi

# --- Show exactly what's about to run --------------------------------------
version="$(python3 -c 'import atem_cut_logger as a; print(a.__version__)' 2>/dev/null)"
commit="$(git rev-parse --short HEAD 2>/dev/null)"
dated="$(git log -1 --format=%cd --date=short 2>/dev/null)"
echo ""
echo "  Version : ${version:-unknown}${commit:+  (build $commit${dated:+, $dated})}"
echo ""

python3 -m atem_cut_logger.web --host 0.0.0.0 || pause_on_error
