#!/bin/bash
# DOUBLE-CLICK ME after unzipping the download.
#
# Installs ATEM Cut Logger to your Home folder as "ATEM Cut Logger" and puts a
# "Start ATEM Cut Logger" icon on your Desktop. Replaces any older install, so
# running this again is how you upgrade to a newer download.
#
# If macOS says it "cannot be opened because it is from an unidentified
# developer": right-click this file, choose Open, then click Open again.

cd "$(dirname "$0")" || exit 1
bash scripts/install-mac.sh
status=$?
echo ""
echo "  Press Return to close this window."
read -r _
exit $status
