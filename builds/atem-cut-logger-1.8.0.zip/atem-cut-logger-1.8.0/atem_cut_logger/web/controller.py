"""The web app's stateful core — everything except HTTP.

A single :class:`Controller` owns the live session, the switcher backend and the
analysis, exactly like the desktop app's window did, but exposes it as plain
data (dicts) plus a broadcast stream of events. The HTTP layer in
:mod:`.server` is a thin translation on top; this class is what the tests
exercise directly.

Thread model: switcher backends call the listener methods from their own
threads. Every state mutation takes ``self._lock`` and then broadcasts a small
event dict to all subscribers (the SSE clients). Timestamps for logged cuts are
captured inside the backend callbacks, never here, so UI latency can't skew cut
times.
"""

from __future__ import annotations

import os
import queue
import threading
import time
from pathlib import Path
from typing import Any

from .. import __version__
from ..backends import create_backend
from ..recorders import (
    RecorderConfig,
    RecorderError,
    RecorderPool,
    RecorderWatcher,
)
from ..session import CameraMapping, LogSession
from ..templates import TemplateError, TemplateStore
from ..updates import UpdateError, UpdateManager
from ..timecode import (
    FRAME_RATES,
    TimecodeError,
    frames_to_timecode,
    seconds_to_frames,
)

RESOLUTIONS = {
    "1920x1080": (1920, 1080),
    "1280x720": (1280, 720),
    "3840x2160": (3840, 2160),
}


def default_autosave_path() -> Path:
    return Path.home() / ".atem_cut_logger" / "autosave.atemlog.json"


# Template fields, and how each maps onto the controller/session. Keeping the
# list in one place is what stops a template from quietly carrying per-show
# values (start timecode, session name) into the next show.
TEMPLATE_FIELDS = ("rate_key", "drop_frame", "resolution", "iso_sync",
                   "auto_timecode", "audio_file", "auto_start_on_record",
                   "fcpxml_transitions")


class ControllerError(Exception):
    """A user-facing error (bad input / illegal state) -> HTTP 400."""


class ControlDenied(ControllerError):
    """Another device holds the control lock -> HTTP 403."""


class Controller:
    def __init__(
        self,
        autosave_path: Path | None = None,
        updates: UpdateManager | None = None,
        templates: TemplateStore | None = None,
    ) -> None:
        self._lock = threading.RLock()
        self.session = LogSession()
        self.backend = None
        self.backend_kind = ""
        self.connected = False
        self.program_input: int | None = None
        self.logging = False
        self.start_mono: float | None = None
        self.status_text = "Not connected."
        self.width, self.height = 1920, 1080
        self.tc_synced = False
        # Write real <transition> elements into FCPXML exports instead of
        # flattening each blend to a cut at its midpoint. Off by default:
        # a plain cut timeline is what most editors expect to receive.
        self.fcpxml_transitions = False
        self.loaded_name = ""
        self.recovered = False
        # When on (default) and the backend supports it, Start Timecode is
        # read live from the switcher's own timecode generator the instant
        # Start Logging is pressed, instead of relying on a typed value.
        # Silently a no-op on backends that don't support it (e.g. Test Mode).
        self.auto_timecode = True

        # Macros the switcher reports, and available to fire from the UI.
        self.macros: list[dict] = []

        # Control lock: which device (token) is currently allowed to drive.
        self.control_token: str | None = None
        self.control_label = ""

        # Recorders (HyperDecks) the operator drives from the UI. The watcher
        # is what starts logging when a deck starts rolling.
        self.recorders = RecorderPool()
        self.auto_start_on_record = False
        self.recorder_watcher = RecorderWatcher(
            self.recorders, self._on_recording_started
        )

        # Saved show setups (frame rate, mapping, ...) for reuse next time.
        self.templates = templates or TemplateStore()

        # True once the log holds work that hasn't been exported to JSON.
        # Drives the warning on "New session".
        self.unsaved = False

        # Crash-safe autosave (disabled unless a path is given).
        self.autosave_path = Path(autosave_path) if autosave_path else None
        self._autosave_lock = threading.Lock()

        # Self-update. Checks run on a timer started by the entry point, never
        # from here, so tests and the desktop app don't touch the network.
        self.updates = updates or UpdateManager(
            on_change=self._broadcast_update,
            is_busy=lambda: self.logging,
        )

        self._subscribers: set[queue.Queue] = set()
        self._sub_lock = threading.Lock()
        self._ticker_stop = threading.Event()
        self._ticker: threading.Thread | None = None

        self._maybe_recover()

    # ------------------------------------------------------------ autosave

    def _maybe_recover(self) -> None:
        """On startup, reload an autosave left behind by a crash."""
        if not self.autosave_path or not self.autosave_path.is_file():
            return
        try:
            session = LogSession.from_json(
                self.autosave_path.read_text(encoding="utf-8")
            )
        except (OSError, ValueError, KeyError):
            return
        if session.events:
            self.session = session
            self.recovered = True
            self.unsaved = True
            self.loaded_name = "recovered session"
            self.status_text = (
                f"Recovered an unsaved session ({len(session.events)} events) "
                "from a previous run. Export it, or Start Logging to begin fresh."
            )

    def _autosave(self) -> None:
        if not self.autosave_path:
            return
        with self._lock:
            if not self.session.events:
                return
            text = self.session.to_json()
        with self._autosave_lock:
            try:
                self.autosave_path.parent.mkdir(parents=True, exist_ok=True)
                tmp = self.autosave_path.with_suffix(".tmp")
                tmp.write_text(text, encoding="utf-8")
                os.replace(tmp, self.autosave_path)  # atomic on POSIX & Windows
            except OSError:
                pass  # never let autosave failure disrupt a live show

    def mark_saved(self) -> None:
        """Called when the user exports the JSON log: clears the crash marker."""
        self.unsaved = False
        if not self.autosave_path:
            return
        with self._autosave_lock:
            try:
                self.autosave_path.unlink(missing_ok=True)
            except OSError:
                pass

    # ------------------------------------------------------------ subscribe

    def subscribe(self) -> queue.Queue:
        q: queue.Queue = queue.Queue()
        with self._sub_lock:
            self._subscribers.add(q)
        return q

    def unsubscribe(self, q: queue.Queue) -> None:
        with self._sub_lock:
            self._subscribers.discard(q)

    def _broadcast(self, kind: str, **data: Any) -> None:
        message = {"type": kind, **data}
        with self._sub_lock:
            subscribers = list(self._subscribers)
        for q in subscribers:
            q.put(message)

    # ------------------------------------------------------------ snapshot

    def snapshot(self) -> dict:
        with self._lock:
            s = self.session
            return {
                "version": __version__,
                "connected": self.connected,
                "logging": self.logging,
                "backend": self.backend_kind,
                "status": self.status_text,
                "program_input": self.program_input,
                "program_camera": (
                    s.camera_label(self.program_input)
                    if self.program_input is not None else None
                ),
                "switcher_product": s.switcher_product,
                "macros": list(self.macros),
                "loaded_name": self.loaded_name,
                "recovered": self.recovered,
                "control_label": self.control_label,
                "settings": {
                    "session_name": s.name,
                    "rate_key": s.rate_key,
                    "drop_frame": s.drop_frame,
                    "start_timecode": s.start_timecode,
                    "resolution": f"{self.width}x{self.height}",
                    "iso_sync": "tc" if self.tc_synced else "start",
                    "fcpxml_transitions": self.fcpxml_transitions,
                    "audio_file": s.audio_file,
                    "auto_timecode": self.auto_timecode,
                    "auto_start_on_record": self.auto_start_on_record,
                },
                "recorders": self.recorders.to_payload(),
                "recorder_status": [
                    s.to_dict() for s in self.recorder_watcher.last
                ],
                "rates": list(FRAME_RATES.keys()),
                "resolutions": list(RESOLUTIONS.keys()),
                "mappings": [
                    {"input_id": m.input_id, "name": m.name, "file": m.file}
                    for m in sorted(s.mappings.values(), key=lambda m: m.input_id)
                ],
                "events": self._events_payload(),
                "flags": self._flags_payload(),
                "notes": self._notes_payload(),
                "clock": self.current_clock(),
                "unsaved": self.unsaved,
                "templates": self._templates_payload(),
                "update": self.updates.status(),
                "can_export": bool(s.events) and not self.logging,
            }

    def _events_payload(self) -> list[dict]:
        return [
            {
                "n": i + 1,
                "elapsed": round(e.elapsed, 3),
                "frame": e.frame,
                "timecode": e.timecode,
                "input": e.input_id,
                "camera": e.camera,
                "transition": e.transition,
                "transition_frames": e.transition_frames,
            }
            for i, e in enumerate(self.session.events)
        ]

    def _flags_payload(self) -> list[dict]:
        return [
            {
                "index": i,
                "elapsed": round(f.elapsed, 3),
                "frame": f.frame,
                "timecode": f.timecode,
                "note": f.note,
            }
            for i, f in enumerate(self.session.flags)
        ]

    def _notes_payload(self) -> list[dict]:
        return [
            {
                "index": i,
                "elapsed": round(n.elapsed, 3),
                "frame": n.frame,
                "timecode": n.timecode,
                "text": n.text,
            }
            for i, n in enumerate(self.session.notes)
        ]

    # ------------------------------------------------------------- updates

    def _broadcast_update(self) -> None:
        self._broadcast("update", update=self.updates.status())

    def check_for_updates(self) -> dict:
        try:
            return self.updates.check()
        except UpdateError as exc:
            raise ControllerError(str(exc)) from exc

    def apply_update(self, restart: bool = True) -> dict:
        """Install a waiting update. Restarts the server so it takes effect."""
        try:
            result = self.updates.apply()
        except UpdateError as exc:
            raise ControllerError(str(exc)) from exc
        result["restarting"] = bool(restart and result.get("updated"))
        if result["restarting"]:
            self.updates.restart()
        return result

    def current_clock(self) -> dict:
        with self._lock:
            if not self.logging or self.start_mono is None:
                # When stopped, show where the log ended (not the start TC).
                stopped_tc = (
                    self.session.end_timecode if self.session.events
                    else self.session.start_timecode
                )
                return {"running": False, "timecode": stopped_tc,
                        "events": len(self.session.events)}
            elapsed = time.monotonic() - self.start_mono
            frame = seconds_to_frames(elapsed, self.session.rate)
            tc = frames_to_timecode(
                self.session.start_frames + frame,
                self.session.rate, self.session.drop_frame,
            )
            return {"running": True, "timecode": tc,
                    "events": len(self.session.events)}

    # ------------------------------------------------------- listener hooks
    # These are called by switcher backends from background threads.

    def on_connected(self, product_name, inputs, program) -> None:
        with self._lock:
            self.connected = True
            self.program_input = program
            self.session.switcher_product = product_name
            for input_id, name in sorted(inputs.items()):
                existing = self.session.mappings.get(input_id)
                if existing is None:
                    self.session.mappings[input_id] = CameraMapping(input_id, name)
                elif not existing.name:
                    existing.name = name
            self.status_text = f"Connected: {product_name}"
        self._broadcast("state", **self.snapshot())

    def on_program_changed(self, input_id, monotonic_time,
                           transition: str = "cut",
                           transition_frames: int = 0) -> None:
        new_event = None
        with self._lock:
            self.program_input = input_id
            if self.logging and self.start_mono is not None:
                new_event = self.session.add_program_change(
                    input_id, max(0.0, monotonic_time - self.start_mono),
                    transition, transition_frames,
                )
        if new_event is not None:
            self._broadcast(
                "event",
                event={
                    "n": len(self.session.events),
                    "elapsed": round(new_event.elapsed, 3),
                    "frame": new_event.frame,
                    "timecode": new_event.timecode,
                    "input": new_event.input_id,
                    "camera": new_event.camera,
                    "transition": new_event.transition,
                    "transition_frames": new_event.transition_frames,
                },
            )
        self._broadcast(
            "program",
            program_input=input_id,
            program_camera=self.session.camera_label(input_id),
            logging=self.logging,
        )
        if new_event is not None:
            self.unsaved = True
            self._autosave()

    def on_macros(self, macros) -> None:
        """The switcher's macro list, delivered once after connecting."""
        with self._lock:
            self.macros = list(macros or [])
        self._broadcast("state", **self.snapshot())

    def on_disconnected(self, reason) -> None:
        was_logging = self.logging
        with self._lock:
            if self.logging:
                self._stop_logging_locked()
            self.connected = False
            self.program_input = None
            self.macros = []
            self.status_text = f"Disconnected: {reason}"
        self._broadcast("state", disconnect_reason=reason,
                        was_logging=was_logging, **self.snapshot())

    def on_error(self, message) -> None:
        with self._lock:
            self.status_text = f"Error: {message}"
        self._broadcast("error", message=message)

    # ----------------------------------------------------------- commands

    def connect(self, mode: str, address: str = "") -> None:
        if mode not in ("atem", "simulator"):
            raise ControllerError("mode must be 'atem' or 'simulator'.")
        if mode == "atem" and not address.strip():
            raise ControllerError("An ATEM IP address is required.")
        with self._lock:
            if self.connected:
                raise ControllerError("Already connected; disconnect first.")
            try:
                self.backend = create_backend(mode, self)
            except (RuntimeError, ImportError) as exc:
                raise ControllerError(str(exc)) from exc
            self.backend_kind = mode
            self.status_text = "Connecting…" if mode == "atem" else "Starting simulator…"
        try:
            self.backend.connect(address.strip())
        except Exception as exc:  # backend-specific failures
            with self._lock:
                self.backend = None
                self.backend_kind = ""
                self.status_text = "Not connected."
            raise ControllerError(f"Could not connect: {exc}") from exc

    def disconnect(self) -> None:
        with self._lock:
            backend = self.backend
        if backend:
            backend.disconnect()
        with self._lock:
            self.backend = None
            self.backend_kind = ""

    def simulate_cut(self, input_id: int) -> None:
        with self._lock:
            backend = self.backend
            kind = self.backend_kind
        if kind != "simulator" or backend is None:
            raise ControllerError("Manual cuts are only available in Test Mode.")
        backend.cut_to(int(input_id))

    def run_macro(self, index: int) -> None:
        """Fire a switcher macro and mark the moment in the log.

        The note is the point: a graphics macro fired at 00:14:32 is exactly
        the kind of thing an editor needs to find later.
        """
        with self._lock:
            backend = self.backend
            names = {m.get("index"): m.get("name", "") for m in self.macros}
        if backend is None:
            raise ControllerError("Not connected to a switcher.")
        try:
            backend.run_macro(int(index))
        except (RuntimeError, ValueError) as exc:
            raise ControllerError(str(exc)) from exc
        label = names.get(int(index)) or f"Macro {index}"
        with self._lock:
            if self.logging and self.start_mono is not None:
                elapsed = max(0.0, time.monotonic() - self.start_mono)
                self.session.add_note(elapsed, f"Macro: {label}")
                self.unsaved = True
        self._broadcast("state", **self.snapshot())

    def update_settings(self, data: dict) -> None:
        with self._lock:
            s = self.session
            # session_name can be set anytime (even while logging)
            if "session_name" in data:
                s.name = str(data["session_name"]).strip()
            if self.logging:
                raise ControllerError("Stop logging before changing other settings.")
            if "rate_key" in data:
                if data["rate_key"] not in FRAME_RATES:
                    raise ControllerError(f"Unknown frame rate {data['rate_key']!r}.")
                s.rate_key = data["rate_key"]
            if "drop_frame" in data:
                s.drop_frame = bool(data["drop_frame"])
            if "start_timecode" in data:
                s.start_timecode = str(data["start_timecode"]).strip()
            if "audio_file" in data:
                s.audio_file = str(data["audio_file"]).strip()
            if "resolution" in data:
                if data["resolution"] not in RESOLUTIONS:
                    raise ControllerError("Unknown resolution.")
                self.width, self.height = RESOLUTIONS[data["resolution"]]
            if "iso_sync" in data:
                self.tc_synced = data["iso_sync"] == "tc"
            if "fcpxml_transitions" in data:
                self.fcpxml_transitions = bool(data["fcpxml_transitions"])
            if "auto_timecode" in data:
                self.auto_timecode = bool(data["auto_timecode"])
            if "auto_start_on_record" in data:
                self.auto_start_on_record = bool(data["auto_start_on_record"])
                self.recorder_watcher.enabled = self.auto_start_on_record
            try:
                s.validate()
            except TimecodeError as exc:
                raise ControllerError(str(exc)) from exc
            # Keep already-logged events' displayed timecodes consistent with
            # a corrected Start Timecode/rate/drop-frame (exports already
            # compute positions live from start_frames; this just makes the
            # log table / JSON / CSV match what actually gets exported).
            s.resync_event_timecodes()
        self._broadcast("state", **self.snapshot())

    def add_flag(self, note: str = "") -> None:
        """One-click "mark this moment as a problem" — deliberately requires
        no typing, so it's fast to hit live. A note can be added/edited
        afterward via set_flag_note()."""
        with self._lock:
            if not self.logging or self.start_mono is None:
                raise ControllerError("Start Logging before marking an issue.")
            elapsed = max(0.0, time.monotonic() - self.start_mono)
            flag = self.session.add_error_flag(elapsed, note)
            self.unsaved = True
        self._broadcast(
            "flag",
            flag={
                "index": len(self.session.flags) - 1,
                "elapsed": round(flag.elapsed, 3),
                "frame": flag.frame,
                "timecode": flag.timecode,
                "note": flag.note,
            },
        )

    def remove_flag(self, index: int) -> None:
        with self._lock:
            try:
                self.session.remove_flag(int(index))
            except IndexError:
                raise ControllerError("That flag no longer exists.") from None
        self._broadcast("state", **self.snapshot())

    def set_flag_note(self, index: int, note: str) -> None:
        with self._lock:
            try:
                self.session.set_flag_note(int(index), str(note))
            except IndexError:
                raise ControllerError("That flag no longer exists.") from None
        self._broadcast("state", **self.snapshot())

    def add_note(self, text: str) -> None:
        """Log an editorial note at the current timecode — graphics cue, broll
        timing, or production notes for later editorial review."""
        with self._lock:
            if not self.logging or self.start_mono is None:
                raise ControllerError("Start Logging before adding a note.")
            elapsed = max(0.0, time.monotonic() - self.start_mono)
            note = self.session.add_note(elapsed, text)
            self.unsaved = True
        self._broadcast(
            "note",
            note={
                "index": len(self.session.notes) - 1,
                "elapsed": round(note.elapsed, 3),
                "frame": note.frame,
                "timecode": note.timecode,
                "text": note.text,
            },
        )

    def upsert_mapping(self, input_id: int, name: str = "", file: str = "") -> None:
        with self._lock:
            input_id = int(input_id)
            mapping = self.session.mappings.get(input_id)
            if mapping is None:
                self.session.mappings[input_id] = CameraMapping(input_id, name, file)
            else:
                mapping.name = name
                mapping.file = file
            # Keep already-logged events' labels in sync with the mapping.
            label = self.session.mappings[input_id].label()
            for e in self.session.events:
                if e.input_id == input_id:
                    e.camera = label
        self._broadcast("state", **self.snapshot())

    def add_input(self) -> int:
        with self._lock:
            next_id = max(self.session.mappings, default=0) + 1
            self.session.mappings[next_id] = CameraMapping(next_id, f"Camera {next_id}")
        self._broadcast("state", **self.snapshot())
        return next_id

    def start_logging(self) -> None:
        with self._lock:
            if self.logging:
                raise ControllerError("Already logging.")
            if self.program_input is None:
                raise ControllerError("Not connected to a switcher.")
            backend, auto = self.backend, self.auto_timecode

        # Ask the switcher for its own timecode right now, outside the lock —
        # this can block up to a second and must never stall other requests
        # (e.g. the SSE state stream) while it waits. A backend that doesn't
        # support it (Test Mode) simply returns None and nothing changes.
        tc = None
        if auto and backend is not None:
            try:
                tc = backend.get_current_timecode()
            except Exception:
                tc = None

        with self._lock:
            if self.logging:  # re-check: another call may have won the race
                raise ControllerError("Already logging.")
            if tc:
                self.session.start_timecode, self.session.drop_frame = tc
            try:
                self.session.validate()
            except TimecodeError as exc:
                raise ControllerError(str(exc)) from exc
            self.session.begin()
            self.recovered = False
            self.start_mono = time.monotonic()
            self.logging = True
            self.status_text = "Logging…"
            self.session.add_program_change(self.program_input, 0.0)
            self.unsaved = True
            self._start_ticker()
        self._broadcast("state", **self.snapshot())

    def stop_logging(self) -> None:
        with self._lock:
            if not self.logging:
                raise ControllerError("Not currently logging.")
            self._stop_logging_locked()
        self._autosave()
        self._broadcast("state", **self.snapshot())

    def _stop_logging_locked(self) -> None:
        if self.start_mono is not None:
            self.session.end(time.monotonic() - self.start_mono)
        self.logging = False
        self.start_mono = None
        self.status_text = "Stopped."
        self._ticker_stop.set()

    def _start_ticker(self) -> None:
        self._ticker_stop.clear()

        def run():
            ticks = 0
            while not self._ticker_stop.wait(0.5):
                self._broadcast("clock", **self.current_clock())
                ticks += 1
                if ticks % 10 == 0:   # ~every 5 s, a backup autosave
                    self._autosave()

        self._ticker = threading.Thread(target=run, name="web-clock", daemon=True)
        self._ticker.start()

    # --------------------------------------------------------- recorders

    def _on_recording_started(self) -> None:
        """A deck started rolling: begin logging, if we can and should."""
        with self._lock:
            if self.logging or not self.connected or not self.auto_start_on_record:
                return
        try:
            self.start_logging()
            with self._lock:
                self.status_text = "Logging — started with the recorders."
        except ControllerError:
            return  # not connected, bad timecode: the UI already shows why
        self._broadcast("state", **self.snapshot())

    def set_recorders(self, items: list) -> list[dict]:
        try:
            self.recorders.set_configs(list(items or []))
        except RecorderError as exc:
            raise ControllerError(str(exc)) from exc
        if self.recorders.configs:
            self.recorder_watcher.start()
        self._broadcast("state", **self.snapshot())
        return self.recorders.to_payload()

    def recorder_status(self) -> list[dict]:
        statuses = self.recorder_watcher.poll_once()
        self._broadcast("state", **self.snapshot())
        return [s.to_dict() for s in statuses]

    def record_all(self) -> list[dict]:
        """Roll every configured deck, naming the clip after the session."""
        if not self.recorders.configs:
            raise ControllerError("No recorders are configured.")
        clip = self.session.export_basename() if self.session.name else ""
        statuses = self.recorders.record_all(clip)
        self.recorder_watcher.last = statuses
        if self.auto_start_on_record and any(s.recording for s in statuses):
            self._on_recording_started()
        self._broadcast("state", **self.snapshot())
        return [s.to_dict() for s in statuses]

    def stop_recorders(self) -> list[dict]:
        if not self.recorders.configs:
            raise ControllerError("No recorders are configured.")
        statuses = self.recorders.stop_all()
        self.recorder_watcher.last = statuses
        self._broadcast("state", **self.snapshot())
        return [s.to_dict() for s in statuses]

    # --------------------------------------------------------- templates

    def _templates_payload(self) -> list[dict]:
        try:
            return self.templates.list()
        except OSError:
            return []

    def template_payload(self) -> dict:
        """The current setup, in template form (no per-show values)."""
        with self._lock:
            s = self.session
            return {
                "rate_key": s.rate_key,
                "drop_frame": s.drop_frame,
                "resolution": f"{self.width}x{self.height}",
                "iso_sync": "tc" if self.tc_synced else "start",
                "fcpxml_transitions": self.fcpxml_transitions,
                "auto_timecode": self.auto_timecode,
                "audio_file": s.audio_file,
                "auto_start_on_record": self.auto_start_on_record,
                "recorders": self.recorders.to_payload(),
                "mappings": [
                    {"input_id": m.input_id, "name": m.name, "file": m.file}
                    for m in sorted(s.mappings.values(), key=lambda m: m.input_id)
                ],
            }

    def save_template(self, name: str) -> dict:
        try:
            saved = self.templates.save(name, self.template_payload())
        except TemplateError as exc:
            raise ControllerError(str(exc)) from exc
        self._broadcast("state", **self.snapshot())
        return saved

    def apply_template(self, name: str) -> None:
        """Load a saved setup over the current one. Never touches the log."""
        try:
            data = self.templates.load(name)
        except TemplateError as exc:
            raise ControllerError(str(exc)) from exc
        with self._lock:
            if self.logging:
                raise ControllerError("Stop logging before loading a template.")
        settings = {k: data[k] for k in TEMPLATE_FIELDS if k in data}
        self.update_settings(settings)   # validates, then broadcasts
        if isinstance(data.get("recorders"), list):
            self.set_recorders(data["recorders"])
        mappings = data.get("mappings") or []
        with self._lock:
            if mappings:
                self.session.mappings = {
                    int(m["input_id"]): CameraMapping(
                        int(m["input_id"]), m.get("name", ""), m.get("file", "")
                    )
                    for m in mappings if "input_id" in m
                }
                for e in self.session.events:
                    e.camera = self.session.camera_label(e.input_id)
            self.status_text = f"Loaded template '{data.get('name', name)}'."
        self._broadcast("state", **self.snapshot())

    def delete_template(self, name: str) -> None:
        try:
            self.templates.delete(name)
        except TemplateError as exc:
            raise ControllerError(str(exc)) from exc
        self._broadcast("state", **self.snapshot())

    # ------------------------------------------------------- new session

    def new_session(self, force: bool = False, keep_settings: bool = True) -> None:
        """Clear the log for the next show, keeping the production setup.

        Refuses when the current log holds unexported work unless ``force`` is
        passed — the UI turns that refusal into a confirmation dialog, so a
        show's cuts can't be thrown away by a mis-click.
        """
        with self._lock:
            if self.logging:
                raise ControllerError("Stop logging before starting a new session.")
            if self.unsaved and self.session.events and not force:
                raise ControllerError(
                    f"This session has {len(self.session.events)} unsaved events. "
                    "Export the log first, or confirm to discard it."
                )
            old = self.session
            fresh = LogSession()
            if keep_settings:
                fresh.rate_key = old.rate_key
                fresh.drop_frame = old.drop_frame
                fresh.start_timecode = old.start_timecode
                fresh.audio_file = old.audio_file
                fresh.switcher_product = old.switcher_product
                fresh.mappings = {
                    i: CameraMapping(m.input_id, m.name, m.file)
                    for i, m in old.mappings.items()
                }
            self.session = fresh
            self.loaded_name = ""
            self.recovered = False
            self.unsaved = False
            self.status_text = ("Connected: " + fresh.switcher_product
                                if self.connected and fresh.switcher_product
                                else "New session ready.")
        self.mark_saved()  # drop the autosave: the old log is deliberately gone
        self._broadcast("state", **self.snapshot())

    # ------------------------------------------------------- session load

    def load_session_json(self, text: str, name: str = "") -> None:
        with self._lock:
            if self.logging:
                raise ControllerError("Stop logging before loading a log.")
            try:
                self.session = LogSession.from_json(text)
            except (ValueError, KeyError) as exc:
                raise ControllerError(f"Could not load log: {exc}") from exc
            self.loaded_name = name or "loaded log"
            self.unsaved = False   # it came from a file, so a copy exists
            self.status_text = f"Loaded {self.loaded_name} ({len(self.session.events)} events)."
        self._broadcast("state", **self.snapshot())

    # ---------------------------------------------------------- control lock

    def claim_control(self, token: str, label: str, force: bool = False) -> None:
        """Take the driver's seat. Fails if someone else holds it (unless force)."""
        if not token:
            raise ControllerError("A control token is required.")
        with self._lock:
            if self.control_token is None or force or token == self.control_token:
                self.control_token = token
                self.control_label = label or "A device"
            else:
                raise ControlDenied(
                    f"{self.control_label} is currently driving. "
                    "Use 'Take control' to take over."
                )
        self._broadcast("control", control_label=self.control_label)

    def release_control(self, token: str) -> None:
        with self._lock:
            if token and token == self.control_token:
                self.control_token = None
                self.control_label = ""
        self._broadcast("control", control_label=self.control_label)

    def enforce_control(self, token: str | None) -> None:
        """Guard mutating actions. While unclaimed, anyone may act (and the
        first claim locks it). Once claimed, only the holder's token passes."""
        with self._lock:
            if self.control_token is None:
                return
            if token != self.control_token:
                raise ControlDenied(
                    f"{self.control_label} is currently driving. "
                    "Use 'Take control' to make changes."
                )

    # --------------------------------------------------------- shutdown

    def shutdown(self) -> None:
        self._ticker_stop.set()
        self.updates.stop()
        self.recorder_watcher.stop()
        try:
            self.disconnect()
        except Exception:
            pass
