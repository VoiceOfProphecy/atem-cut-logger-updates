# Web app

A local, browser-based version of ATEM Cut Logger. A small service runs on a
machine on your production network and serves a modern UI; the service holds all
the hardware and analysis logic, so **nothing is lost versus the desktop app** —
only the *browser* is sandboxed, not the service behind it. You can reach it from
the same machine or, if you choose, from a laptop or tablet elsewhere on the
network.

It has **zero third-party dependencies** — pure Python standard library on the
backend, vanilla HTML/CSS/JS on the front end (no npm, no build step).

![Web app](web-app.png)
![Smart Cleanup in the web app](web-cleanup.png)
![Mark Error flags a moment for later review](mark-error.png)

## Updating

The header shows the running version; clicking it checks for a new one. The app
also checks by itself every 6 hours (`--update-check-hours N`, or `0` to switch
the automatic check off). When something is waiting, a banner offers **Update &
restart**: it fast-forwards the install, rebuilds the ATEM bridge if the SDK
files are there, and relaunches the server with the same options.

It refuses to update while logging, and refuses to fast-forward over local
edits rather than discarding them.

There are two update channels, chosen automatically:

* **git** — the install is a clone, so it fast-forwards from its own remote.
  Needs whatever credentials that remote wants.
* **release** — any other install follows the public feed
  (`VoiceOfProphecy/atem-cut-logger-updates`), which needs no GitHub login on the
  machine at all. The download is checked against the SHA-256 in the manifest
  and the build has to declare the version the feed promised before it replaces
  anything; the licensed SDK files and the compiled bridge are kept.

Publishing a release is `python3 scripts/publish_release.py --feed <checkout of
the feed repo>`, then committing and pushing that checkout. Version and release
notes come from `atem_cut_logger/__init__.py` and `CHANGELOG.md`, so the feed
can't disagree with what the app reports.

## Recorders

HyperDecks (and anything else speaking Blackmagic's TCP protocol on port 9993)
can be listed in the **Recorders** card by name and IP. **Record all** rolls
them together, naming the clip after the session, and **Stop all** stops them.
Each deck is contacted on its own thread, so one dead recorder reports its own
error instead of holding up the rest.

With **Start logging when recording starts** ticked, the app polls the decks
every few seconds and begins logging as soon as any of them rolls — including
when someone presses record on the deck itself. The log's start timecode still
comes from the switcher's own generator, so the few seconds of polling latency
don't affect the exported timeline. Recorders are part of a session template.

## Running it

**Easiest on macOS — run the installer once**, then double-click the Desktop
icon it creates:

* Double-click `Install ATEM Cut Logger (Mac).command` in the downloaded folder.
  It replaces any older install with this copy, puts the app in
  `~/ATEM Cut Logger`, builds a real `~/Applications/ATEM Cut Logger.app`
  (icon from `assets/AppIcon.icns`; the bundle just opens the launcher in
  Terminal), and puts an alias to it on the Desktop — drag that to the Dock.
  Re-running the installer from a fresh download is how you upgrade, or clone
  the repo instead and it self-updates on every launch. See
  [`HOW-TO-RUN.txt`](../HOW-TO-RUN.txt).

**Or double-click a launcher directly** (in the project folder):

* **Windows:** `Start ATEM Cut Logger (Windows).bat`
* **macOS:** `Start ATEM Cut Logger (Mac).command` — updates the copy first if
  it's a git clone, prints the version it's running, then starts the app.

These start the app so it's reachable from **any browser on the network**. The
window that opens prints two addresses:

```
  On this computer :  http://localhost:8760/
  On the network   :  http://192.168.1.42:8760/   <- open THIS on a tablet/laptop
```

Open the network address in any browser on the same network. Close the window to
stop it.

**For the machine that's always on the network** (a control room box, not a
laptop), install it as a background service instead — starts at login, keeps
running even if every Terminal window is closed, restarts itself if it ever
crashes. One-time setup: see [`service/mac/README.md`](../service/mac/README.md).

**Or from a terminal:**

```sh
python -m atem_cut_logger.web                 # this computer only
python -m atem_cut_logger.web --host 0.0.0.0  # reachable from other devices
```

Options:

```sh
python -m atem_cut_logger.web --port 9000        # different port
python -m atem_cut_logger.web --no-browser       # don't auto-open a browser
python -m atem_cut_logger.web --host 0.0.0.0     # reachable from other devices
```

With `--host 0.0.0.0`, open `http://<this-machine-ip>:8760/` from a tablet or
laptop on the same network — handy for driving it from the desk during a show.
Bind to `0.0.0.0` only on a network you trust; there is no authentication, and
the server is hardened against DNS-rebinding and path traversal but assumes a
trusted LAN. See [`SECURITY.md`](SECURITY.md) for the full threat model and
deployment recommendations.

Connecting to real ATEM hardware still needs the per-platform SDK setup from the
main [README](../README.md) (Windows: `pip install comtypes` + ATEM Software
Control; macOS: build `bridge/mac`). **Test Mode** and every export work with no
hardware.

## What it does

Everything the desktop app does, in the browser:

- Connect to an ATEM by IP, or **Test Mode** (simulator, with manual cut buttons)
- Live **Program tally** and running timecode, pushed over Server-Sent Events
- Session settings (frame rate, drop-frame, start timecode, resolution, ISO sync
  model, program-audio file) — locked while logging
- **Export dissolves as real transitions**: off by default, in which case a
  logged blend becomes a cut in the middle of it. On, the FCPXML timeline gets a
  cross dissolve of the length the switcher used. The EDL carries true dissolves
  either way.
- **Auto timecode**: on by default, grabs the switcher's own timecode the
  instant you click Start Logging, instead of you typing it (still falls back
  to the typed value in Test Mode, or if you turn the toggle off)
- Camera-to-input mapping with ISO file paths (edits apply as you type)
- Start/Stop logging with a live event list
- **Mark Error**: one-click button next to the running clock to flag a problem
  moment while it happens (dead feed, wrong camera, audio dropout, …) — no
  typing required in the moment; add a note afterward in the Log section.
  Flags export as Resolve markers ("Flagged Moments (FCPXML)"), independent of
  Smart Cleanup, so editors can jump straight to the moments that need review.
- Exports: JSON log, CSV, Resolve FCPXML timeline
- **Smart Cleanup**: configure rules, review flagged issues, and export the
  report, Resolve markers, and cleaned timeline (see
  [`SMART_CLEANUP.md`](SMART_CLEANUP.md))
- **Open log**: load a saved `.atemlog.json` to regenerate exports later

Light and dark themes are built in (toggle top-right, remembered per browser).

### Who's driving (control lock)

Only one device controls a session at a time, so a second browser can't
override the TD mid-show. The first device to open the app (or make a change)
becomes the driver; other devices are **view-only** — they still see the live
tally, timecode, and event list, but their controls are disabled and the header
shows "🔒 <device> is driving" with a **Take control** button. Clicking it hands
control to that device (and the previous driver flips to view-only instantly).
Exports and Smart Cleanup are read-only, so any viewer can still pull a report.

![View-only device](web-viewonly.png)

### Crash recovery

While logging, the session is continuously autosaved. If the machine loses power
or the app is closed unexpectedly, the next launch **recovers the unsaved
session** and shows a banner offering to save it (or start fresh). Exporting the
JSON log clears the recovery marker. The autosave lives in
`~/.atem_cut_logger/autosave.atemlog.json`.

## Theming / branding

The look is driven entirely by CSS custom properties at the top of
`atem_cut_logger/web/static/styles.css` (`--brand`, `--accent`, `--radius`, the
font, and the neutral palette). To rebrand — e.g. house colors and a logo —
add a small `theme.css` that overrides those variables and load it after the
main stylesheet (there's a commented `<link>` placeholder in `index.html`). No
other markup or CSS needs to change, so the neutral default and a branded build
come from the same codebase.

## How it's built

| File | Role |
| --- | --- |
| `web/controller.py` | thread-safe state + engine glue (session, backends, analysis); broadcasts events |
| `web/server.py` | stdlib `ThreadingHTTPServer`: JSON API, SSE stream, file downloads, static files |
| `web/__main__.py` | `python -m atem_cut_logger.web` entry point |
| `web/static/` | `index.html`, `styles.css` (design system + theme hooks), `app.js` |

The controller is fully unit-tested without HTTP; the server has HTTP-level
integration tests; and the UI itself is exercised end-to-end in a headless
browser. The engine modules (`session`, `timecode`, `fcpxml`, `analysis`,
`backends`) are shared verbatim with the desktop app and CLI.
